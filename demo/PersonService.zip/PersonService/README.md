# Person Service 1.0

A Java Stack 4 starter project. (Replace with your own description and documentation.)

Where to go from here?

* See [Integration Point]:https://ip.app.lds.org/docs

## Static code analysis

This project has been configured with static code analysis around code formatting and known practices to avoid.  Each is handled by
Maven and can be run by invoking the appropriate goal(s).

### Formatting

The formatting plugin allows for a check to be performed on the Java and Javascript code included in the project source tree.  This
allows the avoidance of merge conflicts due to formatting issues.

The check is performed using an embedded invocation of the same formatter library used in Eclipse.  The configuration file that
defines the way that the sources should be formatted is an export from Eclipse.

In this case, the Java formatting configuration is an export of the **Stack Standard** profile.  The Javascript formatting
configuration file is exported from the built-in Javascript formatting configuration that ships with all versions of Eclipse, as the
LDS Tech IDE does not provide any additional configuration beyond it for Javascript.

Version 2.2.1 of the LDS Tech IDE was used as the source for the Java formatting rules.

#### Validating correct formatting

To validate correctness of source formatting, run the Maven goal, as follows from the root directory of the project:

	mvn formatter:validate

The plugin will then list any files that do not match expected formatting.  No source files are altered when running the
**validate** goal.

#### Batch formatting Java and Javascript sources

To automatically format the source files in the project source tree to match the configured format, run the Maven goal, as follows
from the root directory of the project:

	mvn formatter:format

As with any tool that alters source code, it is import to review any and all sources files that are changed to ensure that they
match your expectation and intent before you commit them to SCM.

### PMD and FindBugs checks

PMD and FindBugs provides an automated means to evaluate your source code for potential issues that would impede the quality or
correctness of the code with respect to the intent of the developer.

As with any tool that provides quality metrics, it can and should have its rule inclusion revisited from time to time.

To generate a report of the findings of both PMD and FindBugs, generate a Maven site using the following goal:

	mvn package site

The package goal is required due to FindBugs analyzing compiled class files.

## Regression Testing

Automated tests are broken out into three types:

* Unit - Testing isolated to a single unit without dependencies on external objects or systems
* Integration - Tests that include more than a single unit and do not preclude the use of external resources such as a database to prove that the pieces fit together
* Regression - Automated tests that match the steps outlined in formal written test cases as defined by QA

The typical use-case for running regression is:

	mvn -DskipRegression=false -DskipRegressionApp=false -DskipTests -DskipITs verify

To allow the regression to be run early and often, it is integrated into the Maven build, but disabled by default.  To enable the
regression suite to run, set the user properties **skipRegression** and **skipRegressionApp** to **false**.  This will cause a
detached instance of the application to be started and the regression tests to be executed against it.  In cases where the
regression suite needs to be run against an instance other than the one that is started for convenience, such as one deployed in a
test environment.

To override these behaviors properties of the Maven build may be used:

| Argument | Description | Default value |
| --------|---------|---------|
| skipRegression  | Skips regression suite | true   |
| skipRegressionApp | Skips regression suite local app instance from starting | true   |
| prsms.baseUri  | Base URI where the application is running | Value from /regression.properties |
| prsms.username  | Username to use when calling the application web service | Value from /regression.properties |
| prsms.password  | Password to use when calling the application web service | Value from /regression.properties |

Default values may be controlled more permanently via the regression.properties file located in /src/test/resources.
