package lds.personservice.validation.constraint;

import lds.personservice.util.validation.constraint.GenderValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class GenderValidatorTest {

    private GenderValidator validator;

    @Mock
    private ConstraintValidatorContext context;

    @Before
    public void testBefore(){
        validator = new GenderValidator();
    }

    @Test
    public void isValid_returns_true_with_null(){
        assertTrue(validator.isValid(null, context));
    }

    @Test
    public void isValid_returns_true_with_empty_string(){
        assertTrue(validator.isValid("", context));
    }

    @Test
    public void isValid_returns_false_with_invalid_string(){
        assertFalse(validator.isValid("b", context));
    }

    @Test
    public void isValid_case_insenstive(){
        assertFalse(validator.isValid("m", context));
    }

    @Test
    public void isValid_returns_true_with_M(){
        assertTrue(validator.isValid("M", context));
    }

    @Test
    public void isValid_returns_true_with_F(){
        assertTrue(validator.isValid("F", context));
    }
}
