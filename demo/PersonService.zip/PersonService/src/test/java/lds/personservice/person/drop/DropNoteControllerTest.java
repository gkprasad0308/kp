package lds.personservice.person.drop;

import lds.personservice.person.PersonController;
import lds.personservice.person.PersonService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class DropNoteControllerTest {

    @InjectMocks
    private DropNoteController controller;

    @Mock
    private PersonService service;

    @Mock
    private PersonController personController;

    @Test
    public void dropPersonCallsExpected(){
        WritableDropNote note = mock(WritableDropNote.class);
        controller.dropPerson(note, "abc");
        verify(service, times(1)).dropPerson("abc", note);
        verify(personController, times(1)).getPersonById("abc");
    }

    @Test
    public void undoDropPersonCallsExpected(){
        controller.undoDropPerson("abc");
        verify(service, times(1)).undoDrop("abc");
        verify(personController, times(1)).getPersonById("abc");
    }

    @Test
    public void resetDropCallsExpected(){
        long stamp = System.currentTimeMillis();
        Date date = new Date(stamp);
        controller.resetDrop(stamp, "abc");
        verify(service, times(1)).resetDrop("abc", date);
        verify(personController, times(1)).getPersonById("abc");
    }
}
