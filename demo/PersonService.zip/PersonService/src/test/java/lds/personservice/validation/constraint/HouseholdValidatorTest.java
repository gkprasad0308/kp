package lds.personservice.validation.constraint;

import lds.personservice.util.validation.constraint.HouseholdIdValidator;
import lds.personservice.util.validation.service.HouseholdValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class HouseholdValidatorTest {

    @InjectMocks
    private HouseholdIdValidator validator;

    @Mock
    private HouseholdValidationService householdService;

    @Mock
    private ConstraintValidatorContext context;

    @Test
    public void isValid_returns_true_with_empty_string(){
        assertTrue(validator.isValid("", context));
    }

    @Test
    public void isValid_returns_true_with_null(){
        assertTrue(validator.isValid(null, context));
    }

    @Test
    public void isValid_returns_true_when_service_returns_true(){
        when(householdService.householdExists("a")).thenReturn(true);
        assertTrue(validator.isValid("a", context));
        verify(householdService, times(1)).householdExists("a");
    }

    @Test
    public void isValid_returns_false_when_service_returns_false(){
        when(householdService.householdExists("a")).thenReturn(false);
        assertFalse(validator.isValid("a", context));
        verify(householdService, times(1)).householdExists("a");
    }

}
