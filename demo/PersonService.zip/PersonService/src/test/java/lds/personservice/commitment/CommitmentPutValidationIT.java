package lds.personservice.commitment;

import lds.personservice.AbstractValidationTestRunnerIT;
import lds.personservice.Main;
import lds.personservice.client.ResourceTemplate;
import lds.prsms.utils.UUIDGenerator;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.HttpMethod;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import javax.inject.Inject;
import javax.inject.Provider;

@ActiveProfiles({"local"})
@IntegrationTest({"browser.startup=false", "server.port=0"})
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class CommitmentPutValidationIT extends AbstractValidationTestRunnerIT<Commitment>{

    @Inject
    private Provider<CommitmentTemplate> templateProvider;

    @Override
    protected ResourceTemplate getTemplate() {
        return templateProvider.get();
    }

    @Override
    protected HttpMethod getHttpMethod() {
        return HttpMethod.PUT;
    }

    @Override
    protected String getModelName(Commitment commitment){
        return "commitmentEntity";
    }

    @Test
    public void updateCommitmentIsInvalidWithoutGuid(){
        Commitment commitment = createCommitment();
        commitment.setClientGuid(null);
        runFieldErrorInclusiveTest(commitment, getTemplate().getResourceUriAsString() + "/abc", "clientGuid", MISSING);
    }

    @Test
    public void updateCommitmentIsInvalidWithoutInvitationDate(){
        Commitment commitment = createCommitment();
        commitment.setInviteDate(null);
        runFieldErrorInclusiveTest(commitment, getPutUrl(commitment), "inviteDate", MISSING);
    }

    @Test
    public void updateCommitmentIsInvalidWithInvalidGuid(){
        Commitment commitment = createCommitment();
        commitment.setClientGuid("abc");
        runFieldErrorInclusiveTest(commitment, getPutUrl(commitment), "clientGuid", BAD);
    }

    @Test
    public void updateCommitmentIsInvalidWithInvalidPersonGuid(){
        Commitment commitment = createCommitment();
        commitment.setPersonGuid("-123");
        runFieldErrorInclusiveTest(commitment, getPutUrl(commitment), "personGuid", OUTOFBOUNDS);
    }

    private Commitment createCommitment() {
        Commitment commitment = new Commitment();
        commitment.setClientGuid(UUIDGenerator.getInstance().getAsString());
        return commitment;
    }

    private String getPutUrl(Commitment commitment) {
        return getTemplate().getResourceUriAsString() + "/" + commitment.getClientGuid();
    }
}
