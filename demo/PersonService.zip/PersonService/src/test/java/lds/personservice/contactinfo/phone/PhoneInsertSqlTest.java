package lds.personservice.contactinfo.phone;

import lds.personservice.AbstractUpdateSqlTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class PhoneInsertSqlTest extends AbstractUpdateSqlTest{
    @InjectMocks
    private PhoneInsertSql insertSql;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            PhoneInsertSql.COMM_TYPE_ID,
            PhoneInsertSql.PHN_NUMBER,
            PhoneInsertSql.PERSON_ID
    );

    @Override
    protected SqlUpdate getInstance() {
        return insertSql;
    }

    @Override
    protected List<String> getExpectedParams() {
        return expectedParams;
    }

    @Test
    public void getParamsUsingDoesExpected(){
        Phone phone = mock(Phone.class);
        when(phone.getType()).thenReturn(PhoneTypes.PHN_MOBILE);
        when(phone.getNumber()).thenReturn("1234");

        Map<String, Object> results = insertSql.getParamsUsing(123L, phone);
        checkKeys(results);

        assertEquals(123L, results.get(PhoneInsertSql.PERSON_ID));
        assertEquals(PhoneTypes.PHN_MOBILE.id(), results.get(PhoneInsertSql.COMM_TYPE_ID));
        assertEquals("1234", results.get(PhoneInsertSql.PHN_NUMBER));

        verify(phone, times(1)).getType();
        verify(phone, times(1)).getNumber();
    }
}
