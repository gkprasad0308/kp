package lds.personservice.contactinfo.phone;

import com.fasterxml.jackson.core.JsonParser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PhoneDeserializerTest {

    @Mock
    private JsonParser jsonParser;

    private PhoneDeserializer deserializer;

    @Before
    public void setup(){
        deserializer = new PhoneDeserializer();
    }

    @Test(expected = IllegalArgumentException.class)
    public void deserializeThrowsExcpectedException() throws IOException {
        when(jsonParser.getValueAsString()).thenReturn("red");
        deserializer.deserialize(jsonParser, null);
    }

    @Test
    public void deserializeReturnsExpectedValue() throws IOException {
        when(jsonParser.getValueAsString()).thenReturn(PhoneTypes.PHN_HOME.name().toLowerCase());
        PhoneTypes type = deserializer.deserialize(jsonParser, null);
        assertEquals(PhoneTypes.PHN_HOME, type);
    }
}
