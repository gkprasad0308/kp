package lds.personservice.commitment;

import java.net.URI;

import lds.personservice.client.ResourceTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class CommitmentTemplate extends ResourceTemplate<CommitmentTemplate> {

    @Value("http://localhost:${local.server.port}${lds.api.resources.commitments.href}")
    private URI resourceUri;

    public URI getResourceUri() {
        return resourceUri;
    }

    public String getResourceUriAsString(){
        return getResourceUri().toString();
    }

	public Commitment createCommitment(Commitment commitment) {
		HttpEntity<Commitment> request = new HttpEntity<>(commitment, constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE));
        return sendRequest(resourceUri.toString(), HttpMethod.POST, request, Commitment.class).getBody();
    }

    @SuppressWarnings("unchecked")
    public Commitment deleteCommitment(String commitmentId) {
        HttpEntity<Commitment> request = new HttpEntity<>((Commitment) null, constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE));
        return sendRequest(resourceUri.toString() + "/" + commitmentId, HttpMethod.DELETE, request, Commitment.class).getBody();
    }

    private String constructCommitmentUrl(Commitment commitment) {
        return resourceUri.toString() + "/" + commitment.getClientGuid();
    }

    public Commitment updateCommitment(Commitment commitment) {
        HttpEntity<Commitment> request = new HttpEntity<>(commitment, constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE));
        return sendRequest(constructCommitmentUrl(commitment), HttpMethod.PUT, request, Commitment.class).getBody();
    }
}
