package lds.personservice.household;


import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ListParamsTest {

    private ListParams params;

    @Before
    public void setup(){
        params = new ListParams();
    }

    @Test
    public void setModDateSetsTimeFromLong(){
        long currentTime = System.currentTimeMillis();
        params.setModDate(currentTime);
        assertEquals(currentTime, params.getModDate().getTime());
    }

    @Test
    public void setModDateDoesNothingIfNull(){
        long currentTime = System.currentTimeMillis();
        params.setModDate(currentTime);
        params.setModDate(null);
        assertEquals(currentTime, params.getModDate().getTime());
    }

    @Test
    public void parseInclusionsSetsInclusionsFromString(){
        params.setInclusions(InclusionParams.COMMITMENTS.name() + "," + InclusionParams.CONTACT_INFO.name());
        assertThat(params.getInclusions(), hasItem(InclusionParams.CONTACT_INFO));
    }

    @Test
    public void parseInclusionsIgnoresEmptyResult(){
        params.setInclusions("");
        assertTrue(params.getInclusions().size() == 0);
    }

    @Test
    public void parseInclusionsIgnoresNull(){
        params.setInclusions(null);
        assertTrue(params.getInclusions().size() == 0);
    }

    @Test
    public void parseInclusionsIgnoresInvalid(){
        params.setInclusions("abc");
        assertTrue(params.getInclusions().size() == 0);
    }

    @Test
    public void setAssignmentAreaIsConsideredACtionable(){
        params.setAssignmentArea(123L);
        assertEquals(new Long(123L), params.getAssignmentArea());
        assertTrue(params.hasActionableContent());
    }
}
