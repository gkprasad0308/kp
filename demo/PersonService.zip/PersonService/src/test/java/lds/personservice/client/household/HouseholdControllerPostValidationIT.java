package lds.personservice.client.household;

import lds.personservice.AbstractValidationTestRunnerIT;
import lds.personservice.Main;
import lds.personservice.client.ResourceTemplate;
import lds.personservice.household.Household;
import lds.personservice.person.Person;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.HttpMethod;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import javax.inject.Inject;
import javax.inject.Provider;

@ActiveProfiles({ "local" })
@IntegrationTest({ "browser.startup=false", "server.port=0" })
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class HouseholdControllerPostValidationIT extends AbstractValidationTestRunnerIT<Household> {

    @Inject
    private Provider<HouseholdTemplate> templateProvider;

    @Override
    protected ResourceTemplate getTemplate() {
        return templateProvider.get();
    }

    @Override
    protected HttpMethod getHttpMethod() {
        return HttpMethod.POST;
    }

    @Test
    public void createHouseholdInvalidGuid(){
        Household household = new Household();
        household.setGuid("ABC");
        runFieldErrorInclusiveTest(household, "guid", BAD);
    }

    @Test
    public void createHouseholdAddressToLarge(){
        Household household = new Household();
        household.setAddress("11:07:14.621 [main] DEBUG o.s.t.c.j.SpringJUnit4ClassRunner - SpringJUnit4ClassRunner constructor called with [class lds.personservice.client.household.HouseholdControllerPostValidationIT].\n" +
                "11:07:14.642 [main] DEBUG o.s.test.context.BootstrapUtils - Instantiating TestContextBootstrapper from class [org.springframework.test.context.web.WebTestContextBootstrapper]\n" +
                "11:07:14.670 [main] DEBUG o.s.t.c.w.WebTestContextBootstrapper - Found explicit ContextLoader class [org.springframework.boot.test.SpringApplicationContextLoader] for context configuration attributes [ContextConfigurationAttributes@61f8bee4 declaringClass = 'lds.personservice.client.household.HouseholdControllerPostValidationIT', classes = '{class lds.personservice.Main}', locations = '{}', inheritLocations = true, initializers = '{}', inheritInitializers = true, name = [null], contextLoaderClass = 'org.springframework.boot.test.SpringApplicationContextLoader']\n" +
                "11:07:14.688 [main] INFO  o.s.t.c.w.WebTestContextBootstrapper - Using TestExecutionListeners: [org.springframework.boot.test.IntegrationTestPropertiesListener@1b68ddbd, org.springframework.test.context.support.DependencyInjectionTestExecutionListener@646d64ab, org.springframework.test.context.support.DirtiesContextTestExecutionListener@59e5ddf, org.springframework.test.context.transaction.TransactionalTestExecutionListener@536aaa8d, org.springframework.test.context.jdbc.SqlScriptsTestExecutionListener@e320068]\n" +
                "11:07:14.690 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.691 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "2015-12-21 11:07:23.172  INFO 86857 --- [0-auto-1-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring FrameworkServlet 'dispatcherServlet'\n" +
                "2015-12-21 11:07:23.173  INFO 86857 --- [0-auto-1-exec-1] o.s.web.servlet.DispatcherServlet        : FrameworkServlet 'dispatcherServlet': initialization started\n" +
                "2015-12-21 11:07:23.189  INFO 86857 --- [0-auto-1-exec-1] o.s.web.servlet.DispatcherServlet        : FrameworkServlet 'dispatcherServlet': initialization completed in 16 ms\n" +
                "2015-12-21 11:07:23.206  INFO 86857 --- [0-auto-1-exec-1] l.p.config.SecurityConfiguration         : Authentication success: basic\n" +
                "test\n" +
                "2015-12-21 11:07:23.523 ERROR 86857 --- [0-auto-1-exec-1] lds.personservice.ControllerAdvisor      : Validation errors encountered: {\"status\":\"BAD_REQUEST\",\"code\":\"validation.errors\",\"fieldErrors\":[{\"field\":\"GUID\",\"code\":\"error.post.household.bad.GUID\"}],\"globalErrors\":[]}\n" +
                "11:07:14.696 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.697 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.698 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.699 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.700 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.700 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.703 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.704 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.621 [main] DEBUG o.s.t.c.j.SpringJUnit4ClassRunner - SpringJUnit4ClassRunner constructor called with [class lds.personservice.client.household.HouseholdControllerPostValidationIT].\n" +
                "11:07:14.642 [main] DEBUG o.s.test.context.BootstrapUtils - Instantiating TestContextBootstrapper from class [org.springframework.test.context.web.WebTestContextBootstrapper]\n" +
                "11:07:14.670 [main] DEBUG o.s.t.c.w.WebTestContextBootstrapper - Found explicit ContextLoader class [org.springframework.boot.test.SpringApplicationContextLoader] for context configuration attributes [ContextConfigurationAttributes@61f8bee4 declaringClass = 'lds.personservice.client.household.HouseholdControllerPostValidationIT', classes = '{class lds.personservice.Main}', locations = '{}', inheritLocations = true, initializers = '{}', inheritInitializers = true, name = [null], contextLoaderClass = 'org.springframework.boot.test.SpringApplicationContextLoader']\n" +
                "11:07:14.688 [main] INFO  o.s.t.c.w.WebTestContextBootstrapper - Using TestExecutionListeners: [org.springframework.boot.test.IntegrationTestPropertiesListener@1b68ddbd, org.springframework.test.context.support.DependencyInjectionTestExecutionListener@646d64ab, org.springframework.test.context.support.DirtiesContextTestExecutionListener@59e5ddf, org.springframework.test.context.transaction.TransactionalTestExecutionListener@536aaa8d, org.springframework.test.context.jdbc.SqlScriptsTestExecutionListener@e320068]\n" +
                "11:07:14.690 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.691 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "2015-12-21 11:07:23.172  INFO 86857 --- [0-auto-1-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring FrameworkServlet 'dispatcherServlet'\n" +
                "2015-12-21 11:07:23.173  INFO 86857 --- [0-auto-1-exec-1] o.s.web.servlet.DispatcherServlet        : FrameworkServlet 'dispatcherServlet': initialization started\n" +
                "2015-12-21 11:07:23.189  INFO 86857 --- [0-auto-1-exec-1] o.s.web.servlet.DispatcherServlet        : FrameworkServlet 'dispatcherServlet': initialization completed in 16 ms\n" +
                "2015-12-21 11:07:23.206  INFO 86857 --- [0-auto-1-exec-1] l.p.config.SecurityConfiguration         : Authentication success: basic\n" +
                "test\n" +
                "2015-12-21 11:07:23.523 ERROR 86857 --- [0-auto-1-exec-1] lds.personservice.ControllerAdvisor      : Validation errors encountered: {\"status\":\"BAD_REQUEST\",\"code\":\"validation.errors\",\"fieldErrors\":[{\"field\":\"GUID\",\"code\":\"error.post.household.bad.GUID\"}],\"globalErrors\":[]}\n" +
                "11:07:14.696 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.697 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.698 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.699 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.700 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.700 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.703 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.704 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.621 [main] DEBUG o.s.t.c.j.SpringJUnit4ClassRunner - SpringJUnit4ClassRunner constructor called with [class lds.personservice.client.household.HouseholdControllerPostValidationIT].\n" +
                "11:07:14.642 [main] DEBUG o.s.test.context.BootstrapUtils - Instantiating TestContextBootstrapper from class [org.springframework.test.context.web.WebTestContextBootstrapper]\n" +
                "11:07:14.670 [main] DEBUG o.s.t.c.w.WebTestContextBootstrapper - Found explicit ContextLoader class [org.springframework.boot.test.SpringApplicationContextLoader] for context configuration attributes [ContextConfigurationAttributes@61f8bee4 declaringClass = 'lds.personservice.client.household.HouseholdControllerPostValidationIT', classes = '{class lds.personservice.Main}', locations = '{}', inheritLocations = true, initializers = '{}', inheritInitializers = true, name = [null], contextLoaderClass = 'org.springframework.boot.test.SpringApplicationContextLoader']\n" +
                "11:07:14.688 [main] INFO  o.s.t.c.w.WebTestContextBootstrapper - Using TestExecutionListeners: [org.springframework.boot.test.IntegrationTestPropertiesListener@1b68ddbd, org.springframework.test.context.support.DependencyInjectionTestExecutionListener@646d64ab, org.springframework.test.context.support.DirtiesContextTestExecutionListener@59e5ddf, org.springframework.test.context.transaction.TransactionalTestExecutionListener@536aaa8d, org.springframework.test.context.jdbc.SqlScriptsTestExecutionListener@e320068]\n" +
                "11:07:14.690 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.691 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "2015-12-21 11:07:23.172  INFO 86857 --- [0-auto-1-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring FrameworkServlet 'dispatcherServlet'\n" +
                "2015-12-21 11:07:23.173  INFO 86857 --- [0-auto-1-exec-1] o.s.web.servlet.DispatcherServlet        : FrameworkServlet 'dispatcherServlet': initialization started\n" +
                "2015-12-21 11:07:23.189  INFO 86857 --- [0-auto-1-exec-1] o.s.web.servlet.DispatcherServlet        : FrameworkServlet 'dispatcherServlet': initialization completed in 16 ms\n" +
                "2015-12-21 11:07:23.206  INFO 86857 --- [0-auto-1-exec-1] l.p.config.SecurityConfiguration         : Authentication success: basic\n" +
                "test\n" +
                "2015-12-21 11:07:23.523 ERROR 86857 --- [0-auto-1-exec-1] lds.personservice.ControllerAdvisor      : Validation errors encountered: {\"status\":\"BAD_REQUEST\",\"code\":\"validation.errors\",\"fieldErrors\":[{\"field\":\"GUID\",\"code\":\"error.post.household.bad.GUID\"}],\"globalErrors\":[]}\n" +
                "11:07:14.696 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.697 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.698 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.699 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.700 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.700 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.703 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [lds.personservice.client.household.HouseholdControllerPostValidationIT]\n" +
                "11:07:14.704 [main] DEBUG o.s.t.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [lds.personservice.client.household.HouseholdControllerPostValidationIT]");
        runFieldErrorInclusiveTest(household, "address", OUTOFBOUNDS);
    }

    @Test
    public void createHouseholdLatInvalidSize(){
        Household household = new Household();
        household.setLat("34.0000000000000000000000000000000000000000000000000000000000000000000000");
        runFieldErrorInclusiveTest(household, "lat", OUTOFBOUNDS);
    }

    @Test
    public void createHouseholdLatNumberToLarge(){
        Household household = new Household();
        household.setLat("91");
        runFieldErrorInclusiveTest(household, "lat", INVALID);
    }

    @Test
    public void createHouseholdLatNotNumber(){
        Household household = new Household();
        household.setLat("bob");
        runFieldErrorInclusiveTest(household, "lat", INVALID);
    }

    @Test
    public void createHouseholdLatNumberToSmall(){
        Household household = new Household();
        household.setLat("-91");
        runFieldErrorInclusiveTest(household, "lat", INVALID);
    }

    @Test
    public void createHouseholdLngInvalidSize(){
        Household household = new Household();
        household.setLng("123.000000000000000000000000000000000000000000000000000000000000000");
        runFieldErrorInclusiveTest(household, "lng", OUTOFBOUNDS);
    }

    @Test
    public void createHouseholdLngNumberToLarge(){
        Household household = new Household();
        household.setLng("181");
        runFieldErrorInclusiveTest(household, "lng", INVALID);
    }

    @Test
    public void createHouseholdInvalidOrgAssignmentBadOrgId(){
        Household household = new Household();
        household.setOrgId(456654L);

        Person person = new Person();
        person.setProsAreaId(-1L);

        household.addPerson(person);

        runGlobalErrorInclusiveTest(household, "error.post.household.incompatible.org.for.existing.prosArea");
    }

    @Test
    public void createHouseholdInvalidOrgAssignmentNoParentOrgId(){
        Household household = new Household();
        household.setOrgId(4054990L);

        Person person = new Person();
        person.setProsAreaId(-1L);

        household.addPerson(person);

        runGlobalErrorInclusiveTest(household, "error.post.household.incompatible.org.for.existing.prosArea");
    }

    @Test
    public void createHouseholdInvalidOrgAssignmentNoMatchingProsAreas(){
        Household household = new Household();
        household.setOrgId(4010426L);

        Person person = new Person();
        person.setProsAreaId(-1L);

        household.addPerson(person);

        runGlobalErrorInclusiveTest(household, "error.post.household.incompatible.org.for.existing.prosArea");
    }

    @Test
    public void createHouseholdInvalidWithOrgIdAndMissionaryId(){
        Household household = new Household();
        household.setOrgId(4010426L);
        household.setMissionaryId(234L);

        runGlobalErrorInclusiveTest(household, "error.post.household.invalid.assignment");
    }

    @Test
    public void createHouseholdInvalidWithOrgIdAndStewardId(){
        Household household = new Household();
        household.setOrgId(4010426L);
        household.setStewardCmisId(234L);

        runGlobalErrorInclusiveTest(household, "error.post.household.invalid.assignment");
    }

    @Test
    public void createHouseholdInvalidWithMissionaryIdAndStewardId(){
        Household household = new Household();
        household.setMissionaryId(4010426L);
        household.setStewardCmisId(234L);

        runGlobalErrorInclusiveTest(household, "error.post.household.invalid.assignment");
    }

    @Test
    public void createHouseholdInvalidWithOrgIdMissionaryIdAndStewardId(){
        Household household = new Household();
        household.setOrgId(445L);
        household.setMissionaryId(4010426L);
        household.setStewardCmisId(234L);

        runGlobalErrorInclusiveTest(household, "error.post.household.invalid.assignment");
    }

    @Test
    public void createHouseholdLngNotNumber(){
        Household household = new Household();
        household.setLng("bob");
        runFieldErrorInclusiveTest(household, "lng", INVALID);
    }

    @Test
    public void createHouseholdLngNumberToSmall(){
        Household household = new Household();
        household.setLng("-181");
        runFieldErrorInclusiveTest(household, "lng", INVALID);
    }

    @Test
    public void createHouseholdInvalidPinDropNoLatLng(){
        Household household = new Household();
        household.setPinDropped(true);
        runGlobalErrorInclusiveTest(household, "error.post.household.invalid.pin.drop");
    }

    @Test
    public void createHouseholdInvalidPinDropNoLng(){
        Household household = new Household();
        household.setPinDropped(true);
        household.setLat("32");
        runGlobalErrorInclusiveTest(household, "error.post.household.invalid.pin.drop");
    }

    @Test
    public void createHouseholdInvalidPinDropNoLat(){
        Household household = new Household();
        household.setPinDropped(true);
        household.setLng("24");
        runGlobalErrorInclusiveTest(household, "error.post.household.invalid.pin.drop");
    }

    @Test
    public void createHouseholdInvalidLatNoLng(){
        Household household = new Household();
        household.setLat("32");
        runGlobalErrorInclusiveTest(household, "error.post.household.invalid.state.lat.lng");
    }

    @Test
    public void createHouseholdInvalidLngNoLat(){
        Household household = new Household();
        household.setLng("32");
        runGlobalErrorInclusiveTest(household, "error.post.household.invalid.state.lat.lng");
    }

    @Test
    public void createHouseholdWithMissionaryAndCmisIdInvalid(){
        Person person = new Person();
        person.setCmisId(123L);
        Household household = new Household();
        household.setGuid("abc");
        household.setMissionaryId(123L);
        household.addPerson(person);

        runGlobalErrorInclusiveTest(household, "error.post.household.unsupported.member.household.designation");
    }

    @Test
    public void createHouseholdWithStewardAndCmisIdInvalid(){
        Person person = new Person();
        person.setCmisId(123L);
        Household household = new Household();
        household.setGuid("abc");
        household.setStewardCmisId(123L);
        household.addPerson(person);

        runGlobalErrorInclusiveTest(household, "error.post.household.unsupported.member.household.designation");
    }

    @Test
    public void simpleNestedPersonTest(){
        Person person = new Person();
        person.setGender("Fred");
        Household household = new Household();
        household.addPerson(person);
        runFieldErrorInclusiveTest(household, "people[0].gender", UNSUPPORTED);
    }
}
