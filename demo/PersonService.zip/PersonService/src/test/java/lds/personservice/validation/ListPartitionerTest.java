package lds.personservice.validation;


import lds.personservice.util.ListPartitioner;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import static org.junit.Assert.assertTrue;

public class ListPartitionerTest {

    private ListPartitioner<Long> partitioner;

    @Before
    public void setup(){
        partitioner = new ListPartitioner<>();
    }

    @Test
    public void partitionNullItemsReturnsEmptyPartitions(){
        assertTrue(partitioner.partition(null, 5).size() == 0);
    }

    @Test
    public void partitionEmptyItemsReturnsEmptyPartitions(){
        assertTrue(partitioner.partition(new ArrayList<>(), 5).size() == 0);
    }

    @Test
    public void oraclePartitionNullItemsReturnsEmptyPartitions(){
        assertTrue(partitioner.partition(null, 5).size() == 0);
    }

    @Test
    public void oraclePartitionEmptyItemsReturnsEmptyPartitions(){
        assertTrue(partitioner.partition(new ArrayList<>(), 5).size() == 0);
    }

    @Test
    public void partitionHandlesListsSmallerThanSize(){
        List<List<Long>> partitions  =partitioner.partition(new Random().longs(10).boxed().collect(Collectors.toList()), 20);
        assertTrue(partitions.size() == 1);
        assertTrue(partitions.get(0).size() == 10);
    }

    @Test
    public void partitionCreatesPartitionsOnSizeLimit(){
        List<List<Long>> partitions = partitioner.partition(new Random().longs(150).boxed().collect(Collectors.toList()), 100);
        assertTrue(partitions.size() == 2);
        assertTrue(partitions.get(0).size() == 100);
        assertTrue(partitions.get(1).size() == 50);
    }

    @Test
    public void oraclePartionPartionsOnMAX_ORACLE_SIZE(){
        List<List<Long>> partitions = partitioner.partition(new Random().longs(1250).boxed().collect(Collectors.toList()), ListPartitioner.MAX_ORACLE_SIZE);
        assertTrue(partitions.size() == 2);
        assertTrue(partitions.get(0).size() == ListPartitioner.MAX_ORACLE_SIZE);
    }
}
