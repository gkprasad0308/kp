package lds.personservice.validation.constraint;

import lds.personservice.util.validation.constraint.PreferredLanguageValidator;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PreferredLanguageValidatorTest {

    @InjectMocks
    private PreferredLanguageValidator validator;

    @Mock
    private OptionsValidationService validationService;

    @Mock
    private ConstraintValidatorContext context;

    @Test
    public void isValid_returns_true_with_null(){
        assertTrue(validator.isValid(null, context));
    }

    @Test
    public void isValid_returns_true_if_valid(){
        when(validationService.languageExists(1)).thenReturn(true);
        assertTrue(validator.isValid(1, context));
        verify(validationService, times(1)).languageExists(1);
    }

    @Test
    public void isValid_returns_false_if_valid(){
        when(validationService.languageExists(1)).thenReturn(false);
        assertFalse(validator.isValid(1, context));
        verify(validationService, times(1)).languageExists(1);
    }
}
