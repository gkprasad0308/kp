package lds.personservice.person.drop;

import java.net.URI;

import lds.personservice.client.ResourceTemplate;
import lds.personservice.person.Person;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@Scope("prototype")
public class DropNoteTemplate extends ResourceTemplate<DropNoteTemplate>
{

    //"${lds.api.resources.people.href}/{personId}/drop")
    @Value("http://localhost:${local.server.port}${lds.api.resources.people.href}")
    private URI resourceUri;

    public URI getResourceUri() {
        return resourceUri;
    }

    public String getResourceUriAsString(){
        return getResourceUri().toString();
    }

    private String constructUri(String personGuid)
    {
        return resourceUri + "/" + personGuid + "/" + "drop";
    }

    public Person dropPerson(WritableDropNote note, String personGuid)
    {
        HttpEntity<WritableDropNote> request = new HttpEntity<WritableDropNote>(note, constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE));
        return sendRequest(constructUri(personGuid), HttpMethod.PUT, request, Person.class).getBody();
    }

    public Person undoDropPerson(String personId)
    {
        HttpEntity<WritableDropNote> request = new HttpEntity<WritableDropNote>(constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE));
        return sendRequest(constructUri(personId) + "/undo", HttpMethod.PUT, request, Person.class).getBody();
    }

}
