package lds.personservice.validation.services;

import lds.personservice.options.*;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OptionsValidationServiceTest {

    @InjectMocks
    private OptionsValidationService service;

    @Mock
    private SourceRepository sourceRepository;
    @Mock
    private AgeCategoryRepository ageCategoryRepository;
    @Mock
    private ContactTypeRepository contactTypeRepository;
    @Mock
    private LanguageCodeRepository languageCodeRepository;
    @Mock
    private StatusRepository statusRepository;

    @Test
    public void isMemberStatus_null_status_returns_false(){
        assertFalse("expected false with a null integer", service.isMemberStatus(null));
    }

    @Test
    public void isMemberStatus_returns_false_if_not_in_list(){
        when(statusRepository.getStatusesForCategory(StatusRepository.MEMBER_CATEGORY))
                .thenReturn(createSimpleStatusList(1, 2));

        assertFalse(service.isMemberStatus(4));
        verify(statusRepository, times(1)).getStatusesForCategory(StatusRepository.MEMBER_CATEGORY);
    }

    @Test
    public void isValidMemberStatus_returns_true_if_in_list(){
        when(statusRepository.getStatusesForCategory(StatusRepository.MEMBER_CATEGORY))
                .thenReturn(createSimpleStatusList(1,2,3,4));

        assertTrue(service.isMemberStatus(4));
        verify(statusRepository, times(1)).getStatusesForCategory(StatusRepository.MEMBER_CATEGORY);
    }

    @Test
    public void isValidDropStatus_returns_false_if_null(){
        assertFalse("expected false with a null integer", service.isValidDropStatus(null));
    }

    @Test
    public void isValidDropStatus_returns_false_if_statusId_is_categoryId(){
        assertFalse("Expected a status equal to dropCategoryId to return false", service.isValidDropStatus(StatusRepository.DROP_CATEGORY));
    }

    @Test
    public void isValidDropSTatus_returns_false_if_not_in_list(){
        when(statusRepository.getStatusesForCategory(StatusRepository.DROP_CATEGORY))
                .thenReturn(createSimpleStatusList(1,2));

        assertFalse("expected result to be false if the statusId is not in the list returned", service.isValidDropStatus(4));
        verify(statusRepository, times(1)).getStatusesForCategory(StatusRepository.DROP_CATEGORY);
    }

    @Test
    public void isValidDropStatus_returns_true_if_in_list(){
        when(statusRepository.getStatusesForCategory(StatusRepository.DROP_CATEGORY))
                .thenReturn(createSimpleStatusList(1, 2, 3, 4));

        assertTrue(service.isValidDropStatus(4));
        verify(statusRepository, times(1)).getStatusesForCategory(StatusRepository.DROP_CATEGORY);
    }

    @Test
    public void statusExists_calls_mock_returns_true_if_in_list(){
        when(statusRepository.exists(1)).thenReturn(true);
        assertTrue(service.statusExists(1));
        verify(statusRepository, times(1)).exists(1);
        verifyNoMoreInteractions(statusRepository);
    }

    @Test
    public void statusExists_calls_mock_and_returns_false(){
        when(statusRepository.exists(2)).thenReturn(true);
        assertFalse(service.statusExists(1));
        verify(statusRepository, times(1)).exists(1);
        verifyNoMoreInteractions(statusRepository);
    }

    @Test
    public void ageCategoryExists_calls_mock_and_returns_mock_value(){
        when(ageCategoryRepository.exists(1)).thenReturn(true);
        assertTrue(service.ageCategoryExists(1));
        verify(ageCategoryRepository, times(1)).exists(1);
        verifyNoMoreInteractions(ageCategoryRepository);
    }

    @Test
    public void ageCategoryExists_calls_mock_and_returns_false(){
        when(ageCategoryRepository.exists(1)).thenReturn(true);
        assertFalse(service.ageCategoryExists(2));
        verify(ageCategoryRepository, times(1)).exists(2);
        verifyNoMoreInteractions(ageCategoryRepository);
    }

    @Test
    public void contactSourceExists_calls_mock_returns_true(){
        when(sourceRepository.exists(1)).thenReturn(true);
        assertTrue(service.contactSourceExists(1));
        verify(sourceRepository, times(1)).exists(1);
        verifyNoMoreInteractions(sourceRepository);
    }

    @Test
    public void contactSourceExists_calls_mock_returns_false(){
        when(sourceRepository.exists(1)).thenReturn(true);
        assertFalse(service.contactSourceExists(2));
        verify(sourceRepository, times(1)).exists(2);
        verifyNoMoreInteractions(sourceRepository);
    }

    @Test
    public void languageExists_calls_mock_returns_true(){
        when(languageCodeRepository.exists(1)).thenReturn(true);
        assertTrue(service.languageExists(1));
        verify(languageCodeRepository, times(1)).exists(1);
        verifyNoMoreInteractions(languageCodeRepository);
    }

    @Test
    public void languageExists_calls_mock_returns_false(){
        when(languageCodeRepository.exists(1)).thenReturn(true);
        assertFalse(service.languageExists(2));
        verify(languageCodeRepository, times(1)).exists(2);
        verifyNoMoreInteractions(languageCodeRepository);
    }

    @Test
    public void contactTypeExists_calls_mock_returns_true(){
        when(contactTypeRepository.exists(1)).thenReturn(true);
        assertTrue(service.contactTypeExists(1));
        verify(contactTypeRepository, times(1)).exists(1);
        verifyNoMoreInteractions(contactTypeRepository);
    }

    @Test
    public void contactTypeExists_calls_mock_returns_false(){
        when(contactTypeRepository.exists(1)).thenReturn(true);
        assertFalse(service.contactTypeExists(2));
        verify(contactTypeRepository, times(1)).exists(2);
        verifyNoMoreInteractions(contactTypeRepository);
    }

    private List<Status> createSimpleStatusList(int... statusIds){
        List<Status> statusList = new LinkedList<>();
        Status status;
        for(int id : statusIds){
            status = new Status();
            status.setId(id);
            statusList.add(status);
        }
        return statusList;
    }
}
