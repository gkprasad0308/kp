package lds.personservice.person.drop;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.util.*;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DropNoteRepositoryTest {

    @InjectMocks
    private DropNoteRepository repository;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private NamedParameterJdbcTemplate namedTemplate;

    @Mock
    private DropNoteSproc dropNoteSproc;

    @Mock
    private UndoDropNoteSproc undoDropNoteSproc;

    @Mock
    private ResetPersonSproc resetPersonSproc;

    @Test
    public void hasDropIdReturnsTrueIfJdbcReturnsGreaterThanZero(){
        //when(jdbcTemplate.queryForObject(anyString(), any(Object[].class), any(Long.class.getClass()))).thenReturn(1L);
        assertTrue(repository.hasDropId(1));
        //verify(jdbcTemplate, times(1)).queryForObject(anyString(), any(Object[].class), any(Long.class.getClass()));
        verifyNoMoreInteractions(jdbcTemplate);
    }

    @Test
    public void hasDropIdReturnsFalseIfJdbcReturnsZero(){
        //when(jdbcTemplate.queryForObject(anyString(), any(Object[].class), any(Long.class.getClass()))).thenReturn(0L);
        assertFalse(repository.hasDropId(1));
       // verify(jdbcTemplate, times(1)).queryForObject(anyString(), any(Object[].class), any(Long.class.getClass()));
        verifyNoMoreInteractions(jdbcTemplate);
    }

    @Test
    public void findLatestDropidForPersonReturnsResultFromJdbc(){
       // when(jdbcTemplate.queryForObject(anyString(), any(Object[].class), any(Long.class.getClass()))).thenReturn(1L);
        assertEquals(new Long(1L), repository.findLatestDropIdForPerson(4L));
       // verify(jdbcTemplate, times(1)).queryForObject(anyString(), any(Object[].class), any(Long.class.getClass()));
        verifyNoMoreInteractions(jdbcTemplate);
    }

    @Test
    public void getNotesForPersonReturnsTemplateValues(){
        DropNote dropNote1 = new DropNote();
        DropNote dropNote2 = new DropNote();
        when(namedTemplate.query(anyString(), anyMap(), any(DropNoteMapper.class))).thenReturn(Arrays.asList(dropNote1, dropNote2));

        List<DropNote> results = repository.getNotesForPerson(1L);
        assertTrue(results.size() == 2);
        assertThat(results, hasItem(dropNote1));
        assertThat(results, hasItem(dropNote2));
        verify(namedTemplate, times(1)).query(anyString(), anyMap(), any(DropNoteMapper.class));
        verifyNoMoreInteractions(namedTemplate);
    }

    @Test
    public void getNotesForPeopleReturnsExpectedMap(){
        DropNote dropNote1 = new DropNote();
        DropNote dropNote2 = new DropNote();
        Map<Long, List<DropNote>> expectedMap = new HashMap<>();
        expectedMap.put(1L, Arrays.asList(dropNote1, dropNote2));
        when(namedTemplate.query(anyString(), anyMap(), any(DropNoteResultSetExtractor.class))).thenReturn(expectedMap);

        Map<Long, List<DropNote>> results = repository.getNotesForPeople(Arrays.asList(1L));
        assertTrue(results.size() == 1);
        assertTrue(results.containsKey(1L));
        assertThat(results.get(1L), hasItem(dropNote1));
        assertThat(results.get(1L), hasItem(dropNote2));
    }

    @Test
    public void undoDropCallsSproc(){
        Date date = new Date();
        SimpleJdbcCall mock = mock(SimpleJdbcCall.class);
        when(undoDropNoteSproc.getStoredProc()).thenReturn(mock);
        when(undoDropNoteSproc.getParametersUsing(1L, date)).thenReturn(new MapSqlParameterSource());
        repository.undoDrop(1L, date);
        verify(undoDropNoteSproc, times(1)).getParametersUsing(1L, date);
        verify(undoDropNoteSproc, times(1)).getStoredProc();
        verify(mock, times(1)).execute(any(SqlParameterSource.class));
        verifyNoMoreInteractions(undoDropNoteSproc);
    }

    @Test
    public void dropPersonCallsSproc(){
        WritableDropNote dropNote = new WritableDropNote();
        SimpleJdbcCall mock = mock(SimpleJdbcCall.class);
        when(dropNoteSproc.getStoredProc()).thenReturn(mock);
        when(dropNoteSproc.getParametersUsing(1L, dropNote)).thenReturn(new MapSqlParameterSource());
        repository.dropPerson(1L, dropNote);
        verify(dropNoteSproc, times(1)).getParametersUsing(1L, dropNote);
        verify(dropNoteSproc, times(1)).getStoredProc();
        verify(mock, times(1)).execute(any(SqlParameterSource.class));
        verifyNoMoreInteractions(dropNoteSproc);
    }

    @Test
    public void resetDropCallsSproc(){
        Date date = new Date();
        SimpleJdbcCall mock = mock(SimpleJdbcCall.class);
        when(resetPersonSproc.getStoredProc()).thenReturn(mock);
        when(resetPersonSproc.getParemetersUsing(1L, date)).thenReturn(new MapSqlParameterSource());
        repository.resetPerson(1L, date);
        verify(resetPersonSproc, times(1)).getParemetersUsing(1L, date);
        verify(resetPersonSproc, times(1)).getStoredProc();
        verify(mock, times(1)).execute(any(SqlParameterSource.class));
        verifyNoMoreInteractions(resetPersonSproc);
    }
}
