package lds.personservice.validation.constraint;

import lds.personservice.household.Household;
import lds.personservice.util.validation.constraint.PinDropValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class PinDropValidatorTest {

    @Mock
    private ConstraintValidatorContext context;
    private PinDropValidator validator;

    @Before
    public void setup(){
        validator = new PinDropValidator();
    }

    @Test
    public void isValidIfNullPinDrop(){
        Household household = new Household();
        household.setPinDropped(null);
        assertTrue(validator.isValid(household, context));
    }

    @Test
    public void isValidIfPinDropIsFalse(){
        Household household = new Household();
        household.setPinDropped(false);
        assertTrue(validator.isValid(household, context));
    }

    @Test
    public void isValidIfPinDropAndLatLng(){
        Household household = new Household();
        household.setPinDropped(true);
        household.setLat("123.00");
        household.setLng("100.23");
        assertTrue(validator.isValid(household, context));
    }

    @Test
    public void isNotValidIfPinDropAndNoLatLng(){
        Household household = new Household();
        household.setPinDropped(true);
        assertFalse(validator.isValid(household, context));
    }

    @Test
    public void isNotValidIfPinDropAndNoLat(){
        Household household = new Household();
        household.setPinDropped(true);
        household.setLng("23.00");
        assertFalse(validator.isValid(household, context));
    }

    @Test
    public void isNotValidIfPinDropAndNoLng(){
        Household household = new Household();
        household.setPinDropped(true);
        household.setLat("23.00");
        assertFalse(validator.isValid(household, context));
    }
}
