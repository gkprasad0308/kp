package lds.personservice.config;


import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;


import javax.validation.Validator;

import static org.junit.Assert.assertEquals;

public class ValidationConfigurationTest {

    private ValidationConfiguration configuration;

    @Before
    public void setup(){
        configuration = new ValidationConfiguration();
    }

    @Test
    public void validatorReturnsExpectedLocalValidatorBean(){
        assertEquals(LocalValidatorFactoryBean.class, configuration.validator().getClass());
    }

    @Test
    public void validationConfigurationBeanPostProcessor(){
        Validator validator = configuration.validator();
        ValidationConfiguration.ValidationConfigurationBeanPostProcessor processor = configuration.validationConfigurationBeanPostProcessor(validator);
        ReflectionTestUtils.getField(processor, "validator");
    }
}
