package lds.personservice.person.fellowshipper;

import lds.personservice.person.Person;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class FellowshipperRepositoryTest {

    @InjectMocks
    private FellowshipperRepository repository;

    @Mock
    private FellowshipInsertSql insertSql;

    @Mock
    private FellowshipUpdateSql updateSql;

    @Mock
    private NamedParameterJdbcTemplate namedTemplate;

    @Test
    public void getFellowshipInfoForPersonReturnsEmptyObjectIfNullPersonId(){
        FellowshipInfo info = repository.getFellowshipInfoForPerson(null);
        assertTrue(CollectionUtils.isEmpty(info.getFellowshippees()));
        assertTrue(CollectionUtils.isEmpty(info.getFellowshippers()));
        verifyZeroInteractions(namedTemplate, insertSql, updateSql);
    }

    @Test
    public void getFellowshipInfoForPersonCallsExpected(){
        FellowshipInfo info = new FellowshipInfo();
        FellowshipMap map = mock(FellowshipMap.class);
        when(map.getFellowshipInfoForPerson(123L)).thenReturn(info);
        when(namedTemplate.query(anyString(), any(SqlParameterSource.class), any(FellowshipperResultSetExtractor.class))).thenReturn(map);

        FellowshipInfo results = repository.getFellowshipInfoForPerson(123L);
        assertEquals(info, results);
        verify(map, times(1)).getFellowshipInfoForPerson(123L);
        verify(namedTemplate, times(1)).query(anyString(), any(SqlParameterSource.class), any(FellowshipperResultSetExtractor.class));
        verifyNoMoreInteractions(namedTemplate, map);
    }

    @Test
     public void getFellowshipMapForPeopleReturnsEmptyIfNullPassedIn(){
        FellowshipMap map = repository.getFellowshipMapForPeople(null);
        assertTrue(CollectionUtils.isEmpty((Map<?, ?>) ReflectionTestUtils.getField(map, "fellowshippersMap")));
        assertTrue(CollectionUtils.isEmpty((Map<?, ?>) ReflectionTestUtils.getField(map, "fellowshippeesMap")));
        verifyZeroInteractions(namedTemplate);
    }

    @Test
    public void getFellowshipMapForPeopleReturnsMergedMap(){
        FellowshipMap map1 = mock(FellowshipMap.class);
        FellowshipMap map2 = mock(FellowshipMap.class);

        when(namedTemplate.query(anyString(), any(SqlParameterSource.class), any(FellowshipperResultSetExtractor.class)))
                .thenReturn(map1)
                .thenReturn(map2);

        List<Long> personIds = LongStream.range(1, 1500).boxed().collect(Collectors.toList());
        FellowshipMap result = repository.getFellowshipMapForPeople(personIds);
        assertEquals(map1, result);
        verify(namedTemplate, times(2)).query(anyString(), any(SqlParameterSource.class), any(FellowshipperResultSetExtractor.class));
        verify(map1, times(1)).mergeMaps(map2);
    }

    @Test
    public void removePersonToFellowshipperLinkCallsExpected(){
        repository.removePersonToFellowshipperLink(123L, 456L);
        verify(namedTemplate, times(1)).update(anyString(), any(SqlParameterSource.class));
    }

    @Test
    public void linkPersonToFellowshipperInsertsIfNamedTemplateReturnsFalse(){
        //when(namedTemplate.queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class))).thenReturn(0);

        Person mockPerson = mock(Person.class);
        when(mockPerson.getServerId()).thenReturn(123L);
        Person mockFellowshipper = mock(Person.class);
        when(mockFellowshipper.getServerId()).thenReturn(456L);

        repository.linkPersonToFellowshipper(mockPerson, mockFellowshipper);
        //verify(namedTemplate, times(1)).queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class));
        verify(mockFellowshipper, times(1)).getServerId();
        verify(mockPerson, times(1)).getServerId();
        verify(insertSql, times(1)).getParamsUsing(123L, 456L);
        verify(insertSql, times(1)).updateByNamedParam(anyMap());
        verifyZeroInteractions(updateSql);
    }

    @Test
    public void linkPersonToFellowshipperUpdatesIfNamedTemplateReturnsTrue(){
        //when(namedTemplate.queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class))).thenReturn(1);

        Person mockPerson = mock(Person.class);
        when(mockPerson.getServerId()).thenReturn(123L);
        Person mockFellowshipper = mock(Person.class);
        when(mockFellowshipper.getServerId()).thenReturn(456L);

        repository.linkPersonToFellowshipper(mockPerson, mockFellowshipper);
       // verify(namedTemplate, times(1)).queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class));
        verify(mockFellowshipper, times(1)).getServerId();
        verify(mockPerson, times(1)).getServerId();
        verify(updateSql, times(1)).getParamsUsing(123L, 456L);
        verify(updateSql, times(1)).updateByNamedParam(anyMap());
        verifyZeroInteractions(insertSql);
    }
}
