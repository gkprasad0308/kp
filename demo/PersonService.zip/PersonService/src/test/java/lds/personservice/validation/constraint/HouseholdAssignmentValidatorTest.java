package lds.personservice.validation.constraint;


import lds.personservice.household.Household;
import lds.personservice.util.validation.constraint.HouseholdAssignmentValidator;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class HouseholdAssignmentValidatorTest {

    private HouseholdAssignmentValidator validator;

    @Before
    public void setup(){
        validator = new HouseholdAssignmentValidator();
    }

    @Test
    public void isValidIsTrueIfOrgMissionaryAndStewardAllNull(){
        Household household = createHousehold(null, null, null);
        assertTrue(validator.isValid(household, null));
    }

    @Test
    public void isValidIsTrueIfOrgOnlyHasValue(){
        assertTrue(validator.isValid(createHousehold(1L, null, null), null));
    }

    @Test
    public void isValidIsTrueIfMissionaryIsOnlyHasValue(){
        assertTrue(validator.isValid(createHousehold(null, 1L, null), null));
    }

    @Test
    public void isValidIsTrueIfStewardIsOnlyHasValue(){
        assertTrue(validator.isValid(createHousehold(null, null, 1L), null));
    }

    @Test
    public void isValidIsFalseIfAllHaveValue(){
        assertFalse(validator.isValid(createHousehold(1L, 2L, 1L), null));
    }

    @Test
    public void isValidIsFalseWithOrgAndMissionary(){
        assertFalse(validator.isValid(createHousehold(1L, 1L, null), null));
    }

    @Test
    public void isValidIsFalseWithOrgAndSteward(){
        assertFalse(validator.isValid(createHousehold(1L, null, 1L), null));
    }

    @Test
    public void isValidIsFalseWithMissionaryAndSteward(){
        assertFalse(validator.isValid(createHousehold(null, 1L, 1l), null));
    }

    public Household createHousehold(Long orgId, Long missionaryId, Long stewardCmisId){
        Household household = new Household();
        household.setOrgId(orgId);
        household.setMissionaryId(missionaryId);
        household.setStewardCmisId(stewardCmisId);
        return household;
    }
}
