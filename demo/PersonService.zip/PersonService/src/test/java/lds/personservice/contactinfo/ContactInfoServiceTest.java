package lds.personservice.contactinfo;

import lds.personservice.contactinfo.email.Email;
import lds.personservice.contactinfo.email.EmailTypes;
import lds.personservice.contactinfo.phone.Phone;
import lds.personservice.contactinfo.phone.PhoneTypes;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;

import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ContactInfoServiceTest {

    @InjectMocks
    private ContactInfoService service;

    @Mock
    private ContactInfoRepository repository;

    @Test
    public void createNewContactInfoDoesNothingWithNull(){
        service.createNewContactInfo(1L, null);
        verifyZeroInteractions(repository);
    }

    @Test
    public void createNewContactInfoHandlesEmpty(){
        service.createNewContactInfo(1L, new ContactInfo());
        verifyZeroInteractions(repository);
    }

    @Test
    public void createNewContactInfoCallsDBAppropriately(){
        Phone phone = new Phone(PhoneTypes.PHN_MOBILE, "123");
        Email email = new Email(EmailTypes.EMAIL_HOME, "test@test");

        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setPhoneNumbers(Arrays.asList(phone));
        contactInfo.setEmailAddresses(Arrays.asList(email));

        service.createNewContactInfo(1L, contactInfo);
        verify(repository, times(1)).insertEmail(email, 1l);
        verify(repository, times(1)).insertPhone(phone, 1L);
    }

    @Test
    public void updateContactInfoDoesNothingWithNull(){
        service.updateContactInfo(1L, null);
        verifyZeroInteractions(repository);
    }

    @Test
    public void updateContactInfoDoesNothingWithEmpty(){
        service.updateContactInfo(1L, new ContactInfo());
        verifyZeroInteractions(repository);
    }

    @Test
    public void updateContactInfoCallsDBAppropriately(){
        Phone phone = new Phone(PhoneTypes.PHN_MOBILE, "123");
        Email email = new Email(EmailTypes.EMAIL_HOME, "test@test");

        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setPhoneNumbers(Arrays.asList(phone));
        contactInfo.setEmailAddresses(Arrays.asList(email));

        service.updateContactInfo(1L, contactInfo);
        verify(repository, times(1)).updateEmail(email, 1l);
        verify(repository, times(1)).updatePhone(phone, 1L);
    }

    @Test
    public void removeContactInfoDoesNothingWithNull(){
        service.removeContactInfo(1L, null);
        verifyZeroInteractions(repository);
    }

    @Test
    public void removeContactInfoDoesNothingWithEmpty(){
        service.removeContactInfo(1L, new ContactInfo());
        verifyZeroInteractions(repository);
    }

    @Test
    public void removeContactInfoCallsDBAppropriately(){
        Phone phone = new Phone(PhoneTypes.PHN_MOBILE, "123");
        Email email = new Email(EmailTypes.EMAIL_HOME, "test@test");

        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setPhoneNumbers(Arrays.asList(phone));
        contactInfo.setEmailAddresses(Arrays.asList(email));

        service.removeContactInfo(1L, contactInfo);
        verify(repository, times(1)).removeEmail(email.getType(), 1l);
        verify(repository, times(1)).removePhone(phone.getType(), 1L);
    }

    @Test
    public void mixUpdateContactInfoCallsRemoveIfNewIsNull(){
        Phone phone = new Phone(PhoneTypes.PHN_MOBILE, "123");
        Email email = new Email(EmailTypes.EMAIL_HOME, "test@test");

        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setPhoneNumbers(Arrays.asList(phone));
        contactInfo.setEmailAddresses(Arrays.asList(email));

        service.mixUpdateContactInfo(1L, null, contactInfo);
        verify(repository, times(1)).removeEmail(email.getType(), 1l);
        verify(repository, times(1)).removePhone(phone.getType(), 1L);
        verifyNoMoreInteractions(repository);
    }

    @Test
    public void mixUpdateContactInfoCallsCreateIfOriginalIsNull(){
        Phone phone = new Phone(PhoneTypes.PHN_MOBILE, "123");
        Email email = new Email(EmailTypes.EMAIL_HOME, "test@test");

        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setPhoneNumbers(Arrays.asList(phone));
        contactInfo.setEmailAddresses(Arrays.asList(email));

        service.mixUpdateContactInfo(1L, contactInfo, null);
        verify(repository, times(1)).insertEmail(email, 1l);
        verify(repository, times(1)).insertPhone(phone, 1L);
        verifyNoMoreInteractions(repository);
    }

    @Test
    public void mixUpdateBestCase(){
        Phone phone = new Phone(PhoneTypes.PHN_MOBILE, "123");
        Email email = new Email(EmailTypes.EMAIL_HOME, "test@test");

        ContactInfo newInfo = new ContactInfo();
        newInfo.setPhoneNumbers(Arrays.asList(phone));
        newInfo.setEmailAddresses(Arrays.asList(email));

        Phone phone1 = new Phone(PhoneTypes.PHN_HOME, "678");
        Email email1 = new Email(EmailTypes.EMAIL_HOME, "fam@test");

        ContactInfo original = new ContactInfo();
        original.setPhoneNumbers(Arrays.asList(phone1));
        original.setEmailAddresses(Arrays.asList(email1));

        service.mixUpdateContactInfo(1L, newInfo, original);
        verify(repository, times(1)).insertPhone(phone, 1L);
        verify(repository, times(1)).updateEmail(email, 1L);
        verify(repository, times(1)).removePhone(phone1.getType(), 1L);
        verifyNoMoreInteractions(repository);
    }
}
