package lds.personservice;


import lds.personservice.util.SimpleSproc;
import org.junit.Test;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public abstract class AbstractSimpleSprocTest {

    protected abstract String getSchema();
    protected abstract String getCataglog();
    protected abstract String getFunction();
    protected abstract SimpleSproc getInstance();
    protected abstract List<String> getExpectedParameters();

    @Test
    public void testGetStoredProc(){
        SimpleJdbcCall jdbcCall = getInstance().getStoredProc();
        assertEquals(getSchema(), jdbcCall.getSchemaName());
        assertEquals(getCataglog(), jdbcCall.getCatalogName());
        assertEquals(getFunction(), jdbcCall.getProcedureName());
        List<SqlParameter> declaredParameters = (List<SqlParameter>) ReflectionTestUtils.getField(jdbcCall, "declaredParameters");
        for(SqlParameter declaredParam: declaredParameters){
            assertThat(getExpectedParameters(), hasItem(declaredParam.getName()));
        }
    }

    protected void checkKeys(Map<String, Object> params) {
        List<String> expectedParams = getExpectedParameters();
        assertTrue(params.size() == expectedParams.size());
        for(String key: params.keySet()){
            assertThat(expectedParams, hasItem(key));
        }
    }
}
