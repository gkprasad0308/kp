package lds.personservice.contactinfo.email;

import com.fasterxml.jackson.core.JsonParser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EmailDeserializerTest {

    @Mock
    private JsonParser parser;

    private EmailDeserializer deserializer;

    @Before
    public void setup(){
        deserializer = new EmailDeserializer();
    }

    @Test(expected = IllegalArgumentException.class)
    public void deserializeThrowsExceptionIfUnexpectedValue() throws IOException {
        when(parser.getValueAsString()).thenReturn("jill");
        deserializer.deserialize(parser, null);
    }

    @Test
    public void deserializeReturnsExpectedValue() throws IOException {
        when(parser.getValueAsString()).thenReturn(EmailTypes.EMAIL_FAMILY.name().toLowerCase());
        EmailTypes type = deserializer.deserialize(parser, null);
        assertEquals(EmailTypes.EMAIL_FAMILY, type);
    }
}
