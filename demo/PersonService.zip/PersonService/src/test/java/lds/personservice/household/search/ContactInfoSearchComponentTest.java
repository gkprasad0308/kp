package lds.personservice.household.search;


import lds.personservice.contactinfo.ContactInfoRowMapper;
import lds.personservice.household.InclusionParams;
import lds.personservice.household.ListParams;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class ContactInfoSearchComponentTest {

    private SearchComponent component;

    @Before
    public void setup(){
        component = new ContactInfoSearchComponent("p");
    }

    @Test
    public void buildFragmentReturnsNullWithNullListParams(){
        assertNull(component.buildFragment(null));
    }

    @Test
    public void buildFragmentReturnsNullWithEmptyInclusions(){
        ListParams params = new ListParams();
        params.setInclusions("");
        assertNull(component.buildFragment(params));
    }

    @Test
    public void buildFragmentReturnsNullWithNonContactInfoInclusions(){
        ListParams params = new ListParams();
        List<String> inclusionParamses = Arrays.asList(InclusionParams.DROP_NOTES.name(), InclusionParams.FELLOWSHIPPERS.name(), InclusionParams.REFERRAL_INFO.name(), InclusionParams.COMMITMENTS.name());
        params.setInclusions( String.join(",", inclusionParamses) );
        assertNull(component.buildFragment(params));
    }

    @Test
    public void buildFragmentReturnsExpected(){
        ListParams params = new ListParams();
        params.setInclusions(InclusionParams.CONTACT_INFO.name());

        SearchFragment fragment = component.buildFragment(params);
        assertNotNull(fragment);
        assertFalse(fragment.isEmpty());
        assertEquals(ContactInfoRowMapper.getSelectStatement(), fragment.getSelectFragment());
        assertEquals(ContactInfoRowMapper.getJoinStatement("p"), fragment.getFromFragment());
    }
}
