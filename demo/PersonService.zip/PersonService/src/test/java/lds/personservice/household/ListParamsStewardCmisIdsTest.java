package lds.personservice.household;

import java.util.List;

public class ListParamsStewardCmisIdsTest extends AbstractListParamsTest {
    @Override
    protected void callParser(String value) {
        listParams.parseStewardCmisIds(value);
    }

    @Override
    protected List<Long> getValues() {
        return listParams.getStewardCmisIds();
    }

    @Override
    protected String getFieldName() {
        return "stewardCmisIds";
    }
}
