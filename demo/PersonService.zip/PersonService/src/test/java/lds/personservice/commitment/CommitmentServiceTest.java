package lds.personservice.commitment;

import lds.personservice.person.Person;
import lds.personservice.person.PersonRepository;
import lds.prsms.utils.errors.ServiceException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CommitmentServiceTest {

    @InjectMocks
    private CommitmentService commitmentService;

    @Mock
    private CommitmentRepository mockRepository;

    @Mock
    private PersonRepository mockPersonRepository;

    @Mock
    Commitment mockCommitment;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testDelete() {
        mockCommitment.setDeleted(false);
        when(mockCommitment.getId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("1");
        when(mockCommitment.getPersonId()).thenReturn(1L);
        when(mockRepository.findByClientGuid(anyString())).thenReturn(mockCommitment);

        Commitment response = commitmentService.deleteCommitment("1");
        // assertEquals("Wrong status code", NO_CONTENT.toString(),
        // response.getStatusCode().toString());
    }

    @Test(expected = ServiceException.class)
    public void testDeleteNullResult() {
        when(mockRepository.findById(anyLong())).thenReturn(null);
        Commitment response = commitmentService.deleteCommitment("-1L");
        // assertEquals("Wrong status code", NOT_FOUND.toString(),
        // response.getStatusCode().toString());
    }

    @Test(expected = ServiceException.class)
    public void testDeleteNull() {
        Commitment response = commitmentService.deleteCommitment(null);
        // String result = (String)response.getBody();
        // assertEquals("Wrong Message", "error.delete.commitment.commitmentId",
        // result);
        // assertEquals("Wrong Status Code", HttpStatus.BAD_REQUEST.toString(),
        // response.getStatusCode().toString());

    }

    @Test
    public void testCreate() {
        when(mockCommitment.getId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("1");
        when(mockCommitment.getPersonId()).thenReturn(1L);
        when(mockCommitment.getPersonGuid()).thenReturn("MockGuid");
        when(mockCommitment.getClientGuid()).thenReturn("one");
        when(mockRepository.findByClientGuid(anyString())).thenReturn(null);
        when(mockRepository.save(any(Commitment.class))).thenReturn(mockCommitment);

        Commitment response = commitmentService.createCommitment(mockCommitment);
        // assertEquals("Wrong status code", OK.toString(),
        // response.getStatusCode().toString());
    }

    @Test(expected = ServiceException.class)
    public void testCreateNull() {
        when(mockCommitment.getId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("1");
        when(mockCommitment.getPersonId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("one");

        when(mockRepository.findByClientGuid(anyString())).thenReturn(null);
        when(mockRepository.save(any(Commitment.class))).thenReturn(mockCommitment);

        Commitment response = commitmentService.createCommitment(null);
        // String result = (String)response.getBody();
        // assertEquals("Wrong Message", "error.post.commitment.noEntity",
        // result);
        // assertEquals("Wrong status code", HttpStatus.BAD_REQUEST.toString(),
        // response.getStatusCode().toString());
    }

    @Test(expected = ServiceException.class)
    public void testCreateWithDuplicateGuid() {
        when(mockCommitment.getId()).thenReturn(1L);
        when(mockCommitment.getPersonId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("one");

        when(mockRepository.findByClientGuid(anyString())).thenReturn(mockCommitment);
        when(mockRepository.save(any(Commitment.class))).thenReturn(mockCommitment);

        Commitment response = commitmentService.createCommitment(mockCommitment);
        // String result = (String)response.getBody();
        // assertEquals("Wrong
        // message","error.post.commitment.duplicate.clientGuid",result);
        // assertEquals("Wrong status code", NOT_ACCEPTABLE.toString(),
        // response.getStatusCode().toString());
    }

    @Ignore
    public void testCreateWithDuplicatePersonAndTeaching() {
        try {
            when(mockCommitment.getId()).thenReturn(1L);
            when(mockCommitment.getPersonId()).thenReturn(1L);
            when(mockCommitment.getTeachingItemId()).thenReturn(1L);
            when(mockCommitment.getClientGuid()).thenReturn("one");

            when(mockRepository.findByClientGuid(anyString())).thenReturn(null);
            when(mockRepository.findByPersonAndTeachingItem(anyLong(), anyLong())).thenReturn(mockCommitment);
            when(mockRepository.save(any(Commitment.class))).thenReturn(mockCommitment);

            Commitment response = commitmentService.createCommitment(mockCommitment);
            // Commitment result = (Commitment)response.getBody();
            // assertNotNull(result);
        } catch (Exception e) {
            fail("Exception thrown");
        }
    }

    @Test
    public void testCreateWithEmptyGuid() {
        // can't serialize a mock object for hashkey generation
        Commitment c = new Commitment();
        c.setId(1L);
        c.setPersonId(1L);
        c.setPersonGuid("meh");
        c.setClientGuid("");
        c.setWasKept(true);
        c.setTeachingItemId(1L);
        c.setInviteDate(System.currentTimeMillis());
        c.setWasKept(false);
        // allow the repository to pass the two duplicate checks
        when(mockRepository.findByClientGuid(anyString())).thenReturn(null);
        when(mockRepository.findByPersonAndTeachingItem(anyLong(), anyLong())).thenReturn(null);
        when(mockRepository.save(any(Commitment.class))).thenReturn(c);

        Commitment response = commitmentService.createCommitment(c);
        // assertEquals("Wrong status code", OK.toString(),
        // response.getStatusCode().toString());
    }

    @Test(expected = RuntimeException.class)
    public void testCreateWithException() {
        when(mockCommitment.getId()).thenReturn(1L);
        when(mockCommitment.getPersonId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("one");
        // allow the repository to pass the two duplicate checks
        when(mockRepository.findByClientGuid(anyString())).thenThrow(new RuntimeException("test"));

        Commitment response = commitmentService.createCommitment(mockCommitment);
        // String result = (String)response.getBody();
        // assertEquals("Wrong
        // message","error.post.commitment.exception",result);
        // assertEquals("Wrong status code", INTERNAL_SERVER_ERROR.toString(),
        // response.getStatusCode().toString());
    }

    @Test
    public void testUpdate() {
        when(mockCommitment.getId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("1");
        when(mockCommitment.getPersonId()).thenReturn(1L);
        when(mockCommitment.getPersonGuid()).thenReturn("fox");
        when(mockCommitment.getClientGuid()).thenReturn("one");
        when(mockCommitment.getTeachingItemId()).thenReturn(1L);
        when(mockRepository.findByClientGuid(anyString())).thenReturn(mockCommitment);
        when(mockRepository.findByPersonAndTeachingItem(anyLong(), anyLong())).thenReturn(null);
        when(mockRepository.save(any(Commitment.class))).thenReturn(mockCommitment);

        Commitment response = commitmentService.updateCommitment(mockCommitment, "1L");
        // assertEquals("Wrong status code", OK.toString(),
        // response.getStatusCode().toString());
    }

    @Test(expected = ServiceException.class)
    public void testUpdateNull() {
        when(mockCommitment.getId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("1");
        when(mockCommitment.getPersonId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("one");

        when(mockRepository.findByClientGuid(anyString())).thenReturn(null);
        when(mockRepository.findById(anyLong())).thenReturn(mockCommitment);
        when(mockRepository.save(any(Commitment.class))).thenReturn(mockCommitment);

        Commitment response = commitmentService.updateCommitment(null, "1L");
        // String result = (String)response.getBody();
        // assertEquals("Wrong Message", "error.put.commitment.noEntity",
        // result);
        // assertEquals("Wrong status code", HttpStatus.BAD_REQUEST.toString(),
        // response.getStatusCode().toString());

    }

    @Test(expected = ServiceException.class)
    public void testUpdateDeleted() {
        when(mockCommitment.getId()).thenReturn(1L);
        when(mockCommitment.getPersonId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("bannana");
        when(mockCommitment.getDeleted()).thenReturn(true);

        when(mockRepository.findById(anyLong())).thenReturn(mockCommitment);

        Commitment response = commitmentService.updateCommitment(mockCommitment, "1L");
        // String result = (String)response.getBody();
        // assertEquals("Wrong
        // message","error.put.commitment.not.found",result);
        // assertEquals("Wrong status code", NOT_FOUND.toString(),
        // response.getStatusCode().toString());
    }

    @Test(expected = RuntimeException.class)
    public void testUpdateWithException() {
        when(mockCommitment.getId()).thenReturn(1L);
        when(mockCommitment.getPersonId()).thenReturn(1L);
        when(mockCommitment.getClientGuid()).thenReturn("one");
        // allow the repository to pass the two duplicate checks
        when(mockRepository.findByClientGuid(anyString())).thenThrow(new RuntimeException("test"));

        Commitment response = commitmentService.updateCommitment(mockCommitment, "1L");
        // String result = (String)response.getBody();
        // assertEquals("Wrong
        // message","error.put.commitment.exception",result);
        // assertEquals("Wrong status code", INTERNAL_SERVER_ERROR.toString(),
        // response.getStatusCode().toString());
    }

    @Test
    public void testUpdateWithEmptyGuid() {
        // can't serialize a mock object for hashkey generation
        Commitment c = new Commitment();
        c.setId(1L);
        c.setPersonId(1L);
        c.setPersonGuid("guid");
        c.setClientGuid("");
        c.setWasKept(true);
        // allow the repository to pass the two duplicate checks
        when(mockRepository.findByClientGuid(anyString())).thenReturn(mockCommitment);
        when(mockRepository.findByPersonAndTeachingItem(anyLong(), anyLong())).thenReturn(null);
        when(mockRepository.save(any(Commitment.class))).thenReturn(c);

        Commitment response = commitmentService.updateCommitment(c, "1L");
        // assertEquals("Wrong status code", OK.toString(),
        // response.getStatusCode().toString());
    }

    @Test
    public void testCompleteCommitmentNullPersonGuid() {
        Long personId = 6543231l;
        Long mockId = 123456l;
        String personGuid = "MockPersonGUid";
        String commitmentGuid = "01234567890123456789012345678901";
        Commitment resultCommitment = new Commitment();
        resultCommitment.setClientGuid(commitmentGuid);
        resultCommitment.setDeleted(false);
        resultCommitment.setId(mockId);
        resultCommitment.setInviteDate(1000l);
        resultCommitment.setKeptDate(1000l);
        resultCommitment.setModifiedDate(1000l);
        resultCommitment.setPersonGuid(null);
        resultCommitment.setPersonId(personId);
        resultCommitment.setTeachingItemId(1l);
        resultCommitment.setWasKept(true);

        Person resultPerson = new Person();
        resultPerson.setServerId(personId);
        resultPerson.setGuid(personGuid);

        when(mockRepository.save(any(Commitment.class))).thenReturn(resultCommitment);
        when(mockRepository.findByClientGuid(any(String.class))).thenReturn(resultCommitment);
        when(mockPersonRepository.getPersonById(personId)).thenReturn(resultPerson);

        Commitment result = commitmentService.deleteCommitment(commitmentGuid);

        Assert.assertEquals("Should be the mock result", (long) mockId, (long) result.getId());
        Assert.assertEquals("Should have filled in personGuid in complete", personGuid, result.getPersonGuid());
        Assert.assertEquals("Should have not changed person id", (long) personId, (long) result.getPersonId());
    }

    @Test
    public void testCompleteCommitmentNullPersonId() {
        Long personId = 6543231l;
        Long mockId = 123456l;
        String personGuid = "MockPersonGUid";
        String commitmentGuid = "01234567890123456789012345678901";
        Commitment resultCommitment = new Commitment();
        resultCommitment.setClientGuid(commitmentGuid);
        resultCommitment.setDeleted(false);
        resultCommitment.setId(mockId);
        resultCommitment.setInviteDate(1000l);
        resultCommitment.setKeptDate(1000l);
        resultCommitment.setModifiedDate(1000l);
        resultCommitment.setPersonGuid(personGuid);
        resultCommitment.setPersonId(null);
        resultCommitment.setTeachingItemId(1l);
        resultCommitment.setWasKept(true);

        Person resultPerson = new Person();
        resultPerson.setServerId(personId);
        resultPerson.setGuid(personGuid);

        when(mockRepository.save(any(Commitment.class))).thenReturn(resultCommitment);
        when(mockRepository.findByClientGuid(any(String.class))).thenReturn(resultCommitment);
        when(mockPersonRepository.getPersonIdByGuid(personGuid)).thenReturn(personId);

        Commitment result = commitmentService.deleteCommitment(commitmentGuid);

        Assert.assertNotNull("Should have a result", result);
        Assert.assertEquals("Should be the mock result", (long) mockId, (long) result.getId());
        Assert.assertEquals("Should have not changed personGuid in complete", personGuid, result.getPersonGuid());
        Assert.assertEquals("Should have filled in person id", (long) personId, (long) result.getPersonId());
    }

    @Test
    public void testCompleteCommitmentNull() {
        Long personId = 6543231l;
        Long mockId = 123456l;
        String personGuid = "MockPersonGUid";
        String commitmentGuid = "01234567890123456789012345678901";
        Commitment resultCommitment = new Commitment();
        resultCommitment.setClientGuid(commitmentGuid);
        resultCommitment.setDeleted(false);
        resultCommitment.setId(mockId);
        resultCommitment.setInviteDate(1000l);
        resultCommitment.setKeptDate(1000l);
        resultCommitment.setModifiedDate(1000l);
        resultCommitment.setPersonGuid(personGuid);
        resultCommitment.setPersonId(null);
        resultCommitment.setTeachingItemId(1l);
        resultCommitment.setWasKept(true);

        Person resultPerson = new Person();
        resultPerson.setServerId(personId);
        resultPerson.setGuid(personGuid);

        when(mockRepository.save(any(Commitment.class))).thenReturn(null);
        when(mockRepository.findByClientGuid(any(String.class))).thenReturn(resultCommitment);
        when(mockPersonRepository.getPersonIdByGuid(personGuid)).thenReturn(personId);

        Commitment result = commitmentService.deleteCommitment(commitmentGuid);

        Assert.assertNull("Should have a null result", result);
    }
}
