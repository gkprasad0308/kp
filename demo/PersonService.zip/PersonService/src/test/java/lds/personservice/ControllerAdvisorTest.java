package lds.personservice;

import lds.personservice.util.validation.ValidationException;
import lds.personservice.util.validation.ValidationResult;
import lds.prsms.utils.validation.ValidationError;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ControllerAdvisorTest {

    private ControllerAdvisor controllerAdvisor;

    @Before
    public void setup(){
        controllerAdvisor = new ControllerAdvisor();
    }

    @Test
    public void handleValidationError_happy_path(){
        ValidationException exception = new ValidationException(new lds.prsms.utils.validation.FieldError("test.field", "test.code"));
        ValidationError validationError = controllerAdvisor.handleValidationError(exception);

        assertTrue(validationError.getFieldErrors().size() == 1);
        lds.prsms.utils.validation.FieldError error = validationError.getFieldErrors().get(0);
        assertEquals("test.code", error.getCode());
        assertEquals("test.field", error.getField());
    }

    @Test
    public void handleMethodArgumentNotValidException_happy_path(){
        BindingResult bindingResult = mock(BindingResult.class);
        MethodArgumentNotValidException exception = mock(MethodArgumentNotValidException.class);
        MethodParameter methodParameter = mock(MethodParameter.class);
        HttpServletRequest request = mock(HttpServletRequest.class);

        ObjectError objectError = new ObjectError("person", "invalidStuff");
        FieldError fieldError = new FieldError("person", "name", "invalidName");
        when(bindingResult.getGlobalErrors()).thenReturn(Arrays.asList(objectError));
        when(bindingResult.getFieldErrors()).thenReturn(Arrays.asList(fieldError));
        when(methodParameter.getParameterName()).thenReturn("person");
        when(exception.getBindingResult()).thenReturn(bindingResult);
        when(exception.getParameter()).thenReturn(methodParameter);
        when(request.getMethod()).thenReturn("POST");

        ResponseEntity<ValidationResult> response = controllerAdvisor.handleMethodArgumentNotValidException(request, exception);

        assertEquals("Expected a bad request result", HttpStatus.BAD_REQUEST, response.getStatusCode());
        ValidationResult result = response.getBody();
        assertEquals("Expected validation results status to be bad request", HttpStatus.BAD_REQUEST, result.getStatus());
        assertEquals("Expected validation results to have the code of valitaion.errors", "validation.errors", result.getCode());
        assertTrue("Expected validation results to have exactly one field error", !CollectionUtils.isEmpty(result.getFieldErrors()) && result.getFieldErrors().size() == 1);
        assertTrue("Expected validation results to have exactly one global error", !CollectionUtils.isEmpty(result.getGlobalErrors()) && result.getGlobalErrors().size() == 1);

        assertEquals("error.post.person.invalidStuff", result.getGlobalErrors().get(0));

        lds.prsms.utils.validation.FieldError error = result.getFieldErrors().get(0);
        assertEquals("name", error.getField());
        assertEquals("error.post.person.invalidName.name", error.getCode());
    }

}
