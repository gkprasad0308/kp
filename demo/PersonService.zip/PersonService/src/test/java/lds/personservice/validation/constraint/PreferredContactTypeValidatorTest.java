package lds.personservice.validation.constraint;

import lds.personservice.util.validation.constraint.PreferredContactTypeValidator;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PreferredContactTypeValidatorTest {

    @InjectMocks
    private PreferredContactTypeValidator validator;

    @Mock
    private OptionsValidationService validationService;

    @Mock
    private ConstraintValidatorContext context;

    @Test
    public void isValid_returns_true_with_null(){
        assertTrue(validator.isValid(null, context));
    }

    @Test
    public void isValid_returns_true_when_service_returns_true(){
        when(validationService.contactTypeExists(1)).thenReturn(true);
        assertTrue(validator.isValid(1, context));
        verify(validationService, times(1)).contactTypeExists(1);
    }

    @Test
    public void isValid_returns_false_when_service_returns_false(){
        when(validationService.contactTypeExists(1)).thenReturn(false);
        assertFalse(validator.isValid(1, context));
        verify(validationService, times(1)).contactTypeExists(1);
    }
}
