package lds.personservice.person.builder;

import lds.personservice.commitment.Commitment;
import lds.personservice.commitment.CommitmentRepository;
import lds.personservice.household.InclusionParams;
import lds.personservice.person.Person;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;
import static org.mockito.Matchers.anyList;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PeopleCommitmentBuilderTest {
    @InjectMocks
    private PeopleCommitmentBuilder builder;

    @Mock
    private CommitmentRepository repository;

    @Test
    public void appliesToBuilderReturnsTrueIfParamsHasCommitments(){
        BuilderParams params = new BuilderParams();
        params.setInclusions(Arrays.asList(InclusionParams.COMMITMENTS));
        assertTrue(builder.appliesToBuilder(params));
    }

    @Test
    public void appliesTobuilderReturnsFalseIfParamsDoesNotHaveCommitments(){
        List<InclusionParams> incParams = InclusionParams.valuesAsList().stream().filter(param -> param != InclusionParams.COMMITMENTS).collect(Collectors.toList());
        BuilderParams params = new BuilderParams();
        params.setInclusions(incParams);
        assertFalse(builder.appliesToBuilder(params));
    }

    @Test
    public void buildAppendsCommitmentsToPeople(){
        Person person = new Person();
        person.setServerId(123L);

        Person person2 = new Person();
        person2.setServerId(456L);

        Commitment commitment = new Commitment();
        commitment.setPersonId(123L);

        Commitment commitment2 = new Commitment();
        commitment2.setPersonId(456L);

        when(repository.findByPeople(anyList())).thenReturn(Arrays.asList(commitment, commitment2));
        List<Person> results = builder.build(Arrays.asList(person, person2));
        assertTrue(results.size() == 2);
        assertThat(results, hasItem(person));
        assertThat(results, hasItem(person2));
        assertThat(person.getCommitments(), contains(commitment));
        assertThat(person2.getCommitments(), contains(commitment2));
    }

    @Test
    public void buildReturnsNullIfNullPassedIn(){
        assertNull(builder.build(null));
        verifyZeroInteractions(repository);
    }

    @Test
    public void buildReturnsEmptyIfEmptyPassedIn(){
        List<Person> people = new LinkedList<>();
        assertEquals(people, builder.build(people));
        verifyZeroInteractions(repository);
    }
}
