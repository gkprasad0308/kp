package lds.personservice.person;

import lds.personservice.AbstractSimpleSprocTest;
import lds.personservice.util.SimpleSproc;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class CalcStatusSprocTest extends AbstractSimpleSprocTest{

    @InjectMocks
    private CalcStatusSproc sproc;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            CalcStatusSproc.I_NEW_MOD_DT,
            CalcStatusSproc.PERSON_IDS
    );

    @Override
    protected String getSchema() {
        return CalcStatusSproc.SCHEMA_NAME;
    }

    @Override
    protected String getCataglog() {
        return CalcStatusSproc.CATALOG_NAME;
    }

    @Override
    protected String getFunction() {
        return CalcStatusSproc.PROCEDURE_NAME;
    }

    @Override
    protected SimpleSproc getInstance() {
        return sproc;
    }

    @Override
    protected List<String> getExpectedParameters() {
        return expectedParams;
    }

    @Test
    public void getParametersUsingDoesExpected(){
        MapSqlParameterSource params = sproc.getParametersUsing("abc,def");
        checkKeys(params.getValues());

        assertEquals("abc,def", params.getValue(CalcStatusSproc.PERSON_IDS));
        assertNotNull(params.getValue(CalcStatusSproc.I_NEW_MOD_DT));
    }
}
