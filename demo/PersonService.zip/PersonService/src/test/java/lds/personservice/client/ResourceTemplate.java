/*
 * Copyright (C) 2015 Intellectual Reserve, Inc. All rights reserved.
 * This notice may not be removed.
 */
package lds.personservice.client;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.Set;

import lds.stack.spring.web.Request;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import static lds.stack.collections.HashSets.newSet;

/**
 * A template super-class for consuming REST resources. This class preserves cookie state between requests.
 *
 * @param <T> the implementation type
 *
 * @author Robert Thornton
 */
public abstract class ResourceTemplate<T extends ResourceTemplate<T>> {

    private final Set<String> cookies = newSet();

    private String csrfHeader;
    private String csrfParam;
    private String csrfToken;
    @Value("${basic-auth.username}")
    private String user;
    @Value("${basic-auth.password}")
    private String password;

    protected <T> ResponseEntity<T> followRedirects(ResponseEntity<T> response, Class<T> resultType) {
        ResponseEntity<T> responseEntity = response;
        while (responseEntity.getStatusCode().is3xxRedirection()) {
            cookies.addAll(responseEntity.getHeaders().get("Set-Cookie"));
            String tmpCsrfHeader = responseEntity.getHeaders().getFirst("X-CSRF-HEADER");
            String tmpCsrfParam = responseEntity.getHeaders().getFirst("X-CSRF-PARAM");
            if (tmpCsrfHeader != null) {
                String tmpCsrfToken = responseEntity.getHeaders().getFirst(tmpCsrfHeader);
                if (tmpCsrfToken != null) {
                    csrfHeader = tmpCsrfHeader;
                    csrfParam = tmpCsrfParam;
                    csrfToken = tmpCsrfToken;
                }
            }
            responseEntity = new Request()
                  .uri(responseEntity.getHeaders().getLocation())
                  .header("Cookie", cookies)
                  .get(resultType);
        }
        return responseEntity;
    }

    protected static String encode(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            throw new AssertionError(ex.getMessage(), ex);
        }
    }

    public HttpHeaders constructDefaultHeaders(String contentType) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Basic " + getAuth());
        return httpHeaders;
    }

    public String getAuth() {
        String auth = user + ":" + password;
        auth = Base64.encodeBase64String(auth.getBytes());
        return auth;
    }

    public <T> ResponseEntity<T> sendRequestIgnoreError(String url, HttpMethod method, HttpEntity<? extends Object> request, Class<T> unmarshalledType) {
        RestTemplate template = new RestTemplate();
        template.setErrorHandler(new DefaultResponseErrorHandler() {
            @Override
            protected boolean hasError(HttpStatus statusCode) {
                return false;
            }
        });
        return followRedirects(template.exchange(url, method, request, unmarshalledType), unmarshalledType);
    }

    public <T> ResponseEntity<T> sendRequest(String url, HttpMethod method, HttpEntity<? extends Object> request, Class<T> unmarshalledType) {
        RestTemplate template = new RestTemplate();
        return followRedirects(template.exchange(url, method, request, unmarshalledType), unmarshalledType);
    }

    public ResponseEntity<?> sendRequest(String url, HttpMethod method, HttpEntity<? extends Object> request) {
        RestTemplate template = new RestTemplate();
        return followRedirects(template.exchange(url, method, request, Void.class), Void.class);
    }

    public String getCsrfHeader() {
        return csrfHeader;
    }

    public String getCsrfParam() {
        return csrfParam;
    }

    public String getCsrfToken() {
        return csrfToken;
    }

    public abstract URI getResourceUri();

    public abstract String getResourceUriAsString();

    public Set<String> getCookies()
    {
        return Collections.unmodifiableSet(cookies);
    }

    public void reset() {
        cookies.clear();
        csrfHeader = null;
        csrfParam = null;
        csrfToken = null;
    }
}
