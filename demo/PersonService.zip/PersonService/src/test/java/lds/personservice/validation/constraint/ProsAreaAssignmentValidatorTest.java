package lds.personservice.validation.constraint;

import lds.personservice.missionorg.Entity;
import lds.personservice.missionorg.MissionOrgService;
import lds.personservice.person.Person;
import lds.personservice.util.validation.constraint.ProsAreaAssignmentValidator;
import lds.personservice.util.validation.service.HouseholdValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProsAreaAssignmentValidatorTest {

    @InjectMocks
    private ProsAreaAssignmentValidator validator;

    @Mock
    private HouseholdValidationService householdService;

    @Mock
    private MissionOrgService missionOrgService;

    @Test
    public void isValidIsTrueIfNullPerson(){
        assertTrue(validator.isValid(null, null));
    }

    @Test
    public void isValidIsTrueWithEmptyHouseholdId(){
        assertTrue(validator.isValid(new Person(), null));
    }

    @Test
    public void isValidIsTrueWithNullProsAreaId(){
        when(householdService.getHouseholdOrgId("abc")).thenReturn(456L);
        assertTrue(validator.isValid(createPerson(null), null));
    }

    @Test
    public void isValidIsTrueIfOrgIsNull(){
        when(householdService.getHouseholdOrgId("abc")).thenReturn(null);
        assertTrue(validator.isValid(createPerson(123L), null));
    }

    @Test
    public void isValidIsFalseIfEntityHasNoMatchingChildIds(){
        when(missionOrgService.getOrgUnitsForArea(123L)).thenReturn(createEntityWithChildren(123L, 3L, 4L, 5L));
        when(householdService.getHouseholdOrgId("abc")).thenReturn(456L);
        assertFalse(validator.isValid(createPerson(123L), null));
    }

    @Test
    public void isValidIsTrueIfEntityHasMatchingChildId(){
        when(missionOrgService.getOrgUnitsForArea(123L)).thenReturn(createEntityWithChildren(123L, 3L, 4L, 5L, 456L));
        when(householdService.getHouseholdOrgId("abc")).thenReturn(456L);
        assertTrue(validator.isValid(createPerson(123L), null));
    }

    @Test
    public void isValidIsTrueIfGrandChildHasMatchingId(){
        Entity prosArea = createEntityWithChildren(123L, 1L, 2L, 3L);
        prosArea.addChild( createEntityWithChildren(4L, 5L, 456L));
        when(missionOrgService.getOrgUnitsForArea(123L)).thenReturn(prosArea);
        when(householdService.getHouseholdOrgId("abc")).thenReturn(456L);
        assertTrue(validator.isValid(createPerson(123L), null));
    }

    @Test
    public void isValidIsTrueIfMissionOrgServiceReturnsNullEntity(){
        when(missionOrgService.getOrgUnitsForArea(123L)).thenReturn(null);
        assertFalse(validator.isValid(createPerson(123L), null));
    }

    @Test
    public void isValidIsFalseIfMissionOrgServiceReturnsEntityWithNoChildren(){
        when(missionOrgService.getOrgUnitsForArea(123L)).thenReturn(new Entity());
        assertFalse(validator.isValid(createPerson(123L), null));
    }

    private Entity createEntityWithChildren(long entityId, long... childIds) {
        Entity entity = new Entity();
        entity.setId(entityId);

        Entity child;
        for(long childId : childIds){
            child = new Entity();
            child.setId(childId);
            entity.addChild(child);
        }

        return entity;
    }

    private Person createPerson(Long prosAreaId) {
        Person person = new Person();
        person.setHouseholdId("abc");
        person.setProsAreaId(prosAreaId);
        return person;
    }
}
