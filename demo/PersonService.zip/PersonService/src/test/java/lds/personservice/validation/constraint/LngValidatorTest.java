package lds.personservice.validation.constraint;

import lds.personservice.util.validation.constraint.LngValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class LngValidatorTest {

    @Mock
    private ConstraintValidatorContext context;

    private LngValidator validator;

    @Before
    public void setup(){
        validator = new LngValidator();
    }

    @Test
    public void isValidIfNoLng(){
        assertTrue(validator.isValid(null, context));
    }

    @Test
    public void isValidIfNUmber(){
        assertTrue(validator.isValid("50", context));
    }

    @Test
    public void isValidIfNegative(){
        assertTrue(validator.isValid("-25", context));
    }

    @Test
    public void isValidIfZero(){
        assertTrue(validator.isValid("0", context));
    }

    @Test
    public void isValidIfDecimal(){
        assertTrue(validator.isValid("34.34535", context));
    }

    @Test
    public void isInvalidIfEmptyLng(){
        assertFalse(validator.isValid("", context));
    }

    @Test
    public void isInvalidIfNonNumeric(){
        assertFalse(validator.isValid("bob", context));
    }

    @Test
    public void isInvalidIf180(){
        assertFalse(validator.isValid("180", context));
    }

    @Test
    public void isInvalidIfGreaterThan180(){
        assertFalse(validator.isValid("181", context));
    }

    @Test
    public void isInvalidIfNegative180(){
        assertFalse(validator.isValid("-180", context));
    }

    @Test
    public void isInvalidIfLessThanNegative180(){
        assertFalse(validator.isValid("-181", context));
    }

}
