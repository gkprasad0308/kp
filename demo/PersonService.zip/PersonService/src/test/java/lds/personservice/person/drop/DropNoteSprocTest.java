package lds.personservice.person.drop;


import lds.personservice.AbstractSimpleSprocTest;
import lds.personservice.util.SimpleSproc;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DropNoteSprocTest extends AbstractSimpleSprocTest {

    @InjectMocks
    private DropNoteSproc sproc;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            DropNoteSproc.PERSON_ID,
            DropNoteSproc.STATUS_ID,
            DropNoteSproc.MOD_DT,
            DropNoteSproc.DTL_NOTE,
            DropNoteSproc.DTL_ALERT_DT,
            DropNoteSproc.DTL_CLIENT_GUID
    );

    @Override
    protected String getSchema() {
        return DropNoteSproc.SCHEMA_NAME;
    }

    @Override
    protected String getCataglog() {
        return DropNoteSproc.CATALOG_NAME;
    }

    @Override
    protected String getFunction() {
        return DropNoteSproc.FUNCTION_NAME;
    }

    @Override
    protected SimpleSproc getInstance() {
        return sproc;
    }

    @Override
    protected List<String> getExpectedParameters() {
        return expectedParams;
    }

    @Test
    public void getParametersUsingDoesExpected(){
        Date date = new Date(System.currentTimeMillis());
        WritableDropNote dropNote = mock(WritableDropNote.class);
        when(dropNote.getStatus()).thenReturn(1);
        when(dropNote.getNote()).thenReturn("note");
        when(dropNote.getAlertDate()).thenReturn(date);

        MapSqlParameterSource mapSqlParameterSource = (MapSqlParameterSource) sproc.getParametersUsing(123L, dropNote);
        checkKeys(mapSqlParameterSource.getValues());
        assertEquals(123L, mapSqlParameterSource.getValue(DropNoteSproc.PERSON_ID));
        assertEquals(1, mapSqlParameterSource.getValue(DropNoteSproc.STATUS_ID));
        assertEquals("note", mapSqlParameterSource.getValue(DropNoteSproc.DTL_NOTE));
        assertEquals(date, mapSqlParameterSource.getValue(DropNoteSproc.DTL_ALERT_DT));
        assertNotNull(mapSqlParameterSource.getValue(DropNoteSproc.DTL_CLIENT_GUID));
        assertNotNull(mapSqlParameterSource.getValue(DropNoteSproc.MOD_DT));

        verify(dropNote, times(1)).getStatus();
        verify(dropNote, times(1)).getNote();
        verify(dropNote, times(1)).getAlertDate();
        verifyNoMoreInteractions(dropNote);

    }
}
