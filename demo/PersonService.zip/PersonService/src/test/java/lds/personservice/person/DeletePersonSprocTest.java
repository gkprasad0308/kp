package lds.personservice.person;

import lds.personservice.AbstractSimpleSprocTest;
import lds.personservice.util.SimpleSproc;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class DeletePersonSprocTest extends AbstractSimpleSprocTest {

    @InjectMocks
    private DeletePersonSproc sproc;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            DeletePersonSproc.I_PERSON_ID
    );

    @Override
    protected String getSchema() {
        return DeletePersonSproc.SCHEMA_NAME;
    }

    @Override
    protected String getCataglog() {
        return DeletePersonSproc.CATALOG_NAME;
    }

    @Override
    protected String getFunction() {
        return DeletePersonSproc.PROCEDURE_NAME;
    }

    @Override
    protected SimpleSproc getInstance() {
        return sproc;
    }

    @Override
    protected List<String> getExpectedParameters() {
        return expectedParams;
    }

    @Test
    public void getParametersUsingDoesExpected(){
        MapSqlParameterSource params = sproc.getParametersUsing(123L);
        checkKeys(params.getValues());
        assertEquals(123L, params.getValue(DeletePersonSproc.I_PERSON_ID));
    }
}
