package lds.personservice.options;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class StatusRepositoryTest {

    @InjectMocks
    private StatusRepository repository;

    @Mock
    private JdbcTemplate template;

    @Test
    public void getStatusesForCategoryCallsExpected(){
        List<Status> statuses = new LinkedList<>();
        when(template.query(anyString(), any(Object[].class), any(StatusRowMapper.class))).thenReturn(statuses);
        List<Status> result = repository.getStatusesForCategory(1);
        assertEquals(statuses, result);
        verify(template, times(1)).query(anyString(), any(Object[].class), any(StatusRowMapper.class));
        verifyNoMoreInteractions(template);
    }

    @Test
    public void getOptionsCallsExpected(){
        List<Status> statuses = new LinkedList<>();
        when(template.query(anyString(), any(Object[].class), any(StatusRowMapper.class))).thenReturn(statuses);
        List<Status> result = repository.getOptions(1);
        assertEquals(statuses, result);
        verify(template, times(1)).query(anyString(), any(Object[].class), any(StatusRowMapper.class));
        verifyNoMoreInteractions(template);
    }

    @Test
    public void existsReturnsTrueIfTemplateReturnsGreaterThanZero(){
        //when(template.queryForObject(anyString(), any(Object[].class), any(Class.class))).thenReturn(1);
        assertTrue(repository.exists(0));
    }

    @Test
    public void existsReturnsFalseIfTemplateReturnsZero(){
        //when(template.queryForObject(anyString(), any(Object[].class), any(Class.class))).thenReturn(0);
        assertFalse(repository.exists(0));
    }
}
