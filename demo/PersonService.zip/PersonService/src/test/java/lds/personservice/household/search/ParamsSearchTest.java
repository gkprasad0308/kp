package lds.personservice.household.search;


import lds.personservice.household.ListParams;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class ParamsSearchTest {

    private static final String BASE_SQL = "SELECT h.hshld_id,h.client_guid AS hshld_client_guid,h.addr AS hshld_addr,h.msny_id AS hshld_msny_id,h.org_id AS hshld_org_id,h.stwrd_cmis_id AS hshld_stwrd_cmis_id,h.lat AS hshld_lat,h.lng AS hshld_lng,h.del_yn AS hshld_del_yn,h.pin_drop_yn AS hshld_pin_drop_yn,h.crt_dt AS hshld_crt_dt,h.mod_dt AS hshld_mod_dt,p.person_id,p.hshld_id AS person_hshld_id,p.del_yn AS person_del_yn,p.first_nm AS person_first_nm,p.last_nm AS person_last_nm,p.age_c_id AS person_age_c_id,p.gender AS person_gender,p.person_stat_id,p.crt_dt AS person_crt_dt,p.mod_dt AS person_mod_dt,p.note AS person_note,p.afab_focus_person_yn AS person_afab_focus_person_yn,p.cmis_id AS person_cmis_id,p.pros_area_id AS person_pros_area_id,p.client_guid AS person_client_guid,p.convert_yn AS person_convert_yn,p.find_id AS person_find_id,p.pref_lang_id AS person_pref_lang_id,p.pref_cntct_t_id AS person_pref_cntct_t_id,p.find_dtl_id AS person_find_dtl_id FROM  ( SELECT a.person_id  FROM (SELECT base.person_id, ROW_NUMBER() OVER(PARTITION BY base.person_id ORDER BY ROWNUM) rn  FROM ( SELECT p.person_id\n" +
            "                  FROM hshld_mstr h\n" +
            "                 INNER JOIN person_mstr p\n" +
            "                    ON p.hshld_id = h.hshld_id\n" +
            "                 WHERE 1=1 AND  (  )  UNION ALL SELECT pr.person_id\n" +
            "                  FROM person_rfrl pr\n" +
            "                 INNER JOIN rfrl_grp rg\n" +
            "                    ON rg.rfrl_grp_id = pr.rfrl_grp_id\n" +
            "                 WHERE rg.claim_dt IS NULL AND \n" +
            " (  )  ) base ) a WHERE a.rn = 1  ) root  JOIN  ims.person_mstr p ON root.person_id = p.person_id  JOIN ims.hshld_mstr h  ON h.hshld_id = p.hshld_id WHERE 1=1  AND p.del_yn = :deleted AND h.del_yn = :deleted";

    private static final String PROS_AREA_SQL = "SELECT h.hshld_id,h.client_guid AS hshld_client_guid,h.addr AS hshld_addr,h.msny_id AS hshld_msny_id,h.org_id AS hshld_org_id,h.stwrd_cmis_id AS hshld_stwrd_cmis_id,h.lat AS hshld_lat,h.lng AS hshld_lng,h.del_yn AS hshld_del_yn,h.pin_drop_yn AS hshld_pin_drop_yn,h.crt_dt AS hshld_crt_dt,h.mod_dt AS hshld_mod_dt,p.person_id,p.hshld_id AS person_hshld_id,p.del_yn AS person_del_yn,p.first_nm AS person_first_nm,p.last_nm AS person_last_nm,p.age_c_id AS person_age_c_id,p.gender AS person_gender,p.person_stat_id,p.crt_dt AS person_crt_dt,p.mod_dt AS person_mod_dt,p.note AS person_note,p.afab_focus_person_yn AS person_afab_focus_person_yn,p.cmis_id AS person_cmis_id,p.pros_area_id AS person_pros_area_id,p.client_guid AS person_client_guid,p.convert_yn AS person_convert_yn,p.find_id AS person_find_id,p.pref_lang_id AS person_pref_lang_id,p.pref_cntct_t_id AS person_pref_cntct_t_id,p.find_dtl_id AS person_find_dtl_id FROM  ( SELECT a.person_id  FROM (SELECT base.person_id, ROW_NUMBER() OVER(PARTITION BY base.person_id ORDER BY ROWNUM) rn  FROM ( SELECT p.person_id\n" +
            "                  FROM hshld_mstr h\n" +
            "                 INNER JOIN person_mstr p\n" +
            "                    ON p.hshld_id = h.hshld_id\n" +
            "                 WHERE 1=1 AND  (  p.pros_area_id in (:prosAreaId)  )  UNION ALL SELECT pr.person_id\n" +
            "                  FROM person_rfrl pr\n" +
            "                 INNER JOIN rfrl_grp rg\n" +
            "                    ON rg.rfrl_grp_id = pr.rfrl_grp_id\n" +
            "                 WHERE rg.claim_dt IS NULL AND \n" +
            " (  rg.rcv_pros_area_id IN (:prosAreaId)  )  ) base ) a WHERE a.rn = 1  ) root  JOIN  ims.person_mstr p ON root.person_id = p.person_id  JOIN ims.hshld_mstr h  ON h.hshld_id = p.hshld_id WHERE 1=1  AND p.del_yn = :deleted AND h.del_yn = :deleted";

    private static final String ORG_SQL = "SELECT h.hshld_id,h.client_guid AS hshld_client_guid,h.addr AS hshld_addr,h.msny_id AS hshld_msny_id,h.org_id AS hshld_org_id,h.stwrd_cmis_id AS hshld_stwrd_cmis_id,h.lat AS hshld_lat,h.lng AS hshld_lng,h.del_yn AS hshld_del_yn,h.pin_drop_yn AS hshld_pin_drop_yn,h.crt_dt AS hshld_crt_dt,h.mod_dt AS hshld_mod_dt,p.person_id,p.hshld_id AS person_hshld_id,p.del_yn AS person_del_yn,p.first_nm AS person_first_nm,p.last_nm AS person_last_nm,p.age_c_id AS person_age_c_id,p.gender AS person_gender,p.person_stat_id,p.crt_dt AS person_crt_dt,p.mod_dt AS person_mod_dt,p.note AS person_note,p.afab_focus_person_yn AS person_afab_focus_person_yn,p.cmis_id AS person_cmis_id,p.pros_area_id AS person_pros_area_id,p.client_guid AS person_client_guid,p.convert_yn AS person_convert_yn,p.find_id AS person_find_id,p.pref_lang_id AS person_pref_lang_id,p.pref_cntct_t_id AS person_pref_cntct_t_id,p.find_dtl_id AS person_find_dtl_id FROM  ( SELECT a.person_id  FROM (SELECT base.person_id, ROW_NUMBER() OVER(PARTITION BY base.person_id ORDER BY ROWNUM) rn  FROM ( SELECT p.person_id\n" +
            "                  FROM hshld_mstr h\n" +
            "                 INNER JOIN person_mstr p\n" +
            "                    ON p.hshld_id = h.hshld_id\n" +
            "                 WHERE 1=1 AND  (  h.org_id IN (:orgId)  )  UNION ALL SELECT pr.person_id\n" +
            "                  FROM person_rfrl pr\n" +
            "                 WHERE 1=1 AND   (  pr.owner_org_id IN (:orgId)  )  UNION ALL SELECT pr.person_id\n" +
            "                  FROM person_rfrl pr\n" +
            "                 INNER JOIN rfrl_grp rg\n" +
            "                    ON rg.rfrl_grp_id = pr.rfrl_grp_id\n" +
            "                 WHERE rg.claim_dt IS NULL AND \n" +
            " (  rg.rcv_org_id IN (:orgId)  )  ) base ) a WHERE a.rn = 1  ) root  JOIN  ims.person_mstr p ON root.person_id = p.person_id  JOIN ims.hshld_mstr h  ON h.hshld_id = p.hshld_id WHERE 1=1  AND p.del_yn = :deleted AND h.del_yn = :deleted";

    private static final String STEWARD_SQL = "SELECT h.hshld_id,h.client_guid AS hshld_client_guid,h.addr AS hshld_addr,h.msny_id AS hshld_msny_id,h.org_id AS hshld_org_id,h.stwrd_cmis_id AS hshld_stwrd_cmis_id,h.lat AS hshld_lat,h.lng AS hshld_lng,h.del_yn AS hshld_del_yn,h.pin_drop_yn AS hshld_pin_drop_yn,h.crt_dt AS hshld_crt_dt,h.mod_dt AS hshld_mod_dt,p.person_id,p.hshld_id AS person_hshld_id,p.del_yn AS person_del_yn,p.first_nm AS person_first_nm,p.last_nm AS person_last_nm,p.age_c_id AS person_age_c_id,p.gender AS person_gender,p.person_stat_id,p.crt_dt AS person_crt_dt,p.mod_dt AS person_mod_dt,p.note AS person_note,p.afab_focus_person_yn AS person_afab_focus_person_yn,p.cmis_id AS person_cmis_id,p.pros_area_id AS person_pros_area_id,p.client_guid AS person_client_guid,p.convert_yn AS person_convert_yn,p.find_id AS person_find_id,p.pref_lang_id AS person_pref_lang_id,p.pref_cntct_t_id AS person_pref_cntct_t_id,p.find_dtl_id AS person_find_dtl_id FROM  ( SELECT a.person_id  FROM (SELECT base.person_id, ROW_NUMBER() OVER(PARTITION BY base.person_id ORDER BY ROWNUM) rn  FROM ( SELECT p.person_id\n" +
            "                  FROM hshld_mstr h\n" +
            "                 INNER JOIN person_mstr p\n" +
            "                    ON p.hshld_id = h.hshld_id\n" +
            "                 WHERE 1=1 AND  (  h.stwrd_cmis_id IN (:stwrdCmisId)  )  UNION ALL SELECT pr.person_id\n" +
            "                  FROM person_rfrl pr\n" +
            "                 WHERE 1=1 AND   (  pr.owner_stwrd_cmis_id IN (:stwrdCmisId)  )  UNION ALL SELECT pr.person_id\n" +
            "                  FROM person_rfrl pr\n" +
            "                 INNER JOIN rfrl_grp rg\n" +
            "                    ON rg.rfrl_grp_id = pr.rfrl_grp_id\n" +
            "                 WHERE rg.claim_dt IS NULL AND \n" +
            " (  rg.rcv_stwrd_cmis_id IN (:stwrdCmisId)  )  ) base ) a WHERE a.rn = 1  ) root  JOIN  ims.person_mstr p ON root.person_id = p.person_id  JOIN ims.hshld_mstr h  ON h.hshld_id = p.hshld_id WHERE 1=1  AND p.del_yn = :deleted AND h.del_yn = :deleted";

    private static final String MSNY_SQL = "SELECT h.hshld_id,h.client_guid AS hshld_client_guid,h.addr AS hshld_addr,h.msny_id AS hshld_msny_id,h.org_id AS hshld_org_id,h.stwrd_cmis_id AS hshld_stwrd_cmis_id,h.lat AS hshld_lat,h.lng AS hshld_lng,h.del_yn AS hshld_del_yn,h.pin_drop_yn AS hshld_pin_drop_yn,h.crt_dt AS hshld_crt_dt,h.mod_dt AS hshld_mod_dt,p.person_id,p.hshld_id AS person_hshld_id,p.del_yn AS person_del_yn,p.first_nm AS person_first_nm,p.last_nm AS person_last_nm,p.age_c_id AS person_age_c_id,p.gender AS person_gender,p.person_stat_id,p.crt_dt AS person_crt_dt,p.mod_dt AS person_mod_dt,p.note AS person_note,p.afab_focus_person_yn AS person_afab_focus_person_yn,p.cmis_id AS person_cmis_id,p.pros_area_id AS person_pros_area_id,p.client_guid AS person_client_guid,p.convert_yn AS person_convert_yn,p.find_id AS person_find_id,p.pref_lang_id AS person_pref_lang_id,p.pref_cntct_t_id AS person_pref_cntct_t_id,p.find_dtl_id AS person_find_dtl_id FROM  ( SELECT a.person_id  FROM (SELECT base.person_id, ROW_NUMBER() OVER(PARTITION BY base.person_id ORDER BY ROWNUM) rn  FROM ( SELECT p.person_id\n" +
            "                  FROM hshld_mstr h\n" +
            "                 INNER JOIN person_mstr p\n" +
            "                    ON p.hshld_id = h.hshld_id\n" +
            "                 WHERE 1=1 AND  (  h.msny_id IN (:msnyId)  )  UNION ALL SELECT pr.person_id\n" +
            "                  FROM person_rfrl pr\n" +
            "                 WHERE 1=1 AND   (  pr.owner_msny_id IN (:msnyId)  )  UNION ALL SELECT pr.person_id\n" +
            "                  FROM person_rfrl pr\n" +
            "                 INNER JOIN rfrl_grp rg\n" +
            "                    ON rg.rfrl_grp_id = pr.rfrl_grp_id\n" +
            "                 WHERE rg.claim_dt IS NULL AND \n" +
            " (  rg.rcv_msny_id IN (:msnyId)  )  ) base ) a WHERE a.rn = 1  ) root  JOIN  ims.person_mstr p ON root.person_id = p.person_id  JOIN ims.hshld_mstr h  ON h.hshld_id = p.hshld_id WHERE 1=1  AND p.del_yn = :deleted AND h.del_yn = :deleted";

    @Test(expected = NullPointerException.class)
    public void constructorThrowsWithoutListParams(){
        BaseSearch search = new ParamsSearch(null);
    }

    @Test
    public void getSqlContainsExpectedString(){
        BaseSearch search = new ParamsSearch(new ListParams());
        String sql = search.getSql();
        assertEquals(BASE_SQL, sql);
    }

    @Test
    public void getSqlWithProsAreasContainsExpectedStringAndParams(){
        ListParams params = new ListParams();
        params.parseProsAreas("5500011");
        BaseSearch search = new ParamsSearch(params);
        String sql = search.getSql();
        assertEquals(PROS_AREA_SQL, sql);
        assertThat(search.getSqlParameters().getValues().keySet(), hasItem("prosAreaId"));
        assertThat(search.getSqlParameters().getValues().values(), hasItem(Arrays.asList(5500011L)));
    }

    @Test
    public void getSqlWithOrgsContainsExpectedStringAndParams(){
        ListParams params = new ListParams();
        params.parseOrgIds("55000");
        BaseSearch search = new ParamsSearch(params);
        String sql = search.getSql();
        assertEquals(ORG_SQL, sql);
        assertThat(search.getSqlParameters().getValues().keySet(), hasItem("orgId"));
        assertThat(search.getSqlParameters().getValues().values(), hasItem(Arrays.asList(55000L)));
    }

    @Test
    public void getSqlWithStewardCmisContainsExpectedStringAndParams(){
        ListParams params = new ListParams();
        params.parseStewardCmisIds("55");
        BaseSearch search = new ParamsSearch(params);
        String sql = search.getSql();
        assertEquals(STEWARD_SQL, sql);
        assertThat(search.getSqlParameters().getValues().keySet(), hasItem("stwrdCmisId"));
        assertThat(search.getSqlParameters().getValues().values(), hasItem(Arrays.asList(55L)));
    }

    @Test
    public void getSqlWithMsnyContainsExpectedStringAndParams(){
        ListParams params = new ListParams();
        params.parseMissionaryIds("777");
        BaseSearch search = new ParamsSearch(params);
        String sql = search.getSql();
        assertEquals(MSNY_SQL, sql);
        assertThat(search.getSqlParameters().getValues().keySet(), hasItem("msnyId"));
        assertThat(search.getSqlParameters().getValues().values(), hasItem(Arrays.asList(777L)));
    }
}
