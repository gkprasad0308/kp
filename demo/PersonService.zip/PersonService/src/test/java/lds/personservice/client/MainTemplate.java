package lds.personservice.client;

import java.net.URI;

import lds.stack.spring.web.Request;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.util.MatcherAssertionErrors.assertThat;

@Component
@Scope("prototype")
public class MainTemplate extends ResourceTemplate<MainTemplate> {

	@Value("http://localhost:${local.server.port}${lds.api.resources.serviceDetails.href}") private URI resourceUri;

    public URI getResourceUri() {
        return resourceUri;
    }

    public String getResourceUriAsString(){
        return getResourceUri().toString();
    }

	public <T> T get(String contentType, Class<T> unmarshalledType) {

		Request request = new Request().uri(resourceUri).header("Accept", contentType).header("Cookie", getCookies())
				.header("Authorization", "Basic " + getAuth());
		ResponseEntity<T> response = request.get(unmarshalledType);
		response = followRedirects(response, unmarshalledType);

		// Validate the HTTP response status
		assertThat(response.getStatusCode(), is(HttpStatus.OK));

		// Validate the content type
		assertTrue(MediaType.parseMediaType(contentType).includes(response.getHeaders().getContentType()));

		return response.getBody();
	}
}
