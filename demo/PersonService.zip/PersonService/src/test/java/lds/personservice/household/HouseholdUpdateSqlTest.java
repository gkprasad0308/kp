package lds.personservice.household;

import lds.personservice.AbstractUpdateSqlTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class HouseholdUpdateSqlTest extends AbstractUpdateSqlTest {

    @InjectMocks
    private HouseholdUpdateSql updateSql;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            AbstractHouseholdSqlUpdate.ADDR,
            AbstractHouseholdSqlUpdate.LAT,
            AbstractHouseholdSqlUpdate.LNG,
            AbstractHouseholdSqlUpdate.PIN_DROP,
            AbstractHouseholdSqlUpdate.HOUSEHOLD_ID
    );

    @Override
    protected SqlUpdate getInstance() {
        return updateSql;
    }

    @Override
    protected List<String> getExpectedParams() {
        return expectedParams;
    }

    @Test
    public void getParametersUsingReturnsExpected(){
        Household household = mock(Household.class);
        when(household.getServerId()).thenReturn(123L);
        when(household.getAddress()).thenReturn("address");
        when(household.getLat()).thenReturn("56.78");
        when(household.getLng()).thenReturn("12.34");
        when(household.getPinDropped()).thenReturn(true);

        Map<String, Object> results = updateSql.getParamsUsing(household);
        checkKeys(results);

        assertEquals(123L, results.get(AbstractHouseholdSqlUpdate.HOUSEHOLD_ID));
        assertEquals("address", results.get(AbstractHouseholdSqlUpdate.ADDR));
        assertEquals("56.78", results.get(AbstractHouseholdSqlUpdate.LAT));
        assertEquals("12.34", results.get(AbstractHouseholdSqlUpdate.LNG));
        assertEquals("Y", results.get(AbstractHouseholdSqlUpdate.PIN_DROP));

        verify(household, times(1)).getServerId();
        verify(household, times(1)).getAddress();
        verify(household, times(1)).getLat();
        verify(household, times(1)).getLng();
        verify(household, times(1)).getPinDropped();
        verifyNoMoreInteractions(household);
    }
}
