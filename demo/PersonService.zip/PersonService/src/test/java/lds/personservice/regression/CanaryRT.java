package lds.personservice.regression;

import static org.hamcrest.Matchers.*;

import org.junit.Test;

/**
 * Test of the canary page.
 */
public class CanaryRT extends RestRegressionSpec {

	/**
	 * Test of the GET method of the canary page.
	 */
	@Test
	public void testCanaryGet() {
		givenAnAuthenticatedSession()
		.when()
			.get("/ws/person-service/api")
		.then()
			.contentType("application/hal+json;charset=UTF-8")
			.statusCode(200)
			.body("project.name", is("Person Service"));
	}
}
