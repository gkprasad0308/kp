package lds.personservice.person;

import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.*;

public class PersonTest {

    public static final long PROS_AREA_ID = 123L;

    @Test
    public void hasProsAreaChangedFalseIfOriginalNull(){
        Person person = createPerson(PROS_AREA_ID);
        assertFalse(person.hasProsAreaChanged(null));
    }

    @Test
    public void hasProsAreaChangedFalseIfNotFieldPresent(){
        Person person = new Person();
        Person diff = createPerson(PROS_AREA_ID);
        assertFalse(person.hasProsAreaChanged(diff));
    }

    @Test
    public void hasProsAreaChangedReturnsFalseIfProsAreaNull(){
        Person person = createPerson(null);
        Person diff = createPerson(PROS_AREA_ID);
        assertFalse(person.hasProsAreaChanged(diff));
    }

    @Test
    public void hasProsAreaChangedReturnsFalseIfSameProsArea(){
        Person person = createPerson(PROS_AREA_ID);
        Person diff = createPerson(PROS_AREA_ID);
        assertFalse(person.hasProsAreaChanged(diff));
    }

    @Test
    public void hasProsAreaChangedReturnsTrueIfDifferentProsArea(){
        Person person = createPerson(456L);
        Person diff = createPerson(PROS_AREA_ID);
        assertTrue(person.hasProsAreaChanged(diff));
    }

    @Test
    public void setDeletedAddsKeyAndSetsDeleted(){
        Person person = new Person();

        assertFalse(person.isDeleted());
        person.setDeleted(true);
        assertTrue(person.isFieldPresent("deleted"));
        assertTrue(person.isDeleted());
    }

    @Test
    public void setModDateAddsKeyAndSetsModDate(){
        Person person = new Person();

        assertNull(person.getModDate());

        Date date = new Date();
        person.setModDate(date);
        assertTrue(person.isFieldPresent("modDate"));
        assertEquals(date, person.getModDate());
    }

    @Test
    public void setCreateDateAddsKeyAndSetsCreateDate(){
        Person person = new Person();

        assertNull(person.getModDate());

        Date date = new Date();
        person.setCreateDate(date);
        assertTrue(person.isFieldPresent("createDate"));
        assertEquals(date, person.getCreateDate());
    }

    @Test
    public void applyChangesMovesFielsAcross(){
        Person person = new Person();
        person.setGuid("abc");
        person.setProsAreaId(123L);
        person.setDeleted(true);

        Person existing = new Person();
        existing.setDeleted(false);
        existing.applyChangesToThis(person);
        assertTrue(existing.isDeleted());
        assertEquals(new Long(123L), existing.getProsAreaId());
        assertEquals("abc", existing.getGuid());
    }

    private Person createPerson(Long prosAreaId) {
        Person person = new Person();
        person.setProsAreaId(prosAreaId);
        return person;
    }
}
