package lds.personservice.person.drop;

import lds.personservice.AbstractSimpleSprocTest;
import lds.personservice.util.SimpleSproc;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ResetPersonSprocTest extends AbstractSimpleSprocTest {

    @InjectMocks
    private ResetPersonSproc sproc;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            ResetPersonSproc.PERSON_ID,
            ResetPersonSproc.RESET_DT,
            ResetPersonSproc.MOD_DT,
            ResetPersonSproc.CLIENT_GUID
    );

    @Override
    protected String getSchema() {
        return ResetPersonSproc.SCHEMA_NAME;
    }

    @Override
    protected String getCataglog() {
        return ResetPersonSproc.CATALOG_NAME;
    }

    @Override
    protected String getFunction() {
        return ResetPersonSproc.FUNCTION_NAME;
    }

    @Override
    protected SimpleSproc getInstance() {
        return sproc;
    }

    @Override
    protected List<String> getExpectedParameters() {
        return expectedParams;
    }

    @Test
    public void getParametersUsingReturnsExpected(){
        Date date = new Date(System.currentTimeMillis());
        MapSqlParameterSource params = (MapSqlParameterSource) sproc.getParemetersUsing(123L, date);
        checkKeys(params.getValues());
        assertEquals(123L, params.getValue(ResetPersonSproc.PERSON_ID));
        assertEquals(date, params.getValue(ResetPersonSproc.RESET_DT));
        assertNotNull(params.getValue(ResetPersonSproc.MOD_DT));
        assertNotNull(params.getValue(ResetPersonSproc.CLIENT_GUID));
    }
}
