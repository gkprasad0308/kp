/*
 * Copyright (C) 2015 Intellectual Reserve, Inc. All rights reserved.
 * This notice may not be removed.
 */
package lds.personservice.person;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

import lds.prsms.utils.errors.ServiceException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import lds.prsms.utils.UUIDGenerator;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.util.Arrays;
import java.util.List;

/**
 * Test of the {@link PersonRepository} class.
 */
public class PersonRepositoryTest {

	private static final String GUID_1 = "12345678901234567890123456789012";

	private PersonRepository specimen;

	@Mock private NamedParameterJdbcTemplate namedTemplateMock;

	@Mock private JdbcTemplate jdbcTemplateMock;

	@Mock private PersonInsertSql personInsertSqlMock;

    @Mock
    private PersonUpdateSql personUpdateSqlMock;

	@Mock private DeletePersonSproc deletePersonSprocMock;

	@Before
	public void setup() {
		initMocks(this);

		specimen = new PersonRepository(namedTemplateMock, jdbcTemplateMock, personInsertSqlMock, personUpdateSqlMock, deletePersonSprocMock,
				UUIDGenerator.getInstance());
	}

	/**
	 * Test of {@link PersonRepository#createPerson(Person)} where a guid is
	 * included.
	 */
	@Test
	public void testCreatePersonGuid() {
		long id = 100l;
		Person mockPerson = mock(Person.class);
		mockPerson.setGuid(GUID_1);

		when(jdbcTemplateMock.queryForObject(anyString(), eq(Long.class))).thenReturn(id++);
		when(namedTemplateMock.queryForObject(anyString(), any(SqlParameterSource.class), eq(Integer.class))).thenReturn(0);
		when(mockPerson.getGuid()).thenReturn(GUID_1);

		specimen.createPerson(mockPerson);

		assertNotNull("Expected household to be returned by create", mockPerson);

		verify(mockPerson, times(1)).setGuid(anyString());
	}

	/**
	 * Test of {@link PersonRepository#createPerson(Person)} where no guid is
	 * included.
	 */
	@Test
	public void testCreatePersonNoGuid() {
		long id = 100l;
		Person mockPerson = mock(Person.class);

		when(jdbcTemplateMock.queryForObject(anyString(), eq(Long.class))).thenReturn(id++);
		when(namedTemplateMock.queryForObject(anyString(), any(SqlParameterSource.class), eq(Integer.class))).thenReturn(0);

		specimen.createPerson(mockPerson);

		assertNotNull("Expected household to be returned by create", mockPerson);

		verify(mockPerson, times(1)).setGuid(anyString());
	}

    @Test
    public void updatePersonCallsExpectedMocks(){
        Person person = new Person();
        specimen.updatePerson(person);
        verify(personUpdateSqlMock, times(1)).getParamsUsing(person);
        verify(personUpdateSqlMock, times(1)).updateByNamedParam(anyMap());
        verifyNoMoreInteractions(personUpdateSqlMock);
    }

    @Test
    public void deletePersonCallsExpectedMethods(){
        SimpleJdbcCall mockCall = mock(SimpleJdbcCall.class);
        when(deletePersonSprocMock.getStoredProc()).thenReturn(mockCall);
        MapSqlParameterSource params = new MapSqlParameterSource();
        when(deletePersonSprocMock.getParametersUsing(123L)).thenReturn(params);

        specimen.deletePerson(123L);
        verify(deletePersonSprocMock, times(1)).getParametersUsing(123L);
        verify(deletePersonSprocMock, times(1)).getStoredProc();
        verify(mockCall, times(1)).execute(params);
    }

    @Test(expected = ServiceException.class)
    public void getPersonsByIdsTrowsIfNothingReturned(){
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(PersonExtractor.class))).thenReturn(null);
        specimen.getPersonsByIds(Arrays.asList(new Long(123L), new Long(456L)));
    }

    @Test
    public void getPersonsByIdsReturnsExpected(){
        Person person1 = new Person();
        Person person2 = new Person();

        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(PersonExtractor.class))).thenReturn(Arrays.asList(person1, person2));
        List<Person> results = specimen.getPersonsByIds(Arrays.asList(new Long(1L), new Long(2L)));
        assertTrue(results.size() == 2);
        assertThat(results, hasItem(person1));
        assertThat(results, hasItem(person2));
        verify(namedTemplateMock, times(1)).query(anyString(), any(SqlParameterSource.class), any(PersonExtractor.class));
        verifyNoMoreInteractions(namedTemplateMock);
    }

    @Test
    public void personWithGuidExistsReturnsTrueWhenExpected(){
       // when(namedTemplateMock.queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class))).thenReturn(1);
        assertTrue(specimen.personWithGuidExists("abc"));
        //verify(namedTemplateMock, times(1)).queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class));
        verifyNoMoreInteractions(namedTemplateMock);
    }

    @Test
    public void personWithGuidExistsReturnsFalseWhenExpected(){
        //when(namedTemplateMock.queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class))).thenReturn(0);
        assertFalse(specimen.personWithGuidExists("abc"));
        //verify(namedTemplateMock, times(1)).queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class));
        verifyNoMoreInteractions(namedTemplateMock);
    }

    @Test
    public void getPersonIdByGuidReturnsFirstId(){
       // when(jdbcTemplateMock.queryForList(anyString(), any(Object[].class), any(Class.class))).thenReturn(Arrays.asList(new Long(1l), new Long(2L)));
        Long result = specimen.getPersonIdByGuid("abc");
        assertEquals(new Long(1L), result);
    }

    @Test(expected = ServiceException.class)
    public void getPersonByIdThrowsIfNoResults(){
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(PersonExtractor.class))).thenReturn(null);
        specimen.getPersonById(123L);
    }

    @Test
    public void getPersonByIdReturnsExpected(){
        Person person = new Person();
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(PersonExtractor.class))).thenReturn(Arrays.asList(person));
        Person result = specimen.getPersonById(123L);
        assertEquals(person, result);
    }

    @Test(expected = ServiceException.class)
    public void getPersonByGuidThrowsIfNoResults(){
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(PersonExtractor.class))).thenReturn(null);
        specimen.getPersonByGuid("abc");
    }

    @Test
    public void getPersonByGuidReturnsExpected(){
        Person person = new Person();
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(PersonExtractor.class))).thenReturn(Arrays.asList(person));
        Person result = specimen.getPersonByGuid("abc");
        assertEquals(person, result);
    }
}
