package lds.personservice.household.search;

import lds.personservice.household.InclusionParams;
import lds.personservice.household.ListParams;
import lds.personservice.person.referral.ReferralMapper;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class ReferralInfoSearchComponentTest {

    @Test
    public void buildFragementReturnsNullWithNullParams(){
        SearchComponent component = new ReferralInfoSearchComponent("p");
        assertNull(component.buildFragment(null));
    }

    @Test
    public void buildFragementReturnsNullWithEmptyInclusions(){
        ListParams params = new ListParams();
        params.setInclusions("");
        SearchComponent component = new ReferralInfoSearchComponent("p");
        assertNull(component.buildFragment(params));
    }

    @Test
    public void buildFragementReturnsNullWithoutRightInclusion(){
        List<String> inclusionParamses = Arrays.asList(InclusionParams.DROP_NOTES.name(), InclusionParams.FELLOWSHIPPERS.name(), InclusionParams.CONTACT_INFO.name(), InclusionParams.COMMITMENTS.name());
        ListParams params = new ListParams();
        params.setInclusions(String.join(",", inclusionParamses));
        SearchComponent component = new ReferralInfoSearchComponent("p");
        assertNull(component.buildFragment(params));
    }

    @Test
    public void buildFragementReturnsExpected(){
        ListParams params = new ListParams();
        params.setInclusions(InclusionParams.REFERRAL_INFO.name());
        SearchComponent component = new ReferralInfoSearchComponent("p");
        SearchFragment fragment = component.buildFragment(params);
        assertNotNull(fragment);
        assertEquals(ReferralMapper.getSelectStatement("pr", "rg"), fragment.getSelectFragment());
    }
}
