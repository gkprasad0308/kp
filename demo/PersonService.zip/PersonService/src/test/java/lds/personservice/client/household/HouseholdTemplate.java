package lds.personservice.client.household;

import java.net.URI;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import lds.personservice.client.ResourceTemplate;
import lds.personservice.household.Household;
import lds.personservice.household.InclusionParams;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.util.MatcherAssertionErrors.assertThat;

@Component
@Scope("prototype")
public class HouseholdTemplate extends ResourceTemplate<HouseholdTemplate> {

	@Value("http://localhost:${local.server.port}${lds.api.resources.households.href}") private URI resourceUri;

    public URI getResourceUri() {
        return resourceUri;
    }

    public String getResourceUriAsString(){
        return getResourceUri().toString();
    }

    public <T> T getHousehold(String contentType, String householdId, Class<T> unmarshalledType) {
		HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders(contentType));
        return sendRequest(resourceUri.toString() + "/" + householdId, HttpMethod.GET, request, unmarshalledType).getBody();
	}

	public <T> T createHousehold(String contentType, Household payload, Class<T> unmarshalledType) {
		HttpEntity<Household> request = new HttpEntity<>(payload,
				constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE));
        return sendRequest(resourceUri.toString(), HttpMethod.POST, request, unmarshalledType).getBody();
	}

	public <T> T updateHousehold(Household payload, Class<T> unmarshalledType) {
		HttpEntity<Household> request = new HttpEntity<>(payload, constructDefaultHeaders("application/json"));
        return sendRequest(resourceUri.toString() + "/" + payload.getGuid(), HttpMethod.PUT, request, unmarshalledType).getBody();
	}

	public void deleteHousehold(String householdId) {
		final HttpEntity<Household> request = new HttpEntity<>(null, constructDefaultHeaders("application/json"));
		sendRequest(resourceUri.toString() + "/" + householdId, HttpMethod.DELETE, request);
	}

	public <T> T getSearchResults(String contentType, Class<T> unmarshalledType, QueryParams listParams) {
		HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders(contentType));
		RestTemplate template = new RestTemplate();
		List<String> params = new LinkedList<>();

		if (listParams.getProsAreaId() != null) {
			params.add("prosArea=" + listParams.getProsAreaId());
		}

		if (listParams.getAssignmentArea() != null) {
			params.add("assignmentArea=" + listParams.getAssignmentArea());
		}

		if (listParams.getStewardCmisId() != null) {
			params.add("stewardCmisId=" + listParams.getStewardCmisId());
		}

		if (listParams.getModDate() != null) {
			params.add("modDate=" + listParams.getModDate().getTime());
		}

		if (listParams.getOrgId() != null) {
			params.add("orgId=" + listParams.getOrgId());
		}

		if (listParams.isIncludeDeleted()) {
			params.add("includeDel=true");
		}

		if (!CollectionUtils.isEmpty(listParams.getInclusions())) {
			List<String> inclusionNames = listParams.getInclusions().stream().map(InclusionParams::name)
					.collect(Collectors.toList());
			params.add("include=" + String.join(",", inclusionNames));
		}

		String queryParams = !CollectionUtils.isEmpty(params) ? "?" + String.join("&", params) : "";
		ResponseEntity<T> response = followRedirects(
				template.exchange(resourceUri + queryParams, HttpMethod.GET, request, unmarshalledType),
				unmarshalledType);

		// Validate the HTTP response status
		assertThat(response.getStatusCode(), is(HttpStatus.OK));

		// Validate the content type
		MediaType requestType = MediaType.parseMediaType(contentType);
		MediaType responseType = response.getHeaders().getContentType();
		assertTrue(requestType.includes(responseType));

		return response.getBody();
	}

	public <T> T getHouseholdForAssignmentArea(Long prosAreaId, Class<T> unmarshalledType) {
		HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders("application/json"));
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<T> response = restTemplate.exchange(resourceUri.toString() + "?assignmentArea=" + prosAreaId,
				HttpMethod.GET, request, unmarshalledType);

		return response.getBody();
	}
}
