package lds.personservice.person.fellowshipper;


import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class FellowshipMapTest {

    private FellowshipMap fellowshipMap;

    @Before
    public void setup(){
        fellowshipMap = new FellowshipMap();
    }

    @Test
    public void addFellowshipRelationshipWithNullDataDoesNothing(){
        fellowshipMap.addFellowshipRelationship(1L, 2L, null);
        assertNull(fellowshipMap.getFellowshipInfoForPerson(1L));
        assertNull(fellowshipMap.getFellowshipInfoForPerson(2L));
    }

    @Test
    public void addFellowshipRelationshipAddsToFellowshippeesOfFellowshipperIfDataIdMatchesInvestigatorId(){
        FellowshipData data = new FellowshipData();
        data.setPersonServerId(2L);
        fellowshipMap.addFellowshipRelationship(1L, 2L, data);

        FellowshipInfo info = fellowshipMap.getFellowshipInfoForPerson(1L);
        assertThat(info.getFellowshippers(), is(nullValue()));
        assertThat(info.getFellowshippees(), contains(data));
    }

    @Test
    public void addFellowshipRelationshipAddsToFellowshippersOfFellowshippee(){
        FellowshipData data = new FellowshipData();
        data.setPersonServerId(1L);
        fellowshipMap.addFellowshipRelationship(1L, 2L, data);

        FellowshipInfo info = fellowshipMap.getFellowshipInfoForPerson(2L);
        assertThat(info.getFellowshippees(), is(nullValue()));
        assertThat(info.getFellowshippers(), contains(data));
    }

    @Test
    public void mergeMapsJoinsTwoMaps(){
        FellowshipData data = new FellowshipData();
        data.setPersonServerId(2L);
        fellowshipMap.addFellowshipRelationship(1L, 2L, data);

        FellowshipData data2 = new FellowshipData();
        data2.setPersonServerId(1L);
        FellowshipMap map2 = new FellowshipMap();
        map2.addFellowshipRelationship(1L, 2L, data2);

        FellowshipInfo info = fellowshipMap.getFellowshipInfoForPerson(1L);
        assertThat(info.getFellowshippers(), is(nullValue()));
        assertThat(info.getFellowshippees(), contains(data));
        assertNull(fellowshipMap.getFellowshipInfoForPerson(2L));

        fellowshipMap.mergeMaps(map2);
        info = fellowshipMap.getFellowshipInfoForPerson(2L);
        assertThat(info.getFellowshippees(), is(nullValue()));
        assertThat(info.getFellowshippers(), contains(data2));
        info = fellowshipMap.getFellowshipInfoForPerson(1L);
        assertThat(info.getFellowshippers(), is(nullValue()));
        assertThat(info.getFellowshippees(), contains(data));
    }
}
