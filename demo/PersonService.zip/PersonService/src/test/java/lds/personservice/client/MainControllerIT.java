package lds.personservice.client;

import java.net.URI;

import javax.inject.Inject;
import javax.inject.Provider;

import com.jayway.jsonassert.JsonAssert;
import lds.personservice.Main;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsEqual.equalTo;

@ActiveProfiles({ "local" })
@IntegrationTest({ "browser.startup=false", "server.port=0" })
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class MainControllerIT {

	@Value("http://localhost:${local.server.port}${lds.api.resources.serviceDetails.href}") private URI serviceDetailsUri;

	@Inject private Provider<MainTemplate> templateProvider;

	@Test
	public void test_Get() {
		MainTemplate template = templateProvider.get();
		String serviceDetails = template.get("application/hal+json", String.class);
		JsonAssert.with(serviceDetails)
				// Check endpoints exist
				.assertThat("$._links.self.href", is(equalTo(serviceDetailsUri.toString())))
				// check that healthStatus is present and missionOrgService is
				// okay
				.assertThat("$.healthStatus.missionOrgService", is(not(empty())))
				// Check that models are present
				.assertThat("$.models", is(not(empty())));
	}
}
