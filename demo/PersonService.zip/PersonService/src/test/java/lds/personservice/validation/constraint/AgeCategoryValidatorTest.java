package lds.personservice.validation.constraint;

import lds.personservice.util.validation.constraint.AgeCategoryValidator;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AgeCategoryValidatorTest {

    @InjectMocks
    private AgeCategoryValidator validator;

    @Mock
    private OptionsValidationService validationService;

    @Mock
    private ConstraintValidatorContext context;

    @Test
    public void isValid_returns_true_with_null_ageCategory(){
        assertTrue(validator.isValid(null, context));
    }

    @Test
    public void isValid_returns_false_if_service_returns_false(){
        when(validationService.ageCategoryExists(1)).thenReturn(true);
        assertTrue(validator.isValid(1, context));
        verify(validationService, times(1)).ageCategoryExists(1);
    }

    @Test
    public void isValid_returns_true_if_service_returns_true(){
        when(validationService.ageCategoryExists(1)).thenReturn(false);
        assertFalse(validator.isValid(1, context));
        verify(validationService, times(1)).ageCategoryExists(1);
    }
}
