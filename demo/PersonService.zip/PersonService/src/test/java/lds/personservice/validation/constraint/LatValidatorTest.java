package lds.personservice.validation.constraint;

import lds.personservice.util.validation.constraint.LatValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class LatValidatorTest {

    @Mock
    private ConstraintValidatorContext context;

    private LatValidator validator;

    @Before
    public void setup(){
        validator = new LatValidator();
    }

    @Test
    public void isValidIfNull(){
        assertTrue(validator.isValid(null, context));
    }

    @Test
    public void isValidIfNumber(){
        assertTrue(validator.isValid("50", context));
    }

    @Test
    public void isValidIfZero(){
        assertTrue(validator.isValid("0", context));
    }

    @Test
    public void isValidIfNegative(){
        assertTrue(validator.isValid("-56", context));
    }

    @Test
    public void isValidIfDecimal(){
        assertTrue(validator.isValid("0.234534", context));
    }

    @Test
    public void isNotValidIfEmpty(){
        assertFalse(validator.isValid("", context));
    }

    @Test
    public void isNotValidIf90(){
        assertFalse(validator.isValid("90", context));
    }

    @Test
    public void isNotValidIfGreaterThan90(){
        assertFalse(validator.isValid("90.1", context));
    }

    @Test
    public void isNotValidIfNegative90(){
        assertFalse(validator.isValid("-90", context));
    }

    @Test
    public void isNotValidIfLessThanNegative90(){
        assertFalse(validator.isValid("-90.1", context));
    }
}
