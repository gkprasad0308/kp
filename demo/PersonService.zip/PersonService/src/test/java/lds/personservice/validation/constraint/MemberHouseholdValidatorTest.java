package lds.personservice.validation.constraint;

import lds.personservice.household.Household;
import lds.personservice.person.Person;
import lds.personservice.util.validation.constraint.MemberHouseholdValidator;
import lds.personservice.util.validation.service.HouseholdValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class MemberHouseholdValidatorTest {

    @InjectMocks
    private MemberHouseholdValidator validator;

    @Mock
    private HouseholdValidationService service;

    @Test
    public void isValidReturnsTrueIfMissionaryAndStewardCmisAreNull(){
        Household household = new Household();
        household.setMissionaryId(null);
        household.setServerId(null);
        assertTrue(validator.isValid(household, null));
    }

    @Test
    public void isValidReturnsTrueIfNoCmisIdMembers(){
        Household household = new Household();
        household.setGuid("abc");
        household.setMissionaryId(123L);
        household.addPerson(new Person());

        when(service.getOriginal("abc")).thenReturn(new Household());
        assertTrue(validator.isValid(household, null));
        verify(service, times(1)).getOriginal("abc");
    }

    @Test
    public void isValidReturnsFalseIfNewHouseholdHasMissionaryIdAndHasCmisId(){
        Person person = new Person();
        person.setCmisId(123L);

        Household household = new Household();
        household.addPerson(person);
        household.setMissionaryId(123L);

        assertFalse(validator.isValid(household, null));
        verifyZeroInteractions(service);
    }

    @Test
    public void isValidReturnsFalseIfNewHouseholdHasStewardCmisIdAndHasCmisId(){
        Person person = new Person();
        person.setCmisId(123L);

        Household household = new Household();
        household.addPerson(person);
        household.setStewardCmisId(123L);

        assertFalse(validator.isValid(household, null));
        verifyZeroInteractions(service);
    }

    @Test
    public void isValidReturnsTrueIfExistingHouseholdIsNull(){
        Household household = new Household();
        household.setGuid("abc");
        household.setMissionaryId(123L);
        household.addPerson(new Person());

        when(service.getOriginal("abc")).thenReturn(null);
        assertTrue(validator.isValid(household, null));
        verify(service, times(1)).getOriginal("abc");
    }

    @Test
    public void isValidCallsServiceIfPayloadIsValidWithMissionaryId(){
        Person person = new Person();
        person.setCmisId(123L);

        Household household = new Household();
        household.addPerson(person);

        Household payload = new Household();
        payload.setMissionaryId(123L);
        payload.setGuid("abc");

        when(service.getOriginal("abc")).thenReturn(household);
        assertFalse(validator.isValid(payload, null));
        verify(service, times(1)).getOriginal("abc");
    }

    @Test
    public void isValidCallsServiceIfPayloadIsValidWithStewardCmis(){
        Person person = new Person();
        person.setCmisId(123L);

        Household household = new Household();
        household.addPerson(person);

        Household payload = new Household();
        payload.setStewardCmisId(123L);
        payload.setGuid("abc");

        when(service.getOriginal("abc")).thenReturn(household);
        assertFalse(validator.isValid(payload, null));
        verify(service, times(1)).getOriginal("abc");
    }
}
