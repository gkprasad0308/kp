package lds.personservice;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BaseUpdateSqlTest {

    private BaseUpdateSql updateSql;

    @Before
    public void setup(){
        updateSql = new BaseUpdateSql();
    }

    @Test
    public void parseBooleanReturnsYForTrue(){
        assertEquals("Y", updateSql.parseBoolean(true));
    }

    @Test
    public void parseBooleanReturnsNForFalse(){
        assertEquals("N", updateSql.parseBoolean(false));
    }

    @Test
    public void parseBooleanReturnsNForNull(){
        assertEquals("N", updateSql.parseBoolean(null));
    }
}
