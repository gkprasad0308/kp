package lds.personservice.person;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Provider;
import lds.personservice.Main;
import lds.personservice.client.household.HouseholdTemplate;
import lds.personservice.contactinfo.ContactInfo;
import lds.personservice.contactinfo.email.Email;
import lds.personservice.contactinfo.email.EmailTypes;
import lds.personservice.contactinfo.phone.Phone;
import lds.personservice.contactinfo.phone.PhoneTypes;
import lds.personservice.household.Household;
import lds.personservice.person.drop.WritableDropNote;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;

@ActiveProfiles({"local"})
@IntegrationTest({"browser.startup=false", "server.port=0"})
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class PersonControllerIT {

	private static final Long KNOWN_GOOD_PROSELYTING_AREA_ID = 5484050L;

	private static final Integer KNOWN_GOOD_LANGUAGE_ID = 294;

	private static final Integer KNOWN_GOOD_CONTACT_SOURCE = 10;

	@Inject private Provider<PersonTemplate> templateProvider;

	@Inject private Provider<HouseholdTemplate> templateHousehold;

	@Autowired PersonRepository repository;
	String currentPersonId;
    private PersonTemplate template;

    @Test
	public void Merge_Investigators() {
		Person from = create_automation_person(1, KNOWN_GOOD_CONTACT_SOURCE, "Death Valley");

		Person to = create_automation_person(1, KNOWN_GOOD_CONTACT_SOURCE, "Huntington Beach, CA");
		template.mergePerson(to.getGuid(), from.getGuid());

		Person fromReal = template.getPerson("application/json", from.getGuid(), Person.class);
		assertTrue(fromReal.isDeleted());

		Person toReal = template.getPerson("application/json", to.getGuid(), Person.class);
		assertFalse(toReal.isDeleted());

		currentPersonId = toReal.getGuid();
	}

	@Test
	public void Merge_Investigator_To_Cmis() {
		HouseholdTemplate HHTemp = templateHousehold.get();
		Person from = create_automation_person(1, KNOWN_GOOD_CONTACT_SOURCE, "Death Valley");
		String cmis = "Mommy";
		JSONObject prosHH = new JSONObject(HHTemp.getHouseholdForAssignmentArea(5484050l, String.class));
		JSONArray listofHH = prosHH.getJSONArray("households");
		for (int u = 0; u < listofHH.length(); u++) {
			JSONObject numOne = new JSONObject(listofHH.get(u).toString());
			JSONArray peoples = numOne.getJSONArray("people");
			for (int k = 0; k < peoples.length(); k++) {
				JSONObject firstPerson = new JSONObject(peoples.get(k).toString());
				if (firstPerson.get("cmisId") != null) {
					cmis = firstPerson.get("id").toString();
					break;
				}

			}
			if (cmis != "Mommy") {
				break;
			}
		}
		Person toFirst = template.getPerson("application/json", cmis, Person.class);
		Integer LangId = toFirst.getPreferredLangId();
		template.mergePerson(cmis, from.getGuid());
		Person fromReal = template.getPerson("application/json", from.getGuid(), Person.class);
		assertTrue(fromReal.isDeleted());
		Person toReal = template.getPerson("application/json", cmis, Person.class);
		assertFalse(toReal.isDeleted());
		assertTrue(toReal.getStatus() != 1);
		if (LangId != null && LangId != 294) {
			assertTrue(toReal.getPreferredLangId() != 294);
		}
	}

	@Test
	public void Merge_Cmis_To_Cmis() {
		HouseholdTemplate HHTemp = templateHousehold.get();
		Person from = create_automation_person(1, KNOWN_GOOD_CONTACT_SOURCE, "Death Valley");
		String cmis = "Mommy";
		String cmis2 = "Daddy";
		JSONObject prosHH = new JSONObject(HHTemp.getHouseholdForAssignmentArea(5484050l, String.class));
		JSONArray listofHH = prosHH.getJSONArray("households");
		for (int u = 0; u < listofHH.length(); u++) {
			JSONObject numOne = new JSONObject(listofHH.get(u).toString());
			JSONArray peoples = numOne.getJSONArray("people");
			for (int k = 0; k < peoples.length(); k++) {
				JSONObject firstPerson = new JSONObject(peoples.get(k).toString());
				if (firstPerson.get("cmisId") != null && cmis.equals("Mommy")) {
					cmis = firstPerson.get("id").toString();
					break;
				} else if (firstPerson.get("cmisId") != null && cmis2.equals("Daddy")) {
					cmis2 = firstPerson.get("id").toString();
					break;

				}

			}
			if (cmis2 != "Daddy") {
				break;
			}
		}
		try {
			template.mergePerson(cmis, cmis2);
		} catch (Exception ex) {
			assertEquals("400 Bad Request", ex.getMessage());
		}

	}

	@Test
	public void test_Calc_Status() {
		Person statPerson = create_automation_person(1, KNOWN_GOOD_CONTACT_SOURCE, "512 Huntington Beach, CA");
		Long pId = repository.getPersonIdByGuid(statPerson.getGuid());
		List<Person> results = template.calculateStatus(pId);

		assertNotNull(results);
		assertEquals(results.size(), 1);
		currentPersonId = statPerson.getGuid();
	}

	@Test
	public void person_CRUD() {
		// create person
		Person response = create_automation_person(2, 10, "12 Nantucket Street");
		// change person information
		response.setFirstName("AutoUpdate");
		response.setNote("Who let the dogs out?");
		Person updResponse = template.updatePerson(response, Person.class);
		assertEquals("AutoUpdate", updResponse.getFirstName());
		assertEquals("Who let the dogs out?", updResponse.getNote());
        assertEquals(response.getLastName(), updResponse.getLastName());
		// delete person
		template.deletePerson(updResponse.getGuid());
		// get person verify deleted
		Person deadPerson = template.getPerson("application/json", updResponse.getGuid(), Person.class);
		assertTrue(deadPerson.isDeleted());

	}

	@Test
	public void get_person_with_invalid_id() {
		try {
			template.getPerson("application/hal+json", "9s8e98ne89nrv8nesriure", String.class);
		} catch (Exception ex) {
			assertEquals(ex.getMessage(), "400 Bad Request");
		}
	}

	@Test
	public void multi_drop_undrop() {
		Person response = create_automation_person(3, 10, "7 Heaven Circle");
		WritableDropNote note = new WritableDropNote();
		note.setStatus(20);
		note.setNote("Let the tires burn.");
        pauseTest(2000l);
        Person droppedPerson = template.dropPerson("application/json", response.getGuid(), note);
		assertEquals("20", droppedPerson.getStatus().toString());
		note.setStatus(23);
        pauseTest(2000l);
        Person droppedAgain = template.dropPerson("application/json", response.getGuid(), note);
		assertEquals("23", droppedAgain.getStatus().toString());
        pauseTest(2000l);
        Person undropped = template.undropPerson(droppedAgain.getGuid());
		assertTrue(undropped.getStatus() == 1);

		currentPersonId = undropped.getGuid();

	}

    private void pauseTest(long time) {
        try {
            Thread.sleep(2000l);
        } catch (InterruptedException e) {
            e.printStackTrace(); // To change body of catch statement use File |
                                 // Settings | File Templates.
        }
    }
    //

	@Test
	public void multi_drop_reset() {
		Person response = create_automation_person(3, 10, "7 Heaven Circle");
		WritableDropNote note = new WritableDropNote();
		note.setStatus(20);
		note.setNote("Let the tires burn.");
		pauseTest(3000l);
		Person droppedPerson = template.dropPerson("application/json", response.getGuid(), note);
		assertEquals("20", droppedPerson.getStatus().toString());
		note.setStatus(23);
        pauseTest(3000l);
		Person droppedAgain = template.dropPerson("application/json", droppedPerson.getGuid(), note);
		assertEquals("23", droppedAgain.getStatus().toString());
        pauseTest(3000l);
		Person reset = template.resetPerson(droppedAgain.getGuid(), System.currentTimeMillis());
		assertTrue(reset.getStatus() == 1);

		currentPersonId = reset.getGuid();

	}

	@Test
	public void drop_undrop_person() {
		Person response = create_automation_person(3, 10, "42 Heaven Circle");
		WritableDropNote note = new WritableDropNote();
		note.setStatus(20);
		note.setNote("Let the tires burn.");
        pauseTest(3000l);
		Person droppedPerson = template.dropPerson("application/json", response.getGuid(), note);
		assertEquals("20", droppedPerson.getStatus().toString());

		Person undropped = template.undropPerson(droppedPerson.getGuid());
		assertTrue(undropped.getStatus() != 20);

		currentPersonId = undropped.getGuid();
	}

    @Test
	public void drop_reset_person() {
		Person response = create_automation_person(3, 10, "42 Heaven Circle");
		WritableDropNote note = new WritableDropNote();
		note.setStatus(21);
		note.setNote("Turning the heads");
        pauseTest(3000l);
		Person droppedPerson = template.dropPerson("application/json", response.getGuid(), note);
		assertEquals("21", droppedPerson.getStatus().toString());

		Person reset = template.resetPerson(droppedPerson.getGuid(), System.currentTimeMillis());
		assertTrue(reset.getStatus() == 1);

		currentPersonId = reset.getGuid();

	}

    @Test
    public void createPersonWithContactInformation(){
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.addEmail(EmailTypes.EMAIL_HOME, "test@home");
        contactInfo.addPhone(PhoneTypes.PHN_MOBILE, "mobile");

        Person person = new Person();
        person.setStatus(1);
        person.setContactInfo(contactInfo);
        person.setHouseholdId(createAutomationHousehold("test 1234").getGuid());
        person.setContactSource(10);

        Person response = template.createPerson("application/json", person, Person.class);
        Person persisted = template.getPerson(MediaType.APPLICATION_JSON_VALUE, response.getGuid(), Person.class);
        assertNotNull(persisted.getContactInfo());
        contactInfo = persisted.getContactInfo();

        assertTrue(contactInfo.getPhoneNumbers().size() == 1);
        assertEquals(PhoneTypes.PHN_MOBILE, contactInfo.getPhoneNumbers().get(0).getType());
        assertEquals("mobile", contactInfo.getPhoneNumbers().get(0).getNumber());

        assertTrue(contactInfo.getEmailAddresses().size() == 1);
        assertEquals(EmailTypes.EMAIL_HOME, contactInfo.getEmailAddresses().get(0).getType());
        assertEquals("test@home", contactInfo.getEmailAddresses().get(0).getAddress());
    }

    @Test
    public void updatePersonWithContactInformation(){
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.addEmail(EmailTypes.EMAIL_HOME, "test@home");
        contactInfo.addEmail(EmailTypes.EMAIL_OTHER, "test@other");
        contactInfo.addPhone(PhoneTypes.PHN_MOBILE, "mobile");
        contactInfo.addPhone(PhoneTypes.PHN_OTHER, "other");

        Person person = new Person();
        person.setStatus(1);
        person.setContactInfo(contactInfo);
        person.setHouseholdId(createAutomationHousehold("test 1234").getGuid());
        person.setContactSource(10);

        Person response = template.createPerson("application/json", person, Person.class);
        contactInfo = new ContactInfo();
        contactInfo.addEmail(EmailTypes.EMAIL_HOME, "update@home");
        contactInfo.addEmail(EmailTypes.EMAIL_FAMILY, "test@family");
        contactInfo.addPhone(PhoneTypes.PHN_HOME, "phoneHome");
        contactInfo.addPhone(PhoneTypes.PHN_OTHER, "updatedOther");
        response.setContactInfo(contactInfo);

        response = template.updatePerson(response, Person.class);
        Person persisted = template.getPerson(MediaType.APPLICATION_JSON_VALUE, response.getGuid(), Person.class);
        assertNotNull(persisted.getContactInfo());
        contactInfo = persisted.getContactInfo();
        assertTrue(contactInfo.getPhoneNumbers().size() == 2);
        assertThat(contactInfo.getPhoneNumbers(), hasItem(new Phone(PhoneTypes.PHN_OTHER, "updatedOther")));
        assertThat(contactInfo.getPhoneNumbers(), hasItem(new Phone(PhoneTypes.PHN_HOME, "phoneHome")));

        assertTrue(contactInfo.getEmailAddresses().size() == 2);
        assertThat(contactInfo.getEmailAddresses(), hasItem(new Email(EmailTypes.EMAIL_FAMILY, "test@family")));
        assertThat(contactInfo.getEmailAddresses(), hasItem(new Email(EmailTypes.EMAIL_HOME, "update@home")));
    }

	@Before
	public void before() {
		currentPersonId = null;
        template = templateProvider.get();
	}

	@After
	public void after() {
		if (currentPersonId != null) {
			template.deletePerson(currentPersonId);
		}
	}

	public Person create_automation_person(int status, int cntSource, String addy) {
        Household hTemp = createAutomationHousehold(addy);

        Person testPerson = new Person();
		testPerson.setFirstName("Automation");
		String timeLast = new Date().toString();
		testPerson.setLastName(timeLast);
		testPerson.setProsAreaId(KNOWN_GOOD_PROSELYTING_AREA_ID);
		testPerson.setPreferredLangId(KNOWN_GOOD_LANGUAGE_ID);
		testPerson.setStatus(status);

		testPerson.setContactSource(cntSource);
		testPerson.setHouseholdId(hTemp.getGuid());
		System.out.println(testPerson.getContactSource());
		Person response = template.createPerson("application/json", testPerson, Person.class);
		assertEquals("Automation", response.getFirstName());
		assertEquals(timeLast, response.getLastName());
		return response;
	}

    private Household createAutomationHousehold(String addy) {
        Household testHH = new Household();
        testHH.setAddress(addy);
        return templateHousehold.get().createHousehold("application/json", testHH, Household.class);
    }
}
