
/*
* Copyright (C) 2015 Intellectual Reserve, Inc. All rights reserved.
* This notice may not be removed.
*/

package lds.personservice.regression;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import org.junit.Test;


import static org.hamcrest.Matchers.containsString;

/*
 * @author Dan Adams and Zack Beck
 */
public class PersonRegressionAutomationRT {

    private final String user;
    private final String password;
    private final String uri;
    
    public PersonRegressionAutomationRT(){
        user = RestRegressionSpec.getUsername();
        password = RestRegressionSpec.getPassword();
        uri = RestRegressionSpec.getBaseUri();
    }
    
    @Test
    public void getPersonByGUID() {

        RequestSpecification requestSpecification = RestAssured.given();

        requestSpecification = requestSpecification
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .baseUri(uri)
                .basePath("/people/37088EDAF032BF88A28102C20E44EDBF")
                .authentication().basic(user, password);

        Response response = requestSpecification
                .get()
                .prettyPeek();

        response.then()
                //Verify returned JSON accepted id for new Person
                .body(containsString("37088EDAF032BF88A28102C20E44EDBF"))
                .contentType(ContentType.JSON)
                .statusCode(200);
    }
    @Test
    public void postHouseholdwithPersonCascade() {

        RequestSpecification requestSpecification = RestAssured.given();

        requestSpecification = requestSpecification
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .baseUri(uri)
                .basePath("/households")
                .body("{\n"
                    + "\"id\" : \"12345671234567123456712345678965\",\n"
                    + "\"people\": [\n"
                    + "{\"id\": \"00000009999999888876543212345678\",\n" 
                    + "\"contactSource\": \"120\",\n"
                    + "\"status\": \"1\",\n"
                    + "\"lastName\":\"Cruger\"\n"
                        + "}"
                    + "]"
                    + "}")
                .authentication().basic(user, password);
               

        Response response = requestSpecification
                .post()
                .prettyPeek();

        response.then()
                //Verify returned JSON accepted id for new Household
                .body(containsString("12345671234567123456712345678965"))
                //Verify returned JSON accepted id for new Person
                .body(containsString("00000009999999888876543212345678"))
                .contentType(ContentType.JSON)
                .statusCode(200);
    }
    @Test
    public void postACommitmentWithMinimumRequiredJSON() {

        RequestSpecification requestSpecification = RestAssured.given();

        requestSpecification = requestSpecification
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .baseUri(uri)
                .basePath("/commitments")
                .body("{\n"
                    + "\"inviteDate\" : \"1450480436000\",\n"
                    + "\"personId\": \"12345678987456123568749856213587\",\n"
                    + "\"teachingItemId\": \"6\",\n" 
                    + "\"wasKept\": \"true\",\n"
                    + "}")
                .authentication().basic(user, password);
               

        Response response = requestSpecification
                .post()
                .prettyPeek();

        response.then()
                .body(containsString("true"))
                .body(containsString("12345678987456123568749856213587"))
                .contentType(ContentType.JSON)
                .statusCode(200);
    }
    @Test
    public void postACommitmentWithMaximumRequiredJSON() {

        RequestSpecification requestSpecification = RestAssured.given();

        requestSpecification = requestSpecification
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .baseUri(uri)
                .basePath("/commitments")
                .body("{\n"
                    + "\"inviteDate\" : \"1450480436000\",\n"
                    + "\"id\" : \"39325987456231589595125784563289\",\n"
                    + "\"personId\": \"12345678987456123568749856213587\",\n"
                    + "\"teachingItemId\": \"6\",\n" 
                    + "\"wasKept\": \"true\",\n"
                    + "\"inviteDate\": \"12345\",\n"
                    + "\"keptDate\": \"12345\",\n"    
                    + "}")
                .authentication().basic(user, password);
               

        Response response = requestSpecification
                .post()
                .prettyPeek();

        response.then()
                .body(containsString("true"))
                .body(containsString("39325987456231589595125784563289"))
                .contentType(ContentType.JSON)
                .statusCode(200);
    }
    @Test
    public void deleteACommitment() {

        RequestSpecification requestSpecification = RestAssured.given();

        requestSpecification = requestSpecification
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .baseUri(uri)
                .basePath("/commitments/3AE4C42DD6BA81A0FAB60F22F2874498")
                .authentication().basic(user, password);
               

        Response response = requestSpecification
                .delete()
                .prettyPeek();

        response.then()
                .statusCode(200);
    }
    
}


