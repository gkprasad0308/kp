package lds.personservice.household;


import lds.personservice.AbstractUpdateSqlTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class HouseholdInsertSqlTest extends AbstractUpdateSqlTest {

    @InjectMocks
    private HouseholdInsertSql insertSql;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            AbstractHouseholdSqlUpdate.HOUSEHOLD_ID,
            AbstractHouseholdSqlUpdate.ADDR,
            AbstractHouseholdSqlUpdate.MSNY_ID,
            AbstractHouseholdSqlUpdate.ORG_ID,
            AbstractHouseholdSqlUpdate.STWRD_CMIS_ID,
            AbstractHouseholdSqlUpdate.LAT,
            AbstractHouseholdSqlUpdate.LNG,
            AbstractHouseholdSqlUpdate.PIN_DROP,
            AbstractHouseholdSqlUpdate.CLIENT_GUID
    );

    @Override
    protected SqlUpdate getInstance() {
        return insertSql;
    }

    @Override
    protected List<String> getExpectedParams() {
        return expectedParams;
    }

    @Test
    public void getParamsUsingDoesExpected(){
        Household household = mock(Household.class);
        when(household.getServerId()).thenReturn(123L);
        when(household.getAddress()).thenReturn("address");
        when(household.getMissionaryId()).thenReturn(456L);
        when(household.getOrgId()).thenReturn(789L);
        when(household.getStewardCmisId()).thenReturn(100L);
        when(household.getLat()).thenReturn("56.78");
        when(household.getLng()).thenReturn("12.34");
        when(household.getPinDropped()).thenReturn(true);
        when(household.getGuid()).thenReturn("abc");

        Map<String, Object> results = insertSql.getParamsUsing(household);
        checkKeys(results);

        assertEquals(123L, results.get(AbstractHouseholdSqlUpdate.HOUSEHOLD_ID));
        assertEquals("address", results.get(AbstractHouseholdSqlUpdate.ADDR));
        assertEquals(456L, results.get(AbstractHouseholdSqlUpdate.MSNY_ID));
        assertEquals(789L, results.get(AbstractHouseholdSqlUpdate.ORG_ID));
        assertEquals(100L, results.get(AbstractHouseholdSqlUpdate.STWRD_CMIS_ID));
        assertEquals("56.78", results.get(AbstractHouseholdSqlUpdate.LAT));
        assertEquals("12.34", results.get(AbstractHouseholdSqlUpdate.LNG));
        assertEquals("Y", results.get(AbstractHouseholdSqlUpdate.PIN_DROP));
        assertEquals("abc",results.get(AbstractHouseholdSqlUpdate.CLIENT_GUID));

        verify(household, times(1)).getServerId();
        verify(household, times(1)).getAddress();
        verify(household, times(1)).getMissionaryId();
        verify(household, times(1)).getOrgId();
        verify(household, times(1)).getStewardCmisId();
        verify(household, times(1)).getLat();
        verify(household, times(1)).getLng();
        verify(household, times(1)).getPinDropped();
        verify(household, times(1)).getGuid();
        verifyNoMoreInteractions(household);
    }
}
