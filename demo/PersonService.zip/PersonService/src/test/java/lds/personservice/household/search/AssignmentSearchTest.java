package lds.personservice.household.search;

import lds.personservice.household.ListParams;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertEquals;

public class AssignmentSearchTest {

    private static final String EXPECTED_SQL_WITHOUT = "SELECT h.hshld_id,h.client_guid AS hshld_client_guid," +
            "h.addr AS hshld_addr,h.msny_id AS hshld_msny_id,h.org_id AS hshld_org_id," +
            "h.stwrd_cmis_id AS hshld_stwrd_cmis_id,h.lat AS hshld_lat,h.lng AS hshld_lng," +
            "h.del_yn AS hshld_del_yn,h.pin_drop_yn AS hshld_pin_drop_yn,h.crt_dt AS hshld_crt_dt," +
            "h.mod_dt AS hshld_mod_dt,p.person_id,p.hshld_id AS person_hshld_id," +
            "p.del_yn AS person_del_yn,p.first_nm AS person_first_nm,p.last_nm AS person_last_nm," +
            "p.age_c_id AS person_age_c_id,p.gender AS person_gender,p.person_stat_id," +
            "p.crt_dt AS person_crt_dt,p.mod_dt AS person_mod_dt,p.note AS person_note," +
            "p.afab_focus_person_yn AS person_afab_focus_person_yn,p.cmis_id AS person_cmis_id," +
            "p.pros_area_id AS person_pros_area_id,p.client_guid AS person_client_guid," +
            "p.convert_yn AS person_convert_yn,p.find_id AS person_find_id," +
            "p.pref_lang_id AS person_pref_lang_id,p.pref_cntct_t_id AS person_pref_cntct_t_id," +
            "p.find_dtl_id AS person_find_dtl_id " +
            "FROM  ims.hshld_mstr h LEFT JOIN  ims.person_mstr p ON h.hshld_id = p.hshld_id " +
            "WHERE 1=1  AND p.del_yn = :deleted AND h.del_yn = :deleted";

    private static final String EXPECTED_SQL_WITH = "SELECT h.hshld_id,h.client_guid AS hshld_client_guid,h.addr AS hshld_addr,h.msny_id AS hshld_msny_id,h.org_id AS hshld_org_id,h.stwrd_cmis_id AS hshld_stwrd_cmis_id,h.lat AS hshld_lat,h.lng AS hshld_lng,h.del_yn AS hshld_del_yn,h.pin_drop_yn AS hshld_pin_drop_yn,h.crt_dt AS hshld_crt_dt,h.mod_dt AS hshld_mod_dt,p.person_id,p.hshld_id AS person_hshld_id,p.del_yn AS person_del_yn,p.first_nm AS person_first_nm,p.last_nm AS person_last_nm,p.age_c_id AS person_age_c_id,p.gender AS person_gender,p.person_stat_id,p.crt_dt AS person_crt_dt,p.mod_dt AS person_mod_dt,p.note AS person_note,p.afab_focus_person_yn AS person_afab_focus_person_yn,p.cmis_id AS person_cmis_id,p.pros_area_id AS person_pros_area_id,p.client_guid AS person_client_guid,p.convert_yn AS person_convert_yn,p.find_id AS person_find_id,p.pref_lang_id AS person_pref_lang_id,p.pref_cntct_t_id AS person_pref_cntct_t_id,p.find_dtl_id AS person_find_dtl_id FROM  ims.hshld_mstr h LEFT JOIN  ims.person_mstr p ON h.hshld_id = p.hshld_id  JOIN  ims.crnt_person_gtt crpgtt  ON p.person_id = crpgtt.person_id WHERE 1=1  AND p.del_yn = :deleted AND h.del_yn = :deleted";

    @Test(expected = NullPointerException.class)
    public void constructorThrowsIfNoListParams(){
        BaseSearch search = new AssignmentSearch(null);
    }

    @Test
    public void getSqlReturnsExpectedSqlWithoutASsignmentArea(){

        BaseSearch search = new AssignmentSearch(new ListParams());
        String sql = search.getSql();
        assertEquals(EXPECTED_SQL_WITHOUT, sql);
    }

    @Test
    public void getSqlReturnsExpectedSqlWithAsignmentArea(){
        ListParams listParams = new ListParams();
        listParams.setAssignmentArea(5500011L);
        BaseSearch search = new AssignmentSearch(listParams);
        String sql = search.getSql();
        assertEquals(EXPECTED_SQL_WITH, sql);
    }
}
