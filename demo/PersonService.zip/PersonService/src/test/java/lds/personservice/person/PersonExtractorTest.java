package lds.personservice.person;


import lds.personservice.contactinfo.ContactInfoRowMapper;
import lds.personservice.person.referral.ReferralMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PersonExtractorTest {

    @Mock
    private ResultSet rs;

    @Mock
    private PersonRowMapper personRowMapper;

    @Mock
    private ReferralMapper referralMapper;

    @Mock
    private ContactInfoRowMapper contactInfoRowMapper;

    private PersonExtractor extractor;

    @Before
    public void setup(){
        extractor = new PersonExtractor();
        ReflectionTestUtils.setField(extractor, "mapper", personRowMapper);
        ReflectionTestUtils.setField(extractor, "referralMapper", referralMapper);
        ReflectionTestUtils.setField(extractor, "contactInfoRowMapper", contactInfoRowMapper);
    }

    @Test
    public void extractDataReturnsEmptyListIfNoPersonId() throws SQLException {
        when(rs.next()).thenReturn(true).thenReturn(false);
        when(rs.getObject(PersonRowMapper.PERSON_ID)).thenReturn(null);
        List<Person> result = extractor.extractData(rs);
        assertTrue(CollectionUtils.isEmpty(result));
        assertNotNull(result);
        verify(rs, times(2)).next();
        verify(rs, times(1)).getObject(PersonRowMapper.PERSON_ID);
        verifyNoMoreInteractions(rs);
        verifyZeroInteractions(personRowMapper, referralMapper, contactInfoRowMapper);
    }

    @Test
    public void extractDataCallsExpectedWhenPersonIdPresent() throws SQLException {
        Person mockPerson = mock(Person.class);

        when(personRowMapper.mapRow(rs, 1)).thenReturn(mockPerson);
        when(rs.next()).thenReturn(true).thenReturn(false);
        when(rs.getObject(PersonRowMapper.PERSON_ID)).thenReturn(123L);
        when(rs.getRow()).thenReturn(1);

        List<Person> result = extractor.extractData(rs);
        assertThat(result, contains(mockPerson));
        verify(rs, times(2)).next();
        verify(rs, times(1)).getRow();
        verify(rs, times(1)).getObject(PersonRowMapper.PERSON_ID);
        verify(personRowMapper, times(1)).mapRow(rs, 1);
        verify(referralMapper, times(1)).mapRow(rs, 1);
        verify(contactInfoRowMapper, times(1)).mapRow(rs, 1);
        verify(mockPerson, times(1)).setContactInfo(any());
        verify(mockPerson, times(1)).setReferralInfo(any());
        verifyNoMoreInteractions(rs, mockPerson, personRowMapper, referralMapper, contactInfoRowMapper);
    }
}
