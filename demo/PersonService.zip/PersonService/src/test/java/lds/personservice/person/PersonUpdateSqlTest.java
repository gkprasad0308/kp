package lds.personservice.person;

import lds.personservice.AbstractUpdateSqlTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PersonUpdateSqlTest extends AbstractUpdateSqlTest {

    @InjectMocks
    private PersonUpdateSql updateSql;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            PersonUpdateSql.FIRST_NAME,
            PersonUpdateSql.LAST_NAME,
            PersonUpdateSql.AGE_CAT_ID,
            PersonUpdateSql.GENDER,
            PersonUpdateSql.HSHLD_ID,
            PersonUpdateSql.STATUS_ID,
            PersonUpdateSql.NOTE,
            PersonUpdateSql.FOCUS_PERSON,
            PersonUpdateSql.CMIS_ID,
            PersonUpdateSql.CONVERT,
            PersonUpdateSql.SOURCE_ID,
            PersonUpdateSql.PREF_LANG_ID,
            PersonUpdateSql.PREF_CONTACT_TYPE,
            PersonUpdateSql.SOURCE_DTL,
            PersonUpdateSql.PERSON_ID
    );

    @Override
    protected SqlUpdate getInstance() {
        return updateSql;
    }

    @Override
    protected List<String> getExpectedParams() {
        return expectedParams;
    }

    @Test
    public void getParamsUsingDoesExpected(){
        Person person = mock(Person.class);
        when(person.getFirstName()).thenReturn("bob");
        when(person.getLastName()).thenReturn("smith");
        when(person.getAgeCatId()).thenReturn(1);
        when(person.getGender()).thenReturn("M");
        when(person.getHouseholdServerId()).thenReturn(456L);
        when(person.getStatus()).thenReturn(40);
        when(person.getNote()).thenReturn("note");
        when(person.isFocusPerson()).thenReturn(true);
        when(person.getCmisId()).thenReturn(789L);
        when(person.isConvert()).thenReturn(true);
        when(person.getContactSource()).thenReturn(2);
        when(person.getContactSourceDtl()).thenReturn(3);
        when(person.getServerId()).thenReturn(123L);
        when(person.getPreferredLangId()).thenReturn(0);
        when(person.getPreferredContactType()).thenReturn(5);

        Map<String, Object> results = updateSql.getParamsUsing(person);
        checkKeys(results);

        assertEquals("bob", results.get(PersonUpdateSql.FIRST_NAME));
        assertEquals("smith", results.get(PersonUpdateSql.LAST_NAME));
        assertEquals(1, results.get(PersonUpdateSql.AGE_CAT_ID));
        assertEquals("M", results.get(PersonUpdateSql.GENDER));
        assertEquals(456L, results.get(PersonUpdateSql.HSHLD_ID));
        assertEquals(40, results.get(PersonUpdateSql.STATUS_ID));
        assertEquals("note", results.get(PersonUpdateSql.NOTE));
        assertEquals("Y", results.get(PersonUpdateSql.FOCUS_PERSON));
        assertEquals(789L, results.get(PersonUpdateSql.CMIS_ID));
        assertEquals("Y", results.get(PersonUpdateSql.CONVERT));
        assertEquals(2, results.get(PersonUpdateSql.SOURCE_ID));
        assertEquals(3, results.get(PersonUpdateSql.SOURCE_DTL));
        assertEquals(123L, results.get(PersonUpdateSql.PERSON_ID));
        assertEquals(0, results.get(PersonUpdateSql.PREF_LANG_ID));
        assertEquals(5, results.get(PersonUpdateSql.PREF_CONTACT_TYPE));

        verify(person, times(1)).getFirstName();
        verify(person, times(1)).getLastName();
        verify(person, times(1)).getAgeCatId();
        verify(person, times(1)).getGender();
        verify(person, times(1)).getHouseholdServerId();
        verify(person, times(1)).getStatus();
        verify(person, times(1)).getNote();
        verify(person, times(1)).isFocusPerson();
        verify(person, times(1)).getCmisId();
        verify(person, times(1)).isConvert();
        verify(person, times(1)).getContactSource();
        verify(person, times(1)).getContactSourceDtl();
        verify(person, times(1)).getServerId();
        verify(person, times(1)).getPreferredLangId();
        verify(person, times(1)).getPreferredContactType();
        verifyNoMoreInteractions(person);
    }
}
