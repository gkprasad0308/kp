package lds.personservice.person.drop;

import java.net.URI;

import javax.inject.Inject;
import javax.inject.Provider;

import lds.personservice.Main;
import lds.personservice.person.Person;
import lds.personservice.person.PersonRepository;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.junit.Assert.assertEquals;

@ActiveProfiles({ "local" })
@IntegrationTest({ "browser.startup=false", "server.port=0" })
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class DropNoteControllerIT {

	@Value("http://localhost:${local.server.port}${lds.api.resources.people.href}") private URI serviceDetailsUri;

	private static final Long KNOWN_GOOD_PERSON_STEWARD_ID = 7154206L;
	private static final Long KNOWN_GOOD_PERSON_ID = 2735285L;
	private static final String KNOWN_GOOD_PERSON_GUID = "3c2a51fe68eaec1701526a97fe93dff5";
	private static final Integer KNOWN_GOOD_DROP_STATUS = 20;
	@Inject private Provider<DropNoteTemplate> templateProvider;

	@Autowired PersonRepository repository;

	@Autowired DropNoteRepository dropNoteRepository;

	// Test undo drop controller end point
	@Test
	public void testUndoDrop() {
		Person base = repository.getPersonById(KNOWN_GOOD_PERSON_ID);
		base.setDropNotes(dropNoteRepository.getNotesForPerson(KNOWN_GOOD_PERSON_ID));

		DropNoteTemplate template = templateProvider.get();
		WritableDropNote drop = new WritableDropNote();
		drop.setNote("test");
		drop.setPersonId(KNOWN_GOOD_PERSON_ID);
		drop.setPersonStewardId(KNOWN_GOOD_PERSON_STEWARD_ID);
		drop.setStatus(KNOWN_GOOD_DROP_STATUS);

		Person result = template.undoDropPerson(KNOWN_GOOD_PERSON_GUID);
		assertEquals(base.getDropNotes().size(), result.getDropNotes().size());
	}
}
