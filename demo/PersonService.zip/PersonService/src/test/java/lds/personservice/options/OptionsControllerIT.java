package lds.personservice.options;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Provider;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import lds.personservice.Main;

@ActiveProfiles({ "local" })
@IntegrationTest({ "browser.startup=false", "server.port=0" })
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class OptionsControllerIT {

	@Value("http://localhost:${local.server.port}${lds.api.resources.options.href}") private URI serviceDetailsUri;
	@Inject private Provider<OptionsTemplate> templateProvider;

	@Test
	public void get_languages() {
		OptionsTemplate template = templateProvider.get();

		ArrayList<Map<String, Object>> langs = template.getOptions("language");

		for (int y = 0; y < langs.size(); y++) {
			Map<String, Object> oneLang = langs.get(y);
			assertTrue(oneLang.get("name") != null);

			if ((Integer) oneLang.get("id") == 0) {
				assertEquals("English", oneLang.get("name"));
				assertEquals("eng", oneLang.get("iso3Code"));
				assertTrue((boolean) oneLang.get("written"));
				assertTrue((boolean) oneLang.get("spoken"));
			}
		}
	}

	@Test
	public void get_sources() {
		OptionsTemplate template = templateProvider.get();

		List<Map<String, Object>> sources = template.getOptions("source");

		for (int y = 0; y < sources.size(); y++) {
			Map<String, Object> oneSource = sources.get(y);
			assertTrue(oneSource.get("typeId") != null);

			if ((Integer) oneSource.get("id") == 5393) {
				assertEquals(8210, oneSource.get("typeId"));
				assertEquals("FACEBOOK", oneSource.get("code"));
				assertEquals(5391, oneSource.get("parentId"));
			}
		}
	}

	@Test
	public void get_status() {
		OptionsTemplate template = templateProvider.get();

		List<Map<String, Object>> statuses = template.getOptions("status");

		for (int y = 0; y < statuses.size(); y++) {
			Map<String, Object> oneStatus = statuses.get(y);
			assertTrue(oneStatus.get("typeId") != null);

			if ((Integer) oneStatus.get("id") == 23) {
				assertEquals("Unable to contact", oneStatus.get("name"));
				assertEquals("NOT_ABLE_CONTACT", oneStatus.get("code"));
				assertEquals(5, oneStatus.get("parentId"));
			}
		}
	}

	@Test
	public void get_ages() {
		OptionsTemplate template = templateProvider.get();

		List<Map<String, Object>> ages = template.getOptions("age");

		for (int y = 0; y < ages.size(); y++) {
			Map<String, Object> oneAge = ages.get(y);
			assertTrue(oneAge.get("id") != null);

			if ((Integer) oneAge.get("id") == 40) {
				assertEquals("31-50", oneAge.get("name"));
				assertEquals("MIDDLE_AGE_ADULT", oneAge.get("code"));
			}
		}
	}

	@Test
	public void get_contact_types() {
		OptionsTemplate template = templateProvider.get();

		List<Map<String, Object>> cTypes = template.getOptions("contactType");

		for (int y = 0; y < cTypes.size(); y++) {
			Map<String, Object> oneType = cTypes.get(y);
			assertTrue(oneType.get("id") != null);

			if ((Integer) oneType.get("id") == 30) {
				assertEquals("Text", oneType.get("name"));
				assertEquals("TEXT", oneType.get("code"));
			}
		}
	}

	@Test
	public void get_sources_by_lang() {
		OptionsTemplate template = templateProvider.get();

		List<Map<String, Object>> sources = template.getOptionsByLang("source", "deu");

		for (int y = 0; y < sources.size(); y++) {
			Map<String, Object> oneSource = sources.get(y);
			assertTrue(oneSource.get("typeId") != null);

			if ((Integer) oneSource.get("id") == 5014) {
				assertEquals("Gemeinderat", oneSource.get("name"));
				assertEquals("WRD_CNCL", oneSource.get("code"));
				assertEquals(5011, oneSource.get("parentId"));
			}
		}
	}
}
