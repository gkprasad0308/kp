package lds.personservice;

import com.jayway.jsonassert.JsonAssert;
import lds.personservice.client.ResourceTemplate;
import org.hamcrest.Matchers;
import org.springframework.http.*;

import javax.inject.Inject;
import java.util.regex.Pattern;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;


public abstract class AbstractValidationTestRunnerIT<T> {

    public static final String MISSING = "missing";
    public static final String UNSUPPORTED = "unsupported";
    public static final String OUTOFBOUNDS = "outofbounds";
    public static final String BAD = "bad";
    public static final String INVALID = "invalid";

    protected abstract ResourceTemplate getTemplate();
    protected abstract HttpMethod getHttpMethod();

    protected String getModelName(T payload){
        return payload.getClass().getSimpleName().toLowerCase();
    }

    protected void runGlobalErrorInclusiveTest(T payload, String expectedError){
        runGlobalErrorInclusiveTest(payload, getTemplate().getResourceUriAsString(), expectedError);
    }

    protected void runGlobalErrorInclusiveTest(T payload, String url, String expectedError){
        ResponseEntity<String> response = sendRequest(payload, url);
        JsonAssert.with(response.getBody())
                .assertThat("$.status", is(Matchers.equalTo(HttpStatus.BAD_REQUEST.name())))
                .assertThat("$.globalErrors", hasItem(expectedError));
    }

    protected void runFieldErrorInclusiveTest(T payload, String expectedField, String expectedMessageFragment){
        runFieldErrorInclusiveTest(payload, getTemplate().getResourceUriAsString(), expectedField, expectedMessageFragment);
    }

    protected void runFieldErrorInclusiveTest(T payload, String url, String expectedField, String expectedMessageFragment){
        ResponseEntity<String> response = sendRequest(payload, url);
        JsonAssert.with(response.getBody())
                .assertThat("$.status", is(Matchers.equalTo(HttpStatus.BAD_REQUEST.name())))
                .assertThat(getErrorQuery(expectedField), hasItem(getAssertion(getModelName(payload), expectedField, expectedMessageFragment)));
    }

    protected void runFieldErrorExclusiveTest(T payload, String expectedField){
        runFieldErrorExclusiveTest(payload, getTemplate().getResourceUriAsString(), expectedField);
    }

    protected void runFieldErrorExclusiveTest(T payload, String url, String expectedField){
        ResponseEntity<String> response = sendRequest(payload, url);
        JsonAssert.with(response.getBody())
                .assertThat("$.status", is(Matchers.equalTo(HttpStatus.BAD_REQUEST.name())))
                .assertThat(getErrorQuery(expectedField), is(empty()));
    }

    private ResponseEntity<String> sendRequest(T payload, String url) {
        ResourceTemplate template = getTemplate();
        ResponseEntity<String> response = template.sendRequestIgnoreError(
                url,
                getHttpMethod(),
                new HttpEntity(payload, template.constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE)),
                String.class
        );
        assertEquals("Expected result to be a bad request signifying that validation handled correctly",
                HttpStatus.BAD_REQUEST, response.getStatusCode());
        return response;
    }

    private String getAssertion(String payloadName, String expectedField, String expectedMessageFragment) {
        return "error."+ getHttpMethod().name().toLowerCase() + "." + payloadName +"." + expectedMessageFragment +"." + expectedField;
    }

    private String getErrorQuery(String expectedField) {
        return "$.fieldErrors[?(@.field =~ /"+ Pattern.quote(expectedField.toLowerCase()) + "/i)].code";
    }
}
