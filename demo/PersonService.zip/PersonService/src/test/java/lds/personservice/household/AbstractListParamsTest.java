package lds.personservice.household;


import com.jayway.jsonassert.JsonAssert;
import lds.prsms.utils.errors.ServiceException;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;

public abstract class AbstractListParamsTest {
    protected ListParams listParams;

    @Before
    public void setup(){
        listParams = new ListParams();
    }

    protected abstract void callParser(String value);
    protected abstract List<Long> getValues();
    protected abstract String getFieldName();

    @Test(expected = ServiceException.class)
    public void parseThrowsExceptionIfInvalid(){
        callParser("abc");
    }

    @Test
    public void parseSetsEmptyIfNullValue(){
        callParser(null);
        List<Long> values = getValues();
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    @Test
    public void parseIdsSetsNullIfEmptyValue(){
        callParser("");
        List<Long> values = getValues();
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    @Test
    public void parseSplitsIntoList(){
        callParser("1,2");
        List<Long> results = getValues();
        assertThat(results, hasItem(1L));
        assertThat(results, hasItem(2L));
    }

    @Test
    public void toStringReturnsStringAsWrappedJson(){
        callParser("123");
        JsonAssert.with(listParams.toString())
                .assertThat("$." + getFieldName(), contains(123));
    }

    @Test
    public void hasActionableContentIsTrueIfValuesSet(){
        callParser("1,2");
        assertTrue(listParams.hasActionableContent());
    }

    @Test
    public void hasActionableContentIsFalseIfNothingSet(){
        callParser("");
        assertFalse(listParams.hasActionableContent());
    }
}
