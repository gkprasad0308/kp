package lds.personservice.household.search;

import lds.personservice.household.ListParams;
import org.junit.Test;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.TestCase.assertNull;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;

public class ExcludeDeletedSearchComponentTest {

    @Test
    public void buildFragmentReturnsNullIfNullListParams(){
        ExcludeDeletedSearchComponent component = new ExcludeDeletedSearchComponent("p");
        assertNull(component.buildFragment(null));
    }

    @Test
    public void buildFragmentReturnsNullIfNoPrefixes(){
        ListParams params = new ListParams();
        params.setIncludeDeleted(false);
        ExcludeDeletedSearchComponent component = new ExcludeDeletedSearchComponent();
        assertNull(component.buildFragment(params));
    }

    @Test
    public void buildFragmentReturnsNullIfIncludeDeleted(){
        ListParams params = new ListParams();
        params.setIncludeDeleted(true);
        ExcludeDeletedSearchComponent component = new ExcludeDeletedSearchComponent("p");
        assertNull(component.buildFragment(params));
    }

    @Test
    public void buildFragmentReturnsExpectedFragment(){
        ListParams params = new ListParams();
        params.setIncludeDeleted(false);

        ExcludeDeletedSearchComponent component = new ExcludeDeletedSearchComponent("p", "h");
        SearchFragment fragment = component.buildFragment(params);
        assertNotNull(fragment);
        assertFalse(fragment.isEmpty());
        assertThat(fragment.getParams().getValues().keySet(), hasItem("deleted"));
        assertThat(fragment.getParams().getValues().values(), hasItem("N"));
        assertThat(fragment.getWhereFragment(), containsString("p.del_yn = :deleted AND h.del_yn = :deleted"));
    }
}
