package lds.personservice.contactinfo.email;


import lds.personservice.contactinfo.phone.Phone;
import org.junit.Test;

import static org.junit.Assert.*;

public class EmailTest {

    @Test
    public void equalsIsFalseIfNull(){
        assertFalse(new Email().equals(null));
    }

    @Test
    public void equalsIsFalseIfNotEmail(){
        assertFalse(new Email().equals(new Phone()));
    }

    @Test
    public void equalsIsTrueIfSameFields(){
        assertTrue(new Email(EmailTypes.EMAIL_HOME, "123").equals(new Email(EmailTypes.EMAIL_HOME, "123")));
    }

    @Test
    public void equalsIfFalseIfDifferentType(){
        assertFalse(new Email(EmailTypes.EMAIL_HOME, "123").equals(new Email(EmailTypes.EMAIL_FAMILY, "123")));
    }

    @Test
    public void equalsIfFalseIfDifferentAddress(){
        assertFalse(new Email(EmailTypes.EMAIL_HOME, "123").equals(new Email(EmailTypes.EMAIL_HOME, "456")));
    }

    @Test
    public void hashCodeReturnsSameResultWithSameTypeAndAddress(){
        Email e1 = new Email(EmailTypes.EMAIL_HOME, "123");
        Email e2 = new Email(EmailTypes.EMAIL_HOME, "123");

        assertEquals(e1.hashCode(), e2.hashCode());
    }

    @Test
    public void hashCodeReturnsDifferentResultWithDifferentNumber(){
        Email e1 = new Email(EmailTypes.EMAIL_HOME, "123");
        Email e2 = new Email(EmailTypes.EMAIL_HOME, "1234");

        assertNotEquals(e1.hashCode(), e2.hashCode());
    }

    @Test
    public void hashCodeReturnsDifferentResultWithDifferentType(){
        Email e1 = new Email(EmailTypes.EMAIL_HOME, "123");
        Email e2 = new Email(EmailTypes.EMAIL_FAMILY, "123");

        assertNotEquals(e1.hashCode(), e2.hashCode());
    }
}
