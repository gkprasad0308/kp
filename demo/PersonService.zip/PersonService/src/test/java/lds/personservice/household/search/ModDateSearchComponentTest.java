package lds.personservice.household.search;

import lds.personservice.household.ListParams;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.*;

public class ModDateSearchComponentTest {

    @Test
    public void buildFragmentReturnsNullIfNoListParam(){
        SearchComponent component = new ModDateSearchComponent("p");
        assertNull(component.buildFragment(null));
    }

    @Test
    public void buildFragmentReturnsNullIfNoPrefixes(){
        ListParams listParams = new ListParams();
        listParams.setModDate(System.currentTimeMillis());

        SearchComponent component = new ModDateSearchComponent();
        assertNull(component.buildFragment(listParams));
    }

    @Test
    public void buildFragmentReturnsNullIfNoModDate(){
        ListParams listParams = new ListParams();

        SearchComponent component = new ModDateSearchComponent("p");
        assertNull(component.buildFragment(listParams));
    }

    @Test
    public void buildFragmentReturnsExpected(){
        Date modDate = Calendar.getInstance().getTime();
        ListParams listParams = new ListParams();
        listParams.setModDate(modDate.getTime());

        SearchComponent component = new ModDateSearchComponent("p");
        SearchFragment fragment = component.buildFragment(listParams);
        assertNonEmptyFragment(fragment);
        assertParametersContains(fragment, modDate, "modDate");
        assertThat(fragment.getWhereFragment(), containsString("( p.mod_dt >= :modDate )"));
    }

    @Test
    public void buildFragmentReturnsExpectedWithTwoPrefixes(){
        Date modDate = Calendar.getInstance().getTime();
        ListParams listParams = new ListParams();
        listParams.setModDate(modDate.getTime());

        SearchComponent component = new ModDateSearchComponent("p", "h");
        SearchFragment fragment = component.buildFragment(listParams);
        assertNonEmptyFragment(fragment);
        assertParametersContains(fragment, modDate, "modDate");
        assertThat(fragment.getWhereFragment(), containsString("( p.mod_dt >= :modDate OR h.mod_dt >= :modDate )"));
    }

    private void assertParametersContains(SearchFragment fragment, Object value, String key) {
        assertThat(fragment.getParams().getValues().keySet(), contains(key));
        assertThat(fragment.getParams().getValues().values(), contains(value));
    }

    private void assertNonEmptyFragment(SearchFragment fragment) {
        assertNotNull(fragment);
        assertFalse(fragment.isEmpty());
    }
}
