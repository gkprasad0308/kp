package lds.personservice.contactinfo.phone;

import lds.personservice.contactinfo.email.Email;
import org.junit.Test;

import static org.junit.Assert.*;

public class PhoneTest {
    @Test
    public void equalsIsFalseIfNull(){
        assertFalse(new Phone().equals(null));
    }

    @Test
    public void equalsIsFalseIfNotEmail(){
        assertFalse(new Phone().equals(new Email()));
    }

    @Test
    public void equalsIsTrueIfSameFields(){
        assertTrue(new Phone(PhoneTypes.PHN_HOME, "123").equals(new Phone(PhoneTypes.PHN_HOME, "123")));
    }

    @Test
    public void equalsIfFalseIfDifferentType(){
        assertFalse(new Phone(PhoneTypes.PHN_HOME, "123").equals(new Phone(PhoneTypes.PHN_MOBILE, "123")));
    }

    @Test
    public void equalsIfFalseIfDifferentAddress(){
        assertFalse(new Phone(PhoneTypes.PHN_HOME, "123").equals(new Phone(PhoneTypes.PHN_HOME, "456")));
    }

    @Test
    public void hashCodeReturnsSameResultWithSameTypeAndNumber(){
        Phone p1 = new Phone(PhoneTypes.PHN_HOME, "123");
        Phone p2 = new Phone(PhoneTypes.PHN_HOME, "123");

        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    public void hashCodeReturnsDifferentResultWithDifferentNumber(){
        Phone p1 = new Phone(PhoneTypes.PHN_HOME, "123");
        Phone p2 = new Phone(PhoneTypes.PHN_HOME, "1234");

        assertNotEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    public void hashCodeReturnsDifferentResultWithDifferentType(){
        Phone p1 = new Phone(PhoneTypes.PHN_HOME, "123");
        Phone p2 = new Phone(PhoneTypes.PHN_MOBILE, "123");

        assertNotEquals(p1.hashCode(), p2.hashCode());
    }
}
