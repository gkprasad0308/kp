package lds.personservice.person;

import lds.personservice.AbstractValidationTestRunnerIT;
import lds.personservice.Main;
import lds.personservice.client.ResourceTemplate;
import lds.personservice.client.household.HouseholdTemplate;
import lds.personservice.contactinfo.ContactInfo;
import lds.personservice.contactinfo.phone.PhoneTypes;
import lds.personservice.household.Household;
import lds.prsms.utils.UUIDGenerator;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import javax.inject.Inject;
import javax.inject.Provider;


@ActiveProfiles({ "local" })
@IntegrationTest({ "browser.startup=false", "server.port=0" })
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class PersonControllerPostValidationIT extends AbstractValidationTestRunnerIT<Person> {

    @Inject
    private Provider<PersonTemplate> templateProvider;

    @Inject
    private Provider<HouseholdTemplate> householdTemplateProvider;

    @Override
    protected ResourceTemplate getTemplate() {
        return templateProvider.get();
    }

    @Override
    protected HttpMethod getHttpMethod() {
        return HttpMethod.POST;
    }

    @Test
    public void create_person_no_householdId(){
        Person person = createSimplePostPerson();
        runFieldErrorInclusiveTest(person, "householdId", MISSING);
    }

    @Test
    public void create_person_household_id_matches_no_household(){
        Person person = createSimplePostPerson();
        person.setHouseholdId(UUIDGenerator.getInstance().getAsString());
        runFieldErrorInclusiveTest(person, "householdId", OUTOFBOUNDS);
    }

    @Test
    public void create_person_invalid_guid_results_in_error(){
        Person person = createSimplePostPerson();
        person.setGuid("1234");
        runFieldErrorInclusiveTest(person, "guid", BAD);
    }

    @Test
    public void create_person_firstName_invalid_if_exceeds_60(){
        Person person = createSimplePostPerson();
        person.setFirstName("123456789 123456789 123456789 123456789 123456789 123456789 1");
        runFieldErrorInclusiveTest(person, "firstName", OUTOFBOUNDS);
    }

    @Test
    public void create_person_lastName_invalid_if_exceeds_60(){
        Person person = createSimplePostPerson();
        person.setLastName("123456789 123456789 123456789 123456789 123456789 123456789 1");
        runFieldErrorInclusiveTest(person, "lastName", OUTOFBOUNDS);
    }

    @Test
    public void create_person_invalid_gender_of_g(){
        Person person = createSimplePostPerson();
        person.setGender("g");
        runFieldErrorInclusiveTest(person, "gender", UNSUPPORTED);
    }

    @Test
    public void create_person_case_sensitive_invalid_m(){
        Person person = createSimplePostPerson();
        person.setGender("m");
        runFieldErrorInclusiveTest(person, "gender", UNSUPPORTED);
    }

    @Test
    public void create_person_invalid_age_category(){
        Person person = createSimplePostPerson();
        person.setAgeCatId(-1);
        runFieldErrorInclusiveTest(person, "ageCatId", UNSUPPORTED);
    }

    @Test
    public void create_person_null_status_is_invalid(){
        Person person = createSimplePostPerson();
        person.setStatus(null);
        runFieldErrorInclusiveTest(person, "status", MISSING);
    }

    @Test
    public void create_person_invalid_status_check(){
        Person person = createSimplePostPerson();
        person.setStatus(-1);
        runFieldErrorInclusiveTest(person, "status", UNSUPPORTED);
    }

    @Test
    public void create_person_null_contact_source_invalid(){
        Person person = createSimplePostPerson();
        person.setContactSource(null);
        runFieldErrorInclusiveTest(person, "contactSource", MISSING);
    }

    @Test
    public void create_person_invalid_contact_source_check(){
        Person person = createSimplePostPerson();
        person.setContactSource(-1);
        runFieldErrorInclusiveTest(person, "contactSource", UNSUPPORTED);
    }

    @Test
    public void create_person_invalid_preferredLangId_check(){
        Person person = createSimplePostPerson();
        person.setPreferredLangId(-1);
        runFieldErrorInclusiveTest(person, "preferredLangId", UNSUPPORTED);
    }

    @Test
    public void create_person_null_preferredLangId_isValid(){
        Person person = createSimplePostPerson();
        person.setStatus(-1);
        person.setPreferredLangId(null);
        runFieldErrorExclusiveTest(person, "preferredLangId");
    }

    @Test
    public void create_person_invalid_preferredContactType_check(){
        Person person = createSimplePostPerson();
        person.setPreferredContactType(-1);
        runFieldErrorInclusiveTest(person, "preferredContactType", UNSUPPORTED);
    }

    @Test
    public void create_person_valid_when_null_preferredContactType(){
        Person person = createSimplePostPerson();
        person.setPreferredContactType(null);
        person.setStatus(-1);
        runFieldErrorExclusiveTest(person, "preferredContactType");
    }

    @Test
    public void simple_nested_test(){
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.addPhone(PhoneTypes.PHN_HOME, "a really really really really really really really really really really really really really long phone number");
        Person person = createSimplePostPerson();
        person.setContactInfo(contactInfo);
        runFieldErrorInclusiveTest(person, "contactInfo.phoneNumbers[0].number", OUTOFBOUNDS);
    }

    @Test
    public void create_person_invalid_when_cmisId_and_prosArea_provided(){
        Person person = createSimplePostPerson();
        person.setCmisId(123L);
        person.setProsAreaId(456L);
        runGlobalErrorInclusiveTest(person, "error.post.person.invalid.cmisId.member");
    }

    @Test
    public void createPersonGivesInvalidProsAreaAssignment(){
        Household household = new Household();
        household.setOrgId(4051656L);
        household = householdTemplateProvider.get().createHousehold(MediaType.APPLICATION_JSON_VALUE, household, Household.class);

        Person person = createSimplePostPerson();
        person.setHouseholdId(household.getGuid());
        person.setProsAreaId(5500011L);
        runGlobalErrorInclusiveTest(person, "error.post.person.incompatible.prosArea.for.household.org");
    }

    @Test
    public void createPersonGivesInvalidProsAreaAssignmentIfInvalidProsArea(){
        Household household = new Household();
        household.setOrgId(4051656L);
        household = householdTemplateProvider.get().createHousehold(MediaType.APPLICATION_JSON_VALUE, household, Household.class);

        Person person = createSimplePostPerson();
        person.setHouseholdId(household.getGuid());
        person.setProsAreaId(5500011234234L);
        runGlobalErrorInclusiveTest(person, "error.post.person.incompatible.prosArea.for.household.org");
    }

    private Person createSimplePostPerson() {
        Person person = new Person();
        person.setStatus(1);
        person.setContactSource(10);
        person.setGender("M");
        return person;
    }
}
