package lds.personservice.client.household;

import java.net.URI;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.jayway.jsonassert.JsonAssert;

import javax.inject.Inject;
import javax.inject.Provider;
import lds.personservice.Main;
import lds.personservice.household.Household;
import lds.personservice.household.HouseholdListWrapper;
import lds.personservice.person.Person;
import lds.prsms.utils.UUIDGenerator;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;

import static lds.personservice.household.InclusionParams.CONTACT_INFO;
import static lds.personservice.household.InclusionParams.FELLOWSHIPPERS;
import static lds.personservice.household.InclusionParams.REFERRAL_INFO;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@ActiveProfiles({ "local" })
@IntegrationTest({ "browser.startup=false", "server.port=0" })
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class HouseholdControllerIT {

	@Value("http://localhost:${local.server.port}${lds.api.resources.households.href}") private URI serviceDetailsUri;

	@Inject private Provider<HouseholdTemplate> templateProvider;

	private Household response;

	@Test
	public void testHouseholdSearchIncludesInclusionLinksAndEmptyArrayIfNoParams() {
		final HouseholdTemplate template = templateProvider.get();
		final String jsonPayload = template.getSearchResults(APPLICATION_JSON_VALUE, String.class, new QueryParams());
		final String inclusionPart = serviceDetailsUri.toString() + "?include=";

		JsonAssert.with(jsonPayload).assertThat("$.households", is(empty()))
				.assertThat("$._links._fellowshippers.href",
                        is(equalTo(inclusionPart + FELLOWSHIPPERS.name().toLowerCase())))
				.assertThat("$._links._contact_info.href",
						is(equalTo(inclusionPart + CONTACT_INFO.name().toLowerCase())))
				.assertThat("$._links._referral_info.href",
						is(equalTo(inclusionPart + REFERRAL_INFO.name().toLowerCase())));
	}

	@Test
	public void testHouseholdSearchAppendsToInclusionLinks() {
		final HouseholdTemplate template = templateProvider.get();
		final QueryParams listParams = new QueryParams();
		listParams.setInclusions(CONTACT_INFO.name());
		final String jsonPayload = template.getSearchResults(APPLICATION_JSON_VALUE, String.class, listParams);
		final String inclusionPart = serviceDetailsUri.toString() + "?include=" + CONTACT_INFO.name() + ",";

		JsonAssert.with(jsonPayload)
				.assertThat("$._links._fellowshippers.href",
						is(equalTo(inclusionPart + FELLOWSHIPPERS.name().toLowerCase())))
				.assertThat("$._links._referral_info.href",
						is(equalTo(inclusionPart + REFERRAL_INFO.name().toLowerCase())));
	}

	@Test
	public void testHouseholdSearchInclusionsAppendToQueryParams() {
		final HouseholdTemplate template = templateProvider.get();
		final QueryParams listParams = new QueryParams();
		listParams.setStewardCmisId("55000");
		listParams.setInclusions(CONTACT_INFO.name());
		final String jsonPayload = template.getSearchResults(APPLICATION_JSON_VALUE, String.class, listParams);
		final String inclusionPart = serviceDetailsUri.toString() + "?stewardCmisId=55000&include="
				+ CONTACT_INFO.name() + ",";

		JsonAssert.with(jsonPayload)
				.assertThat("$._links._fellowshippers.href",
						is(equalTo(inclusionPart + FELLOWSHIPPERS.name().toLowerCase())))
				.assertThat("$._links._referral_info.href",
						is(equalTo(inclusionPart + REFERRAL_INFO.name().toLowerCase())));
	}

	@Test
	public void testHouseholdSearchInclusionsAppendToQueryParamsAndInclusions() {
		final QueryParams listParams = new QueryParams();
		listParams.setStewardCmisId("55000");
		final HouseholdTemplate template = templateProvider.get();
		final String jsonPayload = template.getSearchResults(APPLICATION_JSON_VALUE, String.class, listParams);

		final String inclusionPart = serviceDetailsUri.toString() + "?stewardCmisId=55000&include=";

		JsonAssert.with(jsonPayload)
				.assertThat("$._links._fellowshippers.href",
						is(equalTo(inclusionPart + FELLOWSHIPPERS.name().toLowerCase())))
				.assertThat("$._links._referral_info.href",
						is(equalTo(inclusionPart + REFERRAL_INFO.name().toLowerCase())));
	}

	@Test
	public void testHouseholdSearchOnlyGetsWithPeopleInProsArea() {
		final HouseholdTemplate template = templateProvider.get();
		final QueryParams params = new QueryParams();
		params.setProsAreaId("5500011");
		final HouseholdListWrapper householdListWrapper = template.getSearchResults(APPLICATION_JSON_VALUE,
				HouseholdListWrapper.class, params);

		for (final Household household : householdListWrapper.getHouseholds()) {
			assertFalse(household.isDeleted());

			for (final Person p : household.getPeople()) {
				// TODO should this return people that don't have a pros area
				// but are in a household that is part of this pros area?
				assertEquals(p.getProsAreaId(), new Long(5500011L));
				assertFalse(p.isDeleted());
			}
		}
	}

	@Test
	public void testHouseholdSearchOnlyGetsWithPeopleInProsAreaIncludeDeleted() {
		final HouseholdTemplate template = templateProvider.get();
		final QueryParams params = new QueryParams();
		params.setIncludeDeleted(true);
		params.setProsAreaId("5500011");

		final HouseholdListWrapper householdListWrapper = template.getSearchResults(APPLICATION_JSON_VALUE,
                HouseholdListWrapper.class, params);

		boolean hasDeleted = false;

		for (final Household household : householdListWrapper.getHouseholds()) {
			hasDeleted |= household.isDeleted();
			for (final Person p : household.getPeople()) {
				// TODO should this return people that don't have a pros area
				// but are in a household that is part of this pros area?
				hasDeleted |= p.isDeleted();
				assertEquals(p.getProsAreaId(), new Long(5500011L));
			}
		}
		assertTrue(hasDeleted);
	}

	@Test
	public void testHouseholdSearchOnlyGetsHouseholdsWithOrgId() {
		final QueryParams listParams = new QueryParams();
		listParams.setOrgId("45192");
		listParams.setInclusions(REFERRAL_INFO.name());

		final HouseholdTemplate template = templateProvider.get();
		final HouseholdListWrapper householdListWrapper = template.getSearchResults(APPLICATION_JSON_VALUE,
				HouseholdListWrapper.class, listParams);

		for (final Household household : householdListWrapper.getHouseholds()) {
			assertFalse(household.isDeleted());
			for (final Person person : household.getPeople()) {
				assertTrue(household.getOrgId() == 45192L || person.getReferralInfo().getReceivingOrgId() == 45192L
                        || person.getReferralInfo().getOwnerOrgId() == 45192L);
			}
		}
	}

	@Test
	public void testHouseholdSearchWithOrgIdSinceModDate() {
		final Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		final Date date = cal.getTime();
		final QueryParams listParams = new QueryParams();
		listParams.setOrgId("45192");
		listParams.setModDate(date.getTime());

		final HouseholdTemplate template = templateProvider.get();
		final HouseholdListWrapper householdListWrapper = template.getSearchResults(APPLICATION_JSON_VALUE,
				HouseholdListWrapper.class, listParams);
		boolean matchesDate;

		for (final Household household : householdListWrapper.getHouseholds()) {
			matchesDate = household.getModDate().compareTo(date) >= 0;
			assertEquals(household.getOrgId(), new Long(45192L));
			assertFalse(household.isDeleted());

			if (!matchesDate && !CollectionUtils.isEmpty(household.getPeople())) {
				System.out.print("possible non matching date. checking people");

				for (final Person p : household.getPeople()) {
					matchesDate = p.getModDate().compareTo(date) >= 0;
				}
			}

			assertTrue(matchesDate);
		}
	}

	@Test
	public void testHouseholdGetWithInvalidId() {
        HouseholdTemplate template = templateProvider.get();
        ResponseEntity<String> response = template.sendRequestIgnoreError(template.getResourceUriAsString() + "/\"-1\"", HttpMethod.GET, new HttpEntity<>(template.constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE)), String.class);

        assertEquals(response.getStatusCode(), BAD_REQUEST);
        assertTrue(response.getBody().contains("household.notFound"));
	}

	@Test
	public void testHouseholdDeleteWithInvalidId() {
		HouseholdTemplate template = templateProvider.get();
        ResponseEntity<String> response = template.sendRequestIgnoreError(template.getResourceUriAsString() + "/\"-1\"", HttpMethod.DELETE, new HttpEntity<>(template.constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE)), String.class);

		assertEquals(response.getStatusCode(), BAD_REQUEST);
		assertTrue(response.getBody().contains("household.notFound"));
	}

	@Test
	public void testHouseholdUpdateWithInvalidId() {
        HouseholdTemplate template = templateProvider.get();
        Household household = new Household();
        household.setGuid(UUIDGenerator.getInstance().getAsString());
        ResponseEntity<String> response = template.sendRequestIgnoreError(template.getResourceUriAsString() + "/" + household.getGuid(), HttpMethod.PUT, new HttpEntity<>(household, template.constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE)), String.class);

		assertEquals(response.getStatusCode(), BAD_REQUEST);
		assertTrue(response.getBody().contains("household.notFound"));
	}

	@Test
	public void testHouseholdCrudSimpleTest() {
		final Household household = new Household();
		household.setOrgId(45192L);
		household.setAddress("person-service-integration-test");

		final Household firstResponse = templateProvider.get().createHousehold(APPLICATION_JSON_VALUE, household,
				Household.class);

		assertNotNull(firstResponse.getGuid());
		assertPersistedHousehold(firstResponse);
		assertEquals("person-service-integration-test", firstResponse.getAddress());

		firstResponse.setAddress("person-service-integration-test-update");
		final Household secondResponse = templateProvider.get().updateHousehold(firstResponse, Household.class);
		assertEquals("person-service-integration-test-update", secondResponse.getAddress());
		assertPersistedHousehold(secondResponse);
	}

	private void assertPersistedHousehold(Household household) {
		final Household retrievedHousehold = templateProvider.get().getHousehold(APPLICATION_JSON_VALUE,
				household.getGuid(), Household.class);
		assertEquals(household.getServerId(), retrievedHousehold.getServerId());
		assertEquals(household.getGuid(), retrievedHousehold.getGuid());
		assertEquals(household.getOrgId(), retrievedHousehold.getOrgId());
		assertEquals(household.getMissionaryId(), retrievedHousehold.getMissionaryId());
		assertEquals(household.getAddress(), retrievedHousehold.getAddress());
		assertEquals(household.getLat(), retrievedHousehold.getLat());
		assertEquals(household.getLng(), retrievedHousehold.getLng());
	}

	@Test
	public void testCreateHouseholdWithIncludedGuid() {
		final String guid = UUIDGenerator.getInstance().getAsString();

		final Household household = new Household();
		household.setGuid(guid);
		household.setOrgId(45192L);
		household.setAddress("person-service-integration-test");

		response = templateProvider.get().createHousehold(APPLICATION_JSON_VALUE, household, Household.class);

		assertNotNull(response);
		assertEquals(guid, response.getGuid());
		assertEquals("person-service-integration-test", response.getAddress());
		assertEquals(Long.valueOf(45192L), response.getOrgId());
	}

	@Test
	public void testHouseholdCreateErrorsFromDuplicateGuid() {
		final Household household = new Household();
		household.setAddress("household_create_errors_from_duplicate_guid_test:" + System.currentTimeMillis());
		household.setGuid(UUIDGenerator.getInstance().getAsString());

		final HouseholdTemplate template = templateProvider.get();
		template.createHousehold(APPLICATION_JSON_VALUE, household, String.class);

		final ResponseEntity<String> errorResponse = template.sendRequestIgnoreError(
				template.getResourceUri().toString(), POST,
				new HttpEntity<>(household, template.constructDefaultHeaders(APPLICATION_JSON_VALUE)), String.class);
		assertEquals(BAD_REQUEST, errorResponse.getStatusCode());
		JsonAssert.with(errorResponse.getBody()).assertThat("$.status", is(equalTo(BAD_REQUEST.name())))
				.assertThat("$.code", is(equalTo("error.household.create.duplicate.guid")));
	}

	@Test
	public void testCreateHouseholdWithPersonWithIncludedGuid() {
		final String householdGuid = UUIDGenerator.getInstance().getAsString();
		final String personGuid = UUIDGenerator.getInstance().getAsString();

		final Person person = new Person();
		person.setContactSource(120);
		person.setStatus(1);
		person.setGuid(personGuid);

		final List<Person> persons = new ArrayList<>();
		persons.add(person);

		final Household household = new Household();
		household.setGuid(householdGuid);
		household.setOrgId(45192L);
		household.setAddress("person-service-integration-test");
		household.setPeople(persons);

		response = templateProvider.get().createHousehold(APPLICATION_JSON_VALUE, household, Household.class);

		assertNotNull(response);
		assertNotNull(response.getPeople());
		assertEquals(1, response.getPeople().size());
		assertEquals(householdGuid, response.getGuid());
		assertEquals("person-service-integration-test", response.getAddress());
		assertEquals(Long.valueOf(45192L), response.getOrgId());

		final Person responsePerson = response.getPeople().get(0);

		assertEquals(personGuid, responsePerson.getGuid());

		final Household retrievedHousehold = templateProvider.get().getHousehold(APPLICATION_JSON_VALUE,
				household.getGuid(), Household.class);

		assertNotNull(retrievedHousehold);
		assertNotNull(retrievedHousehold.getPeople());
		assertEquals(1, retrievedHousehold.getPeople().size());
		assertEquals(householdGuid, retrievedHousehold.getGuid());
		assertEquals("person-service-integration-test", retrievedHousehold.getAddress());
		assertEquals(Long.valueOf(45192L), retrievedHousehold.getOrgId());

		final Person retrievedPerson = retrievedHousehold.getPeople().get(0);

		assertEquals(personGuid, retrievedPerson.getGuid());
	}

	@Test
	public void testCreateHouseholdUpdateWithPersonWithIncludedGuid() {
		final String householdGuid = UUIDGenerator.getInstance().getAsString();
		final String personGuid = UUIDGenerator.getInstance().getAsString();

		final Household household = new Household();
		household.setGuid(householdGuid);
		household.setOrgId(45192L);
		household.setAddress("person-service-integration-test");

		response = templateProvider.get().createHousehold(APPLICATION_JSON_VALUE, household, Household.class);

		assertNotNull(response);
		assertNull(response.getPeople());
		assertEquals(householdGuid, response.getGuid());
		assertEquals("person-service-integration-test", response.getAddress());
		assertEquals(Long.valueOf(45192L), response.getOrgId());

		final Household retrievedHousehold = templateProvider.get().getHousehold(APPLICATION_JSON_VALUE,
				household.getGuid(), Household.class);

		assertNotNull(retrievedHousehold);
		assertNull(retrievedHousehold.getPeople());
		assertEquals(householdGuid, retrievedHousehold.getGuid());
		assertEquals("person-service-integration-test", retrievedHousehold.getAddress());
		assertEquals(Long.valueOf(45192L), retrievedHousehold.getOrgId());

		final Person person = new Person();
		person.setContactSource(120);
		person.setStatus(1);
		person.setGuid(personGuid);

		final List<Person> persons = new ArrayList<>();
		persons.add(person);
		retrievedHousehold.setPeople(persons);

		final Household updatedHousehold = templateProvider.get().updateHousehold(retrievedHousehold, Household.class);

		final Person addedPerson = updatedHousehold.getPeople().get(0);

		assertEquals(personGuid, addedPerson.getGuid());

		assertNotNull(updatedHousehold);
		assertNotNull(updatedHousehold.getPeople());
		assertEquals(1, updatedHousehold.getPeople().size());
		assertEquals(householdGuid, updatedHousehold.getGuid());
		assertEquals("person-service-integration-test", updatedHousehold.getAddress());
		assertEquals(Long.valueOf(45192L), updatedHousehold.getOrgId());

		final Person updatedPerson = updatedHousehold.getPeople().get(0);

		assertEquals(personGuid, updatedPerson.getGuid());
	}

	@Test
	public void testCreateHouseholdUpdateWithPersonWithoutGuid() {
		final String householdGuid = UUIDGenerator.getInstance().getAsString();

		final Household household = new Household();
		household.setGuid(householdGuid);
		household.setOrgId(45192L);
		household.setAddress("person-service-integration-test");

		response = templateProvider.get().createHousehold(APPLICATION_JSON_VALUE, household, Household.class);

		assertNotNull(response);
		assertNull(response.getPeople());
		assertEquals(householdGuid, response.getGuid());
		assertEquals("person-service-integration-test", response.getAddress());
		assertEquals(Long.valueOf(45192L), response.getOrgId());

		final Household retrievedHousehold = templateProvider.get().getHousehold(APPLICATION_JSON_VALUE,
				household.getGuid(), Household.class);

		assertNotNull(retrievedHousehold);
		assertNull(retrievedHousehold.getPeople());
		assertEquals(householdGuid, retrievedHousehold.getGuid());
		assertEquals("person-service-integration-test", retrievedHousehold.getAddress());
		assertEquals(Long.valueOf(45192L), retrievedHousehold.getOrgId());

		final String personGuid = retrievedHousehold.getGuid();

		final Person person = new Person();
		person.setContactSource(120);
		person.setStatus(1);
		person.setGuid(personGuid);

		final List<Person> persons = new ArrayList<>();
		persons.add(person);
		retrievedHousehold.setPeople(persons);

		final Household updatedHousehold = templateProvider.get().updateHousehold(retrievedHousehold, Household.class);

		final Person addedPerson = updatedHousehold.getPeople().get(0);

		assertEquals(personGuid, addedPerson.getGuid());

		assertNotNull(updatedHousehold);
		assertNotNull(updatedHousehold.getPeople());
		assertEquals(1, updatedHousehold.getPeople().size());
		assertEquals(householdGuid, updatedHousehold.getGuid());
		assertEquals("person-service-integration-test", updatedHousehold.getAddress());
		assertEquals(Long.valueOf(45192L), updatedHousehold.getOrgId());

		final Person updatedPerson = updatedHousehold.getPeople().get(0);

		assertEquals(personGuid, updatedPerson.getGuid());
	}

	@Test
	public void testCreateHouseholdWithoutGuidWithPersonWithIncludedGuid() {
		final String personGuid = UUIDGenerator.getInstance().getAsString();

		final Person person = new Person();
		person.setContactSource(120);
		person.setStatus(1);
		person.setGuid(personGuid);

		final List<Person> persons = new ArrayList<>();
		persons.add(person);

		final Household household = new Household();
		household.setGuid(null);
		household.setOrgId(45192L);
		household.setAddress("person-service-integration-test");
		household.setPeople(persons);

		try {
			response = templateProvider.get().createHousehold(APPLICATION_JSON_VALUE, household, Household.class);
		} catch (HttpClientErrorException ex) {
			fail(ex.getResponseBodyAsString());
		}

		assertNotNull(response);
		assertNotNull(response.getPeople());
		assertEquals(1, response.getPeople().size());
		assertNotNull(response.getGuid());
		assertEquals("person-service-integration-test", response.getAddress());
		assertEquals(Long.valueOf(45192L), response.getOrgId());

		final String householdGuid = response.getGuid();

		final Person responsePerson = response.getPeople().get(0);

		assertEquals(personGuid, responsePerson.getGuid());

		Household retrievedHousehold = null;

		try {
			retrievedHousehold = templateProvider.get().getHousehold(APPLICATION_JSON_VALUE, response.getGuid(),
					Household.class);
		} catch (HttpClientErrorException ex) {
			fail(ex.getResponseBodyAsString());
		}

		assertNotNull(retrievedHousehold);
		assertNotNull(retrievedHousehold.getPeople());
		assertEquals(1, retrievedHousehold.getPeople().size());
		assertEquals(householdGuid, retrievedHousehold.getGuid());
		assertEquals("person-service-integration-test", retrievedHousehold.getAddress());
		assertEquals(Long.valueOf(45192L), retrievedHousehold.getOrgId());

		final Person retrievedPerson = retrievedHousehold.getPeople().get(0);

		assertEquals(personGuid, retrievedPerson.getGuid());
	}

	@Test
	public void testCreateHouseholdWithoutGuidWithPersonWithoutGuid() {
		final Person person = new Person();
		person.setContactSource(120);
		person.setStatus(1);
		person.setGuid(null);

		final List<Person> persons = new ArrayList<>();
		persons.add(person);

		final Household household = new Household();
		household.setGuid(null);
		household.setOrgId(45192L);
		household.setAddress("person-service-integration-test");
		household.setPeople(persons);

		try {
			response = templateProvider.get().createHousehold(APPLICATION_JSON_VALUE, household, Household.class);
		} catch (HttpClientErrorException ex) {
			fail(ex.getResponseBodyAsString());
		}

		assertNotNull(response);
		assertNotNull(response.getPeople());
		assertEquals(1, response.getPeople().size());
		assertNotNull(response.getGuid());
		assertEquals("person-service-integration-test", response.getAddress());
		assertEquals(Long.valueOf(45192L), response.getOrgId());

		final String householdGuid = response.getGuid();
		final Person responsePerson = response.getPeople().get(0);
		final String personGuid = responsePerson.getGuid();

		Household retrievedHousehold = null;

		try {
			retrievedHousehold = templateProvider.get().getHousehold(APPLICATION_JSON_VALUE, response.getGuid(),
					Household.class);
		} catch (HttpClientErrorException ex) {
			fail(ex.getResponseBodyAsString());
		}

		assertNotNull(retrievedHousehold);
		assertNotNull(retrievedHousehold.getPeople());
		assertEquals(1, retrievedHousehold.getPeople().size());
		assertEquals(householdGuid, retrievedHousehold.getGuid());
		assertEquals("person-service-integration-test", retrievedHousehold.getAddress());
		assertEquals(Long.valueOf(45192L), retrievedHousehold.getOrgId());

		final Person retrievedPerson = retrievedHousehold.getPeople().get(0);

		assertEquals(personGuid, retrievedPerson.getGuid());
	}

	@Test
	public void testCreateHouseholdWithGuidWithPersonWithoutGuid() {
		final String householdGuid = UUIDGenerator.getInstance().getAsString();

		final Person person = new Person();
		person.setContactSource(120);
		person.setStatus(1);
		person.setGuid(null);

		final List<Person> persons = new ArrayList<>();
		persons.add(person);

		final Household household = new Household();
		household.setGuid(householdGuid);
		household.setOrgId(45192L);
		household.setAddress("person-service-integration-test");
		household.setPeople(persons);

		try {
			response = templateProvider.get().createHousehold(APPLICATION_JSON_VALUE, household, Household.class);
		} catch (HttpClientErrorException ex) {
			fail(ex.getResponseBodyAsString());
		}

		assertNotNull(response);
		assertNotNull(response.getPeople());
		assertEquals(1, response.getPeople().size());
		assertNotNull(response.getGuid());
		assertEquals("person-service-integration-test", response.getAddress());
		assertEquals(Long.valueOf(45192L), response.getOrgId());

		final Person responsePerson = response.getPeople().get(0);
		final String personGuid = responsePerson.getGuid();

		Household retrievedHousehold = null;

		try {
			retrievedHousehold = templateProvider.get().getHousehold(APPLICATION_JSON_VALUE, response.getGuid(),
					Household.class);
		} catch (HttpClientErrorException ex) {
			fail(ex.getResponseBodyAsString());
		}

		assertNotNull(retrievedHousehold);
		assertNotNull(retrievedHousehold.getPeople());
		assertEquals(1, retrievedHousehold.getPeople().size());
		assertEquals(householdGuid, retrievedHousehold.getGuid());
		assertEquals("person-service-integration-test", retrievedHousehold.getAddress());
		assertEquals(Long.valueOf(45192L), retrievedHousehold.getOrgId());

		final Person retrievedPerson = retrievedHousehold.getPeople().get(0);

		assertEquals(personGuid, retrievedPerson.getGuid());
	}
    
    @Test
    public void householdCreate_errors_from_duplicate_guid() {
        Household household = new Household();
        household.setAddress("household_create_errors_from_duplicate_guid_test:" + System.currentTimeMillis());
        household.setGuid(UUIDGenerator.getInstance().getAsString());

        HouseholdTemplate template = templateProvider.get();
        template.createHousehold(MediaType.APPLICATION_JSON_VALUE, household, String.class);

        ResponseEntity<String> errorResponse = template.sendRequestIgnoreError(template.getResourceUri().toString(), HttpMethod.POST, new HttpEntity<>(household, template.constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE)), String.class);
        assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatusCode());
        JsonAssert.with(errorResponse.getBody())
              .assertThat("$.status", is(equalTo(HttpStatus.BAD_REQUEST.name())))
              .assertThat("$.code", is(equalTo("error.household.create.duplicate.guid")));
    }
}
