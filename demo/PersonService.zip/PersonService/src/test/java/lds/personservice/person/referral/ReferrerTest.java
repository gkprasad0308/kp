package lds.personservice.person.referral;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ReferrerTest {

    @Test
    public void isEmptyIsTrueIfFirstNameLastNameEmailAndPhoneAreNull(){
        Referrer referrer = new Referrer();
        referrer.setFirstName(null);
        referrer.setLastName(null);
        referrer.setEmailAddress(null);
        referrer.setPhoneNumber(null);
        assertTrue(referrer.isEmpty());
    }

    @Test
    public void isEmptyIsTrueIfFirstNameLastNameEmailAndPhoneAreEmpty(){
        Referrer referrer = new Referrer();
        referrer.setFirstName("");
        referrer.setLastName("");
        referrer.setEmailAddress("");
        referrer.setPhoneNumber("");
        assertTrue(referrer.isEmpty());
    }

    @Test
    public void isEmptyIsTrueIfFirstNameHasValue(){
        Referrer referrer = new Referrer();
        referrer.setFirstName("bob");
        assertFalse(referrer.isEmpty());
    }

    @Test
    public void isEmptyIsTrueIfLastNameHasValue(){
        Referrer referrer = new Referrer();
        referrer.setLastName("smith");
        assertFalse(referrer.isEmpty());
    }

    @Test
    public void isEmptyIsTrueIfEmailHasValue(){
        Referrer referrer = new Referrer();
        referrer.setEmailAddress("bob@smith");
        assertFalse(referrer.isEmpty());
    }

    @Test
    public void isEmptyIsTrueIfPhoneHasValue(){
        Referrer referrer = new Referrer();
        referrer.setPhoneNumber("1234");
        assertFalse(referrer.isEmpty());
    }
}
