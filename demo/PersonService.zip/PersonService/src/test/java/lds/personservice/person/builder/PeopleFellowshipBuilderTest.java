package lds.personservice.person.builder;

import lds.personservice.household.InclusionParams;
import lds.personservice.person.Person;
import lds.personservice.person.fellowshipper.FellowshipInfo;
import lds.personservice.person.fellowshipper.FellowshipMap;
import lds.personservice.person.fellowshipper.FellowshipperRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.mockito.Matchers.anyList;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PeopleFellowshipBuilderTest {

    @InjectMocks
    private PeopleFellowshipBuilder builder;

    @Mock
    private FellowshipperRepository repository;

    @Test
    public void appliesToBuilderReturnsTrueIfParamsContainsFellowshippersInclusion(){
        BuilderParams params = new BuilderParams();
        params.setInclusions(Arrays.asList(InclusionParams.FELLOWSHIPPERS));
        assertTrue(builder.appliesToBuilder(params));
    }

    @Test
    public void appliesToBuilderReturnsFalseWithNullParams(){
        assertFalse(builder.appliesToBuilder(null));
    }

    @Test
    public void appliesttoBuilderReturnsFalseWithEmptyParams(){
        assertFalse(builder.appliesToBuilder(new BuilderParams()));
    }

    @Test
    public void appliesToBuilderReturnsFalseIfParamsDoesNotIncludeFellowshippers(){
        BuilderParams params = new BuilderParams();
        params.setInclusions(InclusionParams.valuesAsList().stream().filter(param -> param != InclusionParams.FELLOWSHIPPERS).collect(Collectors.toList()));
        assertFalse(builder.appliesToBuilder(params));
    }

    @Test
    public void buildReturnsNullIfNullPassedIn(){
        assertNull(builder.build(null));
    }

    @Test
    public void buildReturnsSameEmptyListIfPassedIn(){
        List<Person> people = new LinkedList<>();
        assertEquals(people, builder.build(people));
    }

    @Test
    public void buildMapsFellowshipperInfoToPeople(){
        FellowshipInfo info = new FellowshipInfo();
        FellowshipMap map = mock(FellowshipMap.class);
        when(map.getFellowshipInfoForPerson(123L)).thenReturn(info);

        when(repository.getFellowshipMapForPeople(anyList())).thenReturn(map);
        Person person = new Person();
        person.setServerId(123L);

        List<Person> people = Arrays.asList(person);
        assertEquals(people, builder.build(people));
        assertEquals(info, person.getFellowshipInfo());
        verify(map, times(1)).getFellowshipInfoForPerson(123L);
        verify(repository, times(1)).getFellowshipMapForPeople(Arrays.asList(new Long(123L)));
    }
}
