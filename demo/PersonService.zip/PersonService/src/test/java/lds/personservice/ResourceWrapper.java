package lds.personservice;


import lds.stack.spring.web.Link;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;

public class ResourceWrapper<T> {

    private T t;

    public ResourceWrapper(T t){
        if(!t.getClass().getName().toLowerCase().contains("cglib")){
            throw new IllegalArgumentException("Must be a cglib enhanced class");
        }
        this.t = t;
    }

    public LinkedHashMap<String, Link> getLinks(){
        LinkedHashMap<String, Link> result = null;

        try {
            Method method = t.getClass().getDeclaredMethod("getLinks", null);
            method.setAccessible(true);
            result = (LinkedHashMap<String, Link>) method.invoke(t);
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e ) {
            e.printStackTrace();
        }

        return result;
    }

    public T getInstance() {
        return t;
    }
}
