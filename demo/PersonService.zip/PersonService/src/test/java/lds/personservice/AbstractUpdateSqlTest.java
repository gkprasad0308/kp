package lds.personservice;


import org.junit.Test;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public abstract class AbstractUpdateSqlTest {

    protected abstract SqlUpdate getInstance();
    protected abstract List<String> getExpectedParams();

    @Test
    public void sqlUpdateHasExpectedParams(){
        List<SqlParameter> declaredParameters = (List<SqlParameter>) ReflectionTestUtils.getField(getInstance(), "declaredParameters");
        List<String> expectedParams = getExpectedParams();
        assertTrue(declaredParameters.size() == expectedParams.size());
        for(SqlParameter sqlParameter: declaredParameters){
            assertThat(expectedParams, hasItem(sqlParameter.getName()));
        }
    }

    @Test
    public void sqlUpdateHasParamsInSql(){
        String sql = getInstance().getSql();
        for(String expectedParam: getExpectedParams()){
            assertThat(sql, containsString(":" + expectedParam));
        }
    }

    protected void checkKeys(Map<String, Object> params) {
        List<String> expectedParams = getExpectedParams();
        assertTrue(params.size() == expectedParams.size());
        for(String key: params.keySet()){
            assertThat(expectedParams, hasItem(key));
        }
    }
}
