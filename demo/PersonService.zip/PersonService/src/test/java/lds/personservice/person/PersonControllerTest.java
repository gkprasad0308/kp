package lds.personservice.person;

import lds.personservice.AssignmentService;
import lds.personservice.ResourceWrapper;
import lds.personservice.household.Household;
import lds.personservice.household.HouseholdService;
import lds.personservice.util.ResponseWrapper;
import lds.stack.spring.web.Link;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.*;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PersonControllerTest {

    public static final String HOUSEHOLD_ENDPOINT = "householdEndpoint";
    public static final String PEOPLE_ENDPOINT = "peopleEndpoint";
    public static final String GUID_1 = "ABC";
    public static final String GUID_2 = "!@#";

    @InjectMocks
    private PersonController controller;

    @Mock
    private PersonService personService;

    @Mock
    private HouseholdService householdService;

    @Mock
    private AssignmentService assignmentService;

    @Before
    public void setup(){
        ReflectionTestUtils.setField(controller, HOUSEHOLD_ENDPOINT, HOUSEHOLD_ENDPOINT);
        ReflectionTestUtils.setField(controller, PEOPLE_ENDPOINT, PEOPLE_ENDPOINT);
    }

    @Test
    public void getPersonByIdReturnsNullIfNoneFound(){
        when(personService.getPersonDetail(anyString())).thenReturn(null);
        assertNull(controller.getPersonById("abc"));
    }

    @Test
    public void getPersonByIdReturnsExpectedPerson(){
        Person person = new Person();
        person.setGuid(GUID_1);
        person.setHouseholdId("bob");
        when(personService.getPersonDetail(GUID_1)).thenReturn(person);

        ResourceWrapper<Person> resourceWrapper = new ResourceWrapper<>(controller.getPersonById(GUID_1));
        assertEquals(person.getGuid(), resourceWrapper.getInstance().getGuid());
        assertEquals(person.getHouseholdId(), resourceWrapper.getInstance().getHouseholdId());

        LinkedHashMap<String, Link> links = resourceWrapper.getLinks();
        assertThat(links.keySet(), contains("household"));
        assertEquals(HOUSEHOLD_ENDPOINT + "/bob", links.get("household").getHref());
    }

    @Test
    public void updatePersonUpdatesHouseholdIfAssingmentChanged(){
        Household household = new Household();
        household.setGuid(GUID_2);
        Person person = new Person();
        person.setProsAreaId(123L);
        person.setGuid(GUID_1);
        Person original = new Person();
        original.setProsAreaId(null);

        when(personService.getPersonDetail(GUID_1)).thenReturn(original);
        when(assignmentService.handlePersonAssignment(person, GUID_1)).thenReturn(household);
        controller.updatePerson(person, person.getGuid());
        verify(householdService).updateHousehold(household, GUID_2);
        verify(personService, times(0)).updatePerson(anyObject(), anyString());
    }

    @Test
    public void updatePersonUpdatesPersonIfNoProsAreaChange(){
        Person person = new Person();
        person.setGuid(GUID_1);

        when(personService.getPersonDetail(GUID_1)).thenReturn(new Person());
        controller.updatePerson(person, person.getGuid());
        verify(personService, times(1)).updatePerson(person, person.getGuid());
        verifyZeroInteractions(assignmentService);
        verifyZeroInteractions(householdService);
    }

    @Test
    public void deletePersonCallsServiceWithGuid(){
        controller.deletePerson(GUID_1);
        verify(personService, times(1)).deletePerson(GUID_1);
        verifyNoMoreInteractions(personService);
    }

    @Test
    public void linkFellowshipperCAllsServiceWithGuids(){
        controller.linkFellowshipper(GUID_1, GUID_2);
        verify(personService, times(1)).linkFellowshipper(GUID_1, GUID_2);
        verifyNoMoreInteractions(personService);
    }

    @Test
    public void linkFellowshippperReturnsPersonLinks(){
        ResourceWrapper<ResponseWrapper> resource = new ResourceWrapper<>(controller.linkFellowshipper(GUID_1, GUID_2));
        Map<String, Link> links = resource.getLinks();
        assertTrue(links.containsKey("person"));
        assertTrue(links.containsKey("fellowshipper"));
        assertEquals(PEOPLE_ENDPOINT + "/" + GUID_1, links.get("person").getHref());
        assertEquals(PEOPLE_ENDPOINT + "/" + GUID_2, links.get("fellowshipper").getHref());
    }

    @Test
    public void unlinkeFellowshipperCAllsServiceWithGuids(){
        controller.unLinkFellowshipper(GUID_1, GUID_2);
        verify(personService, times(1)).removeFellowshipper(GUID_1, GUID_2);
        verifyNoMoreInteractions(personService);
    }

    @Test
    public void unlinkFellowshipperReturnsPersonLinks(){
        ResourceWrapper<ResponseWrapper> resource = new ResourceWrapper<>(controller.unLinkFellowshipper(GUID_1, GUID_2));
        Map<String, Link> links = resource.getLinks();
        assertTrue(links.containsKey("person"));
        assertTrue(links.containsKey("fellowshipper"));
        assertEquals(PEOPLE_ENDPOINT + "/" + GUID_1, links.get("person").getHref());
        assertEquals(PEOPLE_ENDPOINT + "/" + GUID_2, links.get("fellowshipper").getHref());
    }

    @Test
    public void mergePersonCallsService(){
        controller.mergePerson(GUID_1, GUID_2);
        verify(personService, times(1)).merge(GUID_1, GUID_2);
        verify(personService, times(1)).getPersonDetail(GUID_2);
        verifyNoMoreInteractions(personService);
    }

    @Test
    public void calculatePersonStatusCallsWithId(){
        controller.calculatePersonStatus(1L);
        verify(personService, times(1)).calculateStatuses(Arrays.asList(1L));
        verifyNoMoreInteractions(personService);
    }

    @Test
    public void calculatePersonStatusCAllsWithExpectedIds(){
        List<Long> ids = Arrays.asList(new Long(1), new Long(2));
        controller.calculatePersonStatus(ids);
        verify(personService, times(1)).calculateStatuses(ids);
        verifyNoMoreInteractions(personService);
    }

    @Test
    public void calculatePersonStatusReturnsErrorResponse(){
        when(personService.calculateStatuses(anyList())).thenThrow(new RuntimeException());
        ResponseEntity entity = controller.calculatePersonStatus(Arrays.asList(1L));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, entity.getStatusCode());
        assertEquals("error.put.calc.statuses.failed", entity.getBody());
    }
}
