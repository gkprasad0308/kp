package lds.personservice.person;

import lds.personservice.AbstractUpdateSqlTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PersonInsertSqlTest extends AbstractUpdateSqlTest {

    @InjectMocks
    private PersonInsertSql insertSql;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            PersonInsertSql.PERSON_ID,
            PersonInsertSql.FIRST_NAME,
            PersonInsertSql.LAST_NAME,
            PersonInsertSql.AGE_CAT_ID,
            PersonInsertSql.GENDER,
            PersonInsertSql.HSHLD_ID,
            PersonInsertSql.PERSON_STAT_ID,
            PersonInsertSql.NOTE,
            PersonInsertSql.FOCUS_PERSON,
            PersonInsertSql.CMIS_ID,
            PersonInsertSql.PROS_AREA_ID,
            PersonInsertSql.GUID,
            PersonInsertSql.CONVERT,
            PersonInsertSql.FIND_ID,
            PersonInsertSql.PREF_LANG_ID,
            PersonInsertSql.PREF_CONTACT_TYPE,
            PersonInsertSql.FIND_DETAIL
    );

    @Test
    public void getParamsUsingPersonReturnsExpectedValues(){
        Person person = mock(Person.class);
        when(person.getServerId()).thenReturn(123L);
        when(person.getFirstName()).thenReturn("bob");
        when(person.getLastName()).thenReturn("smith");
        when(person.getAgeCatId()).thenReturn(2);
        when(person.getGender()).thenReturn("M");
        when(person.getHouseholdServerId()).thenReturn(456L);
        when(person.getStatus()).thenReturn(40);
        when(person.getNote()).thenReturn("note");
        when(person.isFocusPerson()).thenReturn(true);
        when(person.getCmisId()).thenReturn(789L);
        when(person.getProsAreaId()).thenReturn(5500011L);
        when(person.getGuid()).thenReturn("abc");
        when(person.isConvert()).thenReturn(true);
        when(person.getContactSource()).thenReturn(1);
        when(person.getPreferredLangId()).thenReturn(0);
        when(person.getPreferredContactType()).thenReturn(3);
        when(person.getContactSourceDtl()).thenReturn(4);

        Map<String, Object> results = insertSql.getParamsUsing(person);
        checkKeys(results);
        assertEquals(results.get(PersonInsertSql.PERSON_ID), 123L);
        assertEquals(results.get(PersonInsertSql.FIRST_NAME), "bob");
        assertEquals(results.get(PersonInsertSql.LAST_NAME), "smith");
        assertEquals(2, results.get(PersonInsertSql.AGE_CAT_ID));
        assertEquals("M", results.get(PersonInsertSql.GENDER));
        assertEquals(456L, results.get(PersonInsertSql.HSHLD_ID));
        assertEquals(40, results.get(PersonInsertSql.PERSON_STAT_ID));
        assertEquals("note", results.get(PersonInsertSql.NOTE));
        assertEquals("Y", results.get(PersonInsertSql.FOCUS_PERSON));
        assertEquals(789L, results.get(PersonInsertSql.CMIS_ID));
        assertEquals(5500011L, results.get(PersonInsertSql.PROS_AREA_ID));
        assertEquals("abc", results.get(PersonInsertSql.GUID));
        assertEquals("Y", results.get(PersonInsertSql.CONVERT));
        assertEquals(1, results.get(PersonInsertSql.FIND_ID));
        assertEquals(0, results.get(PersonInsertSql.PREF_LANG_ID));
        assertEquals(3, results.get(PersonInsertSql.PREF_CONTACT_TYPE));
        assertEquals(4, results.get(PersonInsertSql.FIND_DETAIL));

        verify(person, times(1)).getServerId();
        verify(person, times(1)).getFirstName();
        verify(person, times(1)).getLastName();
        verify(person, times(1)).getAgeCatId();
        verify(person, times(1)).getGender();
        verify(person, times(1)).getHouseholdServerId();
        verify(person, times(1)).getStatus();
        verify(person, times(1)).getNote();
        verify(person, times(1)).isFocusPerson();
        verify(person, times(1)).getCmisId();
        verify(person, times(1)).getProsAreaId();
        verify(person, times(1)).getGuid();
        verify(person, times(1)).isConvert();
        verify(person, times(1)).getContactSource();
        verify(person, times(1)).getPreferredLangId();
        verify(person, times(1)).getPreferredContactType();
        verify(person, times(1)).getContactSourceDtl();
        verifyNoMoreInteractions(person);
    }

    @Override
    protected SqlUpdate getInstance() {
        return insertSql;
    }

    @Override
    protected List<String> getExpectedParams() {
        return expectedParams;
    }
}
