package lds.personservice.person.drop;


import lds.personservice.AbstractSimpleSprocTest;
import lds.personservice.util.SimpleSproc;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class UndoDropNoteSprocTest extends AbstractSimpleSprocTest {

    @InjectMocks
    private UndoDropNoteSproc sproc;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            UndoDropNoteSproc.PERSON_STWRD_DTL_ID,
            UndoDropNoteSproc.NEW_MOD_DT
    );

    @Override
    protected String getSchema() {
        return UndoDropNoteSproc.SCHEMA_NAME;
    }

    @Override
    protected String getCataglog() {
        return UndoDropNoteSproc.CATALOG_NAME;
    }

    @Override
    protected String getFunction() {
        return UndoDropNoteSproc.PROCEDURE_NAME;
    }

    @Override
    protected SimpleSproc getInstance() {
        return sproc;
    }

    @Override
    protected List<String> getExpectedParameters() {
        return expectedParams;
    }

    @Test
    public void getParametersUsingReturnsExpected(){
        Date date = new Date(System.currentTimeMillis());
        MapSqlParameterSource params = sproc.getParametersUsing(123L, date);
        checkKeys(params.getValues());
        assertEquals(123L, params.getValue(UndoDropNoteSproc.PERSON_STWRD_DTL_ID));
        assertEquals(date, params.getValue(UndoDropNoteSproc.NEW_MOD_DT));
    }
}
