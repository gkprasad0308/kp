package lds.personservice.household;

import java.util.List;

public class ListParamsProsAreasTest extends AbstractListParamsTest {
    @Override
    protected void callParser(String value) {
        listParams.parseProsAreas(value);
    }

    @Override
    protected List<Long> getValues() {
        return listParams.getProsAreas();
    }

    @Override
    protected String getFieldName() {
        return "prosAreas";
    }
}
