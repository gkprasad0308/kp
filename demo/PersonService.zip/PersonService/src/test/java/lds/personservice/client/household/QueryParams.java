package lds.personservice.client.household;

import lds.personservice.household.ListParams;

public class QueryParams extends ListParams {

	private String missionaryId;

	private String prosAreaId;

	private String stewardCmisId;

	private String orgId;

	public String getMissionaryId() {
		return missionaryId;
	}

	public void setMissionaryId(String missionaryId) {
		this.missionaryId = missionaryId;
	}

	public String getProsAreaId() {
		return prosAreaId;
	}

	public void setProsAreaId(String prosAreaId) {
		this.prosAreaId = prosAreaId;
	}

	public String getStewardCmisId() {
		return stewardCmisId;
	}

	public void setStewardCmisId(String stewardCmisId) {
		this.stewardCmisId = stewardCmisId;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
}
