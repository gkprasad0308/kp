package lds.personservice.commitment;

import java.net.URI;

import javax.inject.Inject;
import javax.inject.Provider;
import lds.personservice.Main;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.HttpClientErrorException;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@ActiveProfiles({"local"})
@IntegrationTest({"browser.startup=false", "server.port=0"})
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class CommitmentControllerIT {

    private static final Long KNOWN_GOOD_PERSON_ID = 81L;

    private static final String KNOWN_GOOD_PERSON_GUID = "7EA6E7A46A970BF8FB944DB8880FFE53";

    private static final Long KNOWN_GOOD_TEACHING_ITEM_ID = 1L;

    @Value("http://localhost:${local.server.port}${lds.api.resources.commitments.href}")
    private URI commitmentsUri;

    @Inject
    private Provider<CommitmentTemplate> templateProvider;

    @Autowired
    CommitmentRepository commitmentRepository;

    @Autowired
    CommitmentService service;

    private Commitment currentCommitment;

    @Before
    public void before() {
        currentCommitment = null;
    }

    @After
    public void after() {
        if (currentCommitment != null) {
            service.deleteCommitment(currentCommitment.getClientGuid());// make
            // sure
            // our
            // test
            // cases
            // are
            // marked
            // deleted
        }
    }

    @Test
    public void testDelete() {
        CommitmentTemplate template = templateProvider.get();
        Commitment commitment = new Commitment();
        commitment.setPersonGuid(KNOWN_GOOD_PERSON_GUID);
        commitment.setTeachingItemId(KNOWN_GOOD_TEACHING_ITEM_ID);
        commitment.setInviteDate(System.currentTimeMillis());
        currentCommitment = template.createCommitment(commitment);

        template.deleteCommitment(currentCommitment.getClientGuid());

        Commitment check = commitmentRepository.findById(currentCommitment.getId());
        assertTrue(check == null);

        currentCommitment = null; // don't try to delete it twice
    }

    @Test
    public void testUpdate() {
        CommitmentTemplate template = templateProvider.get();
        Commitment commitment = new Commitment();
        commitment.setPersonGuid(KNOWN_GOOD_PERSON_GUID);
        commitment.setTeachingItemId(KNOWN_GOOD_TEACHING_ITEM_ID);
        commitment.setInviteDate(System.currentTimeMillis());
        commitment.setWasKept(true);
        currentCommitment = template.createCommitment(commitment);
        assertNotNull(currentCommitment);

        currentCommitment.setWasKept(false);
        currentCommitment.setPersonGuid(KNOWN_GOOD_PERSON_GUID);
        currentCommitment = template.updateCommitment(currentCommitment);
        assertNotNull(currentCommitment);
        assertFalse(currentCommitment.getWasKept());
    }

    @Test
    public void testCreateCommitment() {
        CommitmentTemplate template = templateProvider.get();
        Commitment commitment = new Commitment();
        commitment.setPersonId(KNOWN_GOOD_PERSON_ID);
        commitment.setPersonGuid(KNOWN_GOOD_PERSON_GUID);
        commitment.setTeachingItemId(KNOWN_GOOD_TEACHING_ITEM_ID);
        commitment.setInviteDate(System.currentTimeMillis());
        currentCommitment = template.createCommitment(commitment);

        assertNotNull(currentCommitment);
        assertNotNull(currentCommitment.getClientGuid());
    }

    @Test
    public void testDeleteCommitment() {
        CommitmentTemplate template = templateProvider.get();

        String id = "AD3FD075F4645174FC684A87631F9807";

        Commitment commitment = template.deleteCommitment(id);

        Assert.assertNotNull("Expected person guid to be returned", commitment.getPersonGuid());
        Assert.assertTrue("Excpected commitment to be deleted", commitment.getDeleted());
    }
}
