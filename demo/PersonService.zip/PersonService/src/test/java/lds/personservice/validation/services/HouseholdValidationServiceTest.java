package lds.personservice.validation.services;

import lds.personservice.household.Household;
import lds.personservice.household.HouseholdRepository;
import lds.personservice.util.validation.service.HouseholdValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class HouseholdValidationServiceTest {

    @InjectMocks
    private HouseholdValidationService service;

    @Mock
    private HouseholdRepository repository;

    @Test
    public void household_exists_returns_what_is_returned_by_repository(){
        when(repository.householdWithGuidExists("abc")).thenReturn(true);
        assertTrue(service.householdExists("abc"));
        assertFalse(service.householdExists("edf"));
    }

    @Test
    public void getHouseholdOrgIdReturnsNullIfNullGuid(){
        assertNull(service.getHouseholdOrgId(null));
        verifyZeroInteractions(repository);
    }

    @Test
    public void getHouseholdOrgIdReturnsNullIfEmptyGuid(){
        assertNull(service.getHouseholdOrgId(""));
        verifyZeroInteractions(repository);
    }

    @Test
    public void getHouseholdOrgIdReturnsNullIfNoOrgId(){
        when(repository.getHouseholdByGuid("abc")).thenReturn(new Household());
        assertNull(service.getHouseholdOrgId("abc"));
        verify(repository, times(1)).getHouseholdByGuid("abc");
    }

    @Test
    public void getHouseholdOrgIdReturnsNullIfNoHousehold(){
        when(repository.getHouseholdByGuid("abc")).thenReturn(null);
        assertNull(service.getHouseholdOrgId("abc"));
        verify(repository, times(1)).getHouseholdByGuid("abc");
    }

    @Test
    public void getHouseholdOrgIdReturnsHouseholdOrgId(){
        Household household = new Household();
        household.setOrgId(123L);
        when(repository.getHouseholdByGuid("abc")).thenReturn(household);
        assertEquals(new Long(123L), service.getHouseholdOrgId("abc"));
        verify(repository, times(1)).getHouseholdByGuid("abc");
    }

    @Test
    public void getOriginalReturnsNullIfEmptyGuid(){
        assertNull(service.getOriginal(""));
        verifyZeroInteractions(repository);
    }

    @Test
    public void getOriginalReturnsNullIfNullGuid(){
        assertNull(service.getOriginal(null));
        verifyZeroInteractions(repository);
    }

    @Test
    public void getOriginalReturnsNullIfGuidDoesntExist(){
        when(repository.householdWithGuidExists("abc")).thenReturn(false);
        assertNull(service.getOriginal("abc"));
        verify(repository, times(1)).householdWithGuidExists("abc");
        verifyNoMoreInteractions(repository);
    }

    @Test
    public void getOriginalReturnsWhatRepositoryReturned(){
        Household household = new Household();
        when(repository.householdWithGuidExists("abc")).thenReturn(true);
        when(repository.getHouseholdByGuid("abc")).thenReturn(household);
        Household result = service.getOriginal("abc");
        assertEquals(household, result);
        verify(repository, times(1)).getHouseholdByGuid("abc");
        verify(repository, times(1)).householdWithGuidExists("abc");
        verifyNoMoreInteractions(repository);
    }
}
