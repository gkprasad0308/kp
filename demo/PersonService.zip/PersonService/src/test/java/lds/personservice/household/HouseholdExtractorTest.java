package lds.personservice.household;

import lds.personservice.contactinfo.email.EmailTypes;
import lds.personservice.person.Person;
import lds.personservice.person.PersonRowMapper;
import lds.personservice.person.referral.ReferralMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.CollectionUtils;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class HouseholdExtractorTest {

    @Mock
    private ResultSet resultSet;
    private HouseholdExtractor extractor;

    @Before
    public void setup() throws SQLException {
        extractor = new HouseholdExtractor();
        when(resultSet.next()).thenReturn(true).thenReturn(false);
    }

    @Test
    public void useContactInfoRowMapperTrueInitiatesClass(){
        extractor.useContactInfoRowMapper(true);
        assertNotNull(ReflectionTestUtils.getField(extractor, "contactInfoRowMapper"));
    }

    @Test
    public void useContactInfoRowMapperFalseSetsAsNull(){
        extractor.useContactInfoRowMapper(false);
        assertNull(ReflectionTestUtils.getField(extractor, "contactInfoRowMapper"));
    }

    @Test
    public void useReferralRowMapperTrueInitializesClass(){
        extractor.useReferralRowMapper(true);
        assertNotNull(ReflectionTestUtils.getField(extractor, "referralMapper"));
    }

    @Test
    public void useReferralRowMapperFalseSetsAsNull(){
        extractor.useReferralRowMapper(false);
        assertNull(ReflectionTestUtils.getField(extractor, "referralMapper"));
    }

    @Test
    public void extractDataOnlyMapsHouseholdIfNoPersonId() throws SQLException {
        when(resultSet.getLong(HouseholdRowMapper.HSHLD_ID)).thenReturn(123L);
        when(resultSet.getObject(PersonRowMapper.PERSON_ID)).thenReturn(null);

        List<Household> households = extractor.extractData(resultSet);
        assertTrue(households.size() == 1);
        assertEquals(new Long(123L), households.get(0).getServerId());
        assertTrue(CollectionUtils.isEmpty(households.get(0).getPeople()));
    }

    @Test
    public void extractDataWithPeopleDoesNotExtractContactOrReferralIfMappersNotInitialized() throws SQLException {
        when(resultSet.getLong(HouseholdRowMapper.HSHLD_ID)).thenReturn(123L);
        when(resultSet.getObject(PersonRowMapper.PERSON_ID)).thenReturn(456L);
        when(resultSet.getLong(PersonRowMapper.PERSON_ID)).thenReturn(456L);
        when(resultSet.getString(EmailTypes.EMAIL_FAMILY.name() + "email_addr")).thenReturn("test");
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));

        List<Household> households = extractor.extractData(resultSet);
        assertTrue(households.size() == 1);
        Household household = households.get(0);
        assertEquals(new Long(123L), household.getServerId());
        assertTrue(household.getPeople().size() == 1);
        Person person = household.getPeople().get(0);
        assertNull(person.getContactInfo());
        assertNull(person.getReferralInfo());
    }

    @Test
    public void extractDataWithPeopleExtractsContactAndReferralIfMappersInitialized() throws SQLException {
        when(resultSet.getLong(HouseholdRowMapper.HSHLD_ID)).thenReturn(123L);
        when(resultSet.getObject(PersonRowMapper.PERSON_ID)).thenReturn(456L);
        when(resultSet.getLong(PersonRowMapper.PERSON_ID)).thenReturn(456L);
        when(resultSet.getString(EmailTypes.EMAIL_FAMILY.name())).thenReturn(EmailTypes.EMAIL_FAMILY.name());
        when(resultSet.getString(EmailTypes.EMAIL_FAMILY.name() + "email_addr")).thenReturn("test");
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));

        extractor.useReferralRowMapper(true);
        extractor.useContactInfoRowMapper(true);

        List<Household> households = extractor.extractData(resultSet);
        assertTrue(households.size() == 1);
        Household household = households.get(0);
        assertEquals(new Long(123L), household.getServerId());
        assertTrue(household.getPeople().size() == 1);
        Person person = household.getPeople().get(0);
        assertNotNull(person.getContactInfo());
        assertNotNull(person.getReferralInfo());
    }
}
