package lds.personservice.household;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import lds.personservice.person.PersonService;
import lds.personservice.person.builder.*;
import lds.prsms.utils.errors.ServiceException;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import lds.personservice.person.Person;

@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class HouseholdServiceTest {

	@InjectMocks private HouseholdService householdService;

	@Mock private Household mockHousehold;

	@Mock private Person mockPerson;

    @Mock private HouseholdRepository householdRepository;

    @Mock
    private PersonService personService;

    @Mock
    private PeopleBuilderService peopleBuilderService;

    @Mock
    private PeopleCommitmentBuilder commitmentBuilder;

    @Mock
    private PeopleDropNoteBuilder dropNoteBuilder;

    @Mock
    private PeopleFellowshipBuilder fellowshipBuilder;

    @Mock
    private PeopleBuilder impl;

    @Test
    public void searchHouseholdsCallsExpected(){
        Person p1 = new Person();
        Person p2 = new Person();
        Person p3 = new Person();

        Household household = new Household();
        household.addPerson(p1);
        household.addPerson(p2);
        Household household2 = new Household();
        household2.addPerson(p3);

        ListParams listParams = new ListParams();
        when(householdRepository.searchHouseholds(listParams)).thenReturn(Arrays.asList(household, household2));
        setupPeopleBuilder();
        HouseholdListWrapper wrapper = householdService.searchHouseholds(listParams);
        assertNotNull(wrapper);
        assertThat(wrapper.getHouseholds(), hasItem(household));
        assertThat(wrapper.getHouseholds(), hasItem(household2));
        verifyPeopleBuilderUsed(Arrays.asList(p1, p2, p3));
    }

    @Test(expected = ServiceException.class)
    public void createNewHouseholdDuplicateGuid(){
        Household household = new Household();
        household.setGuid("1234");
        when(householdRepository.householdWithGuidExists(household.getGuid())).thenReturn(true);

        householdService.createNewHousehold(household);
    }

    @Test
    public void createNewHouseholdMakesExpectedCalls(){
        setupPeopleBuilder();
        List<Person> people = Arrays.asList(new Person());
        Household household = new Household();
        household.setPeople(people);

        when(householdRepository.getHouseholdByGuid(anyString())).thenReturn(household);

        householdService.createNewHousehold(household);
        verify(householdRepository, times(1)).createNewHousehold(household);
        verify(personService, times(1)).savePeople(people);
    }

    @Test
    public void updateHouseholdMakesExpectedCalls(){
        List<Person> people = Arrays.asList(new Person());
        Household household = new Household();
        household.setPeople(people);
        household.setGuid("abc");

        Household original = mock(Household.class);

        when(householdRepository.getHouseholdByGuid("abc")).thenReturn(original);
        householdService.updateHousehold(household, household.getGuid());
        verify(original, times(1)).applyChangesToThis(household);
        verify(householdRepository, times(1)).updateHousehold(original);
        verify(householdRepository, times(1)).getHouseholdByGuid("abc");
        verify(personService, times(1)).savePeople(people);
    }

    @Test
    public void deleteHouseholdCallsExpectedWithoutPeople(){
        Household household = new Household();
        household.setServerId(123L);
        when(householdRepository.getHouseholdByGuid("abc")).thenReturn(household);

        householdService.deleteHousehold("abc");
        verify(householdRepository, times(1)).deleteHousehold(123L);
        verifyZeroInteractions(personService);
    }

    @Test
    public void deleteHouseholdDeletesPeopleAsWell(){
        setupPeopleBuilder();
        Person person = new Person();
        person.setGuid("cba");
        person.setServerId(123L);

        Household original = new Household();
        original.addPerson(person);
        original.setServerId(123L);
        when(householdRepository.getHouseholdByGuid("abc")).thenReturn(original);
        householdService.deleteHousehold("abc");
        verify(householdRepository, times(1)).deleteHousehold(123L);
        verify(personService, times(1)).deletePerson("cba");
    }

    @Test(expected = ServiceException.class)
    public void getHouseholdThrowsIfHouseholdRepoThrowsNullPointer(){
        when(householdRepository.getHouseholdByGuid(anyString())).thenThrow(new NullPointerException());
        householdService.getHousehold("abc");
    }

    @Test
    public void getHouseholdJustReturnsIfNoPeople(){
        setupPeopleBuilder();
        Household household = new Household();
        household.setGuid("ABC");
        when(householdRepository.getHouseholdByGuid("ABC")).thenReturn(household);
        Household result = householdService.getHousehold("ABC");
        assertEquals(result, household);
        verify(householdRepository, times(1)).getHouseholdByGuid("ABC");
        verifyNoMoreInteractions(householdRepository);
    }

    @Test
    public void getHouseholdPopulatesPeople(){
        setupPeopleBuilder();
        Person person = new Person();
        person.setServerId(123L);
        Household household = new Household();
        household.addPerson(person);

        when(householdRepository.getHouseholdByGuid("abc")).thenReturn(household);

        Household result = householdService.getHousehold("abc");
        assertEquals(result, household);
        assertTrue(result.getPeople().size() == 1);
        assertEquals(person, result.getPeople().get(0));
        verifyPeopleBuilderUsed(household.getPeople());
    }

    private void verifyPeopleBuilderUsed(List<Person> people) {
        verify(peopleBuilderService, times(1)).getBuilder();
        verify(impl, times(1)).withParams(any(BuilderParams.class));
        verify(impl, times(1)).withPeople(people);
    }

    private void setupPeopleBuilder(){
        when(peopleBuilderService.getBuilder()).thenReturn(impl);
        when(impl.withParams(any(BuilderParams.class))).thenReturn(impl);
        when(impl.withPeople(anyList())).thenReturn(impl);
        when(impl.construct()).thenReturn(impl);
    }
}
