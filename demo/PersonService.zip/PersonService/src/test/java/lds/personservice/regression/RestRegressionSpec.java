package lds.personservice.regression;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertFalse;

import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;
import java.util.Properties;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.authentication.FormAuthConfig;
import com.jayway.restassured.specification.RequestSpecification;

public class RestRegressionSpec {
	private static final String MISSING_PROPERTY_MESSAGE_TMPL = "%s not defined.  Set property %s as a system property or in %s.";
	private static final String EMPTY_PROPERTY_MESSAGE_TMPL = "%s empty.  Set property %s as a system property or in %s.";
	private static final String BASE_URI_KEY = "prsms.baseUri";
	private static final String USERNAME_KEY = "prsms.username";
	private static final String PASSWORD_KEY = "prsms.password";
	private static final String LOGIN_PAGE_USERNAME_KEY = "prsms.loginPage.username";
	private static final String LOGIN_PAGE_PASSWORD_KEY = "prsms.loginPage.password";
	private static final String LOGIN_PAGE_PATH_KEY = "prsms.loginPage.path";
	private static final String REGRESSION_PROPERTIES_FILE = "/regression.properties";
	private static final Properties regression = new Properties();
	private static final String baseUri;
	private static final String username;
	private static final String password;
	private static final String loginPageUsername;
	private static final String loginPagePassword;
	private static final String loginPagePath;

	static {
		try (final InputStream inputStream = RestRegressionSpec.class.getResourceAsStream(REGRESSION_PROPERTIES_FILE)) {
			regression.load(inputStream);
		} catch (final IOException e) {
			throw new IllegalStateException("Error loading regression properties file", e);
		}

		baseUri = extractProperty(BASE_URI_KEY);
		username = extractProperty(USERNAME_KEY);
		password = extractProperty(PASSWORD_KEY);
		loginPageUsername = extractProperty(LOGIN_PAGE_USERNAME_KEY);
		loginPagePassword = extractProperty(LOGIN_PAGE_PASSWORD_KEY);
		loginPagePath = extractProperty(LOGIN_PAGE_PATH_KEY);

		assertProperty("baseUri", BASE_URI_KEY, baseUri);
		assertProperty("username", USERNAME_KEY, username);
		assertProperty("password", PASSWORD_KEY, password);
		assertProperty("loginPageUsername", LOGIN_PAGE_USERNAME_KEY, loginPageUsername);
		assertProperty("loginPagePassword", LOGIN_PAGE_PASSWORD_KEY, loginPagePassword);
		assertProperty("loginPagePath", LOGIN_PAGE_PATH_KEY, loginPagePath);
	}

    public static String getBaseUri() {
        return baseUri;
    }

    public static String getUsername() {
        return username;
    }

    public static String getPassword() {
        return password;
    }
        
	protected final RequestSpecification given() {
		return RestAssured.given()
			.log().all()
			.baseUri(baseUri);
	}

	protected final RequestSpecification givenAnAuthenticatedSession() {
		return RestAssured.given()
			.log().all()
			.auth()
			.form(username, password, new FormAuthConfig(loginPagePath, loginPageUsername, loginPagePassword))
			.baseUri(baseUri);
	}

	private static String extractProperty(final String key) {
		return Optional.ofNullable(System.getProperty(key)).orElse(regression.getProperty(key));
	}

	private static void assertProperty(final String name, final String key, final String value) {
		assertNotNull(String.format(MISSING_PROPERTY_MESSAGE_TMPL, name, key, REGRESSION_PROPERTIES_FILE), value);
		assertFalse(String.format(EMPTY_PROPERTY_MESSAGE_TMPL, name, key, REGRESSION_PROPERTIES_FILE), value.isEmpty());
	}
}
