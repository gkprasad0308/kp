package lds.personservice.household;


import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;

public class InclusionParamsTest {

    @Test
    public void getFromParamReturnsExpectedInclusion(){
        InclusionParams param = InclusionParams.values()[InclusionParams.values().length - 1];
        InclusionParams result = InclusionParams.getFromParam(param.name());
        assertEquals(param, result);
    }

    @Test
    public void getFromParamReturnsExpectedIgnoringCase(){
        InclusionParams param = InclusionParams.values()[InclusionParams.values().length - 1];
        InclusionParams result = InclusionParams.getFromParam(param.name().toLowerCase());
        assertEquals(param, result);
    }

    @Test
    public void getFromParamReturnsNullIfEmptyParam(){
        assertNull(InclusionParams.getFromParam(""));
    }

    @Test
    public void getFromParamReturnsNullIfNullParam(){
        assertNull(InclusionParams.getFromParam(null));
    }

    @Test
    public void getFromParamReturnsNullIfNoParamMatchesValue(){
        assertNull(InclusionParams.getFromParam("abc"));
    }

    @Test
    public void getDeltasReturnsAllIfParamIsNull(){
        List<InclusionParams> deltas = InclusionParams.getDeltas(null);
        assertThat(deltas, contains(InclusionParams.values()));
    }

    @Test
    public void getDeltasReturnsAllIfParamIsEmpty(){
        List<InclusionParams> deltas = InclusionParams.getDeltas(new ArrayList<>());
        assertThat(deltas, contains(InclusionParams.values()));
    }

    @Test
    public void getDeltasRetursExpectedDeltas(){
        List<InclusionParams> deltas = InclusionParams.getDeltas(Arrays.asList(InclusionParams.COMMITMENTS, InclusionParams.CONTACT_INFO));
        assertThat(deltas, hasItem(InclusionParams.DROP_NOTES));
        assertThat(deltas, hasItem(InclusionParams.FELLOWSHIPPERS));
        assertThat(deltas, hasItem(InclusionParams.REFERRAL_INFO));
        assertTrue(deltas.size() == 3);
    }

    @Test
    public void valuesAsListContainsAllValues(){
        assertThat(InclusionParams.valuesAsList(), contains(InclusionParams.values()));
    }
}
