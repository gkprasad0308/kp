package lds.personservice.commitment;

import lds.personservice.AbstractValidationTestRunnerIT;
import lds.personservice.Main;
import lds.personservice.client.ResourceTemplate;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.HttpMethod;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import javax.inject.Inject;
import javax.inject.Provider;

@ActiveProfiles({"local"})
@IntegrationTest({"browser.startup=false", "server.port=0"})
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class CommitmentPostValidationIT extends AbstractValidationTestRunnerIT<Commitment> {

    @Inject
    private Provider<CommitmentTemplate> templateProvider;

    @Override
    protected ResourceTemplate getTemplate() {
        return templateProvider.get();
    }

    @Override
    protected HttpMethod getHttpMethod() {
        return HttpMethod.POST;
    }

    @Override
    protected String getModelName(Commitment commitment){
        return "commitmentEntity";
    }

    @Test
    public void createCommitmentIsInvalidWithoutTeachingItemId(){
        Commitment commitment = new Commitment();
        commitment.setTeachingItemId(null);
        runFieldErrorInclusiveTest(commitment, "teachingItemId", MISSING);
    }

    @Test
    public void createCommitmentIsInvalidWithoutPersonGuid(){
        Commitment commitment = new Commitment();
        commitment.setPersonGuid(null);
        runFieldErrorInclusiveTest(commitment, "personGuid", MISSING);
    }

    @Test
    public void createCommitmentIsInvalidWithoutInvitationDate(){
        Commitment commitment = new Commitment();
        commitment.setInviteDate(null);
        runFieldErrorInclusiveTest(commitment, "inviteDate", MISSING);
    }

    @Test
    public void createCommitmentIsInvalidWithInvalidGuid(){
        Commitment commitment = new Commitment();
        commitment.setClientGuid("abc");
        runFieldErrorInclusiveTest(commitment, "clientGuid", BAD);
    }

    @Test
    public void createCommitmentIsInvalidWithInvalidPersonGuid(){
        Commitment commitment = new Commitment();
        commitment.setPersonGuid("-123");
        runFieldErrorInclusiveTest(commitment, "personGuid", OUTOFBOUNDS);
    }
}
