package lds.personservice.validation.constraint;

import lds.personservice.util.validation.constraint.PersonIdValidator;
import lds.personservice.util.validation.service.PersonValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PersonIdValidatorTest {

    @InjectMocks
    private PersonIdValidator validator;

    @Mock
    private PersonValidationService service;

    @Test
    public void isValidIsTrueWithNull(){
        assertTrue( validator.isValid(null, null) );
        verifyZeroInteractions(service);
    }

    @Test
    public void isValidIsTrueWithEmpty(){
        assertTrue( validator.isValid(null, null) );
        verifyZeroInteractions(service);
    }

    @Test
    public void isValidIsValidIfServiceReturnsTrue(){
        when(service.personExists("abc")).thenReturn(true);
        assertTrue(validator.isValid("abc", null));
        verify(service, times(1)).personExists("abc");
        verifyNoMoreInteractions(service);
    }

    @Test
    public void isValidIsFalseIfServiceReturnsTrue(){
        when(service.personExists("abc")).thenReturn(false);
        assertFalse(validator.isValid("abc", null));
        verify(service, times(1)).personExists("abc");
        verifyNoMoreInteractions(service);
    }
}
