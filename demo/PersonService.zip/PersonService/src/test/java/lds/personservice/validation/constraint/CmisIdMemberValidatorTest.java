package lds.personservice.validation.constraint;

import lds.personservice.person.Person;
import lds.personservice.util.validation.constraint.CmisIdMemberValidator;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class CmisIdMemberValidatorTest {

    @InjectMocks
    private CmisIdMemberValidator validator;

    @Mock
    private OptionsValidationService validationService;

    @Mock
    private ConstraintValidatorContext context;

    @Test
    public void isValid_returns_false_with_null_person(){
        assertFalse(validator.isValid(null, context));
    }

    @Test
    public void isValid_returns_false_with_cmis_id_and_prosArea_id(){
        Person person = new Person();
        person.setProsAreaId(1L);
        person.setCmisId(2L);
        assertFalse("A person cannot have a cmisId and prosAreaId", validator.isValid(person, context));
    }

    @Test
    public void isValid_returns_true_with_null_cmis_id_and_null_prosArea(){
        Person person = new Person();
        assertTrue("person with null cmisId and null prosArea is valid", validator.isValid(person, context));
    }

    @Test
    public void isValid_returns_true_with_null_cmis_id_a_prosArea(){
        Person person = new Person();
        person.setProsAreaId(5L);
        assertTrue("person with null cmisId and a prosArea is valid", validator.isValid(person, context));
    }

    @Test
    public void isValid_returns_false_if_cmisId_has_value_that_isnt_member_and_prosArea_isNull(){
        Person person = new Person();
        person.setCmisId(1L);
        person.setStatus(1);
        person.setProsAreaId(null);
        assertFalse("person with a cmisId, no prosArea, and nonMember status is invalid", validator.isValid(person, context));
    }

    @Test
    public void isValid_returns_true_if_cmisId_has_value_that_is_member_and_prosArea_isNull(){
        Person person = new Person();
        person.setCmisId(1L);
        person.setStatus(8);
        person.setProsAreaId(null);
        assertFalse("person with a cmisId, no prosArea, and member status is valid", validator.isValid(person, context));
    }
}
