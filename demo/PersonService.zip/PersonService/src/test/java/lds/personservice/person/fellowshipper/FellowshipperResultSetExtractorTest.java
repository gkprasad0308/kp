package lds.personservice.person.fellowshipper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FellowshipperResultSetExtractorTest {

    private FellowshipperResultSetExtractor extractor;

    @Mock
    private ResultSet resultSet;

    @Before
    public void setup(){
        extractor = new FellowshipperResultSetExtractor();
    }

    @Test
    public void extractDataCorrectlyMapsFellowshipperAndCapturesInfo() throws SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getLong(FellowshipperResultSetExtractor.FLLWSHP_PERSON_ID)).thenReturn(1L);
        when(resultSet.getLong(FellowshipperResultSetExtractor.IVGTR_PERSON_ID)).thenReturn(2L);
        when(resultSet.getLong(FellowshipperResultSetExtractor.PERSON_ID)).thenReturn(2L);
        when(resultSet.getString(FellowshipperResultSetExtractor.P_GUID)).thenReturn("test_guid");
        when(resultSet.getString(FellowshipperResultSetExtractor.DEL_YN)).thenReturn("N");
        when(resultSet.getString(FellowshipperResultSetExtractor.FIRST_NM)).thenReturn("bob");
        when(resultSet.getString(FellowshipperResultSetExtractor.LAST_NM)).thenReturn("jones");

        FellowshipMap map = extractor.extractData(resultSet);
        FellowshipInfo info = map.getFellowshipInfoForPerson(1L);
        assertNotNull(info);
        assertTrue(info.getFellowshippees().size() == 1);
        FellowshipData data = info.getFellowshippees().get(0);
        assertEquals(2L, data.getPersonServerId());
        assertEquals("test_guid", data.getPersonId());
        assertEquals(Boolean.FALSE, data.isDeleted());
        assertEquals("bob", data.getFirstName());
        assertEquals("jones", data.getLastName());
    }
}
