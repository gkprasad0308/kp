package lds.personservice.validation;

import lds.personservice.util.validation.ValidationResult;
import lds.prsms.utils.validation.FieldError;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ValidationResultTest {

    @Test
    public void constructerSetsDefaultStatusAndMessage(){
        ValidationResult result = new ValidationResult();
        assertEquals(ValidationResult.DEFAULT_STATUS, result.getStatus());
        assertEquals(ValidationResult.DEFAULT_CODE, result.getCode());
    }

    @Test
    public void constructorSetsValuesFromArguments(){
        ValidationResult result = new ValidationResult(HttpStatus.INTERNAL_SERVER_ERROR, "bad");
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatus());
        assertEquals("bad", result.getCode());
    }

    @Test
    public void addFieldErrorSetsFieldErrors(){
        ValidationResult result = new ValidationResult();
        result.addFieldError("bob", "bad");

        assertTrue(result.getFieldErrors().size() == 1);
        FieldError error = result.getFieldErrors().get(0);
        assertEquals("bob", error.getField());
        assertEquals("bad", error.getCode());
    }

    @Test
    public void addFieldErrorWithObjectSetsErrors(){
        ValidationResult result = new ValidationResult();
        result.addFieldError(new FieldError("object", "invalid"));

        assertTrue(result.getFieldErrors().size() == 1);
        FieldError error = result.getFieldErrors().get(0);
        assertEquals("object", error.getField());
        assertEquals("invalid", error.getCode());
    }
}
