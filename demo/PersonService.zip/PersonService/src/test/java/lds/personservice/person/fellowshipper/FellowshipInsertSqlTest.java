package lds.personservice.person.fellowshipper;

import lds.personservice.AbstractUpdateSqlTest;
import lds.personservice.options.Option;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class FellowshipInsertSqlTest extends AbstractUpdateSqlTest{

    @InjectMocks
    private FellowshipInsertSql insertSql;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            FellowshipInsertSql.FELLOWSHIPPER_ID,
            FellowshipInsertSql.GUID,
            FellowshipInsertSql.PERSON_ID
    );

    @Override
    protected SqlUpdate getInstance() {
        return insertSql;
    }

    @Override
    protected List<String> getExpectedParams() {
        return expectedParams;
    }

    @Test
    public void getParamsUsingDoesExpected(){
        Map<String, Object> results = insertSql.getParamsUsing(123L, 456L);
        checkKeys(results);
        assertEquals(123L, results.get(FellowshipInsertSql.PERSON_ID));
        assertEquals(456L, results.get(FellowshipInsertSql.FELLOWSHIPPER_ID));
        assertNotNull(results.get(FellowshipInsertSql.GUID));
    }
}
