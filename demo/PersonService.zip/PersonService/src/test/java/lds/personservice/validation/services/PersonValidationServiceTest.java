package lds.personservice.validation.services;

import lds.personservice.person.PersonRepository;
import lds.personservice.util.validation.service.PersonValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PersonValidationServiceTest {

    @InjectMocks
    private PersonValidationService service;

    @Mock
    private PersonRepository repository;

    @Test
    public void personExistsReturnsTrueIfRepoDoes(){
        when(repository.personWithGuidExists("abc")).thenReturn(true);
        assertTrue(service.personExists("abc"));
    }

    @Test
    public void personExistsReturnsFalseIfRepoDoes(){
        when(repository.personWithGuidExists("abc")).thenReturn(false);
        assertFalse(service.personExists("abc"));
    }
}
