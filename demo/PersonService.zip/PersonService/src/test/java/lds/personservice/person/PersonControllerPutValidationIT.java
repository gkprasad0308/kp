package lds.personservice.person;

import lds.personservice.AbstractValidationTestRunnerIT;
import lds.personservice.Main;
import lds.personservice.client.ResourceTemplate;
import lds.personservice.client.household.HouseholdTemplate;
import lds.personservice.household.Household;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import javax.inject.Inject;
import javax.inject.Provider;

@ActiveProfiles({ "local" })
@IntegrationTest({ "browser.startup=false", "server.port=0" })
@DirtiesContext
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringApplicationConfiguration(classes = Main.class)
public class PersonControllerPutValidationIT extends AbstractValidationTestRunnerIT<Person> {

    @Inject
    private Provider<PersonTemplate> templateProvider;

    @Inject
    private Provider<HouseholdTemplate> householdTemplateProvider;

    @Override
    protected ResourceTemplate getTemplate() {
        return templateProvider.get();
    }

    @Override
    protected HttpMethod getHttpMethod() {
        return HttpMethod.PUT;
    }

    @Test
    public void update_person_validates_cmisId_member(){
        Person person = new Person();
        person.setProsAreaId(123L);
        person.setCmisId(456L);
        runGlobalErrorInclusiveTest(person, getPutUrl(person), "error.put.person.invalid.cmisId.member");
    }

    @Test
    public void update_person_does_not_require_household_id(){
        Person person = new Person();
        person.setStatus(-1);
        runFieldErrorExclusiveTest(person, getPutUrl(person), "householdId");
    }

    @Test
    public void update_person_household_id_valid_chekc(){
        Person person = new Person();
        person.setHouseholdId("abcd");
        runFieldErrorInclusiveTest(person, getPutUrl(person), "householdId", OUTOFBOUNDS);
    }

    @Test
    public void updatePersonGivesInvalidProsAreaAssignment(){
        Household household = new Household();
        household.setOrgId(4051656L);
        household = householdTemplateProvider.get().createHousehold(MediaType.APPLICATION_JSON_VALUE, household, Household.class);

        Person person = new Person();
        person.setHouseholdId(household.getGuid());
        person.setProsAreaId(5500011L);
        runGlobalErrorInclusiveTest(person, getPutUrl(person), "error.put.person.incompatible.prosArea.for.household.org");
    }

    @Test
    public void updatePersonGivesInvalidProsAreaAssignmentIfInvalidProsArea(){
        Household household = new Household();
        household.setOrgId(4051656L);
        household = householdTemplateProvider.get().createHousehold(MediaType.APPLICATION_JSON_VALUE, household, Household.class);

        Person person = new Person();
        person.setHouseholdId(household.getGuid());
        person.setProsAreaId(5500011234234L);
        runGlobalErrorInclusiveTest(person, getPutUrl(person), "error.put.person.incompatible.prosArea.for.household.org");
    }

    private String getPutUrl(Person person) {
        return getTemplate().getResourceUriAsString() + "/" + person.getGuid();
    }
}
