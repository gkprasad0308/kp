package lds.personservice.validation.constraint;

import lds.personservice.household.Household;
import lds.personservice.util.validation.constraint.LatLngValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class LatLngValidatorTest {

    @Mock
    private ConstraintValidatorContext context;

    private LatLngValidator validator;

    @Before
    public void setup(){
        validator = new LatLngValidator();
    }

    @Test
    public void isValidBothLatLngNull(){
        Household household = createHousehold(null, null);
        assertTrue(validator.isValid(household, context));
    }

    @Test
    public void isValidBothEmpty(){
        Household household = createHousehold("", "");
        assertTrue(validator.isValid(household, context));
    }

    @Test
    public void isValidBothHaveValue(){
        assertTrue(validator.isValid(createHousehold("ba", "ra"), context));
    }

    @Test
    public void isNotValidIfLngNoLat(){
        assertFalse(validator.isValid(createHousehold(null, "12"), context));
    }

    @Test
    public void isNotValidIfLatNoLng(){
        assertFalse(validator.isValid(createHousehold("2", null),context));
    }

    private Household createHousehold(String lat, String lng) {
        Household household = new Household();
        household.setLat(lat);
        household.setLng(lng);
        return household;
    }
}
