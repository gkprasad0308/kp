/*
 * Copyright (C) 2015 Intellectual Reserve, Inc. All rights reserved.
 * This notice may not be removed.
 */
package lds.personservice.client.household;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

import lds.personservice.household.*;
import lds.personservice.household.search.AssignmentSearch;
import lds.personservice.household.search.HouseholdSearchFactory;
import lds.personservice.household.search.ParamsSearch;
import lds.prsms.utils.errors.ServiceException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import lds.personservice.person.PopulateCurrentPersonProcedure;
import lds.prsms.utils.UUIDGenerator;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.util.*;

/**
 * Test of the {@link HouseholdRepository} class.
 */
public class HouseholdRepositoryTest {

	private static final String GUID_1 = "12345678901234567890123456789012";

	private HouseholdRepository specimen;

	@Mock private NamedParameterJdbcTemplate namedTemplateMock;

	@Mock private JdbcTemplate jdbcTemplateMock;

	@Mock private HouseholdInsertSql householdInsertSqlMock;

    @Mock
    private HouseholdUpdateSql householdUpdateMock;

	@Mock private PopulateCurrentPersonProcedure populateCurrentPersonProcedureMock;

    @Mock
    private HouseholdSearchFactory searchFactory;

	@Before
	public void setup() {
		initMocks(this);

		specimen = new HouseholdRepository(namedTemplateMock, jdbcTemplateMock, householdInsertSqlMock,
                householdUpdateMock, populateCurrentPersonProcedureMock, searchFactory, UUIDGenerator.getInstance());
	}

	@Test
	public void testCreateHouseholdGuid() {
		long id = 100l;
		Household mockHousehold = mock(Household.class);
		mockHousehold.setGuid(GUID_1);

		when(jdbcTemplateMock.queryForObject(anyString(), eq(Long.class))).thenReturn(id++);
		when(namedTemplateMock.queryForObject(anyString(), any(SqlParameterSource.class), eq(Integer.class))).thenReturn(0);
		when(mockHousehold.getGuid()).thenReturn(GUID_1);

		specimen.createNewHousehold(mockHousehold);

		assertNotNull("Expected household to be returned by create", mockHousehold);

		verify(mockHousehold, times(1)).setGuid(anyString());
        verify(mockHousehold, times(1)).cleanAddress();
	}

	@Test
	public void testCreateHouseholdNoGuid() {
		long id = 100l;
		Household mockHousehold = mock(Household.class);

		when(jdbcTemplateMock.queryForObject(anyString(), eq(Long.class))).thenReturn(id++);
		when(namedTemplateMock.queryForObject(anyString(), any(SqlParameterSource.class), eq(Integer.class))).thenReturn(0);
		specimen.createNewHousehold(mockHousehold);

		assertNotNull("Expected household to be returned by create", mockHousehold);

		verify(mockHousehold, times(1)).setGuid(anyString());
        verify(mockHousehold, times(1)).cleanAddress();
	}

    @Test
    public void searchHouseholdsCallsExpected(){
        SimpleJdbcCall mockSproc = mock(SimpleJdbcCall.class);
        when(populateCurrentPersonProcedureMock.getStoredProc()).thenReturn(mockSproc);
        when(populateCurrentPersonProcedureMock.getParametersUsing(1L)).thenReturn(new MapSqlParameterSource());

        ListParams params = new ListParams();
        params.setAssignmentArea(1L);

        Household household = new Household();
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(HouseholdExtractor.class))).thenReturn(Arrays.asList(household));
        when(searchFactory.getSearch(params)).thenReturn(mock(AssignmentSearch.class));
        List<Household> results = specimen.searchHouseholds(params);
        assertThat(results, hasItem(household));
        assertTrue(results.size() == 1);

        verify(searchFactory, times(1)).getSearch(params);
        verify(populateCurrentPersonProcedureMock, times(1)).getParametersUsing(1L);
        verify(mockSproc, times(1)).execute(any(SqlParameterSource.class));
    }

    @Test
    public void searchHouseholdsCallsExpectedWithoutCallingSproc(){
        ListParams params = new ListParams();

        Household household = new Household();
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(HouseholdExtractor.class))).thenReturn(Arrays.asList(household));
        when(searchFactory.getSearch(params)).thenReturn(mock(ParamsSearch.class));
        List<Household> results = specimen.searchHouseholds(params);
        assertThat(results, hasItem(household));
        assertTrue(results.size() == 1);

        verify(searchFactory, times(1)).getSearch(params);
        verifyZeroInteractions(populateCurrentPersonProcedureMock);
    }

    @Test
    public void updateHouseholdCallsExpected(){
        Household household = mock(Household.class);
        Map<String, Object> map = new HashMap<>();
        when(householdUpdateMock.getParamsUsing(household)).thenReturn(map);
        specimen.updateHousehold(household);
        verify(householdUpdateMock, times(1)).getParamsUsing(household);
        verify(householdUpdateMock, times(1)).updateByNamedParam(map);
        verify(household, times(1)).cleanAddress();
    }

    @Test(expected = ServiceException.class)
    public void getHouseholdByIdThrowsIfNullHouseholds(){
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(HouseholdExtractor.class))).thenReturn(null);
        specimen.getHouseholdById(123L);
    }

    @Test(expected = ServiceException.class)
    public void getHouseholdByIdThrowsIfEmptyHouseholds(){
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(HouseholdExtractor.class))).thenReturn(new LinkedList<>());
        specimen.getHouseholdById(123L);
    }

    @Test
    public void getHouseholdByIdReturnsExpected(){
        Household household = new Household();
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(HouseholdExtractor.class))).thenReturn(Arrays.asList(household, new Household()));
        Household result = specimen.getHouseholdById(123L);
        assertEquals(household, result);
    }

    @Test(expected = NullPointerException.class)
    public void getHouseholdByGuidThrowsIfNullHouseholds(){
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(HouseholdExtractor.class))).thenReturn(null);
        specimen.getHouseholdByGuid("abc");
    }

    @Test(expected = NullPointerException.class)
    public void getHouseholdByGuidThrowsIfEmptyHouseholds(){
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(HouseholdExtractor.class))).thenReturn(new LinkedList<>());
        specimen.getHouseholdByGuid("abc");
    }

    @Test
    public void getHouseholdByGuidReturnsExpected(){
        Household household = new Household();
        when(namedTemplateMock.query(anyString(), any(SqlParameterSource.class), any(HouseholdExtractor.class))).thenReturn(Arrays.asList(household, new Household()));
        Household result = specimen.getHouseholdByGuid("abc");
        assertEquals(household, result);
    }

    @Test
    public void deleteHouseholdCallsExpected(){
        // TODO extract into a simple update sql for testing
        specimen.deleteHousehold(123L);
        verify(namedTemplateMock, times(1)).update(anyString(), any(SqlParameterSource.class));
        verifyNoMoreInteractions(namedTemplateMock);
    }

    @Test
    public void householdWithGuidReturnsExpected(){
        //when(namedTemplateMock.queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class))).thenReturn(1);
        assertTrue(specimen.householdWithGuidExists("abc"));

        //when(namedTemplateMock.queryForObject(anyString(), any(SqlParameterSource.class), any(Class.class))).thenReturn(0);
        assertFalse(specimen.householdWithGuidExists("abc"));
    }
}
