package lds.personservice;

import lds.personservice.household.Household;
import lds.personservice.household.HouseholdService;
import lds.personservice.missionorg.MissionOrgService;
import lds.personservice.person.Person;
import lds.personservice.person.PersonService;
import lds.prsms.utils.errors.ServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AssignmentServiceTest {

    @InjectMocks
    private AssignmentService service;

    @Mock
    private PersonService personService;

    @Mock
    private HouseholdService householdService;

    @Mock
    private MissionOrgService missionOrgService;

    @Test
    public void handleHouseholdAssignmentHandlesChangeToMissionary(){
        Person newPerson = new Person();
        newPerson.setProsAreaId(123L);
        newPerson.setGuid("2");

        Household newHousehold = new Household();
        newHousehold.setStewardCmisId(3L);
        newHousehold.setMissionaryId(456L);
        newHousehold.addPerson(newPerson);
        newHousehold.setGuid("abc");

        Person originalPerson = new Person();
        originalPerson.setProsAreaId(123L);
        originalPerson.setGuid("4");

        Household originalHousehold = new Household();
        originalHousehold.setOrgId(1L);
        originalHousehold.addPerson(originalPerson);

        when(householdService.getHousehold("abc")).thenReturn(originalHousehold);
        Household result = service.handleHouseholdAssignment(newHousehold, newHousehold.getGuid());
        assertNull(result.getStewardCmisId());
        assertNull(result.getOrgId());
        assertEquals(new Long(456L), result.getMissionaryId());
        assertTrue(result.getPeople().size() == 2);

        assertThat(result.getPeople().get(1).getProsAreaId(), is(nullValue()));
        assertThat(result.getPeople().get(0).getProsAreaId(), is(nullValue()));
    }

    @Test
    public void handleHouseholdAssignmentHandlesChangeToMissionaryFiltersOutMatchingPeopleIds(){
        Person newPerson = new Person();
        newPerson.setProsAreaId(123L);
        newPerson.setGuid("2");

        Household newHousehold = new Household();
        newHousehold.setStewardCmisId(3L);
        newHousehold.setMissionaryId(456L);
        newHousehold.addPerson(newPerson);
        newHousehold.setGuid("abc");

        Person originalPerson = new Person();
        originalPerson.setProsAreaId(123L);
        originalPerson.setGuid("2");

        Household originalHousehold = new Household();
        originalHousehold.setOrgId(1L);
        originalHousehold.addPerson(originalPerson);

        when(householdService.getHousehold("abc")).thenReturn(originalHousehold);
        Household result = service.handleHouseholdAssignment(newHousehold, newHousehold.getGuid());
        assertNull(result.getStewardCmisId());
        assertNull(result.getOrgId());
        assertEquals(new Long(456L), result.getMissionaryId());
        assertTrue(result.getPeople().size() == 1);

        assertThat(result.getPeople().get(0).getProsAreaId(), is(nullValue()));
    }

    @Test
    public void handleHouseholdAssignmentHandlesChangeToMissionaryHandlesOnlyNewPeople(){
        Person newPerson = new Person();
        newPerson.setProsAreaId(123L);
        newPerson.setGuid("2");

        Household newHousehold = new Household();
        newHousehold.setStewardCmisId(3L);
        newHousehold.setMissionaryId(456L);
        newHousehold.addPerson(newPerson);
        newHousehold.setGuid("abc");

        Household originalHousehold = new Household();
        originalHousehold.setOrgId(1L);

        when(householdService.getHousehold("abc")).thenReturn(originalHousehold);
        Household result = service.handleHouseholdAssignment(newHousehold, newHousehold.getGuid());
        assertNull(result.getStewardCmisId());
        assertNull(result.getOrgId());
        assertEquals(new Long(456L), result.getMissionaryId());
        assertTrue(result.getPeople().size() == 1);

        assertThat(result.getPeople().get(0).getProsAreaId(), is(nullValue()));
    }

    @Test
    public void handleHouseholdAssignmentHandlesChangeToMissionaryHandlesOnlyExistant(){
        Household newHousehold = new Household();
        newHousehold.setStewardCmisId(3L);
        newHousehold.setMissionaryId(456L);
        newHousehold.setGuid("abc");

        Person originalPerson = new Person();
        originalPerson.setProsAreaId(123L);
        originalPerson.setGuid("4");

        Household originalHousehold = new Household();
        originalHousehold.setOrgId(1L);
        originalHousehold.addPerson(originalPerson);

        when(householdService.getHousehold("abc")).thenReturn(originalHousehold);
        Household result = service.handleHouseholdAssignment(newHousehold, newHousehold.getGuid());
        assertNull(result.getStewardCmisId());
        assertNull(result.getOrgId());
        assertEquals(new Long(456L), result.getMissionaryId());
        assertTrue(result.getPeople().size() == 1);

        assertThat(result.getPeople().get(0).getProsAreaId(), is(nullValue()));
    }

    @Test
    public void handleHouseholdAssignmentDoesNotChangeOrgIfMissionaryIdIsNull(){
        Household household = new Household();
        household.setOrgId(123L);
        household.setGuid("abc");

        when(householdService.getHousehold("abc")).thenReturn(new Household());
        Household result = service.handleHouseholdAssignment(household, household.getGuid());
        assertEquals(new Long(123L), result.getOrgId());
    }

    @Test
    public void handleHouseholdAssignmentDoesNotChangeStewardIfMissionaryIdIsNull(){
        Household household = new Household();
        household.setStewardCmisId(123L);
        household.setGuid("abc");

        when(householdService.getHousehold("abc")).thenReturn(new Household());
        Household result = service.handleHouseholdAssignment(household, household.getGuid());
        assertEquals(new Long(123L), result.getStewardCmisId());
    }

    @Test
    public void handleHouseholdAssignmentDoesNotChangeOrgIfExistingDoesntHaveOrgId(){
        Household household = new Household();
        household.setOrgId(123L);
        household.setMissionaryId(456L);
        household.setGuid("abc");

        when(householdService.getHousehold("abc")).thenReturn(new Household());
        Household result = service.handleHouseholdAssignment(household, household.getGuid());
        assertEquals(new Long(123L), result.getOrgId());
        assertEquals(new Long(456L), result.getMissionaryId());
    }

    @Test
    public void handlePersonAssignmentReturnsNullIfProsAreaHasNotChanged(){
        when(personService.getPersonDetail(anyString())).thenReturn(new Person());
        Household result = service.handlePersonAssignment(new Person(), "abc");
        assertNull(result);
    }

    @Test
    public void handlePersonAssignmentSetsMissionaryIdAndOrgIdToNull(){
        Person person = new Person();
        person.setGuid("abc");
        person.setProsAreaId(123L);
        person.setHouseholdId("def");

        when(personService.getPersonDetail("abc")).thenReturn(new Person());

        Household household = new Household();
        household.setMissionaryId(123L);
        household.setOrgId(456L);
        household.setStewardCmisId(789L);
        when(householdService.getHousehold("def")).thenReturn(household);

        Household result = service.handlePersonAssignment(person, "abc");
        assertNull(result.getOrgId());
        assertNull(result.getStewardCmisId());
        assertNull(result.getMissionaryId());
        assertTrue(result.getPeople().size() == 1);
        assertThat(result.getPeople(), hasItem(person));
    }

    @Test
    public void handlePersonAssignmentSetsChangesProsAreaIds(){
        Person person = new Person();
        person.setGuid("abc");
        person.setProsAreaId(123L);
        person.setHouseholdId("def");

        when(personService.getPersonDetail("abc")).thenReturn(new Person());

        Person householdPerson = new Person();
        householdPerson.setProsAreaId(666L);
        householdPerson.setGuid("bob");

        Person cmisIdPerson = new Person();
        cmisIdPerson.setCmisId(123L);
        cmisIdPerson.setGuid("jill");

        Household household = new Household();
        household.setMissionaryId(123L);
        household.setOrgId(456L);
        household.setStewardCmisId(789L);
        household.addPerson(householdPerson);
        household.addPerson(cmisIdPerson);
        household.addPerson(person);
        when(householdService.getHousehold("def")).thenReturn(household);

        Household result = service.handlePersonAssignment(person, "abc");
        assertNull(result.getOrgId());
        assertNull(result.getStewardCmisId());
        assertNull(result.getMissionaryId());
        assertTrue(result.getPeople().size() == 2);
        assertThat(result.getPeople(), hasItem(person));
        assertThat(result.getPeople(), hasItem(householdPerson));
        assertEquals(new Long(123L), householdPerson.getProsAreaId());
    }

    @Test(expected = ServiceException.class)
    public void handlePersonAssignmentThrowsIfProsAreaChangesAndOriginalIsCmis(){
        Person person = new Person();
        person.setProsAreaId(123L);
        person.setGuid("abc");

        Person original = new Person();
        original.setCmisId(456L);

        when(personService.getPersonDetail("abc")).thenReturn(original);
        service.handlePersonAssignment(person, "abc");
    }
}
