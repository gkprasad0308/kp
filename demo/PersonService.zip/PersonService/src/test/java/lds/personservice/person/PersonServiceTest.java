package lds.personservice.person;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;

import lds.personservice.commitment.CommitmentRepository;
import lds.personservice.contactinfo.ContactInfo;
import lds.personservice.contactinfo.ContactInfoService;
import lds.personservice.household.Household;
import lds.personservice.household.HouseholdRepository;
import lds.personservice.person.drop.DropNoteRepository;
import lds.personservice.person.drop.UndoDropNoteSproc;
import lds.personservice.person.drop.WritableDropNote;
import lds.personservice.person.fellowshipper.FellowshipperRepository;
import lds.personservice.util.validation.service.OptionsValidationService;
import lds.prsms.utils.errors.ServiceException;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PersonServiceTest {

    @InjectMocks
    private PersonService service;

    @Mock
    private HouseholdRepository householdRepository;

    @Mock
    private DropNoteRepository dropNoteRepository;

    @Mock
    private CalcStatusSproc calcStatusSproc;

    @Mock
    private MergePersonSproc mergePersonSproc;

    @Mock
    private UndoDropNoteSproc undoDropNoteSproc;

    @Mock
    private PersonRepository personRepository;

    @Mock
    private FellowshipperRepository fellowshipperRepository;

    @Mock
    private CommitmentRepository commitmentRepository;

    @Mock
    private ContactInfoService contactInfoService;

    @Mock
    private OptionsValidationService optionsValidationService;

    @Mock
    private Person person;

    @Mock
    private SimpleJdbcCall simpleJdbcCall;

    @Test(expected = ServiceException.class)
    public void deletePersonThrowsIfHasCmisId(){
        Person person = new Person();
        person.setCmisId(123L);
        when(personRepository.getPersonByGuid("abc")).thenReturn(person);
        service.deletePerson("abc");
    }

    @Test
    public void deletePersonDoesExpected(){
        Person person = mock(Person.class);
        when(person.getServerId()).thenReturn(123L);
        when(person.getCmisId()).thenReturn(null);

        when(personRepository.getPersonByGuid(anyString())).thenReturn(person);
        service.deletePerson("abc");
        verify(personRepository, times(1)).getPersonByGuid("abc");
        verify(personRepository, times(1)).deletePerson(123L);
        verify(person, times(1)).getCmisId();
        verify(person, times(1)).getServerId();
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testUndoDropSuccess() {
        when(dropNoteRepository.findLatestDropIdForPerson(anyLong())).thenReturn(-1L);
        when(undoDropNoteSproc.getStoredProc()).thenReturn(simpleJdbcCall);
        when(calcStatusSproc.getStoredProc()).thenReturn(simpleJdbcCall);
        when(personRepository.getPersonByGuid(anyString())).thenReturn(person);
        when(personRepository.getPersonsByIds(anyList())).thenReturn(Arrays.asList(person));
        when(dropNoteRepository.getNotesForPerson(anyLong())).thenReturn(new ArrayList<>());
        when(dropNoteRepository.hasDropId(anyLong())).thenReturn(true);
        service.undoDrop("ABC");
        verify(dropNoteRepository, times(1)).hasDropId(anyLong());
        verify(dropNoteRepository, times(1)).findLatestDropIdForPerson(anyLong());
        verify(dropNoteRepository, times(1)).undoDrop(anyLong(), any(Date.class));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testUndoDropIgnoresIfNoDrops() {
        when(calcStatusSproc.getStoredProc()).thenReturn(simpleJdbcCall);
        when(personRepository.getPersonByGuid(anyString())).thenReturn(person);
        when(personRepository.getPersonsByIds(anyList())).thenReturn(Arrays.asList(person));
        when(dropNoteRepository.hasDropId(anyLong())).thenReturn(false);
        service.undoDrop("ABC");
        verify(dropNoteRepository, times(1)).hasDropId(anyLong());
        verify(dropNoteRepository, times(0)).findLatestDropIdForPerson(anyLong());
        verify(dropNoteRepository, times(0)).undoDrop(anyLong(), any(Date.class));
    }

    @Test
    public void testMergePersonSuccess() {
        when(person.getCmisId()).thenReturn(null);
        when(personRepository.getPersonByGuid(anyString())).thenReturn(person);

        when(mergePersonSproc.getStoredProc()).thenReturn(simpleJdbcCall);
        service.merge("-1L", "-2L");
        verify(mergePersonSproc, times(1)).getStoredProc();
    }

    @Test(expected = ServiceException.class)
    public void testMergePersonExceptionIfFromPersonIsNull() {
        when(personRepository.getPersonByGuid("abc")).thenReturn(null);
        when(personRepository.getPersonByGuid("def")).thenReturn(mock(Person.class));
        service.merge("abc", "def");
    }

    @Test(expected = ServiceException.class)
    public void testMergePersonExceptionIfToPersonIsNull() {
        when(personRepository.getPersonByGuid("abc")).thenReturn(mock(Person.class));
        when(personRepository.getPersonByGuid("def")).thenReturn(null);
        service.merge("abc", "def");
    }

    @Test(expected = ServiceException.class)
    public void mergeThrowsIfFromHasCmisId(){
        Person from = mock(Person.class);
        when(from.getCmisId()).thenReturn(123L);
        when(personRepository.getPersonByGuid("abc")).thenReturn(from);
        when(personRepository.getPersonByGuid("def")).thenReturn(mock(Person.class));
        service.merge("abc", "def");
    }

    @Test
    public void getPersonIdByGuidDoesntLookupPersonIdIfGuidDoesNotExist() {
        when(personRepository.personWithGuidExists("bob")).thenReturn(false);
        Long serverId = service.getPersonIdByGuid("bob");
        assertNull(serverId);
        verify(personRepository, times(1)).personWithGuidExists("bob");
        verifyNoMoreInteractions(personRepository);
    }

    @Test
    public void getPersonIdByGuidReturnsRepositoryValue(){
        when(personRepository.personWithGuidExists("bob")).thenReturn(true);
        when(personRepository.getPersonIdByGuid("bob")).thenReturn(123L);
        Long serverId = service.getPersonIdByGuid("bob");
        assertEquals(new Long(123L), serverId);
        verify(personRepository, times(1)).personWithGuidExists("bob");
        verify(personRepository, times(1)).getPersonIdByGuid("bob");
    }

    @Test(expected = ServiceException.class)
    public void test_createPerson_throws_if_duplicate_guid() {
        Person localPerson = new Person();
        localPerson.setGuid("1234");
        localPerson.setHouseholdId("4321");
        when(householdRepository.getHouseholdByGuid(anyString())).thenReturn(new Household());
        when(personRepository.personWithGuidExists(localPerson.getGuid())).thenReturn(true);

        service.createPerson(localPerson);
    }

    @Test
    public void createPersonCallsExpected(){
        ContactInfo info = mock(ContactInfo.class);

        Household household = mock(Household.class);
        when(household.getServerId()).thenReturn(123L);

        Person person = mock(Person.class);
        when(person.getServerId()).thenReturn(456L);
        when(person.getContactInfo()).thenReturn(info);
        when(person.getHouseholdId()).thenReturn("abc");

        when(householdRepository.getHouseholdByGuid("abc")).thenReturn(household);

        service.createPerson(person);

        verify(householdRepository, times(1)).getHouseholdByGuid("abc");
        verify(person, times(1)).setHouseholdServerId(123L);
        verify(person, times(1)).getServerId();
        verify(personRepository, times(1)).createPerson(person);
        verify(contactInfoService, times(1)).createNewContactInfo(456L, info);
    }

    @Test(expected = ServiceException.class)
    public void updatePersonThrowsIfPersonHasCmisIdAndNonMatchingHouseholds(){
        Person original = mock(Person.class);
        when(original.getHouseholdId()).thenReturn("def");
        when(original.getCmisId()).thenReturn(123L);
        when(personRepository.getPersonByGuid("abc")).thenReturn(original);

        Person update = mock(Person.class);
        when(update.getHouseholdId()).thenReturn("abc");
        service.updatePerson(update, "abc");
    }

    @Test
    public void updatePersonCallsExpected(){
        ContactInfo originalInfo = mock(ContactInfo.class);
        ContactInfo newInfo = mock(ContactInfo.class);

        Person original = mock(Person.class);
        when(original.getContactInfo()).thenReturn(originalInfo);
        when(original.getServerId()).thenReturn(123L);
        when(original.getCmisId()).thenReturn(null);

        Person person = mock(Person.class);
        when(person.getHouseholdServerId()).thenReturn(456L);
        when(person.getContactInfo()).thenReturn(newInfo);

        when(personRepository.getPersonByGuid("abc")).thenReturn(original);
        service.updatePerson(person, "abc");
        verify(personRepository, times(1)).getPersonByGuid("abc");
        verify(personRepository, times(1)).updatePerson(original);
        verify(original, times(1)).applyChangesToThis(person);
        verify(contactInfoService, times(1)).mixUpdateContactInfo(123L, newInfo, originalInfo);
    }

    @Test
    public void updatePersonAppliesHouseholdGuidIfNeeded(){
        ContactInfo originalInfo = mock(ContactInfo.class);
        ContactInfo newInfo = mock(ContactInfo.class);

        Person original = mock(Person.class);
        when(original.getContactInfo()).thenReturn(originalInfo);
        when(original.getServerId()).thenReturn(123L);
        when(original.getCmisId()).thenReturn(null);

        Person person = mock(Person.class);
        when(person.getContactInfo()).thenReturn(newInfo);
        when(person.getHouseholdId()).thenReturn("house");
        when(person.getHouseholdServerId()).thenReturn(null);

        when(personRepository.getPersonByGuid("abc")).thenReturn(original);
        when(householdRepository.getHouseholdByGuid("house")).thenReturn(new Household());
        service.updatePerson(person, "abc");
        verify(personRepository, times(1)).getPersonByGuid("abc");
        verify(personRepository, times(1)).updatePerson(original);
        verify(householdRepository, times(1)).getHouseholdByGuid("house");
        verify(original, times(1)).applyChangesToThis(person);
        verify(contactInfoService, times(1)).mixUpdateContactInfo(123L, newInfo, originalInfo);
    }

    @Test
    public void savePeopleDoesNothingIfEmptyList(){
        service.savePeople(new LinkedList<>());
        verifyZeroInteractions(personRepository);
    }

    @Test
    public void savePeopleDoesNothingIfNullList(){
        service.savePeople(null);
        verifyZeroInteractions(personRepository);
    }

    @Test
    public void savePeopleCreatesIfPersonHasGuidButGuidDoesNotExist(){
        Person person = new Person();
        person.setGuid("abc");
        person.setServerId(123L);

        when(personRepository.personWithGuidExists("abc")).thenReturn(false);
        when(householdRepository.getHouseholdByGuid(any())).thenReturn(new Household());
        service.savePeople(Arrays.asList(person));
        verify(personRepository, times(2)).personWithGuidExists("abc");
        verify(personRepository, times(1)).createPerson(person);
        verify(contactInfoService, times(1)).createNewContactInfo(anyLong(), any(ContactInfo.class));
    }

    @Test
    public void savePeopleCreatesAndUpdates(){
        Person updatePerson = new Person();
        updatePerson.setGuid("abc");
        updatePerson.setServerId(123L);

        Person createPerson = new Person();
        createPerson.setServerId(321L);

        when(personRepository.personWithGuidExists("abc")).thenReturn(true);
        when(personRepository.getPersonByGuid("abc")).thenReturn(updatePerson);
        when(householdRepository.getHouseholdByGuid(any())).thenReturn(new Household());
        service.savePeople(Arrays.asList(updatePerson, createPerson));
        verify(personRepository, times(1)).personWithGuidExists("abc");
        verify(personRepository, times(1)).createPerson(createPerson);
        verify(personRepository, times(1)).updatePerson(updatePerson);
        verify(contactInfoService, times(1)).createNewContactInfo(anyLong(), any(ContactInfo.class));
        verify(contactInfoService, times(1)).mixUpdateContactInfo(anyLong(), any(ContactInfo.class), any(ContactInfo.class));
    }

    @Test(expected = ServiceException.class)
    public void linkFellowshipperThrowsIfPersonReturnsNull(){
        when(personRepository.getPersonByGuid("abc")).thenReturn(null);
        service.linkFellowshipper("abc", "def");
    }

    @Test(expected = ServiceException.class)
    public void linkFellowshipperThrowsIfFellowshipperReturnsNull(){
        when(personRepository.getPersonByGuid("abc")).thenReturn(mock(Person.class));
        when(personRepository.getPersonByGuid("def")).thenReturn(null);
        service.linkFellowshipper("abc", "def");
    }

    @Test(expected = ServiceException.class)
    public void linkFellowshipperThrowsIfFellowshipperIsNotMember(){
        Person fellowshipper = mock(Person.class);
        when(fellowshipper.getStatus()).thenReturn(4);

        when(personRepository.getPersonByGuid("abc")).thenReturn(mock(Person.class));
        when(personRepository.getPersonByGuid("def")).thenReturn(fellowshipper);
        when(optionsValidationService.isMemberStatus(4)).thenReturn(false);
        service.linkFellowshipper("abc", "def");
    }

    @Test
    public void linkFellowshipperCallsExpected(){
        Person person = mock(Person.class);
        Person fellowshipper = mock(Person.class);

        when(personRepository.getPersonByGuid("abc")).thenReturn(person);
        when(personRepository.getPersonByGuid("def")).thenReturn(fellowshipper);
        when(optionsValidationService.isMemberStatus(any())).thenReturn(true);
        service.linkFellowshipper("abc", "def");
        verify(personRepository, times(1)).getPersonByGuid("abc");
        verify(personRepository, times(1)).getPersonByGuid("def");
        verify(optionsValidationService, times(1)).isMemberStatus(any());
        verify(fellowshipperRepository, times(1)).linkPersonToFellowshipper(person, fellowshipper);
    }

    @Test(expected = ServiceException.class)
    public void removeFellowshipperThrowsIfNullPerson(){
        when(personRepository.getPersonByGuid("abc")).thenReturn(null);
        service.removeFellowshipper("abc", "def");
    }

    @Test(expected = ServiceException.class)
    public void removeFellowshipperThrowsIfNullFellowshipper(){
        when(personRepository.getPersonByGuid("abc")).thenReturn(mock(Person.class));
        when(personRepository.getPersonByGuid("def")).thenReturn(null);
        service.removeFellowshipper("abc", "def");
    }

    @Test
    public void removeFellowshipperCallsRemove(){
        Person person = mock(Person.class);
        when(person.getServerId()).thenReturn(123L);
        Person fellowshipper = mock(Person.class);
        when(fellowshipper.getServerId()).thenReturn(456L);

        when(personRepository.getPersonByGuid("abc")).thenReturn(person);
        when(personRepository.getPersonByGuid("def")).thenReturn(fellowshipper);

        service.removeFellowshipper("abc", "def");
        verify(personRepository, times(1)).getPersonByGuid("abc");
        verify(personRepository, times(1)).getPersonByGuid("def");
        verify(fellowshipperRepository, times(1)).removePersonToFellowshipperLink(123L, 456L);
    }

    @Test(expected = ServiceException.class)
    public void dropPersonThrowsIfPersonIsNull(){
        when(personRepository.getPersonByGuid("abc")).thenReturn(null);
        service.dropPerson("abc", null);
    }

    @Test
    public void dropPersonCallsExpected(){
        Person person = mock(Person.class);
        when(person.getServerId()).thenReturn(123L);
        WritableDropNote note = mock(WritableDropNote.class);
        when(personRepository.getPersonByGuid("abc")).thenReturn(person);
        service.dropPerson("abc", note);
        verify(personRepository, times(1)).getPersonByGuid("abc");
        verify(dropNoteRepository, times(1)).dropPerson(123L, note);
    }

    @Test(expected = ServiceException.class)
    public void resetDropThrowsIfPersonIsNull(){
        when(personRepository.getPersonByGuid("abc")).thenReturn(null);
        service.resetDrop("abc", null);
    }

    @Test
    public void resetDropCallsExpected(){
        Person person = mock(Person.class);
        when(person.getServerId()).thenReturn(123L);
        Date date = mock(Date.class);

        when(personRepository.getPersonByGuid("abc")).thenReturn(person);
        service.resetDrop("abc", date);
        verify(personRepository, times(1)).getPersonByGuid("abc");
        verify(dropNoteRepository, times(1)).resetPerson(123L, date);
    }

    @Test
    public void undoDropDoesNothingIfPersonIsNull(){
        when(personRepository.getPersonByGuid("abc")).thenReturn(null);
        service.undoDrop("abc");
        verify(personRepository, times(1)).getPersonByGuid("abc");
        verifyNoMoreInteractions(personRepository);
        verifyZeroInteractions(dropNoteRepository, householdRepository);
    }
}
