package lds.personservice.person.drop;

import org.junit.Test;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DropNoteResultSetExtractorTest {

    @Test
    public void extractDataReturnsExpectedMap() throws SQLException {
        Date modDate = new Date(System.currentTimeMillis());
        Date alertDate = new Date(System.currentTimeMillis());

        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getLong(DropNoteResultSetExtractor.PERSON_ID)).thenReturn(1L);
        when(resultSet.getString(DropNoteMapper.NOTE)).thenReturn("note");
        when(resultSet.getString(DropNoteMapper.DEL_YN)).thenReturn("N");
        when(resultSet.getDate(DropNoteMapper.ALERT_DT)).thenReturn(alertDate);
        when(resultSet.getDate(DropNoteMapper.MOD_DT)).thenReturn(modDate);
        when(resultSet.getString(DropNoteMapper.CLIENT_GUID)).thenReturn("ABC");

        DropNoteResultSetExtractor extractor = new DropNoteResultSetExtractor();
        Map<Long, List<DropNote>> results = extractor.extractData(resultSet);
        assertTrue(results.size() == 1);
        assertTrue(results.containsKey(1L));

        List<DropNote> dropNotes = results.get(1L);
        assertTrue(dropNotes.size() == 1);

        DropNote dropNote = dropNotes.get(0);
        assertEquals("note", dropNote.getNote());
        assertFalse(dropNote.getDeleted());
        assertEquals(alertDate, dropNote.getAlertDate());
        assertEquals(modDate, dropNote.getModifiedDate());
        assertEquals("ABC", dropNote.getGuid());
    }
}
