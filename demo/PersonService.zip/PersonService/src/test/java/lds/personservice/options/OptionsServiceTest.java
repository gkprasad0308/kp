package lds.personservice.options;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class OptionsServiceTest {

    @InjectMocks
    private OptionsService service;

    @Mock
    private SourceRepository sourceRepository;

    @Mock
    private AgeCategoryRepository ageCategoryRepository;

    @Mock
    private ContactTypeRepository contactTypeRepository;

    @Mock
    private LanguageCodeRepository languageCodeRepository;

    @Mock
    private StatusRepository statusRepository;

    @Test
    public void getSourcesReturnsEnglishIfLangIdIsNotEnglishAndRepoDoesntReturnForLang(){
        setupLanguagueFallThrough(sourceRepository, createSource(1));
        List<Source> sources = service.getSources("bob");
        assertOptionsList(sources);
        verifyLanguageFallThrough(sourceRepository);
    }

    @Test
    public void getSourcesReturnsNullIfEnglishReturnsNothing(){
        setupNoEnglishData(sourceRepository);
        List<Source> sources = service.getSources("en");
        assertTrue(CollectionUtils.isEmpty(sources));
        verifyNoEnglishData(sourceRepository);
    }

    @Test
    public void getAgeCategoriesReturnsNullIfEnglishReturnsNothing(){
        setupLanguagueFallThrough(ageCategoryRepository, createAgeCategory(1));
        List<AgeCategory> ageCategories = service.getAgeCategories("bob");
        assertOptionsList(ageCategories);
    }

    @Test
    public void getAgeCategoriesReturnsNullIfNothingIsFound(){
        setupNoEnglishData(ageCategoryRepository);
        List<AgeCategory> categories = service.getAgeCategories("en");
        assertTrue(CollectionUtils.isEmpty(categories));
        verifyNoEnglishData(ageCategoryRepository);
    }

    @Test
    public void getContactTypesLanguageFallThrough(){
        ContactType contactType = createContactType(1);
        setupLanguagueFallThrough(contactTypeRepository, contactType);
        List<ContactType> contactTypes = service.getContactTypes("bob");
        assertOptionsList(contactTypes);
        verifyLanguageFallThrough(contactTypeRepository);
    }

    private ContactType createContactType(int id) {
        ContactType contactType = new ContactType();
        contactType.setId(id);
        return contactType;
    }

    @Test
    public void getContactTypesNoEnglishData(){
        setupNoEnglishData(contactTypeRepository);
        service.getContactTypes("en");
        verifyNoEnglishData(contactTypeRepository);
    }

    @Test
    public void getStatusLanguageFallThrough(){
        Status status = createStatus(1);
        setupLanguagueFallThrough(statusRepository, status);
        List<Status> stats = service.getStats("bob");
        assertOptionsList(stats);
        verifyLanguageFallThrough(statusRepository);
    }

    private Status createStatus(int id) {
        Status status = new Status();
        status.setId(id);
        return status;
    }

    @Test
    public void getStatusNoEnglishData(){
        setupNoEnglishData(statusRepository);
        service.getStats("en");
        verifyNoEnglishData(statusRepository);
    }

    @Test
    public void getLanguageCodesLanguageFallThrough(){
        Language language = createLanguate(1);
        setupLanguagueFallThrough(languageCodeRepository, language);
        List<Language> languages = service.getLanguages("bob");
        assertOptionsList(languages);
    }

    private Language createLanguate(int id) {
        Language language = new Language();
        language.setId(id);
        return language;
    }

    @Test
    public void getLanguageCodesNoEnglishData(){
        setupNoEnglishData(languageCodeRepository);
        service.getLanguages("en");
        verify(languageCodeRepository,times(1)).getOptions(0);
    }

    @Test
    public void getOptionsPopulatesFromAllRepos(){
        when(languageCodeRepository.getLangIdFromLocale("en")).thenReturn(0);
        when(sourceRepository.getOptions(0)).thenReturn(Arrays.asList(createSource(1)));
        when(ageCategoryRepository.getOptions(0)).thenReturn(Arrays.asList(createAgeCategory(2)));
        when(statusRepository.getOptions(0)).thenReturn(Arrays.asList(createStatus(3)));
        when(languageCodeRepository.getOptions(0)).thenReturn(Arrays.asList(createLanguate(4)));
        when(contactTypeRepository.getOptions(0)).thenReturn(Arrays.asList(createContactType(5)));

        Options options = service.getOptions("en");
        assertEquals(1, options.getSources().get(0).getId());
        assertEquals(2, options.getAgeCategories().get(0).getId());
        assertEquals(3, options.getStatuses().get(0).getId());
        assertEquals(4, options.getLanguages().get(0).getId());
        assertEquals(5, options.getContactTypes().get(0).getId());
    }

    private void assertOptionsList(List<? extends Option> options) {
        assertTrue(options.size() == 1);
        assertEquals(1, options.get(0).getId());
    }


    private void verifyLanguageFallThrough(OptionsRepository repo) {
        verify(repo, times(1)).getOptions(34);
        verify(repo, times(1)).getOptions(0);
        verifyNoMoreInteractions(repo);
    }

    private void setupLanguagueFallThrough(OptionsRepository repo, Option payload) {
        when(repo.getOptions(34)).thenReturn(null);
        when(repo.getOptions(0)).thenReturn(Arrays.asList(payload));
        when(languageCodeRepository.getLangIdFromLocale("bob")).thenReturn(34);
    }

    private void verifyNoEnglishData(OptionsRepository repo) {
        verify(repo,times(1)).getOptions(0);
        verifyNoMoreInteractions(repo);
    }

    private void setupNoEnglishData(OptionsRepository repo) {
        when(repo.getOptions(0)).thenReturn(null);
        when(languageCodeRepository.getLangIdFromLocale("en")).thenReturn(0);
    }


    private Source createSource(int sourceId) {
        Source source = new Source();
        source.setId(sourceId);
        return source;
    }

    private AgeCategory createAgeCategory(int id){
        AgeCategory category = new AgeCategory();
        category.setId(id);
        return category;
    }
}
