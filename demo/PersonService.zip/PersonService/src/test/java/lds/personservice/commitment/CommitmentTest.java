package lds.personservice.commitment;


import org.junit.Before;
import org.junit.Test;

import java.util.Calendar;
import java.util.TimeZone;

import static org.junit.Assert.*;

public class CommitmentTest {

    private Commitment commitment;

    @Before
    public void setup(){
        commitment = new Commitment();
    }

    @Test
    public void configureModDateSetsModDateToBoiseTime(){
        TimeZone boiseTz = TimeZone.getTimeZone("America/Boise");
        Calendar boiseC = Calendar.getInstance(boiseTz);

        TimeZone newYorkTz = TimeZone.getTimeZone("America/NewYork");
        Calendar newYorkC = Calendar.getInstance(newYorkTz);

        commitment.configureModDate();
        Long modDate = commitment.getModifiedDate();
        Calendar calendar = Calendar.getInstance(boiseTz);
        calendar.setTimeInMillis(modDate);
        assertEquals(boiseC.get(Calendar.HOUR), calendar.get(Calendar.HOUR));
        assertNotEquals(newYorkC.get(Calendar.HOUR), calendar.get(Calendar.HOUR));
    }
}
