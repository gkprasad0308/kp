package lds.personservice.household.search;

import lds.personservice.household.ListParams;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class HouseholdSearchFactoryTest {

    @InjectMocks
    private HouseholdSearchFactory factory;

    @Test
    public void getSearchReturnsParamsSearchInstanceifNoAssignmentArea(){
        ListParams params = new ListParams();
        params.setAssignmentArea(null);
        BaseSearch search = factory.getSearch(params);
        assertTrue(search instanceof ParamsSearch);
    }

    @Test
    public void getSearchReturnsParamsSearchInstanceifAssignmentAreaZero(){
        ListParams params = new ListParams();
        params.setAssignmentArea(0L);
        BaseSearch search = factory.getSearch(params);
        assertTrue(search instanceof ParamsSearch);
    }

    @Test
    public void getSearchReturnsParamsSearchInstanceifAssignmentAreaNegative(){
        ListParams params = new ListParams();
        params.setAssignmentArea(-1L);
        BaseSearch search = factory.getSearch(params);
        assertTrue(search instanceof ParamsSearch);
    }

    @Test
    public void getSearchReturnsAssignmentSearchInstanceIfAssignmentHasPositiveValue(){
        ListParams params = new ListParams();
        params.setAssignmentArea(1L);
        BaseSearch search = factory.getSearch(params);
        assertTrue(search instanceof AssignmentSearch);
    }
}
