package lds.personservice.household;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.StringUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class HouseholdRowMapperTest {

    @Mock
    private ResultSet resultSet;
    private HouseholdRowMapper rowMapper;

    @Before
    public void setup(){
        rowMapper = new HouseholdRowMapper();
    }

    @Test
    public void mapRowSetsMissionaryIdIfProvided() throws SQLException {
        setupObjectLongInteraction(HouseholdRowMapper.MSNY_ID);

        Household household = rowMapper.mapRow(resultSet, 1);
        assertEquals(new Long(1L), household.getMissionaryId());
        verifyObjectLongInteraction(HouseholdRowMapper.MSNY_ID);
    }

    @Test
    public void mapRowIgnoresMissionaryIdIfObjectIsNull() throws SQLException {
        when(resultSet.getObject(HouseholdRowMapper.MSNY_ID)).thenReturn(null);
        Household household = rowMapper.mapRow(resultSet, 1);
        assertNull(household.getMissionaryId());
    }

    @Test
    public void mapRowMapsOrgIdIfNotNull() throws SQLException {
        setupObjectLongInteraction(HouseholdRowMapper.ORG_ID);
        assertEquals(new Long(1L), rowMapper.mapRow(resultSet, 1).getOrgId());
        verifyObjectLongInteraction(HouseholdRowMapper.ORG_ID);
    }

    @Test
    public void mapRowIgnoresOrgIdIfNull() throws SQLException{
        when(resultSet.getObject(HouseholdRowMapper.ORG_ID)).thenReturn(null);
        assertNull(rowMapper.mapRow(resultSet, 1).getOrgId());
    }

    @Test
    public void mapRowMapsStewardCmisIfNotNull() throws SQLException {
        setupObjectLongInteraction(HouseholdRowMapper.STWRD_CMIS_ID);
        assertEquals(new Long(1L), rowMapper.mapRow(resultSet, 1).getStewardCmisId());
        verifyObjectLongInteraction(HouseholdRowMapper.STWRD_CMIS_ID);
    }

    @Test
    public void mapRowIngoresStewardCmiswIfNull() throws SQLException{
        when(resultSet.getObject(HouseholdRowMapper.STWRD_CMIS_ID)).thenReturn(null);
        assertNull(rowMapper.mapRow(resultSet, 1).getStewardCmisId());
    }

    @Test
    public void mapRowAppliesPinDropIfNotNull() throws SQLException {
        when(resultSet.getObject(HouseholdRowMapper.PIN_DROP_YN)).thenReturn("Y");
        when(resultSet.getString(HouseholdRowMapper.PIN_DROP_YN)).thenReturn("Y");
        assertTrue(rowMapper.mapRow(resultSet, 1).getPinDropped());
    }

    @Test
    public void mapRowReturnsExpectedHousehold() throws SQLException {
        Timestamp cDate = new Timestamp(System.currentTimeMillis());
        Timestamp mDate = new Timestamp(System.currentTimeMillis());
        when(resultSet.getLong(HouseholdRowMapper.HSHLD_ID)).thenReturn(1L);
        when(resultSet.getString(HouseholdRowMapper.GUID)).thenReturn("abc");
        when(resultSet.getString(HouseholdRowMapper.ADDR)).thenReturn("123 street");
        when(resultSet.getString(HouseholdRowMapper.LAT)).thenReturn("67.0");
        when(resultSet.getString(HouseholdRowMapper.LNG)).thenReturn("34.2");
        when(resultSet.getString(HouseholdRowMapper.DEL_YN)).thenReturn("Y");
        when(resultSet.getTimestamp(HouseholdRowMapper.CRT_DT)).thenReturn(cDate);
        when(resultSet.getTimestamp(HouseholdRowMapper.MOD_DT)).thenReturn(mDate);

        Household household = rowMapper.mapRow(resultSet, 1);

        assertEquals(new Long(1L), household.getServerId());
        assertEquals("abc", household.getGuid());
        assertEquals("123 street", household.getAddress());
        assertEquals("67.0", household.getLat());
        assertEquals("34.2", household.getLng());
        assertTrue(household.isDeleted());
        assertEquals(cDate, household.getCreateDate());
        assertEquals(mDate, household.getModDate());
    }

    private void verifyObjectLongInteraction(String column) throws SQLException {
        verify(resultSet, times(1)).getObject(column);
        verify(resultSet, times(1)).getLong(column);
    }

    private void setupObjectLongInteraction(String column) throws SQLException {
        when(resultSet.getObject(column)).thenReturn(new Long(1L));
        when(resultSet.getLong(column)).thenReturn(1L);
    }

    @Test
    public void getSelectStatmentReturnsExpectedString(){
        String select = HouseholdRowMapper.getSelectStatement("h");
        assertThat(select, containsString(getSelectPart(HouseholdRowMapper.HSHLD_ID, null)));
        assertThat(select, containsString(getSelectPart("client_guid", HouseholdRowMapper.GUID)));
        assertThat(select, containsString(getSelectPart("addr", HouseholdRowMapper.ADDR)));
        assertThat(select, containsString(getSelectPart("msny_id", HouseholdRowMapper.MSNY_ID)));
        assertThat(select, containsString(getSelectPart("org_id", HouseholdRowMapper.ORG_ID)));
        assertThat(select, containsString(getSelectPart("stwrd_cmis_id", HouseholdRowMapper.STWRD_CMIS_ID)));
        assertThat(select, containsString(getSelectPart("lat", HouseholdRowMapper.LAT)));
        assertThat(select, containsString(getSelectPart("lng", HouseholdRowMapper.LNG)));
        assertThat(select, containsString(getSelectPart("del_yn", HouseholdRowMapper.DEL_YN)));
        assertThat(select, containsString(getSelectPart("pin_drop_yn", HouseholdRowMapper.PIN_DROP_YN)));
        assertThat(select, containsString(getSelectPart("crt_dt", HouseholdRowMapper.CRT_DT)));
        assertThat(select, containsString(getSelectPart("mod_dt", HouseholdRowMapper.MOD_DT)));
        assertThat(select, not(endsWith(",")));
    }

    @Test
    public void getSelectStatmentWithPeriodAfterPrefixReturnsExpectedString(){
        String select = HouseholdRowMapper.getSelectStatement("h.");
        assertThat(select, containsString(getSelectPart(HouseholdRowMapper.HSHLD_ID, null)));
        assertThat(select, containsString(getSelectPart("client_guid", HouseholdRowMapper.GUID)));
        assertThat(select, containsString(getSelectPart("addr", HouseholdRowMapper.ADDR)));
        assertThat(select, containsString(getSelectPart("msny_id", HouseholdRowMapper.MSNY_ID)));
        assertThat(select, containsString(getSelectPart("org_id", HouseholdRowMapper.ORG_ID)));
        assertThat(select, containsString(getSelectPart("stwrd_cmis_id", HouseholdRowMapper.STWRD_CMIS_ID)));
        assertThat(select, containsString(getSelectPart("lat", HouseholdRowMapper.LAT)));
        assertThat(select, containsString(getSelectPart("lng", HouseholdRowMapper.LNG)));
        assertThat(select, containsString(getSelectPart("del_yn", HouseholdRowMapper.DEL_YN)));
        assertThat(select, containsString(getSelectPart("pin_drop_yn", HouseholdRowMapper.PIN_DROP_YN)));
        assertThat(select, containsString(getSelectPart("crt_dt", HouseholdRowMapper.CRT_DT)));
        assertThat(select, containsString(getSelectPart("mod_dt", HouseholdRowMapper.MOD_DT)));
        assertThat(select, not(endsWith(",")));
    }

    private String getSelectPart(String originalColumn, String alias) {
        return "h." + originalColumn + (StringUtils.isEmpty(alias) ? "" : " AS " + alias);
    }
}
