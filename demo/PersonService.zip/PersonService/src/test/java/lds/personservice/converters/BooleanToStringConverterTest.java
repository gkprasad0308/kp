package lds.personservice.converters;


import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


public class BooleanToStringConverterTest {

    private BooleanToStringConverter converter;

    @Before
    public void setup(){
        converter = new BooleanToStringConverter();
    }

    @Test
    public void convertToDatabaseColumnIsNForNull(){
        assertEquals("N", converter.convertToDatabaseColumn(null));
    }

    @Test
    public void convertToDatabaseColumnIsNForFalse(){
        assertEquals("N", converter.convertToDatabaseColumn(false));
    }

    @Test
    public void convertToDatabaseColumnIsYForTrue(){
        assertEquals("Y", converter.convertToDatabaseColumn(true));
    }

    @Test
    public void convertToEntityAtributeIsFalseForNull(){
        assertFalse(converter.convertToEntityAttribute(null));
    }

    @Test
    public void convertToEntityAttributeIsFalseForEmpty(){
        assertFalse(converter.convertToEntityAttribute(""));
    }

    @Test
    public void convertToEntityAttributeIsFalseForN(){
        assertFalse(converter.convertToEntityAttribute("N"));
    }

    @Test
    public void convertToEntityAttributeIsTrueForY(){
        assertTrue(converter.convertToEntityAttribute("Y"));
    }

    @Test
    public void convertToEnttityAttributeIsCaseSensitive(){
        assertFalse(converter.convertToEntityAttribute("y"));
    }
}
