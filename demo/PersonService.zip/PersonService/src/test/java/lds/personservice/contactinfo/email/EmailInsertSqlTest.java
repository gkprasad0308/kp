package lds.personservice.contactinfo.email;


import lds.personservice.AbstractUpdateSqlTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class EmailInsertSqlTest extends AbstractUpdateSqlTest {

    @InjectMocks
    private EmailInsertSql insertSql;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            EmailInsertSql.COMM_TYPE_ID,
            EmailInsertSql.EMAIL_ADDR,
            EmailInsertSql.PERSON_ID
    );

    @Override
    protected SqlUpdate getInstance() {
        return insertSql;
    }

    @Override
    protected List<String> getExpectedParams() {
        return expectedParams;
    }

    @Test
    public void getParamsUsingDoesExpected(){
        Email email = mock(Email.class);
        when(email.getType()).thenReturn(EmailTypes.EMAIL_HOME);
        when(email.getAddress()).thenReturn("test@test");

        Map<String, Object> results = insertSql.getParamsUsing(email, 123L);
        checkKeys(results);

        assertEquals(123L, results.get(EmailInsertSql.PERSON_ID));
        assertEquals(EmailTypes.EMAIL_HOME.id(), results.get(EmailInsertSql.COMM_TYPE_ID));
        assertEquals("test@test", results.get(EmailInsertSql.EMAIL_ADDR));

        verify(email, times(1)).getType();
        verify(email, times(1)).getAddress();
    }
}
