package lds.personservice.household;

import java.util.List;

public class ListParamsOrgIdsTest extends AbstractListParamsTest {

    @Override
    protected void callParser(String value) {
        listParams.parseOrgIds(value);
    }

    @Override
    protected List<Long> getValues() {
        return listParams.getOrgIds();
    }

    @Override
    protected String getFieldName() {
        return "orgIds";
    }
}
