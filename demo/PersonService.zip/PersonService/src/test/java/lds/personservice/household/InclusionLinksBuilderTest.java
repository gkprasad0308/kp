package lds.personservice.household;


import lds.stack.spring.web.Link;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class InclusionLinksBuilderTest {

    @Test
    public void withRequestUrlAddsQuestionMarkOnEndIfNeeded(){
        InclusionLinksBuilder builder = new InclusionLinksBuilder().withRequestUrl("bob");
        assertEquals("bob?", ReflectionTestUtils.getField(builder, "requestUrl"));
    }

    @Test
    public void withRequestUrlAddsAmpersandMarkOnEndIfNeeded(){
        InclusionLinksBuilder builder = new InclusionLinksBuilder().withRequestUrl("bob?ted");
        assertEquals("bob?ted&", ReflectionTestUtils.getField(builder, "requestUrl"));
    }

    @Test
    public void withRequestUrlParsesCurrentIncludeSegment(){
        InclusionLinksBuilder builder = new InclusionLinksBuilder().withRequestUrl("bob?include=fred");
        assertEquals("bob?", ReflectionTestUtils.getField(builder, "requestUrl"));
        assertEquals("include=fred", ReflectionTestUtils.getField(builder, "incSegment"));
    }

    @Test
    public void generateReturnsEmptyListWithoutParams(){
        List<Link> links =  new InclusionLinksBuilder()
                .withRequestUrl("bob").generate();
        assertThat(links, is(empty()));
    }

    @Test
     public void generateReturnsExpectedWithNoOtherIncludes(){
        List<Link> links =  new InclusionLinksBuilder()
                .withRequestUrl("bob").withInclusionParams(Arrays.asList(InclusionParams.DROP_NOTES)).generate();
        assertTrue(links.size() == 1);
        Link link = links.get(0);
        assertEquals("bob?include=" + InclusionParams.DROP_NOTES.name().toLowerCase(), link.getHref());
    }

    @Test
    public void generateReturnsExpectedAppendingOtherIncludes(){
        List<Link> links =  new InclusionLinksBuilder()
                .withRequestUrl("bob?include=ted").withInclusionParams(Arrays.asList(InclusionParams.DROP_NOTES)).generate();
        assertTrue(links.size() == 1);
        Link link = links.get(0);
        assertEquals("bob?include=ted," + InclusionParams.DROP_NOTES.name().toLowerCase(), link.getHref());
    }
}
