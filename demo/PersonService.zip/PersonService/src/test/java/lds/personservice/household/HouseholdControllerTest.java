package lds.personservice.household;

import lds.personservice.AssignmentService;
import lds.personservice.ResourceWrapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletRequest;

import java.util.Arrays;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class HouseholdControllerTest {

    @InjectMocks
    private HouseholdController controller;

    @Mock
    private HouseholdService householdService;

    @Mock
    private AssignmentService assignmentService;

    private HttpServletRequest request;

    @Before
    public void setup(){
        request = mock(HttpServletRequest.class);
    }

    @Test
    public void getHouseholdsReturnsEmptyListIfNoParams(){
        when(request.getRequestURI()).thenReturn("bob");
        ResourceWrapper<HouseholdListWrapper> wrapper = new ResourceWrapper<>(controller.getHouseholds(null, null, null, null, null, null, null, false, request));
        assertTrue(CollectionUtils.isEmpty(wrapper.getInstance().getHouseholds()));
        assertTrue(wrapper.getLinks().size() == InclusionParams.values().length);
        verifyZeroInteractions(householdService);
    }

    @Test
    public void getHouseholdsCallsExpected(){
        Household household = new Household();

        HouseholdListWrapper householdListWrapper = new HouseholdListWrapper();
        householdListWrapper.setHouseholds(Arrays.asList(household));

        when(request.getRequestURI()).thenReturn("bob");
        when(householdService.searchHouseholds(any(ListParams.class))).thenReturn(householdListWrapper);
        ResourceWrapper<HouseholdListWrapper> wrapper = new ResourceWrapper<>(controller.getHouseholds("123", null, null, null, null, null, System.currentTimeMillis(), false, request));
        assertThat(wrapper.getInstance().getHouseholds(), hasItem(household));
        assertTrue(wrapper.getLinks().size() == InclusionParams.values().length);
        verify(householdService, times(1)).searchHouseholds(any(ListParams.class));
    }

    @Test
    public void createNewHouseholdCallsExpected(){
        Household household = new Household();
        when(householdService.createNewHousehold(household)).thenReturn(household);
        Household result = controller.createNewHousehold(household);
        assertEquals(result, household);
        verify(householdService, times(1)).createNewHousehold(household);
        verifyNoMoreInteractions(householdService);
    }

    @Test
    public void getHouseholdByIdCallsExpected(){
        Household household = new Household();
        when(householdService.getHousehold("abc")).thenReturn(household);
        Household result = controller.getHouseholdById("abc");
        assertEquals(result, household);
        verify(householdService, times(1)).getHousehold("abc");
        verifyNoMoreInteractions(householdService);
    }

    @Test
    public void updateHouseholdCallsExpected(){
        Household household = new Household();
        when(householdService.getHousehold("abc")).thenReturn(household);
        when(assignmentService.handleHouseholdAssignment(household, "abc")).thenReturn(household);
        Household result = controller.updateHousehold(household, "abc");
        assertEquals(result, household);
        verify(householdService, times(1)).updateHousehold(household, "abc");
        verify(householdService, times(1)).getHousehold("abc");
        verifyNoMoreInteractions(householdService);
    }

    @Test
    public void deleteHouseholdCallsExpected(){
        controller.deleteHousehold("abc");
        verify(householdService, times(1)).deleteHousehold("abc");
        verifyNoMoreInteractions(householdService);
    }
}
