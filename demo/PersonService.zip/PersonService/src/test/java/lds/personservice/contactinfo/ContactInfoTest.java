package lds.personservice.contactinfo;

import lds.personservice.contactinfo.email.EmailTypes;
import lds.personservice.contactinfo.phone.PhoneTypes;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ContactInfoTest {

    @Test
    public void extractUniqueTypesReturnsExtractorIfNull(){
        ContactInfo contactInfo = new ContactInfo();
        contactInfo.addPhone(PhoneTypes.PHN_HOME, "231");
        contactInfo.addEmail(EmailTypes.EMAIL_FAMILY, "test@test");

        ContactInfo delta = contactInfo.extractUniqueTypes(null);
        assertEquals(delta, contactInfo);

        assertTrue(delta.getEmailAddresses().size() == 1);
        assertEquals(delta.getEmailAddresses().get(0).getAddress(), "test@test");
        assertEquals(delta.getEmailAddresses().get(0).getType(), EmailTypes.EMAIL_FAMILY);

        assertTrue(delta.getPhoneNumbers().size() == 1);
        assertEquals(delta.getPhoneNumbers().get(0).getType(), PhoneTypes.PHN_HOME);
        assertEquals("231", delta.getPhoneNumbers().get(0).getNumber());
    }

    @Test
    public void extractUniqueTypesReturnsTypesNotInOther(){
        ContactInfo base = new ContactInfo();
        base.addEmail(EmailTypes.EMAIL_FAMILY, "test@test");
        base.addEmail(EmailTypes.EMAIL_HOME, "home@home");
        base.addPhone(PhoneTypes.PHN_HOME, "123");
        base.addPhone(PhoneTypes.PHN_MOBILE, "mobile");

        ContactInfo diff = new ContactInfo();
        diff.addEmail(EmailTypes.EMAIL_HOME, "home");
        diff.addPhone(PhoneTypes.PHN_HOME, "423");

        ContactInfo delta = base.extractUniqueTypes(diff);

        assertTrue(delta.getEmailAddresses().size() == 1);
        assertEquals(EmailTypes.EMAIL_FAMILY, delta.getEmailAddresses().get(0).getType());
        assertEquals("test@test", delta.getEmailAddresses().get(0).getAddress());

        assertTrue(delta.getPhoneNumbers().size() == 1);
        assertEquals(PhoneTypes.PHN_MOBILE, delta.getPhoneNumbers().get(0).getType());
        assertEquals("mobile", delta.getPhoneNumbers().get(0).getNumber());
    }

    @Test
    public void extractUniqueTypesReturnsEmptyContactInfoIfNoDeltas(){
        ContactInfo base = new ContactInfo();
        base.addEmail(EmailTypes.EMAIL_HOME, "home@home");
        base.addPhone(PhoneTypes.PHN_HOME, "123");

        ContactInfo diff = new ContactInfo();
        diff.addEmail(EmailTypes.EMAIL_HOME, "home");
        diff.addPhone(PhoneTypes.PHN_HOME, "423");

        ContactInfo delta = base.extractUniqueTypes(diff);

        assertTrue(delta.getEmailAddresses().size() == 0);
        assertTrue(delta.getPhoneNumbers().size() == 0);
    }

    @Test
    public void extractUniqueTypesReturnsAllPhonesIfNoDelta(){
        ContactInfo base = new ContactInfo();
        base.addEmail(EmailTypes.EMAIL_HOME, "home@home");
        base.addPhone(PhoneTypes.PHN_HOME, "123");

        ContactInfo diff = new ContactInfo();
        diff.addEmail(EmailTypes.EMAIL_HOME, "home");

        ContactInfo delta = base.extractUniqueTypes(diff);

        assertTrue(delta.getEmailAddresses().size() == 0);
        assertTrue(delta.getPhoneNumbers().size() == 1);
        assertEquals(PhoneTypes.PHN_HOME, delta.getPhoneNumbers().get(0).getType());
        assertEquals("123", delta.getPhoneNumbers().get(0).getNumber());
    }

    @Test
    public void extractUniqueTypesReturnsNothingIfThisHasNoTypes(){
        ContactInfo diff = new ContactInfo();
        diff.addEmail(EmailTypes.EMAIL_HOME, "home");
        diff.addPhone(PhoneTypes.PHN_HOME, "423");

        ContactInfo delta = new ContactInfo().extractUniqueTypes(diff);

        assertTrue(delta.getEmailAddresses().size() == 0);
        assertTrue(delta.getPhoneNumbers().size() == 0);
    }

    @Test
    public void extractUniqueTypesReturnsAllEmailsIfNoDelta(){
        ContactInfo base = new ContactInfo();
        base.addEmail(EmailTypes.EMAIL_FAMILY, "test@test");
        base.addPhone(PhoneTypes.PHN_HOME, "123");

        ContactInfo diff = new ContactInfo();
        diff.addPhone(PhoneTypes.PHN_HOME, "423");

        ContactInfo delta = base.extractUniqueTypes(diff);

        assertTrue(delta.getEmailAddresses().size() == 1);
        assertEquals(EmailTypes.EMAIL_FAMILY, delta.getEmailAddresses().get(0).getType());
        assertEquals("test@test", delta.getEmailAddresses().get(0).getAddress());
        assertTrue(delta.getPhoneNumbers().size() == 0);
    }

    @Test
    public void extractDuplicatedTypesReturnsEmptyIfOtherNull(){
        ContactInfo base = new ContactInfo();
        base.addEmail(EmailTypes.EMAIL_FAMILY, "test@test");
        base.addPhone(PhoneTypes.PHN_HOME, "123");

        ContactInfo duplicates = base.extractDuplicatedTypes(null);
        assertTrue(duplicates.getEmailAddresses().size() == 0);
        assertTrue(duplicates.getPhoneNumbers().size() == 0);
    }

    @Test
    public void extractDuplicatedTypesReturnsEmptyIfOtherEmpty(){
        ContactInfo base = new ContactInfo();
        base.addEmail(EmailTypes.EMAIL_FAMILY, "test@test");
        base.addPhone(PhoneTypes.PHN_HOME, "123");

        ContactInfo duplicates = base.extractDuplicatedTypes(new ContactInfo());
        assertTrue(duplicates.getEmailAddresses().size() == 0);
        assertTrue(duplicates.getPhoneNumbers().size() == 0);
    }

    @Test
    public void extractDuplicatedTypesReturnsEmptyIfThisEmpty(){
        ContactInfo diff = new ContactInfo();
        diff.addEmail(EmailTypes.EMAIL_FAMILY, "test@test");
        diff.addPhone(PhoneTypes.PHN_HOME, "123");

        ContactInfo duplicates = new ContactInfo().extractDuplicatedTypes(diff);
        assertTrue(duplicates.getEmailAddresses().size() == 0);
        assertTrue(duplicates.getPhoneNumbers().size() == 0);
    }

    @Test
    public void extractDuplicatedTypesResturnsEmptyIfBothEmpty(){
        ContactInfo duplicates = new ContactInfo().extractDuplicatedTypes(new ContactInfo());
        assertTrue(duplicates.getEmailAddresses().size() == 0);
        assertTrue(duplicates.getPhoneNumbers().size() == 0);
    }

    @Test
    public void extractDuplicatedTypesReturnsDuplicatedTypes(){
        ContactInfo base = new ContactInfo();
        base.addEmail(EmailTypes.EMAIL_HOME, "home@home");
        base.addEmail(EmailTypes.EMAIL_OTHER, "bob");
        base.addPhone(PhoneTypes.PHN_HOME, "123");

        ContactInfo diff = new ContactInfo();
        diff.addEmail(EmailTypes.EMAIL_HOME, "home");
        diff.addPhone(PhoneTypes.PHN_HOME, "423");
        diff.addPhone(PhoneTypes.PHN_MOBILE, "bob");

        ContactInfo duplicates = base.extractDuplicatedTypes(diff);

        assertTrue(duplicates.getEmailAddresses().size() == 1);
        assertEquals(EmailTypes.EMAIL_HOME, duplicates.getEmailAddresses().get(0).getType());
        assertEquals("home@home", duplicates.getEmailAddresses().get(0).getAddress());
        assertTrue(duplicates.getPhoneNumbers().size() == 1);
        assertEquals(PhoneTypes.PHN_HOME, duplicates.getPhoneNumbers().get(0).getType());
        assertEquals("123", duplicates.getPhoneNumbers().get(0).getNumber());
    }
}
