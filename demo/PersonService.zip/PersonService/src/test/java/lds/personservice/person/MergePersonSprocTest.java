package lds.personservice.person;

import lds.personservice.AbstractSimpleSprocTest;
import lds.personservice.util.SimpleSproc;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class MergePersonSprocTest extends AbstractSimpleSprocTest {

    @InjectMocks
    private MergePersonSproc sproc;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            MergePersonSproc.FROM_PERSON_ID,
            MergePersonSproc.TO_PERSON_ID
    );

    @Override
    protected String getSchema() {
        return MergePersonSproc.SCHEMA_NAME;
    }

    @Override
    protected String getCataglog() {
        return MergePersonSproc.CATALOG_NAME;
    }

    @Override
    protected String getFunction() {
        return MergePersonSproc.PROCEDURE_NAME;
    }

    @Override
    protected SimpleSproc getInstance() {
        return sproc;
    }

    @Override
    protected List<String> getExpectedParameters() {
        return expectedParams;
    }

    @Test
    public void getParametersUsingDoesExpected(){
        MapSqlParameterSource params = sproc.getParametersUsing(123L, 456L);
        checkKeys(params.getValues());

        assertEquals(123L, params.getValue(MergePersonSproc.FROM_PERSON_ID));
        assertEquals(456L, params.getValue(MergePersonSproc.TO_PERSON_ID));
    }
}
