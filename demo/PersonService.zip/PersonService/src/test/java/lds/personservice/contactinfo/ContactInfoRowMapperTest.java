package lds.personservice.contactinfo;

import lds.personservice.contactinfo.email.Email;
import lds.personservice.contactinfo.email.EmailTypes;
import lds.personservice.contactinfo.phone.Phone;
import lds.personservice.contactinfo.phone.PhoneTypes;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContactInfoRowMapperTest {

    @Mock
    private ResultSet resultSet;

    private ContactInfoRowMapper contactInfoRowMapper;

    @Before
    public void setup(){
        contactInfoRowMapper = new ContactInfoRowMapper();
    }

    @Test
    public void mapRowReturnsNullIfNothingWasMapped() throws SQLException {
        ContactInfo info = contactInfoRowMapper.mapRow(resultSet, 1);
        assertNull(info);
    }

    @Test
    public void mapRowReturnsExpectedValues() throws SQLException{
        when(resultSet.getString(PhoneTypes.PHN_HOME.name())).thenReturn("1234");
        when(resultSet.getString(EmailTypes.EMAIL_FAMILY.name())).thenReturn("email@family");

        ContactInfo info = contactInfoRowMapper.mapRow(resultSet, 1);
        assertNotNull(info);
        assertTrue(info.getPhoneNumbers().size() == 1);
        assertThat(info.getPhoneNumbers(), contains(new Phone(PhoneTypes.PHN_HOME, "1234")));

        assertTrue(info.getEmailAddresses().size() == 1);
        assertThat(info.getEmailAddresses(), contains(new Email(EmailTypes.EMAIL_FAMILY, "email@family")));
    }

    @Test
    public void getSelectStatementContainsAllPhonesAndEmailsAsExpected(){
        String select = ContactInfoRowMapper.getSelectStatement();
        for(PhoneTypes type : PhoneTypes.values()) {
            assertThat(select, containsString(getPhoneSelectFragment(type)));
        }
        for(EmailTypes type: EmailTypes.values()){
            assertThat(select, containsString(getEmailSelectFragment(type)));
        }
        assertThat(select, not(endsWith(",")));
    }

    private String getPhoneSelectFragment(PhoneTypes type){
        return type.name() + ".phn_nbr AS " + type.name();
    }

    private String getEmailSelectFragment(EmailTypes type){
        return type.name() + ".email_addr AS " + type.name();
    }

    @Test
    public void getJoinStatementContainsExpectedJoins(){
        String join = ContactInfoRowMapper.getJoinStatement("p");
        for(PhoneTypes type: PhoneTypes.values()){
            assertThat(join, containsString(getPhoneJoin(type)));
            assertThat(join, containsString(getPhoneJoinOn(type)));
            assertThat(join, containsString(getPhoneComType(type)));
        }for(EmailTypes type: EmailTypes.values()){
            assertThat(join, containsString(getEmailJoin(type)));
            assertThat(join, containsString(getEmailJoinOn(type)));
            assertThat(join, containsString(getEmailComType(type)));
        }
    }

    private String getPhoneComType(PhoneTypes type) {
        return "AND " + type.name() + ".comm_t_id = " + type.id();
    }

    private String getPhoneJoinOn(PhoneTypes type) {
        return "ON " + type.name() + ".person_id = " + "p.person_id";
    }

    private String getPhoneJoin(PhoneTypes type) {
        return "LEFT JOIN ims.person_phn " + type.name();
    }

    private String getEmailComType(EmailTypes type) {
        return "AND " + type.name() + ".comm_t_id = " + type.id();
    }

    private String getEmailJoinOn(EmailTypes type) {
        return "ON " + type.name() + ".person_id = " + "p.person_id";
    }

    private String getEmailJoin(EmailTypes type) {
        return "LEFT JOIN ims.person_email " + type.name();
    }
}
