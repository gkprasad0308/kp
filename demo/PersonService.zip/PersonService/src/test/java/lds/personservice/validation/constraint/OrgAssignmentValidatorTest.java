package lds.personservice.validation.constraint;

import lds.personservice.household.Household;
import lds.personservice.missionorg.MissionOrgService;
import lds.personservice.missionorg.Parentage;
import lds.personservice.missionorg.ParentageWrapper;
import lds.personservice.person.Person;
import lds.personservice.util.validation.constraint.OrgAssignmentValidator;
import lds.personservice.util.validation.service.HouseholdValidationService;
import lds.prsms.utils.errors.ServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class OrgAssignmentValidatorTest {

    @InjectMocks
    private OrgAssignmentValidator validator;

    @Mock
    private HouseholdValidationService householdService;

    @Mock
    private MissionOrgService missionOrgService;

    @Test
    public void isValidIsTrueIfOrgIsNull(){
        assertTrue(validator.isValid(new Household(), null));
    }

    @Test
    public void isValidIsTrueIfNoProsAreas(){
        when(householdService.getOriginal("abc")).thenReturn(new Household());
        Household household = new Household();
        household.setGuid("abc");
        household.setOrgId(123L);

        assertTrue(validator.isValid(household, null));
        verifyZeroInteractions(missionOrgService);
        verify(householdService, times(1)).getOriginal("abc");
    }

    @Test
    public void isValidHandlesNewHousehold(){
        Person person = new Person();
        person.setProsAreaId(123L);

        Household household = new Household();
        household.setGuid("abc");
        household.setOrgId(456L);
        household.addPerson(person);

        ParentageWrapper wrapper = new ParentageWrapper();
        wrapper.setParentage(Arrays.asList(createParentageWithParents(456L, "organization", "pros_area", 1L, 2L, 123L)));
        when(householdService.getOriginal("abc")).thenReturn(null);
        when(missionOrgService.getAreasForOrg(456L)).thenReturn(wrapper);

        assertTrue(validator.isValid(household, null));
        verify(householdService, times(1)).getOriginal("abc");
        verify(missionOrgService, times(1)).getAreasForOrg(456L);
        verifyNoMoreInteractions(householdService, missionOrgService);
    }

    @Test
    public void isValidHandlesNoParentsReturned(){
        Person person = new Person();
        person.setProsAreaId(123L);

        Household household = new Household();
        household.setGuid("abc");
        household.setOrgId(456L);
        household.addPerson(person);

        when(householdService.getOriginal("abc")).thenReturn(null);
        when(missionOrgService.getAreasForOrg(456L)).thenReturn(null);

        assertFalse(validator.isValid(household, null));
        verify(householdService, times(1)).getOriginal("abc");
        verify(missionOrgService, times(1)).getAreasForOrg(456L);
        verifyNoMoreInteractions(householdService, missionOrgService);
    }

    @Test
    public void isValidHandlesNoMatches(){
        Person person = new Person();
        person.setProsAreaId(123L);

        Household household = new Household();
        household.setGuid("abc");
        household.setOrgId(456L);
        household.addPerson(person);

        ParentageWrapper wrapper = new ParentageWrapper();
        wrapper.setParentage(Arrays.asList(createParentageWithParents(456L, "organization", "pros_area", 1L, 2L)));
        when(householdService.getOriginal("abc")).thenReturn(null);
        when(missionOrgService.getAreasForOrg(456L)).thenReturn(null);

        assertFalse(validator.isValid(household, null));
        verify(householdService, times(1)).getOriginal("abc");
        verify(missionOrgService, times(1)).getAreasForOrg(456L);
        verifyNoMoreInteractions(householdService, missionOrgService);
    }
    @Test
    public void isValidHandlesNoParents(){
        Person person = new Person();
        person.setProsAreaId(123L);

        Household household = new Household();
        household.setGuid("abc");
        household.setOrgId(456L);
        household.addPerson(person);

        ParentageWrapper wrapper = new ParentageWrapper();
        wrapper.setParentage(Arrays.asList(createParentageWithParents(456L, "organization", null, null)));
        when(householdService.getOriginal("abc")).thenReturn(null);
        when(missionOrgService.getAreasForOrg(456L)).thenReturn(null);

        assertFalse(validator.isValid(household, null));
        verify(householdService, times(1)).getOriginal("abc");
        verify(missionOrgService, times(1)).getAreasForOrg(456L);
        verifyNoMoreInteractions(householdService, missionOrgService);
    }

    @Test
    public void isValidHandlesAreaIdOnOriginalHousehold(){
        Person person = new Person();
        person.setProsAreaId(123L);

        Household household = new Household();
        household.setGuid("abc");
        household.setOrgId(456L);
        Household original = new Household();
        original.addPerson(person);

        ParentageWrapper wrapper = new ParentageWrapper();
        wrapper.setParentage(Arrays.asList(createParentageWithParents(456L, "organization", "pros_area", 1L, 2L, 123L)));
        when(householdService.getOriginal("abc")).thenReturn(original);
        when(missionOrgService.getAreasForOrg(456L)).thenReturn(wrapper);

        assertTrue(validator.isValid(household, null));
        verify(householdService, times(1)).getOriginal("abc");
        verify(missionOrgService, times(1)).getAreasForOrg(456L);
        verifyNoMoreInteractions(householdService, missionOrgService);
    }

    @Test
    public void isValidHandlesDoubleNestingOfParents(){
        Person person = new Person();
        person.setProsAreaId(123L);

        Household household = new Household();
        household.setGuid("abc");
        household.setOrgId(456L);
        household.addPerson(person);

        ParentageWrapper wrapper = new ParentageWrapper();
        Parentage area = new Parentage();
        area.setType("pros_area");
        area.setId(123L);
        Parentage base = createParentageWithParents(456L, "organization", "organization", 1L, 2L, 3L);
        base.getParents().get(0).addParent(area);
        wrapper.setParentage(Arrays.asList(base));
        when(householdService.getOriginal("abc")).thenReturn(null);
        when(missionOrgService.getAreasForOrg(456L)).thenReturn(wrapper);

        assertTrue(validator.isValid(household, null));
        verify(householdService, times(1)).getOriginal("abc");
        verify(missionOrgService, times(1)).getAreasForOrg(456L);
        verifyNoMoreInteractions(householdService, missionOrgService);
    }

    @Test
    public void isValidHandlesServiceExceptionThrown(){
        Person person = new Person();
        person.setProsAreaId(123L);

        Household household = new Household();
        household.setGuid("abc");
        household.setOrgId(456L);
        household.addPerson(person);

        when(householdService.getOriginal("abc")).thenReturn(null);
        when(missionOrgService.getAreasForOrg(456L)).thenThrow(new ServiceException());

        assertFalse(validator.isValid(household, null));
        verify(householdService, times(1)).getOriginal("abc");
        verify(missionOrgService, times(1)).getAreasForOrg(456L);
        verifyNoMoreInteractions(householdService, missionOrgService);
    }

    private Parentage createParentageWithParents(long id, String type, String parentType, long... parentIds) {
        Parentage base = new Parentage();
        base.setId(id);
        base.setType(type);

        if(parentIds != null && parentIds.length != 0) {
            Parentage parent;
            for (long childId : parentIds) {
                parent = new Parentage();
                parent.setType(parentType);
                parent.setId(childId);
                base.addParent(parent);
            }
        }

        return base;
    }
}
