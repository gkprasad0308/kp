package lds.personservice.person.builder;

import lds.personservice.person.Person;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PeopleBuilderServiceTest {

    @InjectMocks
    private PeopleBuilderService builderService;

    @Mock
    private PeopleCommitmentBuilder commitmentBuilder;

    @Mock
    private PeopleDropNoteBuilder dropNoteBuilder;

    @Mock
    private PeopleFellowshipBuilder fellowshipBuilder;

    private List<ConcretePeopleBuilder> possibles;

    @Before
    public void setup(){
        possibles = Arrays.asList(
                commitmentBuilder,
                dropNoteBuilder,
                fellowshipBuilder
        );
    }

    @Test
    public void withParamsDoesntSetBuildersIfEmpty(){
        PeopleBuilder builder = builderService.getBuilder();
        builder.withParams(null);
        assertNull(ReflectionTestUtils.getField(builder, "params"));
        assertNull(ReflectionTestUtils.getField(builder, "builders"));
    }

    @Test
    public void withParamsCallsEachBuildersApply(){
        BuilderParams params = new BuilderParams();
        PeopleBuilder builder = builderService.getBuilder();
        possibles.forEach(possible -> when(possible.appliesToBuilder(params)).thenReturn(false));

        builder.withParams(params);
        assertEquals(params, ReflectionTestUtils.getField(builder, "params"));
        assertNull(ReflectionTestUtils.getField(builder, "builders"));
        possibles.forEach(possible -> verify(possible, times(1)).appliesToBuilder(params));
    }

    @Test
    public void withParamsAddsBuildersThatApply(){
        BuilderParams params = new BuilderParams();
        possibles.forEach(possible -> when(possible.appliesToBuilder(params)).thenReturn(false));
        when(commitmentBuilder.appliesToBuilder(params)).thenReturn(true);
        when(dropNoteBuilder.appliesToBuilder(params)).thenReturn(true);

        PeopleBuilder builder = builderService.getBuilder();
        builder.withParams(params);

        assertEquals(params, ReflectionTestUtils.getField(builder, "params"));
        List<ConcretePeopleBuilder> actuals = (List<ConcretePeopleBuilder>) ReflectionTestUtils.getField(builder, "builders");
        assertTrue(actuals.size() == 2);
        assertThat(actuals, hasItem(commitmentBuilder));
        assertThat(actuals, hasItem(dropNoteBuilder));
        possibles.forEach(possible -> verify(possible, times(1)).appliesToBuilder(params));
    }

    @Test
    public void withPeopleSetsVariableToWhatsPassed(){
        List<Person> people = Arrays.asList(new Person(), new Person());
        PeopleBuilder builder = builderService.getBuilder();
        builder.withPeople(people);
        assertEquals(people, ReflectionTestUtils.getField(builder, "people"));
    }

    @Test
    public void getResultsReturnsPeople(){
        List<Person> people = Arrays.asList(new Person(), new Person());
        PeopleBuilder builder = builderService.getBuilder();
        builder.withPeople(people);
        assertEquals(people, builder.getResults());
    }

    @Test
    public void constructDoesNothingIfNoBuilders(){
        PeopleBuilder builder = builderService.getBuilder();
        builder.construct();

        possibles.stream().forEach(possible -> verifyZeroInteractions(possible));
    }

    @Test
    public void constructCallsIncludedPossibles(){
        BuilderParams params = new BuilderParams();
        possibles.forEach(possible -> when(possible.appliesToBuilder(params)).thenReturn(false));
        when(commitmentBuilder.appliesToBuilder(params)).thenReturn(true);
        when(dropNoteBuilder.appliesToBuilder(params)).thenReturn(true);
        List<Person> people = Arrays.asList(new Person(), new Person());

        PeopleBuilder builder = builderService.getBuilder();
        builder.withParams(params).withPeople(people).construct();

        verify(fellowshipBuilder, times(0)).build(people);
        verify(commitmentBuilder, times(1)).build(people);
        verify(dropNoteBuilder, times(1)).build(people);
    }
}
