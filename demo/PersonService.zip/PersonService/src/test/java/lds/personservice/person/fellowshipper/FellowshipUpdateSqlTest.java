package lds.personservice.person.fellowshipper;

import lds.personservice.AbstractUpdateSqlTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class FellowshipUpdateSqlTest extends AbstractUpdateSqlTest {

    @InjectMocks
    private FellowshipUpdateSql updateSql;

    @Mock
    private DataSource dataSource;

    private List<String> expectedParams = Arrays.asList(
            FellowshipUpdateSql.FELLOWSHIPPER_ID,
            FellowshipUpdateSql.PERSON_ID
    );

    @Override
    protected SqlUpdate getInstance() {
        return updateSql;
    }

    @Override
    protected List<String> getExpectedParams() {
        return expectedParams;
    }

    @Test
    public void getParamsUsingReturnsExpected(){
        Map<String, Object> results = updateSql.getParamsUsing(123L, 456L);
        checkKeys(results);
        assertEquals(123L, results.get(FellowshipUpdateSql.PERSON_ID));
        assertEquals(456L, results.get(FellowshipUpdateSql.FELLOWSHIPPER_ID));
    }
}
