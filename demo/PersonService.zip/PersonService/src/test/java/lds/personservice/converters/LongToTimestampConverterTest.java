package lds.personservice.converters;


import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.Calendar;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class LongToTimestampConverterTest {

    private LongToTimestampConverter converter;

    @Before
    public void setup(){
        converter = new LongToTimestampConverter();
    }

    @Test
    public void convertToDAtabaseColumnReturnsNullForNull(){
        assertNull(converter.convertToDatabaseColumn(null));
    }

    @Test
    public void convertToDatabaseColumnReturnsExpectedTimestamp(){
        long time = Calendar.getInstance().getTime().getTime();
        assertEquals(time, converter.convertToDatabaseColumn(time).getTime());
    }

    @Test
    public void convertToEntityAttributeReturnsNullForNull(){
        assertNull(converter.convertToEntityAttribute(null));
    }

    @Test
    public void convertToEntityAttributeReturnsExpectedTime(){
        long time = System.currentTimeMillis();
        Timestamp stamp = new Timestamp(time);
        assertEquals(new Long(time), converter.convertToEntityAttribute(stamp));
    }
}
