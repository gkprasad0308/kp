package lds.personservice.household;

import java.util.List;

public class ListParamsMissionaryIdsTest extends AbstractListParamsTest {
    @Override
    protected void callParser(String value) {
        listParams.parseMissionaryIds(value);
    }

    @Override
    protected List<Long> getValues() {
        return listParams.getMissionaryIds();
    }

    @Override
    protected String getFieldName() {
        return "missionaryIds";
    }
}
