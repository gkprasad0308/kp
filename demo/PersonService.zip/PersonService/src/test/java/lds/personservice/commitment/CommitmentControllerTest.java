package lds.personservice.commitment;

import lds.personservice.ResourceWrapper;
import lds.stack.spring.web.Link;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Map;

import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class CommitmentControllerTest {

    @InjectMocks
    private CommitmentController controller;

    @Mock
    private CommitmentService service;

    @Test
    public void updateCommitmentCallsServiceWithExpectedParams(){
        Commitment commitment = new Commitment();
        controller.put(commitment, "abc");
        verify(service, times(1)).updateCommitment(commitment, "abc");
        verifyNoMoreInteractions(service);
    }

    @Test
    public void updateCommitmentReturnsDecoratedResourceWithLinkToSelf(){
        Commitment commitment = new Commitment();
        commitment.setClientGuid("abc");

        when(service.updateCommitment(commitment, commitment.getClientGuid())).thenReturn(commitment);
        ResourceWrapper<Commitment> response = new ResourceWrapper<>(controller.put(commitment, commitment.getClientGuid()));
        assertEquals("abc", response.getInstance().getClientGuid());
        Map<String, Link> links = response.getLinks();
        assertThat(links.keySet(), contains("self"));
    }

    @Test
    public void postCallsServiceWithExpectedParams(){
        Commitment commitment = new Commitment();
        controller.post(commitment);
        verify(service, times(1)).createCommitment(commitment);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void postReturnsDecordatedWithResourceLinkToSelf(){
        Commitment commitment = new Commitment();
        commitment.setClientGuid("abc");
        when(service.createCommitment(commitment)).thenReturn(commitment);

        ResourceWrapper<Commitment> resource = new ResourceWrapper<>(controller.post(commitment));
        assertEquals("abc", resource.getInstance().getClientGuid());
        assertThat(resource.getLinks().keySet(), contains("self"));
    }

    @Test
    public void deleteCallsServiceWithexpectedParams(){
        controller.delete("abc");
        verify(service, times(1)).deleteCommitment("abc");
        verifyNoMoreInteractions(service);
    }

    @Test
    public void deleteReturnsDecordatedWithResourceLinkToSelf(){
        Commitment commitment = new Commitment();
        commitment.setClientGuid("abc");
        when(service.deleteCommitment("abc")).thenReturn(commitment);

        ResourceWrapper<Commitment> resource = new ResourceWrapper<>(controller.delete("abc"));
        assertEquals("abc", resource.getInstance().getClientGuid());
        assertThat(resource.getLinks().keySet(), contains("self"));
    }
}
