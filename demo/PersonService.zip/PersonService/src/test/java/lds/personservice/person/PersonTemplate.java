package lds.personservice.person;

import java.net.URI;
import java.util.List;

import lds.personservice.client.ResourceTemplate;
import lds.personservice.person.drop.WritableDropNote;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class PersonTemplate extends ResourceTemplate<PersonTemplate> {

    @Value("http://localhost:${local.server.port}${lds.api.resources.people.href}")
    private URI resourceUri;

    public URI getResourceUri() {
        return resourceUri;
    }

    public String getResourceUriAsString(){
        return getResourceUri().toString();
    }

    public Person mergePerson(String to, String from) {
        HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE));
        String url = resourceUri.toString() + "/merge/from/" + from + "/to/" + to;
        return sendRequest(url, HttpMethod.PUT, request, Person.class).getBody();

    }

    @SuppressWarnings("unchecked")
    public List<Person> calculateStatus(Long id) {
        HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders(MediaType.APPLICATION_JSON_VALUE));
        String url = resourceUri.toString() + "/calculate/status/" + id;
        return (List<Person>) sendRequest(url, HttpMethod.PUT, request, List.class).getBody();

    }

    public <T> T getPerson(String contentType, String personId, Class<T> unmarshalledType) {
        HttpEntity<Person> request = new HttpEntity<>(constructDefaultHeaders(contentType));
        return sendRequest(getPersonGuidUrl(personId), HttpMethod.GET, request, unmarshalledType).getBody();
    }

    public <T> T createPerson(String contentType, Person payload, Class<T> unmarshalledType) {
        HttpEntity<Person> request = new HttpEntity<>(payload, constructDefaultHeaders(contentType));
        ResponseEntity<T> response = sendRequest(resourceUri.toString(), HttpMethod.POST, request, unmarshalledType);
        return response.getBody();
    }

    public <T> T updatePerson(Person payload, Class<T> unmarshalledType) {
        HttpEntity<Person> request = new HttpEntity<>(payload, constructDefaultHeaders("application/json"));
        return sendRequest(getPersonGuidUrl(payload.getGuid()), HttpMethod.PUT, request, unmarshalledType).getBody();
    }

    public void deletePerson(String personId) {
        HttpEntity<Person> request = new HttpEntity<>(constructDefaultHeaders("application/json"));
        sendRequest(getPersonGuidUrl(personId), HttpMethod.DELETE, request, String.class);
    }

    public Person dropPerson(String contentType, String personId, WritableDropNote note) {
        HttpEntity<WritableDropNote> request = new HttpEntity<>(note, constructDefaultHeaders(contentType));
        return sendRequest(getPersonGuidUrl(personId) + "/drop", HttpMethod.PUT, request, Person.class).getBody();
    }

    public Person undropPerson(String personId) {
        HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders("application/json"));
        return sendRequest(getPersonGuidUrl(personId) + "/drop/undo", HttpMethod.PUT, request, Person.class).getBody();
    }

    public Person resetPerson(String personId, Long epochTime) {
        HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders("application/json"));
        return sendRequest(getPersonGuidUrl(personId) + "/drop/reset/" + epochTime, HttpMethod.PUT, request, Person.class).getBody();
    }

    public String manageFellowshipper(String personId, String fellowshipperId, HttpMethod call) {
        HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders("application/json"));
        return sendRequest(resourceUri.toString() + "/" + personId + "/fellowshipper/" + fellowshipperId,
                           HttpMethod.PUT, request, String.class).getBody();
    }

    private String getPersonGuidUrl(String personId) {
        return resourceUri.toString() + "/" + personId;
    }
}
