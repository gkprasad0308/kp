package lds.personservice;

import lds.personservice.util.BaseRowMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class BaseRowMapperTest {

    @Mock
    private ResultSet resultSet;

    @Test
    public void extractLongObjectReturnsNullIfResultSetReturnsNull() throws SQLException {
        when(resultSet.getObject("abc")).thenReturn(null);
        BaseRowMapper rowMapper = new BaseRowMapper();
        assertNull(rowMapper.extractLongObject(resultSet, "abc"));
        verify(resultSet, times(1)).getObject("abc");
        verifyNoMoreInteractions(resultSet);
    }

    @Test
    public void extractLongObjectREturnsLongIfResultHasValue() throws SQLException{
        when(resultSet.getObject("abc")).thenReturn(1L);
        when(resultSet.getLong("abc")).thenReturn(1L);
        BaseRowMapper rowMapper = new BaseRowMapper();
        assertEquals(new Long(1L), rowMapper.extractLongObject(resultSet, "abc"));
        verify(resultSet, times(1)).getObject("abc");
        verify(resultSet, times(1)).getLong("abc");
        verifyNoMoreInteractions(resultSet);
    }

    @Test
    public void extractIntegerObjectReturnsNullIfResultSetReturnsNull() throws SQLException {
        when(resultSet.getObject("abc")).thenReturn(null);
        BaseRowMapper rowMapper = new BaseRowMapper();
        assertNull(rowMapper.extractIntegerObject(resultSet, "abc"));
        verify(resultSet, times(1)).getObject("abc");
        verifyNoMoreInteractions(resultSet);
    }

    @Test
    public void extractIntegerObjectREturnsLongIfResultHasValue() throws SQLException{
        when(resultSet.getObject("abc")).thenReturn(1);
        when(resultSet.getInt("abc")).thenReturn(1);
        BaseRowMapper rowMapper = new BaseRowMapper();
        assertEquals(new Integer(1), rowMapper.extractIntegerObject(resultSet, "abc"));
        verify(resultSet, times(1)).getObject("abc");
        verify(resultSet, times(1)).getInt("abc");
        verifyNoMoreInteractions(resultSet);
    }

    @Test
    public void extractBooleanObjectReturnsNullIfResultSetReturnsNull() throws SQLException {
        when(resultSet.getObject("abc")).thenReturn(null);
        BaseRowMapper rowMapper = new BaseRowMapper();
        assertNull(rowMapper.extractBooleanObject(resultSet, "abc"));
        verify(resultSet, times(1)).getObject("abc");
        verifyNoMoreInteractions(resultSet);
    }

    @Test
    public void extractBooleanObjectReturnsTrueIfResultHasYValue() throws SQLException{
        when(resultSet.getObject("abc")).thenReturn("Y");
        when(resultSet.getString("abc")).thenReturn("Y");
        BaseRowMapper rowMapper = new BaseRowMapper();
        assertTrue(rowMapper.extractBooleanObject(resultSet, "abc"));
        verify(resultSet, times(1)).getObject("abc");
        verify(resultSet, times(1)).getString("abc");
        verifyNoMoreInteractions(resultSet);
    }

    @Test
    public void extractBooleanObjectReturnsFalseIfResultHasNValue() throws SQLException{
        when(resultSet.getObject("abc")).thenReturn("N");
        when(resultSet.getString("abc")).thenReturn("N");
        BaseRowMapper rowMapper = new BaseRowMapper();
        assertFalse(rowMapper.extractBooleanObject(resultSet, "abc"));
        verify(resultSet, times(1)).getObject("abc");
        verify(resultSet, times(1)).getString("abc");
        verifyNoMoreInteractions(resultSet);
    }

    @Test
    public void extractBooleanObjectReturnsFalseIfResultHasAnyStringValue() throws SQLException{
        when(resultSet.getObject("abc")).thenReturn("dY");
        when(resultSet.getString("abc")).thenReturn("dY");
        BaseRowMapper rowMapper = new BaseRowMapper();
        assertFalse(rowMapper.extractBooleanObject(resultSet, "abc"));
        verify(resultSet, times(1)).getObject("abc");
        verify(resultSet, times(1)).getString("abc");
        verifyNoMoreInteractions(resultSet);
    }
}
