package lds.personservice.person.referral;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.StringUtils;

import javax.swing.tree.RowMapper;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ReferralMapperTest {

    @Mock
    private ResultSet resultSet;

    private ReferralMapper mapper;

    @Before
    public void setup(){
        mapper = new ReferralMapper();
    }

    @Test
    public void mapRowReturnsExpected() throws SQLException{
        Date claimDate = new Date(System.currentTimeMillis());
        Date cDate = new Date(System.currentTimeMillis());

        when(resultSet.getInt(ReferralMapper.RFRL_STAT_ID)).thenReturn(1);
        when(resultSet.getObject(ReferralMapper.ESCALATE_DT)).thenReturn("true");
        when(resultSet.getString(ReferralMapper.NOTE)).thenReturn("note");
        when(resultSet.getDate(ReferralMapper.CLAIM_DT)).thenReturn(claimDate);
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(cDate);
        when(resultSet.getString(ReferralMapper.EMAIL_ADDR)).thenReturn("test@TEst");
        when(resultSet.getString(ReferralMapper.FIRST_NAME)).thenReturn("bob");
        when(resultSet.getString(ReferralMapper.LAST_NAME)).thenReturn("smith");
        when(resultSet.getString(ReferralMapper.PHN_NBR)).thenReturn("1234");

        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertTrue(1 == result.getReferralStatId());
        assertTrue(result.isEscalated());
        assertEquals("note", result.getNote());
        assertEquals(claimDate, result.getClaimDate());
        assertEquals(cDate, result.getCreateDate());
        assertEquals("test@TEst", result.getReferrer().getEmailAddress());
        assertEquals("bob", result.getReferrer().getFirstName());
        assertEquals("smith", result.getReferrer().getLastName());
        assertEquals("1234", result.getReferrer().getPhoneNumber());
    }

    @Test
    public void mapRowReturnsNothingWithoutCDateAndReferrer() throws SQLException{
        Date claimDate = new Date(System.currentTimeMillis());

        when(resultSet.getInt(ReferralMapper.RFRL_STAT_ID)).thenReturn(1);
        when(resultSet.getObject(ReferralMapper.ESCALATE_DT)).thenReturn("true");
        when(resultSet.getString(ReferralMapper.NOTE)).thenReturn("note");
        when(resultSet.getDate(ReferralMapper.CLAIM_DT)).thenReturn(claimDate);

        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertNull(result);
    }

    @Test
    public void mapRowApplysOwnerMissionaryIdIfValueSupplied() throws SQLException {
        setupLongExtract(ReferralMapper.OWNER_MSNY_ID);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertEquals(new Long(1L), result.getOwnerMissionaryId());
        verifyExtractLong(ReferralMapper.OWNER_MSNY_ID);
    }

    @Test
    public void mapRowOwnerMissionaryIdNullIfNoValue() throws SQLException {
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));
        when(resultSet.getObject(ReferralMapper.OWNER_MSNY_ID)).thenReturn(null);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertNull(result.getOwnerMissionaryId());
        verifyExtractLongNull(ReferralMapper.OWNER_MSNY_ID);
    }

    @Test
    public void mapRowApplysOwnerOrgIdIfValueSupplied() throws SQLException {
        setupLongExtract(ReferralMapper.OWNER_ORG_ID);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertEquals(new Long(1L), result.getOwnerOrgId());
        verifyExtractLong(ReferralMapper.OWNER_ORG_ID);
    }

    @Test
    public void mapRowOwnerOrgIdNullIfNoValue() throws SQLException {
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));
        when(resultSet.getObject(ReferralMapper.OWNER_ORG_ID)).thenReturn(null);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertNull(result.getOwnerOrgId());
        verifyExtractLongNull(ReferralMapper.OWNER_ORG_ID);
    }

    @Test
    public void mapRowApplysOwnerCmisIdIfValueSupplied() throws SQLException {
        setupLongExtract(ReferralMapper.OWNER_CMIS_ID);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertEquals(new Long(1L), result.getOwnerStewardCmisId());
        verifyExtractLong(ReferralMapper.OWNER_CMIS_ID);
    }

    @Test
    public void mapRowOwnerCmisIdNullIfNoValue() throws SQLException {
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));
        when(resultSet.getObject(ReferralMapper.OWNER_CMIS_ID)).thenReturn(null);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertNull(result.getOwnerStewardCmisId());
        verifyExtractLongNull(ReferralMapper.OWNER_CMIS_ID);
    }

    @Test
    public void mapRowApplysReceivingProsAreaIdIfValueSupplied() throws SQLException {
        setupLongExtract(ReferralMapper.RCV_PROS_AREA_ID);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertEquals(new Long(1L), result.getReceivingProsArea());
        verifyExtractLong(ReferralMapper.RCV_PROS_AREA_ID);
    }

    @Test
    public void mapRowReceivingProsAreaIdNullIfNoValue() throws SQLException {
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));
        when(resultSet.getObject(ReferralMapper.RCV_PROS_AREA_ID)).thenReturn(null);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertNull(result.getReceivingProsArea());
        verifyExtractLongNull(ReferralMapper.RCV_PROS_AREA_ID);
    }

    @Test
    public void mapRowApplysReceivingOrgIdIfValueSupplied() throws SQLException {
        setupLongExtract(ReferralMapper.RCV_ORG_ID);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertEquals(new Long(1L), result.getReceivingOrgId());
        verifyExtractLong(ReferralMapper.RCV_ORG_ID);
    }

    @Test
    public void mapRowReceivingOrgIdNullIfNoValue() throws SQLException {
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));
        when(resultSet.getObject(ReferralMapper.RCV_ORG_ID)).thenReturn(null);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertNull(result.getReceivingOrgId());
        verifyExtractLongNull(ReferralMapper.RCV_ORG_ID);
    }

    @Test
    public void mapRowReceivingMsnyIdNullIfNoValue() throws SQLException {
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));
        when(resultSet.getObject(ReferralMapper.RCV_MSNY_ID)).thenReturn(null);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertNull(result.getReceivingMissionaryId());
        verifyExtractLongNull(ReferralMapper.RCV_MSNY_ID);
    }

    @Test
    public void mapRowApplysReceivingMsnyIdIfValueSupplied() throws SQLException {
        setupLongExtract(ReferralMapper.RCV_MSNY_ID);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertEquals(new Long(1L), result.getReceivingMissionaryId());
        verifyExtractLong(ReferralMapper.RCV_MSNY_ID);
    }

    @Test
    public void mapRowReceivingCmisIdNullIfNoValue() throws SQLException {
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));
        when(resultSet.getObject(ReferralMapper.RCV_CMIS_ID)).thenReturn(null);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertNull(result.getReceivingStewardCmisId());
        verifyExtractLongNull(ReferralMapper.RCV_CMIS_ID);
    }

    @Test
    public void mapRowApplysReceivingCmisIdIfValueSupplied() throws SQLException {
        setupLongExtract(ReferralMapper.RCV_CMIS_ID);
        ReferralInfo result = mapper.mapRow(resultSet, 1);
        assertEquals(new Long(1L), result.getReceivingStewardCmisId());
        verifyExtractLong(ReferralMapper.RCV_CMIS_ID);
    }

    private void verifyExtractLong(String column) throws SQLException {
        verify(resultSet, times(1)).getObject(column);
        verify(resultSet, times(1)).getLong(column);
    }

    private void verifyExtractLongNull(String column) throws SQLException {
        verify(resultSet, times(1)).getObject(column);
        verify(resultSet, times(0)).getLong(column);
    }

    private void setupLongExtract(String column) throws SQLException {
        when(resultSet.getDate(ReferralMapper.CRT_DT)).thenReturn(new Date(System.currentTimeMillis()));
        when(resultSet.getObject(column)).thenReturn(1L);
        when(resultSet.getLong(column)).thenReturn(1L);
    }

    @Test
    public void getSelectStatement(){
        String select = ReferralMapper.getSelectStatement("r", "rg");

        assertThat(select, containsString(getSelectFragment("r", ReferralMapper.RFRL_STAT_ID, null)));
        assertThat(select, containsString(getSelectFragment("r", "ESCALATE_DT", ReferralMapper.ESCALATE_DT)));
        assertThat(select, containsString(getSelectFragment("r", "owner_msny_id", ReferralMapper.OWNER_MSNY_ID)));
        assertThat(select, containsString(getSelectFragment("r", "owner_stwrd_cmis_id", ReferralMapper.OWNER_CMIS_ID)));
        assertThat(select, containsString(getSelectFragment("r", "owner_org_id", ReferralMapper.OWNER_ORG_ID)));
        assertThat(select, containsString(getSelectFragment("rg", ReferralMapper.NOTE, null)));
        assertThat(select, containsString(getSelectFragment("rg", "rcv_pros_area_id", ReferralMapper.RCV_PROS_AREA_ID)));
        assertThat(select, containsString(getSelectFragment("rg", "rcv_org_id", ReferralMapper.RCV_ORG_ID)));
        assertThat(select, containsString(getSelectFragment("rg", "rcv_msny_id", ReferralMapper.RCV_MSNY_ID)));
        assertThat(select, containsString(getSelectFragment("rg", "rcv_stwrd_cmis_id", ReferralMapper.RCV_CMIS_ID)));
        assertThat(select, containsString(getSelectFragment("rg", "claim_dt", ReferralMapper.CLAIM_DT)));
        assertThat(select, containsString(getSelectFragment("rg", "crt_dt", ReferralMapper.CRT_DT)));
        assertThat(select, containsString(getSelectFragment("rg", "rfrr_first_nm", ReferralMapper.FIRST_NAME)));
        assertThat(select, containsString(getSelectFragment("rg", "rfrr_last_nm", ReferralMapper.LAST_NAME)));
        assertThat(select, containsString(getSelectFragment("rg", ReferralMapper.PHN_NBR, null)));
        assertThat(select, containsString(getSelectFragment("rg", ReferralMapper.EMAIL_ADDR, null)));
        assertThat(select, not(endsWith(",")));
    }

    private String getSelectFragment(String prefix, String column, String alias){
        return prefix + "." + column + (StringUtils.isEmpty(alias) ? "" : " AS " + alias);
    }

    @Test
    public void getJoinStatementContainsExpectedStrings(){
        String join = ReferralMapper.getJoinStatement("p", "pr", "rg");
        assertThat(join, containsString(getJoinFragment("pr", "ims.person_rfrl")));
        assertThat(join, containsString(getJoinFragment("rg", "ims.rfrl_grp")));
        assertThat(join, containsString("pr.msny_visit_yn = 'Y'"));
        assertThat(join, containsString("p.person_id = pr.person_id"));
        assertThat(join, containsString("pr.rfrl_grp_id = rg.rfrl_grp_id"));
    }

    private String getJoinFragment(String prefix, String table){
        return "LEFT JOIN " + table + " " + prefix;
    }
}
