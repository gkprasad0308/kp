package lds.personservice.person.builder;

import lds.personservice.household.InclusionParams;
import lds.personservice.person.Person;
import lds.personservice.person.drop.DropNote;
import lds.personservice.person.drop.DropNoteRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.*;
import static org.mockito.Matchers.anyList;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PeopleDropNoteBuilderTest {

    @InjectMocks
    private PeopleDropNoteBuilder builder;

    @Mock
    private DropNoteRepository repository;

    @Test
    public void appliesTobuilderIsTrueIfParamsContainsDropNotes(){
        BuilderParams params = new BuilderParams();
        params.setInclusions(Arrays.asList(InclusionParams.DROP_NOTES));
        assertTrue(builder.appliesToBuilder(params));
    }

    @Test
    public void appliesTobuilderIsFalseIfNullParams(){
        assertFalse(builder.appliesToBuilder(null));
    }

    @Test
    public void appliesTobuilderIsFalseIfParamsDoesNotContainsDropNotes(){
        BuilderParams params = new BuilderParams();
        params.setInclusions(InclusionParams.valuesAsList().stream().filter(param -> param != InclusionParams.DROP_NOTES).collect(Collectors.toList()));
        assertFalse(builder.appliesToBuilder(params));
    }

    @Test
    public void buildAppendsCommitmentsToPeople(){
        Person person = new Person();
        person.setServerId(123L);

        Person person2 = new Person();
        person2.setServerId(456L);

        DropNote note1 = new DropNote();
        note1.setPersonId(123L);

        DropNote note2 = new DropNote();
        note2.setPersonId(456L);

        Map<Long, List<DropNote>> repMap = new HashMap<>();
        repMap.put(123L, Arrays.asList(note1));
        repMap.put(456L, Arrays.asList(note2));

        when(repository.getNotesForPeople(anyList())).thenReturn(repMap);
        List<Person> results = builder.build(Arrays.asList(person, person2));
        assertTrue(results.size() == 2);
        assertThat(results, hasItem(person));
        assertThat(results, hasItem(person2));
        assertThat(person.getDropNotes(), contains(note1));
        assertThat(person2.getDropNotes(), contains(note2));
    }

    @Test
    public void buildReturnsNullIfNullPassedIn(){
        assertNull(builder.build(null));
        verifyZeroInteractions(repository);
    }

    @Test
    public void buildReturnsEmptyIfEmptyPassedIn(){
        List<Person> people = new LinkedList<>();
        assertEquals(people, builder.build(people));
        verifyZeroInteractions(repository);
    }
}
