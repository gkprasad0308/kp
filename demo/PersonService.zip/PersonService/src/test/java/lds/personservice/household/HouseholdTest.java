package lds.personservice.household;

import lds.personservice.person.Person;
import org.junit.Test;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class HouseholdTest {

    private static final String TEST_ADDRESS = "9000 S. Main Street, Sandy, UT";
    private static final Double TEST_LATITUDE = 40.5884660;
    private static final Double TEST_LONGITUDE = -111.8912990;

    @Test
    public void addPersonAddesValueToList(){
        Household household = createSimpleHousehold();
        Person person = createSimplePerson();
        household.addPerson(person);

        assertTrue(household.getPeople().size() == 1);
        assertThat(household.getPeople(), contains(person));
    }

    @Test
    public void addPersonDoesNothingIfPersonIsNull(){
        Household household = createSimpleHousehold();
        household.addPerson(null);
        assertNull(household.getPeople());
    }

    @Test
    public void addPersonAddsToPersonList(){
        Person p1 = createSimplePerson();
        Person p2 = createSimplePerson();
        Household household = createSimpleHousehold();
        household.addPerson(p1);
        household.addPerson(p2);

        assertTrue(household.getPeople().size() == 2);
        assertThat(household.getPeople(), hasItem(p1));
        assertThat(household.getPeople(), hasItem(p2));
    }

    @Test
    public void listProsAreaIdsReturnsEmptyListIfNullPeople(){
        Household household = createSimpleHousehold();
        household.setPeople(null);
        assertTrue(CollectionUtils.isEmpty(household.listProsAreaIds()));
    }

    @Test
    public void listProsAreaIdsReturnsListOfAllProsAreasOnPeople(){
        Person p1 = createPersonWithProsArea(123L);
        Person p2 = createPersonWithProsArea(456L);
        Household household = createSimpleHousehold();
        household.setPeople(Arrays.asList(p1, p2));

        List<Long> areaIds = household.listProsAreaIds();
        assertTrue(areaIds.size() == 2);
        assertThat(areaIds, hasItem(123L));
        assertThat(areaIds, hasItem(456L));
    }

    @Test
    public void listProsAreaIdsHandlesPeopleWithNoProsAreaId(){
        Person p1 = createSimplePerson();
        Household household = createSimpleHousehold();
        household.addPerson(p1);

        List<Long> areas = household.listProsAreaIds();
        assertTrue(CollectionUtils.isEmpty(areas));

        household.addPerson(createPersonWithProsArea(234L));
        areas = household.listProsAreaIds();
        assertTrue(areas.size() == 1);
        assertThat(areas, contains(234L));

    }

    @Test
    public void hasOrgChangedIsFalseIfNullpassedIn(){
        assertFalse(createSimpleHousehold().hasOrgChanged(null));
    }

    @Test
    public void hasOrgChangedIsFalseIfOrgNotSet(){
        assertFalse(createSimpleHousehold().hasOrgChanged(createHouseholdWithOrgId(123L)));
    }

    @Test
    public void hasOrgChangedIsFalseIfNull(){
        assertFalse(createHouseholdWithOrgId(null).hasOrgChanged(createHouseholdWithOrgId(123L)));
    }

    @Test
    public void hasOrgChangedIsFalseIfBothSameValue(){
        assertFalse(createHouseholdWithOrgId(123L).hasOrgChanged(createHouseholdWithOrgId(123L)));
    }

    @Test
    public void hasOrgChangedIsTrueIfBothDifferent(){
        assertTrue(createHouseholdWithOrgId(456L).hasOrgChanged(createHouseholdWithOrgId(123L)));
    }

    @Test
    public void hasCmisIdMemberReturnsFalseIfNoPeople(){
        assertFalse(new Household().hasCmisIdMember());
    }

    @Test
    public void hasCmisIdMemberReturnsFalseIfNoCmisIdMembers(){
        Person person = createSimplePerson();
        person.setCmisId(null);
        Household household = createSimpleHousehold();
        household.addPerson(person);

        assertFalse(household.hasCmisIdMember());
    }

    @Test
    public void hasCmisIdMemberREturnsTrueIfOneIsCmisId(){
        Person person = createSimplePerson();
        person.setCmisId(123L);
        Household household = createSimpleHousehold();
        household.setPeople(Arrays.asList(new Person(), new Person(), person));

        assertTrue(household.hasCmisIdMember());
    }

    @Test
    public void changedToMissionaryIsTrueIfThisHasMissionaryIdAndThatHasOrgId(){
        Household household = new Household();
        household.setMissionaryId(123L);

        Household original = new Household();
        original.setOrgId(456L);

        assertTrue(household.changedToMissionary(original));
    }

    @Test
    public void changedToMissionaryIsFalseIfThisHasOrgIdAndThatHasMissionaryId(){
        Household household = new Household();
        household.setOrgId(123L);

        Household original = new Household();
        original.setMissionaryId(456L);

        assertFalse(household.changedToMissionary(original));
    }

    @Test
    public void changedToMissionaryIsFalseIfThisHasMissionaryIdAndThatDoesNotHaveOrgId(){
        Household household = new Household();
        household.setMissionaryId(123L);

        Household original = new Household();

        assertFalse(household.changedToMissionary(original));
    }

    @Test
    public void applyHouseholdIdsAcrossPeopleSetsIdsOnEachPerson(){
        Household household = new Household();
        household.setServerId(123L);
        household.setGuid("abc");
        household.setPeople(Arrays.asList(new Person(), new Person(), new Person()));

        household.applyHouseholdIdsAcrossPeople();
        for(Person person: household.getPeople()){
            assertEquals("abc", person.getHouseholdId());
            assertEquals(new Long(123L), person.getHouseholdServerId());
        }
    }

    @Test
    public void applyHouseholdIdsAcrossPeopleIsStableWithEmptyPeople(){
        List<Person> mockList = mock(List.class);
        when(mockList.isEmpty()).thenReturn(true);

        Household household = new Household();
        household.setServerId(123L);
        household.setGuid("abc");
        household.setPeople(mockList);
        household.applyHouseholdIdsAcrossPeople();
        verify(mockList, times(1)).isEmpty();
        verifyNoMoreInteractions(mockList);
    }


    @Test
    public void testGetCoordinates5() throws Exception {
        // Pin Dropped Has Address Has Lat Has Long Result
        // FALSE TRUE FALSE FALSE Store null coordinates
        Household test = new Household();
        test.setPinDropped(false);
        test.setAddress(TEST_ADDRESS);
        test.setLat(null);
        test.setLng(null);
        test.cleanAddress();
        assertNull(test.getLat());
        assertNull(test.getLng());
    }

    @Test
    public void testGetCoordinates6() throws Exception {
        // Pin Dropped Has Address Has Lat Has Long Result
        // FALSE TRUE FALSE TRUE Store null coordinates
        Household test = new Household();
        test.setPinDropped(false);
        test.setAddress(TEST_ADDRESS);
        test.setLat(null);
        test.setLng(String.valueOf(TEST_LONGITUDE));
        test.cleanAddress();
        assertNull(test.getLat());
        assertNull(test.getLng());
    }

    @Test
    public void testGetCoordinates7() throws Exception {
        // Pin Dropped Has Address Has Lat Has Long Result
        // FALSE TRUE TRUE FALSE Store null coordinates
        Household test = new Household();
        test.setPinDropped(false);
        test.setAddress(TEST_ADDRESS);
        test.setLat(String.valueOf(TEST_LATITUDE));
        test.setLng(null);
        test.cleanAddress();
        assertNull(test.getLat());
        assertNull(test.getLng());
    }
    private Person createSimplePerson() {
        return new Person();
    }

    private Person createPersonWithProsArea(long prosArea){
        Person person = createSimplePerson();
        person.setProsAreaId(prosArea);
        return person;
    }

    private Household createSimpleHousehold(){
        return new Household();
    }

    private Household createHouseholdWithOrgId(Long orgId){
        Household household = createSimpleHousehold();
        household.setOrgId(orgId);
        return household;
    }
}
