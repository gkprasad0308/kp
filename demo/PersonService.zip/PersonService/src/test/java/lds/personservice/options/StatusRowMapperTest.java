package lds.personservice.options;


import org.junit.Before;
import org.junit.Test;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

public class StatusRowMapperTest {

    private StatusRowMapper rowMapper;
    private ResultSet resultSet;

    @Before
    public void setup(){
        rowMapper = new StatusRowMapper();
        resultSet = mock(ResultSet.class);
    }

    @Test
    public void mapRowReturnsExpected() throws SQLException {
        when(resultSet.getInt(StatusRowMapper.STAT_ID)).thenReturn(1);
        when(resultSet.getObject(StatusRowMapper.PARENT_STAT_ID)).thenReturn(2);
        when(resultSet.getInt(StatusRowMapper.PARENT_STAT_ID)).thenReturn(2);
        when(resultSet.getInt(StatusRowMapper.TYPE_ID)).thenReturn(3);
        when(resultSet.getString(StatusRowMapper.STAT_CODE)).thenReturn("code");
        when(resultSet.getString(StatusRowMapper.DESCRIPTION)).thenReturn("description");

        Status result = rowMapper.mapRow(resultSet, 1);
        assertTrue(1 == result.getId());
        assertEquals(new Integer(2), result.getParentId());
        assertTrue(3 == result.getTypeId());
        assertEquals("code", result.getCode());
        assertEquals("description", result.getName());
    }

    @Test
    public void mapRowReturnsNullParentStatIdIfNotSetup() throws SQLException {
        when(resultSet.getObject(StatusRowMapper.PARENT_STAT_ID)).thenReturn(null);
        Status result = rowMapper.mapRow(resultSet, 1);
        assertNull(result.getParentId());
        verify(resultSet, times(1)).getObject(StatusRowMapper.PARENT_STAT_ID);
        verify(resultSet, times(0)).getInt(StatusRowMapper.PARENT_STAT_ID);
    }
}
