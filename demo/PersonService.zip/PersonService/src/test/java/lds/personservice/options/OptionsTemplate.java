package lds.personservice.options;

import java.net.URI;
import java.util.ArrayList;
import java.util.Map;

import lds.personservice.client.ResourceTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
@Scope("prototype")
public class OptionsTemplate extends ResourceTemplate<OptionsTemplate> {

    @Value("http://localhost:${local.server.port}${lds.api.resources.options.href}")
    private URI resourceUri;

    public URI getResourceUri() {
        return resourceUri;
    }

    public String getResourceUriAsString(){
        return getResourceUri().toString();
    }

	public ArrayList getOptions(String optionType) {
		HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders("application/json"));
        return sendRequest(constructUri(optionType, null), HttpMethod.GET, request, ArrayList.class).getBody();
    }

    @SuppressWarnings("unchecked")
    public ArrayList<Map<String, Object>> getOptionsByLang(String optionType, String lang) {
        HttpEntity<String> request = new HttpEntity<>(constructDefaultHeaders("application/json"));
        return sendRequest(constructUri(optionType, lang), HttpMethod.GET, request, ArrayList.class).getBody();
    }

    public String constructUri(String optionType, String lang) {
        String uri = resourceUri.toString() + "/" + optionType;
        if (!StringUtils.isEmpty(lang)) {
            uri += "?lang=" + lang;
        }
        return uri;
    }
}
