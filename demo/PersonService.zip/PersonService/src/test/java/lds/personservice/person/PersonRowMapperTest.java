package lds.personservice.person;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.StringUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PersonRowMapperTest {

    @Mock
    public ResultSet resultSet;

    private PersonRowMapper rowMapper;

    @Before
    public void setup(){
        rowMapper = new PersonRowMapper();
    }

    @Test
    public void mapRowMapsAgeCategoryIfNotNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.AGE_C_ID)).thenReturn(1);
        when(resultSet.getInt(PersonRowMapper.AGE_C_ID)).thenReturn(1);
        assertEquals(new Integer(1), rowMapper.mapRow(resultSet, 1).getAgeCatId());
    }

    @Test
    public void mapRowIgnoresAgeCategoryNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.AGE_C_ID)).thenReturn(null);
        assertNull(rowMapper.mapRow(resultSet, 1).getAgeCatId());
    }

    @Test
    public void mapRowMapsFocusPersonIfNotNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.AFAB_FOCUS_PERSON_YN)).thenReturn("Y");
        when(resultSet.getString(PersonRowMapper.AFAB_FOCUS_PERSON_YN)).thenReturn("Y");
        assertTrue(rowMapper.mapRow(resultSet, 1).isFocusPerson());
    }

    @Test
    public void mapRowIgnoresFocusPersonIfNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.AFAB_FOCUS_PERSON_YN)).thenReturn(null);
        assertFalse(rowMapper.mapRow(resultSet, 1).isFocusPerson());
    }

    @Test
    public void mapRowMapsCmisIfNotNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.CMIS_ID)).thenReturn(1);
        when(resultSet.getLong(PersonRowMapper.CMIS_ID)).thenReturn(1L);
        assertEquals(new Long(1L), rowMapper.mapRow(resultSet, 1).getCmisId());
    }

    @Test
    public void mapRowIgnoresCmisNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.CMIS_ID)).thenReturn(null);
        assertNull(rowMapper.mapRow(resultSet, 1).getCmisId());
    }

    @Test
    public void mapRowMapsProsAreaIfNotNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.PROS_AREA_ID)).thenReturn(1);
        when(resultSet.getLong(PersonRowMapper.PROS_AREA_ID)).thenReturn(1L);
        assertEquals(new Long(1L), rowMapper.mapRow(resultSet, 1).getProsAreaId());
    }

    @Test
    public void mapRowIgnoresProsAreaNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.PROS_AREA_ID)).thenReturn(null);
        assertNull(rowMapper.mapRow(resultSet, 1).getProsAreaId());
    }

    @Test
    public void mapRowMapsPreferredLangIdIfNotNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.PREF_LANG_ID)).thenReturn(1);
        when(resultSet.getInt(PersonRowMapper.PREF_LANG_ID)).thenReturn(1);
        assertEquals(new Integer(1), rowMapper.mapRow(resultSet, 1).getPreferredLangId());
    }

    @Test
    public void mapRowIgnoresPreferredLangIdNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.PREF_LANG_ID)).thenReturn(null);
        assertNull(rowMapper.mapRow(resultSet, 1).getPreferredLangId());
    }

    @Test
    public void mapRowMapsPreferredContactTypeIfNotNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.PREF_CNTCT_T_ID)).thenReturn(1);
        when(resultSet.getInt(PersonRowMapper.PREF_CNTCT_T_ID)).thenReturn(1);
        assertEquals(new Integer(1), rowMapper.mapRow(resultSet, 1).getPreferredContactType());
    }

    @Test
    public void mapRowIgnoresPreferredContactTypeNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.PREF_CNTCT_T_ID)).thenReturn(null);
        assertNull(rowMapper.mapRow(resultSet, 1).getPreferredContactType());
    }

    @Test
    public void mapRowMapsFindDetailIfNotNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.FIND_DTL_ID)).thenReturn(1);
        when(resultSet.getInt(PersonRowMapper.FIND_DTL_ID)).thenReturn(1);
        assertEquals(new Integer(1), rowMapper.mapRow(resultSet, 1).getContactSourceDtl());
    }

    @Test
    public void mapRowIgnoresFindDetailNull() throws SQLException{
        when(resultSet.getObject(PersonRowMapper.FIND_DTL_ID)).thenReturn(null);
        assertNull(rowMapper.mapRow(resultSet, 1).getContactSourceDtl());
    }

    @Test
    public void mapRowReturnsExpected() throws SQLException{
        Timestamp cDate = new Timestamp(System.currentTimeMillis());
        Timestamp mDate = new Timestamp(System.currentTimeMillis());
        when(resultSet.getLong(PersonRowMapper.PERSON_ID)).thenReturn(1L);
        when(resultSet.getLong(PersonRowMapper.HSHLD_ID)).thenReturn(2L);
        when(resultSet.getString(PersonRowMapper.DEL_YN)).thenReturn("Y");
        when(resultSet.getString(PersonRowMapper.FIRST_NM)).thenReturn("bob");
        when(resultSet.getString(PersonRowMapper.LAST_NM)).thenReturn("smith");
        when(resultSet.getString(PersonRowMapper.GENDER)).thenReturn("M");
        when(resultSet.getInt(PersonRowMapper.PERSON_STAT_ID)).thenReturn(8);
        when(resultSet.getTimestamp(PersonRowMapper.CRT_DT)).thenReturn(cDate);
        when(resultSet.getTimestamp(PersonRowMapper.MOD_DT)).thenReturn(mDate);
        when(resultSet.getString(PersonRowMapper.NOTE)).thenReturn("note");
        when(resultSet.getString(PersonRowMapper.CLIENT_GUID)).thenReturn("abc");
        when(resultSet.getString(PersonRowMapper.CONVERT_YN)).thenReturn("Y");
        when(resultSet.getInt(PersonRowMapper.FIND_ID)).thenReturn(10);

        Person person = rowMapper.mapRow(resultSet, 1);

        assertEquals(new Long(1L), person.getServerId());
        assertEquals(new Long(2L), person.getHouseholdServerId());
        assertTrue(person.isDeleted());
        assertEquals("bob", person.getFirstName());
        assertEquals("smith", person.getLastName());
        assertEquals("M", person.getGender());
        assertEquals(new Integer(8), person.getStatus());
        assertEquals(cDate, person.getCreateDate());
        assertEquals(mDate, person.getModDate());
        assertEquals("note", person.getNote());
        assertEquals("abc", person.getGuid());
        assertTrue(person.isConvert());
        assertEquals(new Integer(10), person.getContactSource());
    }

    @Test
    public void getSelectStatmentContainsExpectedFragments(){
        String select = PersonRowMapper.getSelectStatement("p");
        assertThat(select, containsString(getSelectPart(PersonRowMapper.PERSON_ID, null)));
        assertThat(select, containsString(getSelectPart("hshld_id", PersonRowMapper.HSHLD_ID)));
        assertThat(select, containsString(getSelectPart("del_yn", PersonRowMapper.DEL_YN)));
        assertThat(select, containsString(getSelectPart("first_nm", PersonRowMapper.FIRST_NM)));
        assertThat(select, containsString(getSelectPart("last_nm", PersonRowMapper.LAST_NM)));
        assertThat(select, containsString(getSelectPart("age_c_id", PersonRowMapper.AGE_C_ID)));
        assertThat(select, containsString(getSelectPart("gender", PersonRowMapper.GENDER)));
        assertThat(select, containsString(getSelectPart(PersonRowMapper.PERSON_STAT_ID, null)));
        assertThat(select, containsString(getSelectPart("crt_dt", PersonRowMapper.CRT_DT)));
        assertThat(select, containsString(getSelectPart("mod_dt", PersonRowMapper.MOD_DT)));
        assertThat(select, containsString(getSelectPart("note", PersonRowMapper.NOTE)));
        assertThat(select, containsString(getSelectPart("afab_focus_person_yn", PersonRowMapper.AFAB_FOCUS_PERSON_YN)));
        assertThat(select, containsString(getSelectPart("cmis_id", PersonRowMapper.CMIS_ID)));
        assertThat(select, containsString(getSelectPart("pros_area_id", PersonRowMapper.PROS_AREA_ID)));
        assertThat(select, containsString(getSelectPart("client_guid", PersonRowMapper.CLIENT_GUID)));
        assertThat(select, containsString(getSelectPart("convert_yn", PersonRowMapper.CONVERT_YN)));
        assertThat(select, containsString(getSelectPart("find_id", PersonRowMapper.FIND_ID)));
        assertThat(select, containsString(getSelectPart("pref_lang_id", PersonRowMapper.PREF_LANG_ID)));
        assertThat(select, containsString(getSelectPart("pref_cntct_t_id", PersonRowMapper.PREF_CNTCT_T_ID)));
        assertThat(select, containsString(getSelectPart("find_dtl_id", PersonRowMapper.FIND_DTL_ID)));
        assertThat(select, not(endsWith(",")));
    }


    private String getSelectPart(String originalColumn, String alias) {
        return "p." + originalColumn + (StringUtils.isEmpty(alias) ? "" : " AS " + alias);
    }
}
