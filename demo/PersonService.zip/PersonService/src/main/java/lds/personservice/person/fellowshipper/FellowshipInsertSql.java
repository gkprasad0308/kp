package lds.personservice.person.fellowshipper;

import lds.prsms.utils.UUIDGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Map;

@Component
public class FellowshipInsertSql extends SqlUpdate
{

    public static final String FELLOWSHIPPER_ID = "fellowshipperId";
    public static final String PERSON_ID = "personId";
    public static final String GUID = "guid";

    @Autowired
    public FellowshipInsertSql(DataSource dataSource)
    {
        setDataSource(dataSource);
        setSql(" INSERT INTO ims.fellowshipper_mstr_uv ("
              + "   fellowshipper_id"
              + "   ,person_id"
              + "   ,ivgtr_person_id"
              + "   ,del_yn"
              + "   ,crt_dt"
              + "   ,mod_dt"
              + "   ,client_" + GUID
              + " ) VALUES ("
              + "   ims.fellowshipper_sq.nextval"
              + "   ,:" + FELLOWSHIPPER_ID
              + "   ,:" + PERSON_ID
              + "   ,'N'"
              + "   ,SYSDATE"
              + "   ,SYSDATE"
              + "   ,:" + GUID
              + " ) ");

        declareParameter(new SqlParameter(FELLOWSHIPPER_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PERSON_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(GUID, Types.VARCHAR));
    }

    public Map<String, Object> getParamsUsing(long personId, long fellowshipperId)
    {
        return new MapSqlParameterSource()
              .addValue(FELLOWSHIPPER_ID, fellowshipperId)
              .addValue(PERSON_ID, personId)
              .addValue(GUID, UUIDGenerator.getInstance().getAsString())
              .getValues();
    }
}
