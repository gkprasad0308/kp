package lds.personservice.person.drop;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.validation.Valid;

import lds.personservice.person.Person;
import lds.personservice.person.PersonController;
import lds.personservice.person.PersonService;
import lds.prsms.utils.validation.ValidationGroups;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${lds.api.resources.people.href}/{personId}/drop")
public class DropNoteController
{

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private PersonService personService;

    @Autowired
    private PersonController personController;

    @RequestMapping(method = RequestMethod.PUT, produces = "application/json")
    public Person dropPerson(@RequestBody @Validated(ValidationGroups.Put.class) @Valid WritableDropNote dropNote, @PathVariable("personId") String personGuid)
    {
        LOGGER.info(String.format("Received request to drop person %s with status %d", personGuid, dropNote.getStatus()));
        personService.dropPerson(personGuid, dropNote);

        return personController.getPersonById(personGuid);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/reset/{epochDate}", produces = "application/json")
    public Person resetDrop(@PathVariable("epochDate") Long dateTimeStamp, @PathVariable("personId") String personGuid)
    {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("America/Boise"));
        cal.setTimeInMillis(dateTimeStamp);
        Date resetDate = cal.getTime();

        LOGGER.info(String.format("Received a request to reset drop for person %s to time %tD", personGuid, resetDate));
        personService.resetDrop(personGuid, resetDate);
        return personController.getPersonById(personGuid);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/undo", produces = "application/json")
    public Person undoDropPerson(@PathVariable("personId") String personGuid)
    {
        LOGGER.info(String.format("Received request to undo drop person %s", personGuid));
        personService.undoDrop(personGuid);
        return personController.getPersonById(personGuid);
    }
}
