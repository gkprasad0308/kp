package lds.personservice.options;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SourceType
{

    @JsonProperty(value = "typeId")
    private int sourceTypeId;
    @JsonProperty(value = "code")
    private String sourceTypeCode;
    @JsonProperty(value = "name")
    private String sourceTypeDescription;

    public int getSourceTypeId()
    {
        return sourceTypeId;
    }

    public void setSourceTypeId(int sourceTypeId)
    {
        this.sourceTypeId = sourceTypeId;
    }

    public String getSourceTypeCode()
    {
        return sourceTypeCode;
    }

    public void setSourceTypeCode(String sourceTypeCode)
    {
        this.sourceTypeCode = sourceTypeCode;
    }

    public String getSourceTypeDescription()
    {
        return sourceTypeDescription;
    }

    public void setSourceTypeDescription(String sourceTypeDescription)
    {
        this.sourceTypeDescription = sourceTypeDescription;
    }
}
