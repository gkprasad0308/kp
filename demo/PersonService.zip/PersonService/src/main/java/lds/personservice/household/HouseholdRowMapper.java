package lds.personservice.household;

import java.sql.ResultSet;
import java.sql.SQLException;

import lds.personservice.util.BaseRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

public class HouseholdRowMapper extends BaseRowMapper implements RowMapper<Household>
{

    public static final String HSHLD_ID = "hshld_id";
    public static final String GUID = "hshld_client_guid";
    public static final String ADDR = "hshld_addr";
    public static final String MSNY_ID = "hshld_msny_id";
    public static final String ORG_ID = "hshld_org_id";
    public static final String STWRD_CMIS_ID = "hshld_stwrd_cmis_id";
    public static final String LAT = "hshld_lat";
    public static final String LNG = "hshld_lng";
    public static final String DEL_YN = "hshld_del_yn";
    public static final String PIN_DROP_YN = "hshld_pin_drop_yn";
    public static final String CRT_DT = "hshld_crt_dt";
    public static final String MOD_DT = "hshld_mod_dt";

    @Override
    public Household mapRow(ResultSet resultSet, int i) throws SQLException
    {
        Household household = new Household();

        household.setServerId(resultSet.getLong(HSHLD_ID));
        household.setGuid(resultSet.getString(GUID));
        household.setAddress(resultSet.getString(ADDR));
        household.setMissionaryId(extractLongObject(resultSet, MSNY_ID));
        household.setOrgId(extractLongObject(resultSet, ORG_ID));
        household.setStewardCmisId(extractLongObject(resultSet, STWRD_CMIS_ID));
        household.setLat(resultSet.getString(LAT));
        household.setLng(resultSet.getString(LNG));
        household.setDeleted("Y".equals(resultSet.getString(DEL_YN)));
        household.setPinDropped(extractBooleanObject(resultSet, PIN_DROP_YN));
        household.setCreateDate(resultSet.getTimestamp(CRT_DT));
        household.setModDate(resultSet.getTimestamp(MOD_DT));

        return household;
    }

    public static String getSelectStatement(String prefix)
    {
        StringBuilder sb = new StringBuilder(128);
        String finalPrefix = prefix;
        if (!StringUtils.isEmpty(finalPrefix) && !finalPrefix.endsWith(".")) {
            finalPrefix += ".";
        }

        sb.append(finalPrefix).append(HSHLD_ID).append(",");
        sb.append(finalPrefix).append("client_guid AS ").append(GUID).append(",");
        sb.append(finalPrefix).append("addr AS ").append(ADDR).append(",");
        sb.append(finalPrefix).append("msny_id AS ").append(MSNY_ID).append(",");
        sb.append(finalPrefix).append("org_id AS ").append(ORG_ID).append(",");
        sb.append(finalPrefix).append("stwrd_cmis_id AS ").append(STWRD_CMIS_ID).append(",");
        sb.append(finalPrefix).append("lat AS ").append(LAT).append(",");
        sb.append(finalPrefix).append("lng AS ").append(LNG).append(",");
        sb.append(finalPrefix).append("del_yn AS ").append(DEL_YN).append(",");
        sb.append(finalPrefix).append("pin_drop_yn AS ").append(PIN_DROP_YN).append(",");
        sb.append(finalPrefix).append("crt_dt AS ").append(CRT_DT).append(",");
        sb.append(finalPrefix).append("mod_dt AS ").append(MOD_DT);

        return sb.toString();
    }
}
