package lds.personservice.person.fellowshipper;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.stereotype.Component;

@Component
public class FellowshipUpdateSql extends SqlUpdate
{

    public static final String FELLOWSHIPPER_ID = "fellowshipperId";
    public static final String PERSON_ID = "personId";

    @Autowired
    public FellowshipUpdateSql(DataSource dataSource)
    {
        init(dataSource);
    }

    private void init(DataSource dataSource)
    {
        setDataSource(dataSource);
        setSql(" UPDATE ims.fellowshipper_mstr_uv SET " +
                "       mod_dt = SYSDATE" +
                "      ,del_yn ='N'" +
                " WHERE person_id = :" + FELLOWSHIPPER_ID +
                "   AND ivgtr_person_id = :" + PERSON_ID);

        declareParameter(new SqlParameter(FELLOWSHIPPER_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PERSON_ID, Types.NUMERIC));
    }

    public Map<String, Object> getParamsUsing(long personId, long fellowshipperId)
    {
        return new MapSqlParameterSource()
              .addValue(PERSON_ID, personId)
              .addValue(FELLOWSHIPPER_ID, fellowshipperId)
              .getValues();
    }
}
