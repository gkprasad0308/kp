package lds.personservice.missionorg;

import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.util.CollectionUtils;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Entity extends MisOrgEntity
{
    private List<Entity> children;

    public List<Entity> getChildren()
    {
        return children;
    }

    public void setChildren(List<Entity> children)
    {
        this.children = children;
    }

    public void addChild(Entity child) {
        if(CollectionUtils.isEmpty(children)){
            children = new LinkedList<>();
        }
        children.add(child);
    }
}
