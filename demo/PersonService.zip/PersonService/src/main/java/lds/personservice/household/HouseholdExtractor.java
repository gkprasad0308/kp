package lds.personservice.household;

import lds.personservice.contactinfo.ContactInfo;
import lds.personservice.contactinfo.ContactInfoRowMapper;
import lds.personservice.person.Person;
import lds.personservice.person.PersonRowMapper;
import lds.personservice.person.referral.ReferralInfo;
import lds.personservice.person.referral.ReferralMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HouseholdExtractor implements ResultSetExtractor<List<Household>>
{

    private final HouseholdRowMapper householdRowMapper = new HouseholdRowMapper();
    private final PersonRowMapper personRowMapper = new PersonRowMapper();
    private ContactInfoRowMapper contactInfoRowMapper;
    private ReferralMapper referralMapper;

    public void useContactInfoRowMapper(boolean useMapper)
    {
        if (useMapper) {
            contactInfoRowMapper = new ContactInfoRowMapper();
        } else {
            contactInfoRowMapper = null;
        }
    }

    public void useReferralRowMapper(boolean useMapper)
    {
        if (useMapper) {
            referralMapper = new ReferralMapper();
        } else {
            referralMapper = null;
        }
    }

    @Override
    public List<Household> extractData(ResultSet resultSet) throws SQLException
    {
        Map<Long, Household> householdMap = new HashMap<>();
        List<Household> households = new ArrayList<>();
        Household household;
        long householdId;
        int i = 0;

        while (resultSet.next()) {
            i++;
            householdId = resultSet.getLong("hshld_id");
            if (!householdMap.containsKey(householdId)) {
                household = householdRowMapper.mapRow(resultSet, i);
                households.add(household);
                householdMap.put(householdId, household);
            }
            household = householdMap.get(householdId);
            extractPerson(resultSet, household, i);

        }

        return households;
    }

    private void extractPerson(ResultSet resultSet, Household household, int i) throws SQLException {
        Long personId = getLongFromResultSet(resultSet, PersonRowMapper.PERSON_ID);
        if (personId != null) {
            Person person = personRowMapper.mapRow(resultSet, i);
            person.setHouseholdId(household.getGuid());
            household.addPerson(person);

            extractContactInfo(resultSet, i, person);
            extractReferral(resultSet, i, person);
        }
    }

    private void extractContactInfo(ResultSet resultSet, int i, Person person) throws SQLException {
        if (contactInfoRowMapper != null) {
            ContactInfo contactInfo = contactInfoRowMapper.mapRow(resultSet, i);
            if (contactInfo != null && (!CollectionUtils.isEmpty(contactInfo.getPhoneNumbers()) || !CollectionUtils.isEmpty(contactInfo.getEmailAddresses()))) {
                person.setContactInfo(contactInfo);
            }
        }
    }

    private void extractReferral(ResultSet resultSet, int i, Person person) throws SQLException {
        if (referralMapper != null) {
            ReferralInfo referralInfo = referralMapper.mapRow(resultSet, i);
            person.setReferralInfo(referralInfo);
        }
    }

    private Long getLongFromResultSet(ResultSet resultSet, String column) throws SQLException
    {
        return resultSet.getObject(column) != null ? resultSet.getLong(column) : null;
    }
}
