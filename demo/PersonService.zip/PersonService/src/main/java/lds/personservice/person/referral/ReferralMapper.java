package lds.personservice.person.referral;

import lds.personservice.util.BaseRowMapper;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ReferralMapper extends BaseRowMapper implements RowMapper<ReferralInfo>
{

    public static final String RFRL_STAT_ID = "rfrl_stat_id";
    public static final String ESCALATE_DT = "rfrl_escalate_dt";
    public static final String OWNER_MSNY_ID = "rfrl_owner_msny_id";
    public static final String OWNER_CMIS_ID = "rfrl_owner_cmis_id";
    public static final String OWNER_ORG_ID = "rfrl_owner_org_id";
    public static final String NOTE = "rfrl_note";
    public static final String RCV_PROS_AREA_ID = "rfrl_rcv_pros_area_id";
    public static final String RCV_ORG_ID = "rfrl_rcv_org_id";
    public static final String RCV_MSNY_ID = "rfrl_rcv_msny_id";
    public static final String RCV_CMIS_ID = "rfrl_rcv_cmis_id";
    public static final String CLAIM_DT = "rfrl_claim_dt";
    public static final String CRT_DT = "rfrl_crt_dt";
    public static final String FIRST_NAME = "rfrr_first_name";
    public static final String LAST_NAME = "rfrr_last_name";
    public static final String PHN_NBR = "rfrr_phn_nbr";
    public static final String EMAIL_ADDR = "rfrr_email_addr";

    @Override
    public ReferralInfo mapRow(ResultSet resultSet, int i) throws SQLException
    {
        ReferralInfo referral = new ReferralInfo();

        referral.setReferralStatId(resultSet.getInt(RFRL_STAT_ID));
        referral.setEscalated(resultSet.getObject(ESCALATE_DT) != null);
        referral.setOwnerMissionaryId(extractLongObject(resultSet, OWNER_MSNY_ID));
        referral.setOwnerStewardCmisId(extractLongObject(resultSet, OWNER_CMIS_ID));
        referral.setOwnerOrgId(extractLongObject(resultSet, OWNER_ORG_ID));
        referral.setNote(resultSet.getString(NOTE));
        referral.setReceivingProsArea(extractLongObject(resultSet, RCV_PROS_AREA_ID));
        referral.setReceivingOrgId(extractLongObject(resultSet, RCV_ORG_ID));
        referral.setReceivingMissionaryId(extractLongObject(resultSet, RCV_MSNY_ID));
        referral.setReceivingStewardCmisId(extractLongObject(resultSet, RCV_CMIS_ID));
        referral.setClaimDate(resultSet.getDate(CLAIM_DT));
        referral.setCreateDate(resultSet.getDate(CRT_DT));
        referral.setReferrer(extractReferrer(resultSet));

        if (referral.isEmpty()) {
            return null;
        }

        return referral;
    }

    private Referrer extractReferrer(ResultSet resultSet) throws SQLException {
        Referrer referrer = new Referrer();
        referrer.setEmailAddress(resultSet.getString(EMAIL_ADDR));
        referrer.setFirstName(resultSet.getString(FIRST_NAME));
        referrer.setLastName(resultSet.getString(LAST_NAME));
        referrer.setPhoneNumber(resultSet.getString(PHN_NBR));
        return referrer.isEmpty() ? null : referrer;
    }

    public static String getSelectStatement(String personReferralPrefix, String referralGroupPrefix)
    {
        StringBuilder sb = new StringBuilder(256);

        sb.append(personReferralPrefix).append(".").append(RFRL_STAT_ID).append(",");
        sb.append(personReferralPrefix).append(".ESCALATE_DT AS ").append(ESCALATE_DT).append(",");
        sb.append(personReferralPrefix).append(".owner_msny_id AS ").append(OWNER_MSNY_ID).append(",");
        sb.append(personReferralPrefix).append(".owner_stwrd_cmis_id AS ").append(OWNER_CMIS_ID).append(",");
        sb.append(personReferralPrefix).append(".owner_org_id AS ").append(OWNER_ORG_ID).append(",");
        sb.append(referralGroupPrefix).append(".").append(NOTE).append(",");
        sb.append(referralGroupPrefix).append(".rcv_pros_area_id AS ").append(RCV_PROS_AREA_ID).append(",");
        sb.append(referralGroupPrefix).append(".rcv_org_id AS ").append(RCV_ORG_ID).append(",");
        sb.append(referralGroupPrefix).append(".rcv_msny_id AS ").append(RCV_MSNY_ID).append(",");
        sb.append(referralGroupPrefix).append(".rcv_stwrd_cmis_id AS ").append(RCV_CMIS_ID).append(",");
        sb.append(referralGroupPrefix).append(".claim_dt AS ").append(CLAIM_DT).append(",");
        sb.append(referralGroupPrefix).append(".crt_dt AS ").append(CRT_DT).append(",");
        sb.append(referralGroupPrefix).append(".rfrr_first_nm AS ").append(FIRST_NAME).append(",");
        sb.append(referralGroupPrefix).append(".rfrr_last_nm AS ").append(LAST_NAME).append(",");
        sb.append(referralGroupPrefix).append(".").append(PHN_NBR).append(",");
        sb.append(referralGroupPrefix).append(".").append(EMAIL_ADDR);

        return sb.toString();
    }

    public static String getJoinStatement(String personPrefix, String personReferralPrefix, String referralGroupPrefix)
    {
        StringBuilder sb = new StringBuilder(128);

        sb.append(" LEFT JOIN ims.person_rfrl ").append(personReferralPrefix);
        sb.append(" ON ").append(personPrefix).append(".person_id = ").append(personReferralPrefix).append(".person_id AND ")
                .append(personReferralPrefix).append(".msny_visit_yn = 'Y' ");
        sb.append(" LEFT JOIN ims.rfrl_grp ").append(referralGroupPrefix);
        sb.append(" ON ").append(personReferralPrefix).append(".rfrl_grp_id = ").append(referralGroupPrefix).append(".rfrl_grp_id ");

        return sb.toString();
    }
}
