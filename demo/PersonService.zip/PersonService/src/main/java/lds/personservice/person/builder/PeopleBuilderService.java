package lds.personservice.person.builder;

import lds.personservice.person.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.util.CollectionUtils;

import javax.inject.Named;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Named
public class PeopleBuilderService {

    private final List<ConcretePeopleBuilder> possibleBuilders;

    @Autowired
    public PeopleBuilderService(PeopleCommitmentBuilder commitmentBuilder,
                                 PeopleDropNoteBuilder dropNoteBuilder,
                                 PeopleFellowshipBuilder fellowshipBuilder){
        possibleBuilders = Arrays.asList(
                commitmentBuilder,
                dropNoteBuilder,
                fellowshipBuilder
        );
    }

    public PeopleBuilder getBuilder(){
        return new PeopleBuilderImpl();
    }

    private class PeopleBuilderImpl implements PeopleBuilder {

        public static final int TIMEOUT = 6 * 60 * 1000;
        private BuilderParams params;
        private List<Person> people;
        private List<ConcretePeopleBuilder> builders;


        @Override
        public PeopleBuilder withParams(BuilderParams params) {
            this.params = params;
            if (this.params != null) {
                initializeBuilders();
            }
            return this;
        }

        private void initializeBuilders() {
            possibleBuilders.stream()
                    .filter(builder -> builder.appliesToBuilder(params))
                    .forEach(builder -> addBuilder(builder));
        }

        private void addBuilder(ConcretePeopleBuilder builder) {
            if(builders == null){
                builders = new LinkedList<>();
            }
            builders.add(builder);
        }

        @Override
        public PeopleBuilder withPeople(List<Person> people) {
            this.people = people;
            return this;
        }

        @Override
        public PeopleBuilder construct() {
            if (!CollectionUtils.isEmpty(builders)) {
                List<AsyncResult<List<Person>>> results = new LinkedList<>();
                builders.parallelStream()
                        .forEach(builder -> results.add(new AsyncResult<>(builder.build(people))));
                results.forEach(result -> result.get(TIMEOUT, TimeUnit.MILLISECONDS));
            }

            return this;
        }

        @Override
        public List<Person> getResults() {
            return people;
        }
    }
}
