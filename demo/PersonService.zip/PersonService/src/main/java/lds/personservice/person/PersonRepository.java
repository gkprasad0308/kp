package lds.personservice.person;

import static java.util.Objects.requireNonNull;

import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import lds.personservice.contactinfo.ContactInfoRowMapper;
import lds.personservice.person.referral.ReferralMapper;
import lds.prsms.utils.UUIDGenerator;
import lds.prsms.utils.errors.ServiceException;
import lds.stack.logging.slf4j.Logging;

@Repository
public class PersonRepository {

    private static final Logger LOGGER = Logging.getLogger();

    private final NamedParameterJdbcTemplate namedTemplate;

    private final JdbcTemplate jdbcTemplate;

    private final PersonInsertSql personInsertSql;

    private final PersonUpdateSql personUpdateSql;

    private final DeletePersonSproc deletePersonSproc;

    private final UUIDGenerator uuidGenerator;

    private static final String BASE_PERSON_SELECT = "SELECT " + PersonRowMapper.getSelectStatement("p") + ","
            + ContactInfoRowMapper.getSelectStatement() + ","
            + ReferralMapper.getSelectStatement("pr", "rg")
            + " FROM ims.person_mstr p "
            + ContactInfoRowMapper.getJoinStatement("p")
            + ReferralMapper.getJoinStatement("p", "pr", "rg");

    @Inject
    public PersonRepository(final NamedParameterJdbcTemplate namedTemplate, final JdbcTemplate jdbcTemplate,
            final PersonInsertSql personInsertSql, final PersonUpdateSql personUpdateSql, final DeletePersonSproc deletePersonSproc, final UUIDGenerator uuidGenerator) {
        this.namedTemplate = requireNonNull(namedTemplate, "namedTemplate shall not be null");
        this.jdbcTemplate = requireNonNull(jdbcTemplate, "jdbcTemplate shall not be null");
        this.personInsertSql = requireNonNull(personInsertSql, "personInsertSql shall not be null");
        this.personUpdateSql = requireNonNull(personUpdateSql, "personUpdateSql shall not be null");
        this.deletePersonSproc = requireNonNull(deletePersonSproc, "deletePersonSproc shall not be null");
        this.uuidGenerator = requireNonNull(uuidGenerator, "uuidGenerator shall not be null");
    }

    public Person getPersonById(Long personId) {
        String sql = BASE_PERSON_SELECT + " WHERE p.person_id = :personId";
        return getPersonForSqlAndParam(sql, new MapSqlParameterSource().addValue("personId", personId));
    }

    public Person getPersonByGuid(String personGuid) {
        String sql = BASE_PERSON_SELECT + " WHERE p.client_guid = :personGuid";
        return getPersonForSqlAndParam(sql, new MapSqlParameterSource().addValue("personGuid", personGuid));
    }

    private Person getPersonForSqlAndParam(String sql, MapSqlParameterSource params) {
        List<Person> persons = namedTemplate.query(sql, params, new PersonExtractor());
        if (CollectionUtils.isEmpty(persons)) {
            throw new ServiceException(HttpStatus.BAD_REQUEST, "person.notFound");
        } else {
            return persons.get(0); //there should only ever be one but we are reusing the extractor that returns a list
        }
    }
    
    public boolean personWithGuidExists(final String personGuid) {
        String sql = "SELECT count(*) FROM ims.person_mstr p WHERE p.client_guid = :personGuid";
        final int count = namedTemplate.queryForObject(sql, new MapSqlParameterSource().addValue("personGuid", personGuid), Integer.class);

        return count > 0;
    }

    public List<Person> getPersonsByIds(List<Long> personIds) {
        String sql = "SELECT " + PersonRowMapper.getSelectStatement("p") + ","
                     + ContactInfoRowMapper.getSelectStatement() + ","
                     + ReferralMapper.getSelectStatement("pr", "rg")
                     + " FROM ims.person_mstr p "
                     + ContactInfoRowMapper.getJoinStatement("p")
                     + ReferralMapper.getJoinStatement("p", "pr", "rg")
                     + " WHERE p.person_id in (:personIds)";
        List<Person> persons = namedTemplate.query(sql, new MapSqlParameterSource().addValue("personIds", personIds), new PersonExtractor());
        if (persons == null) {
            throw new ServiceException(HttpStatus.BAD_REQUEST, "persons.notFound");
        }

        return persons;
    }

    public void createPerson(Person person) {
        person.setServerId(getNextPersonId());
        LOGGER.info(String.format("Assigning person id %d", person.getServerId()));
        if (StringUtils.isEmpty(person.getGuid())) {
            person.setGuid(generateAcceptableId());
        }

        personInsertSql.updateByNamedParam(personInsertSql.getParamsUsing(person));
    }

    public void updatePerson(Person person) {
        personUpdateSql.updateByNamedParam(personUpdateSql.getParamsUsing(person));
    }

    public void deletePerson(Long personId) {
        deletePersonSproc.getStoredProc().execute(deletePersonSproc.getParametersUsing(personId));
    }

    private Long getNextPersonId() {
        return jdbcTemplate.queryForObject("SELECT ims.person_sq.nextval FROM dual", Long.class);
    }

    public Long getPersonIdByGuid(String guid) {
        String sql = "SELECT person_id FROM ims.person_mstr WHERE client_guid = :guid";

        List<Long> ids = jdbcTemplate.queryForList(sql, new Object[]{guid}, Long.class);

        final Long id = ids.stream()
           .filter(Objects::nonNull)
           .findFirst()
           .orElse(null);

        return id;
    }

    private String generateAcceptableId() {
        final String result = Stream.generate(uuidGenerator::getAsString)
              .filter(g -> !personWithGuidExists(g))
              .limit(5)
              .findFirst()
              .orElseThrow(() -> new ServiceException(HttpStatus.INTERNAL_SERVER_ERROR, "error.post.person.ungeneratable.guid"));

        return result;
    }
}
