package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.PreferredContactTypeValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PreferredContactTypeValidator.class)
@ConstraintDescription("If provided, the preferred contact type must match those returned by the options endpoint")
public @interface ValidPreferredContactType {

    String message() default "{lds.personservice.util.validation.constraints.UnsupportedValue.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
