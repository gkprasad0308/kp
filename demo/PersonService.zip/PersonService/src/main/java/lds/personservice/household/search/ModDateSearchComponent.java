package lds.personservice.household.search;


import lds.personservice.household.ListParams;
import org.apache.commons.lang3.ArrayUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ModDateSearchComponent implements SearchComponent{

    private String[] prefixis;

    public ModDateSearchComponent(String... prefixis){
        this.prefixis = prefixis;
    }

    @Override
    public SearchFragment buildFragment(ListParams listParams) {
        SearchFragment fragment = null;
        if(listParams != null && listParams.getModDate() != null && !ArrayUtils.isEmpty(prefixis)){

            List<String> fragments = Arrays.asList(prefixis).stream()
                    .map(prefix -> prefix + ".mod_dt >= :modDate")
                    .collect(Collectors.toList());

            fragment = new SearchFragment()
                    .withWhereFragment(" ( " + String.join(" OR ", fragments) + " ) ")
                    .addParameter("modDate", listParams.getModDate());
        }
        return fragment;
    }
}
