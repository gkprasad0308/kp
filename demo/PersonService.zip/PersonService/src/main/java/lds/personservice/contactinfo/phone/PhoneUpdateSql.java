package lds.personservice.contactinfo.phone;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.stereotype.Component;

@Component
public class PhoneUpdateSql extends SqlUpdate
{

    public static final String PHN_NUMBER = "phnNbr";
    public static final String COMM_TYPE_ID = "commTypeId";
    public static final String PERSON_ID = "personId";

    @Autowired
    public PhoneUpdateSql(DataSource dataSource)
    {
        init(dataSource);
    }

    private void init(DataSource dataSource)
    {
        setDataSource(dataSource);
        setSql(" UPDATE ims.person_phn SET " +
                "       phn_nbr = :" + PHN_NUMBER +
                " WHERE comm_t_id = :" + COMM_TYPE_ID +
                "   AND person_id = :" + PERSON_ID);

        declareParameter(new SqlParameter(PHN_NUMBER, Types.VARCHAR));
        declareParameter(new SqlParameter(COMM_TYPE_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PERSON_ID, Types.NUMERIC));
    }

    public Map<String, Object> getParamsUsing(Phone phone, Long personId)
    {
        return new MapSqlParameterSource()
              .addValue(PHN_NUMBER, phone.getNumber())
              .addValue(COMM_TYPE_ID, phone.getType().id())
              .addValue(PERSON_ID, personId)
              .getValues();
    }
}
