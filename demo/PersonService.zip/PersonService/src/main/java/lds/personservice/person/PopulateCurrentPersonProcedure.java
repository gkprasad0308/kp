package lds.personservice.person;

import java.sql.Types;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

@Component
public class PopulateCurrentPersonProcedure
{

    private final DataSource dataSource;

    @Autowired
    public PopulateCurrentPersonProcedure(DataSource dataSource)
    {
        this.dataSource = dataSource;
    }

    /**
     * Gets the SimpleJdbcCall in order to call the stored procedure.
     *
     * @return a SimpleJdbcCall object.
     */
    public SimpleJdbcCall getStoredProc()
    {
        return new SimpleJdbcCall(dataSource)
              .withSchemaName("ims")
              .withCatalogName("ims_pros_area_mgmt")
              .withProcedureName("populate_crnt_person_gtt");
    }

    /**
     * Builds the parameters to pass into the stored procedure call.
     *
     * @param assignmentArea
     *
     * @return the parameters to execute the stored procedure.
     */
    public SqlParameterSource getParametersUsing(long assignmentArea)
    {
        return new MapSqlParameterSource()
              .addValue("i_pros_area_id", assignmentArea, Types.NUMERIC);
    }
}
