package lds.personservice.options;

import lds.stack.logging.jdk.Logging;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.logging.Logger;

@Repository
public class ContactTypeRepository implements OptionsRepository<ContactType>
{

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private JdbcTemplate template;

    @Override
    public List<ContactType> getOptions(int langId)
    {
        LOGGER.info("Getting contact types");
        String sql = "SELECT type.cntct_t_id, type.cntct_t_cd, str.str as cntct_t_dscr "
              + " FROM ims.z_cntct_t type"
              + " JOIN ims.afab_str_key strKey ON ('contactType.' || type.cntct_t_cd) = strKey.afab_str_key"
              + " JOIN ims.afab_str str ON strKey.afab_str_key_id = str.afab_str_key_id"
              + " WHERE str.lang_id = ? ";
        return template.query(sql, new Object[]{langId}, (rs, rowNum) -> {
            ContactType contactType = new ContactType();

            contactType.setId(rs.getInt("cntct_t_id"));
            contactType.setCode(rs.getString("cntct_t_cd"));
            contactType.setName(rs.getString("cntct_t_dscr"));

            return contactType;
        });
    }

    public boolean exists(int contactTypeId)
    {
        return template.queryForObject(
              "SELECT count(*) FROM ims.z_cntct_t WHERE cntct_t_id = ?",
              new Object[]{contactTypeId},
              Integer.class
        ) > 0;
    }
}
