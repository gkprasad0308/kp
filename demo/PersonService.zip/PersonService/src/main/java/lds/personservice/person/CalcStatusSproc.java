package lds.personservice.person;

import lds.personservice.util.SimpleSproc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Date;

@Component
public class CalcStatusSproc implements SimpleSproc
{

    public static final String SCHEMA_NAME = "ims";
    public static final String CATALOG_NAME = "ims_person_stat_pkg";
    public static final String PROCEDURE_NAME = "update_status_by_person";
    public static final String PERSON_IDS = "i_person_ids";
    public static final String I_NEW_MOD_DT = "i_new_mod_dt";
    private final DataSource dataSource;

    @Autowired
    public CalcStatusSproc(DataSource dataSource)
    {
        this.dataSource = dataSource;
    }

    @Override
    public SimpleJdbcCall getStoredProc()
    {
        return new SimpleJdbcCall(dataSource)
              .withSchemaName(SCHEMA_NAME)
              .withCatalogName(CATALOG_NAME)
              .withProcedureName(PROCEDURE_NAME)
              .declareParameters(
                    new SqlParameter(PERSON_IDS, Types.VARCHAR),
                    new SqlParameter(I_NEW_MOD_DT, Types.DATE)
              );
    }

    public MapSqlParameterSource getParametersUsing(String personIds)
    {
        return new MapSqlParameterSource()
              .addValue(PERSON_IDS, personIds)
              .addValue(I_NEW_MOD_DT, new Date());
    }
}
