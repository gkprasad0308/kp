package lds.personservice.util;


import java.sql.ResultSet;
import java.sql.SQLException;

public class BaseRowMapper {

    public Long extractLongObject(ResultSet rs, String column) throws SQLException {
        Long value = null;
        if(rs.getObject(column) != null){
           value = rs.getLong(column);
        }
        return value;
    }

    public Integer extractIntegerObject(ResultSet rs, String column) throws SQLException {
        Integer value = null;
        if(rs.getObject(column) != null){
            value = rs.getInt(column);
        }
        return value;
    }

    public Boolean extractBooleanObject(ResultSet rs, String column) throws SQLException{
        Boolean value = null;
        if(rs.getObject(column) != null){
            value = "Y".equals(rs.getString(column));
        }
        return value;
    }
}
