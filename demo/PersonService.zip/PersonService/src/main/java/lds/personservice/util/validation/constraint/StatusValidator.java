package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidStatus;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class StatusValidator implements ConstraintValidator<ValidStatus, Integer> {

    @Autowired
    private OptionsValidationService optionsService;

    @Override
    public void initialize(ValidStatus validStatus) {
        // TODO consider initializing the list of statuses and consider checking against that list
    }

    @Override
    public boolean isValid(Integer statusValue, ConstraintValidatorContext constraintValidatorContext) {
        return statusValue == null || optionsService.statusExists(statusValue);
    }
}
