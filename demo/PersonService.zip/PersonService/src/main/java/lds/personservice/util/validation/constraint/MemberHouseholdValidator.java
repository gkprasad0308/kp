package lds.personservice.util.validation.constraint;


import lds.personservice.household.Household;
import lds.personservice.util.validation.annotation.ValidMemberHousehold;
import lds.personservice.util.validation.service.HouseholdValidationService;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class MemberHouseholdValidator implements ConstraintValidator<ValidMemberHousehold, Household>{

    @Inject
    private HouseholdValidationService service;

    @Override
    public void initialize(ValidMemberHousehold validMemberHousehold) {
        // isValid does the work
    }

    @Override
    public boolean isValid(Household household, ConstraintValidatorContext constraintValidatorContext) {
        boolean result = household.getMissionaryId() == null && household.getStewardCmisId() == null;

        if(!result){
            result = !household.hasCmisIdMember();
            if(result && !StringUtils.isEmpty(household.getGuid())){
                Household original = service.getOriginal(household.getGuid());
                result = original == null || !original.hasCmisIdMember();
            }
        }

        return result;
    }
}
