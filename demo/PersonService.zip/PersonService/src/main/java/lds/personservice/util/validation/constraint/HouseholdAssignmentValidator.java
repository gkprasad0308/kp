package lds.personservice.util.validation.constraint;

import lds.personservice.household.Household;
import lds.personservice.util.validation.annotation.ValidHouseholdAssignment;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class HouseholdAssignmentValidator implements ConstraintValidator<ValidHouseholdAssignment, Household> {

    @Override
    public void initialize(ValidHouseholdAssignment validHouseholdAssignment) {
        // isValid does the work
    }

    @Override
    public boolean isValid(Household household, ConstraintValidatorContext constraintValidatorContext) {
        List<Boolean> truthList = Arrays.asList(
                household.getOrgId() != null,
                household.getMissionaryId() != null,
                household.getStewardCmisId() != null
        );

        boolean results = truthList.stream().filter(val -> val).collect(Collectors.toList()).size() <= 1;

        return results;
    }
}
