package lds.personservice.person;

import java.sql.ResultSet;
import java.sql.SQLException;

import lds.personservice.util.BaseRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

public class PersonRowMapper extends BaseRowMapper implements RowMapper<Person>
{

    public static final String HSHLD_ID = "person_hshld_id";
    public static final String PERSON_ID = "person_id";
    public static final String DEL_YN = "person_del_yn";
    public static final String FIRST_NM = "person_first_nm";
    public static final String LAST_NM = "person_last_nm";
    public static final String AGE_C_ID = "person_age_c_id";
    public static final String GENDER = "person_gender";
    public static final String PERSON_STAT_ID = "person_stat_id";
    public static final String CRT_DT = "person_crt_dt";
    public static final String MOD_DT = "person_mod_dt";
    public static final String NOTE = "person_note";
    public static final String AFAB_FOCUS_PERSON_YN = "person_afab_focus_person_yn";
    public static final String CMIS_ID = "person_cmis_id";
    public static final String PROS_AREA_ID = "person_pros_area_id";
    public static final String CLIENT_GUID = "person_client_guid";
    public static final String CONVERT_YN = "person_convert_yn";
    public static final String FIND_ID = "person_find_id";
    public static final String PREF_LANG_ID = "person_pref_lang_id";
    public static final String PREF_CNTCT_T_ID = "person_pref_cntct_t_id";
    public static final String FIND_DTL_ID = "person_find_dtl_id";

    @Override
    public Person mapRow(ResultSet resultSet, int i) throws SQLException
    {
        Person person = new Person();

        person.setServerId(resultSet.getLong(PERSON_ID));
        person.setHouseholdServerId(resultSet.getLong(HSHLD_ID));
        person.setDeleted("Y".equals(resultSet.getString(DEL_YN)));
        person.setFirstName(resultSet.getString(FIRST_NM));
        person.setLastName(resultSet.getString(LAST_NM));
        person.setAgeCatId(extractIntegerObject(resultSet, AGE_C_ID));
        person.setGender(resultSet.getString(GENDER));
        person.setStatus(resultSet.getInt(PERSON_STAT_ID));
        person.setCreateDate(resultSet.getTimestamp(CRT_DT));
        person.setModDate(resultSet.getTimestamp(MOD_DT));
        person.setNote(resultSet.getString(NOTE));
        person.setFocusPerson("Y".equals(resultSet.getString(AFAB_FOCUS_PERSON_YN)));
        person.setCmisId(extractLongObject(resultSet, CMIS_ID));
        person.setProsAreaId(extractLongObject(resultSet, PROS_AREA_ID));
        person.setGuid(resultSet.getString(CLIENT_GUID));
        person.setIsConvert("Y".equals(resultSet.getString(CONVERT_YN)));
        person.setContactSource(resultSet.getInt(FIND_ID));
        person.setPreferredLangId(extractIntegerObject(resultSet, PREF_LANG_ID));
        person.setPreferredContactType(extractIntegerObject(resultSet, PREF_CNTCT_T_ID));
        person.setContactSourceDtl(extractIntegerObject(resultSet, FIND_DTL_ID));

        // TODO remove hard coding for member status. This can be done be checking against the z_person_stat where parent_stat_id = 8
        person.setMember(person.getStatus() == 8 || (person.getStatus() >= 40 && person.getStatus() <= 50));

        return person;
    }

    public static String getSelectStatement(String prefix)
    {
        StringBuilder sb = new StringBuilder(256);
        String finalPrefix = prefix;
        if (StringUtils.isEmpty(finalPrefix)) {
            finalPrefix = "";
        } else if (!finalPrefix.endsWith(".")) {
            finalPrefix += ".";
        }

        sb.append(finalPrefix).append(PERSON_ID).append(",");
        sb.append(finalPrefix).append("hshld_id AS ").append(HSHLD_ID).append(",");
        sb.append(finalPrefix).append("del_yn AS ").append(DEL_YN).append(",");
        sb.append(finalPrefix).append("first_nm AS ").append(FIRST_NM).append(",");
        sb.append(finalPrefix).append("last_nm AS ").append(LAST_NM).append(",");
        sb.append(finalPrefix).append("age_c_id AS ").append(AGE_C_ID).append(",");
        sb.append(finalPrefix).append("gender AS ").append(GENDER).append(",");
        sb.append(finalPrefix).append(PERSON_STAT_ID).append(",");
        sb.append(finalPrefix).append("crt_dt AS ").append(CRT_DT).append(",");
        sb.append(finalPrefix).append("mod_dt AS ").append(MOD_DT).append(",");
        sb.append(finalPrefix).append("note AS ").append( NOTE).append(",");
        sb.append(finalPrefix).append("afab_focus_person_yn AS ").append(AFAB_FOCUS_PERSON_YN).append(",");
        sb.append(finalPrefix).append("cmis_id AS ").append(CMIS_ID).append(",");
        sb.append(finalPrefix).append("pros_area_id AS ").append( PROS_AREA_ID).append(",");
        sb.append(finalPrefix).append("client_guid AS ").append(CLIENT_GUID).append(",");
        sb.append(finalPrefix).append("convert_yn AS ").append(CONVERT_YN).append(",");
        sb.append(finalPrefix).append("find_id AS ").append(FIND_ID).append(",");
        sb.append(finalPrefix).append("pref_lang_id AS ").append(PREF_LANG_ID).append(",");
        sb.append(finalPrefix).append("pref_cntct_t_id AS ").append(PREF_CNTCT_T_ID).append(",");
        sb.append(finalPrefix).append("find_dtl_id AS ").append(FIND_DTL_ID);

        return sb.toString();
    }
}
