package lds.personservice.options;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
public class OptionsService
{

    @Autowired
    private SourceRepository sourceRepository;

    @Autowired
    private AgeCategoryRepository ageCategoryRepository;

    @Autowired
    private ContactTypeRepository contactTypeRepository;

    @Autowired
    private LanguageCodeRepository languageCodeRepository;

    @Autowired
    private StatusRepository statusRepository;

    public Options getOptions(final String langCd)
    {
        int langId = languageCodeRepository.getLangIdFromLocale(langCd);

        Options options = new Options();

        options.setAgeCategories(getOptionsFromRepo(langId, ageCategoryRepository));
        options.setContactTypes(getOptionsFromRepo(langId, contactTypeRepository));
        options.setLanguages(getOptionsFromRepo(langId, languageCodeRepository));
        options.setSources(getOptionsFromRepo(langId, sourceRepository));
        options.setStatuses(getOptionsFromRepo(langId, statusRepository));

        return options;
    }

    public List getOptionsFromRepo(final int langId, final OptionsRepository repo){
        List<Option> options = repo.getOptions(langId);
        if(CollectionUtils.isEmpty(options) && langId != LanguageCodeRepository.DEFAULT_LANG_ID){
            options = repo.getOptions(LanguageCodeRepository.DEFAULT_LANG_ID);
        }
        return options;
    }

    public List getAgeCategories(String langCd)
    {
        return getOptionsFromRepo(languageCodeRepository.getLangIdFromLocale(langCd), ageCategoryRepository);
    }

    public List<ContactType> getContactTypes(String langCd)
    {
        return getOptionsFromRepo(languageCodeRepository.getLangIdFromLocale(langCd), contactTypeRepository);
    }

    public List<Source> getSources(String langCd)
    {
        return getOptionsFromRepo(languageCodeRepository.getLangIdFromLocale(langCd), sourceRepository);
    }

    public List<Status> getStats(String langCd)
    {
        return getOptionsFromRepo(languageCodeRepository.getLangIdFromLocale(langCd), statusRepository);
    }

    public List<Language> getLanguages(String langCd)
    {
        return getOptionsFromRepo(languageCodeRepository.getLangIdFromLocale(langCd), languageCodeRepository);
    }
}
