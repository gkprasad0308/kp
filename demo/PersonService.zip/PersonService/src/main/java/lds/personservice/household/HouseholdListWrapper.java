package lds.personservice.household;

import java.util.LinkedList;
import java.util.List;

public class HouseholdListWrapper
{

    private List<Household> households;

    public HouseholdListWrapper()
    {
        this.households = new LinkedList<>();
    }

    public HouseholdListWrapper(List<Household> households)
    {
        this.households = households;
    }

    public List<Household> getHouseholds()
    {
        return households;
    }

    public void setHouseholds(List<Household> households)
    {
        this.households = households;
    }
}
