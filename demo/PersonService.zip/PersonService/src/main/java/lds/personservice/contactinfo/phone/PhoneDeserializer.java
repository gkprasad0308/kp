package lds.personservice.contactinfo.phone;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;

public class PhoneDeserializer extends JsonDeserializer<PhoneTypes>
{

    @Override
    public PhoneTypes deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException
    {
        String value = jsonParser.getValueAsString().toUpperCase();
        return PhoneTypes.forValue(value);
    }
}
