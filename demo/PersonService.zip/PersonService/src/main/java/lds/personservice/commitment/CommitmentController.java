package lds.personservice.commitment;

import lds.prsms.utils.validation.ValidationGroups;
import lds.stack.spring.web.Link;
import lds.stack.spring.web.ResourceDecorator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

import static org.springframework.web.bind.annotation.RequestMethod.*;

@RestController
@RequestMapping(value = "${lds.api.resources.commitments.href}")
public class CommitmentController
{

    @Autowired
    private CommitmentService commitmentService;

    /**
     * Deletes the {@link Commitment} resource with the given ID.
     *
     * @param commitmentGuid
     *
     * @return if successful, a 200(OK) response that encloses the now deleted entity. If there is no commitment with that ID, this
     *         method will return a 404.
     */
    @RequestMapping(value = "/{commitmentId}", method = DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Commitment delete(@PathVariable("commitmentId") String commitmentGuid)
    {
        Commitment result = commitmentService.deleteCommitment(commitmentGuid);
        return ResourceDecorator.forResource(result).link(Link.toSelf()).decorate();
    }

    /**
     * Creates the given commitment. The commitment JSON must be submitted in the POST body and must include a personId, a
     * teachingItemId, and an inviteDate.
     *
     * @param commitmentEntity
     *
     * @return the commitment object that has been created, including an ID.
     */
    @RequestMapping(method = POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Commitment post(@RequestBody(required = false) @Validated(ValidationGroups.Post.class) @Valid Commitment commitmentEntity)
    {
        Commitment result = commitmentService.createCommitment(commitmentEntity);
        return ResourceDecorator.forResource(result).link(Link.toSelf()).decorate();
    }

    /**
     * Updates the given commitment. The commitment JSON must be submitted in the POST body and must include a personId, a
     * teachingItemId, and an inviteDate.
     *
     * @param commitmentEntity
     * @param guid
     *
     * @return the commitment object that has been updated, including an ID.
     */
    @RequestMapping(method = PUT, value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Commitment put(@RequestBody(required = false) @Validated(ValidationGroups.Put.class) @Valid Commitment commitmentEntity, @PathVariable("id") String guid)
    {
        Commitment result = commitmentService.updateCommitment(commitmentEntity, guid);
        return ResourceDecorator.forResource(result).link(Link.toSelf()).decorate();
    }
}
