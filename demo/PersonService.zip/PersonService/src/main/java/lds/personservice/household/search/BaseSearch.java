package lds.personservice.household.search;

import lds.personservice.household.HouseholdExtractor;
import lds.personservice.household.InclusionParams;
import lds.personservice.household.ListParams;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Objects.requireNonNull;

public abstract class BaseSearch {

    public static final String PERSON_PREFIX = "p";
    public static final String HOUSEHOLD_PREFIX = "h";
    protected StringBuilder select;
    protected StringBuilder from;
    protected List<String> whereSegments;
    protected final ListParams listParams;
    protected MapSqlParameterSource sqlParameters;
    private List<SearchComponent> searchComponents = Arrays.asList(
            new ContactInfoSearchComponent(PERSON_PREFIX),
            new ReferralInfoSearchComponent(PERSON_PREFIX),
            new ExcludeDeletedSearchComponent(PERSON_PREFIX, HOUSEHOLD_PREFIX),
            new ModDateSearchComponent(PERSON_PREFIX, HOUSEHOLD_PREFIX)
    );

    public BaseSearch(ListParams listParams){
        this.listParams = requireNonNull(listParams);
        select = new StringBuilder(128);
        from = new StringBuilder(128);
        whereSegments = new LinkedList<>();
        sqlParameters = new MapSqlParameterSource();
    }

    public String getSql(){
        buildMainSelect();
        buildInclusions();
        String where = whereSegments.stream().reduce("WHERE 1=1 ", (a, b) -> a + " AND " + b);

        String sql = select.toString() + from.toString() + where;
        return sql;
    }

    protected abstract void buildMainSelect();

    public HouseholdExtractor getExtractor() {
        HouseholdExtractor extractor = new HouseholdExtractor();
        if(!CollectionUtils.isEmpty(listParams.getInclusions())){
            extractor.useContactInfoRowMapper(listParams.getInclusions().contains(InclusionParams.CONTACT_INFO));
            extractor.useReferralRowMapper(listParams.getInclusions().contains(InclusionParams.REFERRAL_INFO));
        }
        return extractor;
    }

    public MapSqlParameterSource getSqlParameters() {
        return sqlParameters;
    }

    private void buildInclusions() {
        List<SearchFragment> fragments = searchComponents.stream()
                .map(component -> component.buildFragment(listParams))
                .filter(fragment -> fragment != null)
                .filter(fragment -> !fragment.isEmpty()).collect(Collectors.toList());

        applyFragments(fragments);
    }

    private void applyFragments(List<SearchFragment> fragments) {
        for(SearchFragment fragment: fragments){
            applySelectFragment(fragment);
            applyFromFragment(fragment);
            applyWhereFragment(fragment);
        }
    }

    private void applyWhereFragment(SearchFragment fragment) {
        if(!StringUtils.isEmpty(fragment.getWhereFragment())){
            whereSegments.add(fragment.getWhereFragment());
            sqlParameters.addValues(fragment.getParams().getValues());
        }
    }

    private void applyFromFragment(SearchFragment fragment) {
        if(!StringUtils.isEmpty(fragment.getFromFragment())){
            from.append(" ").append(fragment.getFromFragment()).append(" ");
        }
    }

    private void applySelectFragment(SearchFragment fragment) {
        if(!StringUtils.isEmpty(fragment.getSelectFragment())){
            select.append(",").append(fragment.getSelectFragment());
        }
    }
}
