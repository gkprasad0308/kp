package lds.personservice.person.drop;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lds.prsms.utils.validation.ValidationGroups;

@Entity
@Table(name = "PERSON_STWRD_DTL", schema = "IMS")
@SuppressWarnings("PersistenceUnitPresent")
@JsonPropertyOrder({"id", "note", "alertDate", "deleted", "modifiedDate"})
public class DropNote implements Serializable {

    private static final long serialVersionUID = 8717108604858254383L;

    @JsonIgnore
    @Id
    @SequenceGenerator(name = "personStewardDetailIdSequence", sequenceName = "IMS.person_stwrd_dtl_sq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "personStewardDetailIdSequence")
    @Column(name = "PERSON_STWRD_DTL_ID", nullable = false, precision = 19)
    private long id;
    @JsonIgnore
    @Column(name = "PERSON_STWRD_ID")
    private Long personStewardId;
    @JsonIgnore
    @Column(name = "PERSON_ID")
    private long personId;

    @NotNull
    @Size(max = 1000, groups = {ValidationGroups.Post.class, ValidationGroups.Put.class})
    @Column(name = "NOTE")
    private String note;
    @Column(name = "ALERT_DT")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date alertDate;
    @Column(name = "DEL_YN")
    private Boolean deleted;
    @Column(name = "MOD_DT")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date modifiedDate;
    @JsonProperty("id")
    @Column(name = "CLIENT_GUID")
    @JsonIgnore
    private String guid;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getPersonStewardId() {
        return personStewardId;
    }

    public void setPersonStewardId(long personStewardId) {
        this.personStewardId = personStewardId;
    }

    public long getPersonId() {
        return personId;
    }

    public void setPersonId(long personId) {
        this.personId = personId;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Date getAlertDate() {
        return alertDate;
    }

    public void setAlertDate(Date alertDate) {
        this.alertDate = alertDate;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }
}
