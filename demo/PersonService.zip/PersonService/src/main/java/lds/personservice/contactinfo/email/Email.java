package lds.personservice.contactinfo.email;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lds.prsms.utils.validation.ValidationGroups;
import org.apache.commons.lang3.builder.CompareToBuilder;

import java.util.Objects;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Email
{

    @NotNull(groups = {ValidationGroups.Put.class, ValidationGroups.Post.class})
    private EmailTypes type;
    @Size(max = 255, groups = {ValidationGroups.Put.class, ValidationGroups.Post.class})
    private String address;

    public Email()
    {
        // default constructor
    }

    public Email(EmailTypes type, String address)
    {
        this.type = type;
        this.address = address;
    }

    public EmailTypes getType()
    {
        return type;
    }

    @JsonDeserialize(using = EmailDeserializer.class)
    public void setType(EmailTypes type)
    {
        this.type = type;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    @Override
    public int hashCode(){
        return Objects.hash(37, this.getType(), this.getAddress());
    }

    @Override
    public boolean equals(Object obj){
        if(obj == null || !(obj instanceof Email)){
            return false;
        }
        Email that = (Email)obj;

        return CompareToBuilder.reflectionCompare(this, that) == 0;
    }
}
