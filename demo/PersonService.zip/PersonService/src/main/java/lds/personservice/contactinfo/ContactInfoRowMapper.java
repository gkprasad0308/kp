package lds.personservice.contactinfo;

import java.sql.ResultSet;
import java.sql.SQLException;

import lds.personservice.contactinfo.email.EmailTypes;
import lds.personservice.contactinfo.phone.PhoneTypes;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

public class ContactInfoRowMapper implements RowMapper<ContactInfo>
{

    @Override
    public ContactInfo mapRow(ResultSet resultSet, int i) throws SQLException
    {
        ContactInfo contactInfo = new ContactInfo();

        for (PhoneTypes type : PhoneTypes.values()) {
            addNonNullContactType(resultSet, contactInfo, type);
        }
        for (EmailTypes type : EmailTypes.values()) {
            addNonNullContactType(resultSet, contactInfo, type);
        }

        if (CollectionUtils.isEmpty(contactInfo.getEmailAddresses()) && CollectionUtils.isEmpty(contactInfo.getPhoneNumbers())) {
            contactInfo = null;
        }
        return contactInfo;
    }

    private void addNonNullContactType(ResultSet resultSet, ContactInfo contactInfo, ContactInfoType type) throws SQLException
    {
        String value = resultSet.getString(type.name());
        if (!StringUtils.isEmpty(value)) {
            if (type instanceof PhoneTypes) {
                contactInfo.addPhone((PhoneTypes) type, value);
            } else if (type instanceof EmailTypes) {
                contactInfo.addEmail((EmailTypes) type, value);
            }
        }
    }

    public static String getSelectStatement()
    {
        StringBuilder sb = new StringBuilder(128);

        appendPhoneSelectTypes(sb);
        appendEmailSelectTypes(sb);
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    private static void appendEmailSelectTypes(StringBuilder sb) {
        for (EmailTypes type : EmailTypes.values()) {
            sb.append(type.name()).append(".email_addr AS ").append(type.name()).append(",");
        }
    }

    private static void appendPhoneSelectTypes(StringBuilder sb) {
        for (PhoneTypes type : PhoneTypes.values()) {
            sb.append(type.name()).append(".phn_nbr AS ").append(type.name()).append(",");
        }
    }

    public static String getJoinStatement(String personPrefix)
    {
        StringBuilder sb = new StringBuilder(128);

        for (PhoneTypes type : PhoneTypes.values()) {
            sb.append(" LEFT JOIN ims.person_phn ").append(type.name());
            sb.append(" ON ").append(type.name()).append(".person_id = ").append(personPrefix).append(".person_id");
            sb.append(" AND ").append(type.name()).append(".comm_t_id = ").append(type.id());
        }
        for (EmailTypes type : EmailTypes.values()) {
            sb.append(" LEFT JOIN ims.person_email ").append(type.name());
            sb.append(" ON ").append(type.name()).append(".person_id = ").append(personPrefix).append(".person_id");
            sb.append(" AND ").append(type.name()).append(".comm_t_id = ").append(type.id());
        }

        return sb.toString();
    }
}
