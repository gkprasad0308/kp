package lds.personservice.options;

public interface Option {

    int getId();
}
