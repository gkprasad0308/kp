package lds.personservice.options;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface AgeCategoryRepository extends JpaRepository<AgeCategory, Integer>, OptionsRepository<AgeCategory>
{

    @Override
    @Query(value = "select z.age_c_id, z.age_c_cd, str.str as AGE_C_DSCR"
          + "  from ims.Z_AGE_C z"
          + "  JOIN ims.afab_str_key strKey ON 'ageCategory.' || z.age_c_cd = strKey.afab_str_key"
          + "  JOIN ims.afab_str str ON strKey.afab_str_key_id = str.afab_str_key_id"
          + " WHERE str.lang_id = ?1", nativeQuery = true)
    List<AgeCategory> getOptions(int langid);
}
