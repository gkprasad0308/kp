package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidPreferredContactType;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class PreferredContactTypeValidator implements ConstraintValidator<ValidPreferredContactType, Integer> {

    @Autowired
    private OptionsValidationService optionsService;
    
    @Override
    public void initialize(ValidPreferredContactType validPreferredContactType) {
        // TODO consider intializing the list of possible contactTypes and check against that list
    }

    @Override
    public boolean isValid(Integer preferredContactType, ConstraintValidatorContext constraintValidatorContext) {
        return preferredContactType == null || optionsService.contactTypeExists(preferredContactType);
    }
}
