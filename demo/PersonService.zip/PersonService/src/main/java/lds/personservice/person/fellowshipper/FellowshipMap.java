package lds.personservice.person.fellowshipper;

import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FellowshipMap
{

    private final Map<Long, List<FellowshipData>> fellowshippersMap;
    private final Map<Long, List<FellowshipData>> fellowshippeesMap;

    public FellowshipMap()
    {
        fellowshippersMap = new HashMap<>();
        fellowshippeesMap = new HashMap<>();
    }

    public void mergeMaps(FellowshipMap fellowshipMap)
    {
        if(!CollectionUtils.isEmpty(fellowshipMap.fellowshippeesMap)) {
            fellowshippeesMap.putAll(fellowshipMap.fellowshippeesMap);
        }
        if(!CollectionUtils.isEmpty(fellowshipMap.fellowshippersMap)) {
            fellowshippersMap.putAll(fellowshipMap.fellowshippersMap);
        }
    }

    public void addFellowshipRelationship(long fellowshipperId, long investigatorId, FellowshipData data)
    {
        if(data == null){
            return;
        }

        if (data.getPersonServerId() == investigatorId) {
            addToMap(fellowshippersMap, fellowshipperId, data);
        } else {
            addToMap(fellowshippeesMap, investigatorId, data);
        }
    }

    private void addToMap(Map<Long, List<FellowshipData>> map, long key, FellowshipData value)
    {
        if (!map.containsKey(key)) {
            map.put(key, new ArrayList<>());
        }
        map.get(key).add(value);
    }

    public FellowshipInfo getFellowshipInfoForPerson(long personId)
    {
        if (!fellowshippeesMap.containsKey(personId) && !fellowshippersMap.containsKey(personId)) {
            return null;
        }
        FellowshipInfo info = new FellowshipInfo();
        info.setFellowshippers(fellowshippeesMap.get(personId));
        info.setFellowshippees(fellowshippersMap.get(personId));

        return info;
    }
}
