package lds.personservice.util;

import org.springframework.jdbc.core.simple.SimpleJdbcCall;

public interface SimpleSproc {

    SimpleJdbcCall getStoredProc();
}
