package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.PersonIdValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PersonIdValidator.class)
@ConstraintDescription("the person associated must match one that exists currently")
public @interface ValidPersonId {

    String message() default "{lds.personservice.util.validation.constraints.ValueOutOfBounds.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
