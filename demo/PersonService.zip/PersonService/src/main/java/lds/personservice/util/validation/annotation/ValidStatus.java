package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.StatusValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = StatusValidator.class)
@ConstraintDescription("Must be a proper status id that aligns with those on the options/status endpoint")
public @interface ValidStatus {

    String message() default "{lds.personservice.util.validation.constraints.UnsupportedValue.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
