package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.CmisIdMemberValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = CmisIdMemberValidator.class)
@ConstraintDescription("If a cmisId is provided, the person must not have a prosAreaId and must have a valid member id")
public @interface ValidCmisIdMember {

    String message()  default "{lds.personservice.util.validation.constraints.ValidCmisIdMember.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
