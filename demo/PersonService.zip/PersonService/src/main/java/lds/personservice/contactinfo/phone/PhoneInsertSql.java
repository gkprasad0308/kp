package lds.personservice.contactinfo.phone;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.stereotype.Component;

@Component
public class PhoneInsertSql extends SqlUpdate
{

    public static final String PERSON_ID = "personId";
    public static final String COMM_TYPE_ID = "commTypeId";
    public static final String PHN_NUMBER = "phnNumber";

    @Autowired
    public PhoneInsertSql(DataSource dataSource)
    {
        init(dataSource);
    }

    private void init(DataSource dataSource)
    {
        setDataSource(dataSource);
        setSql("INSERT INTO ims.person_phn ("
              + "   person_phn_id"
              + "   ,person_id"
              + "   ,comm_t_id"
              + "   ,phn_nbr"
              + " ) VALUES ("
              + "   ims.person_phn_sq.nextval "
              + "   ,:" + PERSON_ID
              + "   ,:" + COMM_TYPE_ID
              + "   ,:" + PHN_NUMBER
              + " )");

        declareParameter(new SqlParameter(PERSON_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(COMM_TYPE_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PHN_NUMBER, Types.VARCHAR));
    }

    public Map<String, Object> getParamsUsing(Long personId, Phone phone)
    {
        return new MapSqlParameterSource()
              .addValue(PERSON_ID, personId)
              .addValue(COMM_TYPE_ID, phone.getType().id())
              .addValue(PHN_NUMBER, phone.getNumber())
              .getValues();
    }
}
