package lds.personservice.household;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class HouseholdInsertSql extends AbstractHouseholdSqlUpdate
{

    @Autowired
    public HouseholdInsertSql(DataSource dataSource)
    {
        init(dataSource);
    }

    private void init(DataSource dataSource)
    {
        this.setDataSource(dataSource);
        this.setSql(" INSERT INTO ims.hshld_mstr ("
              + "   hshld_id"
              + "   ,del_yn"
              + "   ,addr"
              + "   ,msny_id"
              + "   ,org_id"
              + "   ,stwrd_cmis_id"
              + "   ,lat"
              + "   ,lng"
              + "   ,crt_dt"
              + "   ,mod_dt"
              + "   ,pin_drop_yn"
              + "   ,client_guid"
              + " ) VALUES ("
              + "   :" + HOUSEHOLD_ID
              + "   ,'N'"
              + "   ,:" + ADDR
              + "   ,:" + MSNY_ID
              + "   ,:" + ORG_ID
              + "   ,:" + STWRD_CMIS_ID
              + "   ,:" + LAT
              + "   ,:" + LNG
              + "   ,SYSDATE"
              + "   ,SYSDATE"
              + "   ,:" + PIN_DROP
              + "   ,:" + CLIENT_GUID
              + " ) ");

        declareParameter(new SqlParameter(HOUSEHOLD_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(ADDR, Types.VARCHAR));
        declareParameter(new SqlParameter(MSNY_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(ORG_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(STWRD_CMIS_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(LAT, Types.VARCHAR));
        declareParameter(new SqlParameter(LNG, Types.VARCHAR));
        declareParameter(new SqlParameter(PIN_DROP, Types.VARCHAR));
        declareParameter(new SqlParameter(CLIENT_GUID, Types.VARCHAR));
    }

    public Map<String, Object> getParamsUsing(Household household)
    {
        return new MapSqlParameterSource()
              .addValue(HOUSEHOLD_ID, household.getServerId())
              .addValue(ADDR, household.getAddress())
              .addValue(MSNY_ID, household.getMissionaryId())
              .addValue(ORG_ID, household.getOrgId())
              .addValue(STWRD_CMIS_ID, household.getStewardCmisId())
              .addValue(LAT, household.getLat())
              .addValue(LNG, household.getLng())
              .addValue(PIN_DROP, parseBoolean(household.getPinDropped()))
              .addValue(CLIENT_GUID, household.getGuid())
              .getValues();
    }
}
