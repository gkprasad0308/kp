package lds.personservice.contactinfo;

import java.util.logging.Logger;

import lds.personservice.contactinfo.email.Email;
import lds.personservice.contactinfo.email.EmailInsertSql;
import lds.personservice.contactinfo.email.EmailTypes;
import lds.personservice.contactinfo.email.EmailUpdateSql;
import lds.personservice.contactinfo.phone.Phone;
import lds.personservice.contactinfo.phone.PhoneInsertSql;
import lds.personservice.contactinfo.phone.PhoneTypes;
import lds.personservice.contactinfo.phone.PhoneUpdateSql;
import lds.stack.logging.jdk.Logging;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ContactInfoRepository
{

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private NamedParameterJdbcTemplate namedTemplate;

    @Autowired
    private PhoneInsertSql phoneInsertSql;

    @Autowired
    private PhoneUpdateSql phoneUpdateSql;

    @Autowired
    private EmailInsertSql emailInsertSql;

    @Autowired
    private EmailUpdateSql emailUpdateSql;

    public void insertPhone(Phone phone, Long personId)
    {
        LOGGER.info(String.format("Inserting phone type %s for person %d", phone.getType().name(), personId));
        phoneInsertSql.updateByNamedParam(phoneInsertSql.getParamsUsing(personId, phone));
    }

    public void updatePhone(Phone phone, Long personId)
    {
        LOGGER.info(String.format("Updating phone type %s for person %d", phone.getType().name(), personId));
        phoneUpdateSql.updateByNamedParam(phoneUpdateSql.getParamsUsing(phone, personId));
    }

    public void removePhone(PhoneTypes type, Long personId)
    {
        LOGGER.info(String.format("Removing phone type %s from person %d", type.name(), personId));
        String sql = "DELETE FROM ims.person_phn WHERE person_id = :personId AND comm_t_id = :commTypeId ";
        namedTemplate.update(sql, new MapSqlParameterSource().addValue("personId", personId).addValue("commTypeId", type.id()));
    }

    public void insertEmail(Email email, Long personId)
    {
        LOGGER.info(String.format("Inserting email type %s for person %d", email.getType().name(), personId));
        emailInsertSql.updateByNamedParam(emailInsertSql.getParamsUsing(email, personId));
    }

    public void updateEmail(Email email, Long personId)
    {
        LOGGER.info(String.format("Updating email type %s for person %d", email.getType().name(), personId));
        emailUpdateSql.updateByNamedParam(emailUpdateSql.getParamsUsing(email, personId));
    }

    public void removeEmail(EmailTypes type, Long personId)
    {
        LOGGER.info(String.format("Removing email type %s from person %d", type.name(), personId));
        String sql = "DELETE FROM ims.person_email WHERE person_id = :personId AND comm_t_id = :commTypeId ";
        namedTemplate.update(sql, new MapSqlParameterSource().addValue("personId", personId).addValue("commTypeId", type.id()));
    }
}
