package lds.personservice.util.validation.constraint;

import lds.personservice.household.Household;
import lds.personservice.util.validation.annotation.ValidPinDrop;
import org.springframework.util.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;


public class PinDropValidator implements ConstraintValidator<ValidPinDrop, Household> {

    @Override
    public void initialize(ValidPinDrop validPinDrop) {
        // isValid does the work
    }

    @Override
    public boolean isValid(Household household, ConstraintValidatorContext constraintValidatorContext) {
        boolean result = true;

        if(Boolean.TRUE.equals(household.getPinDropped())){
            result = !StringUtils.isEmpty(household.getLat()) &&
                    !StringUtils.isEmpty(household.getLng());
        }

        return result;
    }
}
