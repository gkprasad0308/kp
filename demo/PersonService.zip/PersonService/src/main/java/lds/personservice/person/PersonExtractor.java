package lds.personservice.person;

import lds.personservice.contactinfo.ContactInfoRowMapper;
import lds.personservice.person.referral.ReferralMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Tim Jacobsen on 10/9/2015.
 */
public class PersonExtractor implements ResultSetExtractor<List<Person>>
{

    private ContactInfoRowMapper contactInfoRowMapper;
    private ReferralMapper referralMapper;
    private PersonRowMapper mapper;

    public PersonExtractor(){
        contactInfoRowMapper = new ContactInfoRowMapper();
        referralMapper = new ReferralMapper();
        mapper = new PersonRowMapper();
    }

    @Override
    public List<Person> extractData(ResultSet rs) throws SQLException
    {
        List<Person> result = new ArrayList<>();
        while (rs.next()) {
            if (rs.getObject(PersonRowMapper.PERSON_ID) != null) {
                Person person = mapPerson(rs);
                result.add(person);
            }
        }
        return result;
    }

    private Person mapPerson(ResultSet rs) throws SQLException {
        int row = rs.getRow();
        Person p = mapper.mapRow(rs, row);
        p.setContactInfo(contactInfoRowMapper.mapRow(rs, row));
        p.setReferralInfo(referralMapper.mapRow(rs, row));
        return p;
    }
}
