package lds.personservice.household;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class HouseholdUpdateSql extends AbstractHouseholdSqlUpdate
{

    @Autowired
    public HouseholdUpdateSql(DataSource dataSource)
    {
        init(dataSource);
    }

    private void init(DataSource dataSource)
    {
        setDataSource(dataSource);
        setSql("UPDATE ims.hshld_mstr " +
                "  SET addr = :" + ADDR +
                "     ,lat = :" + LAT +
                "     ,lng = :" + LNG +
                "     ,mod_dt = SYSDATE " +
                "     ,pin_drop_yn = :" + PIN_DROP
              + " WHERE hshld_id = :" + HOUSEHOLD_ID);

        declareParameter(new SqlParameter(ADDR, Types.VARCHAR));
        declareParameter(new SqlParameter(LAT, Types.VARCHAR));
        declareParameter(new SqlParameter(LNG, Types.VARCHAR));
        declareParameter(new SqlParameter(PIN_DROP, Types.VARCHAR));
        declareParameter(new SqlParameter(HOUSEHOLD_ID, Types.NUMERIC));
    }

    public Map<String, Object> getParamsUsing(Household household)
    {
        return new MapSqlParameterSource()
              .addValue(ADDR, household.getAddress())
              .addValue(LAT, household.getLat())
              .addValue(LNG, household.getLng())
              .addValue(PIN_DROP, parseBoolean(household.getPinDropped()))
              .addValue(HOUSEHOLD_ID, household.getServerId())
              .getValues();
    }
}
