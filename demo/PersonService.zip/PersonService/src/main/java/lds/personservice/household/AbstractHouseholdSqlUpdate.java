package lds.personservice.household;


import lds.personservice.BaseUpdateSql;

public abstract class AbstractHouseholdSqlUpdate extends BaseUpdateSql{
    public static final String HOUSEHOLD_ID = "householdId";
    public static final String ADDR = "addr";
    public static final String MSNY_ID = "msnyId";
    public static final String ORG_ID = "orgId";
    public static final String STWRD_CMIS_ID = "stwrdCmisId";
    public static final String LAT = "lat";
    public static final String LNG = "lng";
    public static final String PIN_DROP = "pinDrop";
    public static final String CLIENT_GUID = "clientGuid";
}
