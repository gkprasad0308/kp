package lds.personservice.person.fellowshipper;

import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FellowshipperResultSetExtractor implements ResultSetExtractor<FellowshipMap>
{

    public static final String FLLWSHP_PERSON_ID = "person_id";
    public static final String IVGTR_PERSON_ID = "ivgtr_person_id";
    public static final String PERSON_ID = "pId";
    public static final String P_GUID = "pGuid";
    public static final String DEL_YN = "del_yn";
    public static final String FIRST_NM = "first_nm";
    public static final String LAST_NM = "last_nm";

    @Override
    public FellowshipMap extractData(ResultSet resultSet) throws SQLException
    {
        FellowshipMap fellowshipMap = new FellowshipMap();

        FellowshipData data;
        while (resultSet.next()) {
            long fellowshipperId = resultSet.getLong(FLLWSHP_PERSON_ID);
            long investigatorId = resultSet.getLong(IVGTR_PERSON_ID);
            data = new FellowshipData();
            data.setPersonServerId(resultSet.getLong(PERSON_ID));
            data.setPersonId(resultSet.getString(P_GUID));
            data.setDeleted("Y".equals(resultSet.getString(DEL_YN)));
            data.setFirstName(resultSet.getString(FIRST_NM));
            data.setLastName(resultSet.getString(LAST_NM));

            fellowshipMap.addFellowshipRelationship(fellowshipperId, investigatorId, data);
        }

        return fellowshipMap;
    }
}
