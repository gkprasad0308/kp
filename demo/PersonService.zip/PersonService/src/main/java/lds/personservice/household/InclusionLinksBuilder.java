package lds.personservice.household;

import lds.stack.spring.web.Link;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class InclusionLinksBuilder {

    private static final String INCLUDE_STR = "include=";
    private List<InclusionParams> params;
    private String incSegment = INCLUDE_STR;
    private String requestUrl;

    public InclusionLinksBuilder withRequestUrl(String requestUrl){
        String thisUrl = requestUrl;
        if(!StringUtils.isEmpty(requestUrl)){
            incSegment = parseIncludeString(requestUrl);
            thisUrl = requestUrl.replace(incSegment, "");
            thisUrl += requestUrl.contains("?") ? "" : "?";
            thisUrl += thisUrl.endsWith("?") || thisUrl.endsWith("&") ? "" : "&";
        }
        this.requestUrl = thisUrl;

        return this;
    }

    public InclusionLinksBuilder withInclusionParams(List<InclusionParams> params){
        this.params = params;
        return this;
    }

    public List<Link> generate(){
        List<Link> links = new LinkedList<>();
        if(!CollectionUtils.isEmpty(params)){
            links = params.stream().map(param -> createLink(param)).collect(Collectors.toList());
        }

        return links;
    }

    private Link createLink(final InclusionParams param){
        Link link = new Link();
        link.setRel("_" + param.name().toLowerCase());
        String href = requestUrl + incSegment + (incSegment.length() > INCLUDE_STR.length() ? "," : "") + param.name().toLowerCase();
        link.setHref(href);
        return link;
    }

    private String parseIncludeString(String queryString) {
        int includeIndex = queryString.indexOf("include=");
        int includeEndIndex = queryString.indexOf('&', includeIndex) > 0 ? queryString.indexOf('&', includeIndex)
                : queryString.length();
        return includeIndex >= 0 ? queryString.substring(includeIndex, includeEndIndex) : INCLUDE_STR;
    }
}
