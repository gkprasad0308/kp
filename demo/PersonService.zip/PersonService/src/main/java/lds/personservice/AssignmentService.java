package lds.personservice;

import lds.personservice.household.Household;
import lds.personservice.household.HouseholdService;
import lds.personservice.missionorg.MissionOrgService;
import lds.personservice.person.Person;
import lds.personservice.person.PersonService;
import lds.prsms.utils.errors.ServiceException;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class AssignmentService
{

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    PersonService personService;

    @Autowired
    HouseholdService householdService;

    @Autowired
    MissionOrgService missionOrgService;

    public Household handleHouseholdAssignment(Household household, String householdGuid)
    {
        LOGGER.info(String.format("Checking household %s assignment", householdGuid));
        Household entity = householdService.getHousehold(householdGuid);

        // if this update has a change to missionaryId and the original has an orgId present, then we need to remove
        // the orgId and replace it with a missionaryId
        if (household.changedToMissionary(entity)) {
            LOGGER.info(String.format("Detected the inclusion of a missionaryId on household %s where one was not already", householdGuid));
            alterHouseholdForMissionary(household, entity);
        }

        return household;
    }

    private void alterHouseholdForMissionary(Household household, Household original)
    {
        household.setOrgId(null);
        household.setStewardCmisId(null);
        if (!CollectionUtils.isEmpty(original.getPeople()) || !CollectionUtils.isEmpty(household.getPeople())) {
            Map<String, Person> people = original.getPeople() == null ? new HashMap<>() : original.getPeople().stream().collect(Collectors.toMap(Person::getGuid, Function.<Person>identity()));
            if (!CollectionUtils.isEmpty(household.getPeople())) {
                household.getPeople().forEach(p -> {
                    LOGGER.info(String.format("Nulling out prosAreaId for household member %s on household %s", p.getGuid(), household.getGuid()));
                    p.setProsAreaId(null);
                    people.remove(p.getGuid());
                });
            }

            // We will need to update the other people on the household not originally sent.
            if (!CollectionUtils.isEmpty(people)) {
                for (Person p : people.values()) {
                    LOGGER.info(String.format("Nulling out prosAreaId for household member %s not included in payload for household %d adding them to be updated",
                          p.getGuid(), household.getServerId()));
                    p.setProsAreaId(null);
                    household.addPerson(p);
                }
            }
        }
    }

    public Household handlePersonAssignment(Person person, String personGuid)
    {
        Person original = personService.getPersonDetail(personGuid);
        Household result = null;
        if (person.hasProsAreaChanged(original)) {
            LOGGER.info(String.format("Detected in a change in prosAreaId from %d, to %d ", original.getProsAreaId(), person.getProsAreaId()));
            if (original.getCmisId() != null) {
                LOGGER.warn(String.format("Person %s has a cmisId return an error", personGuid));
                throw new ServiceException(HttpStatus.BAD_REQUEST, "invalidState.cmisIdAndprosAreaId");
            }

            LOGGER.info(String.format("Retreiving household %s for person %s", person.getHouseholdId(), personGuid));
            result = householdService.getHousehold(person.getHouseholdId());

            //If household has a missionaryId, we null that out and any orgId since a household can not have a missionaryId and a prosAreaId
            if (result.getMissionaryId() != null) {
                LOGGER.info(String.format("Household %d had a non null missionary id. setting missionaryId and orgId to null", result.getServerId()));
                result.setMissionaryId(null);
                result.setStewardCmisId(null);
                result.setOrgId(null);
            }

            LOGGER.info(String.format("Iterating over household %d and assigning people to pros area %d", result.getServerId(), person.getProsAreaId()));
            if(!CollectionUtils.isEmpty(result.getPeople())) {
                List<Person> people = result.getPeople().stream().filter(p -> !p.getGuid().equals(personGuid) && p.getCmisId() == null).collect(Collectors.toList());
                for (Person member : people) {
                    member.setProsAreaId(person.getProsAreaId());
                }
                result.setPeople(people);
            }
            result.addPerson(person);
        }

        return result;
    }
}
