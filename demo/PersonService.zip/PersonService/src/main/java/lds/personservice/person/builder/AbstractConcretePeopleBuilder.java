package lds.personservice.person.builder;


import lds.personservice.household.InclusionParams;
import lds.personservice.person.Person;
import org.springframework.util.CollectionUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class AbstractConcretePeopleBuilder<T> implements ConcretePeopleBuilder{

    @Override
    public List<Person> build(List<Person> people){
        if(!CollectionUtils.isEmpty(people)) {
            List<Long> personIds = extractPersonIds(people);
            Map<Long, List<T>> typeMap = getPeopleIdToTypeMap(personIds);
            mapToPeople(people, typeMap);
        }

        return people;
    }

    protected List<Long> extractPersonIds(List<Person> people){
        List<Long> personIds = new LinkedList<>();
        if(!CollectionUtils.isEmpty(people)) {
            personIds = people.stream().map(Person::getServerId).collect(Collectors.toList());
        }
        return personIds;
    }

    protected boolean containsInclusion(BuilderParams params, InclusionParams inclusion) {
        return params != null && params.hasInclusion(inclusion);
    }

    protected abstract Map<Long, List<T>> getPeopleIdToTypeMap(List<Long> personIds);
    protected abstract void mapToPeople(List<Person> people, Map<Long, List<T>> typeMap);
}
