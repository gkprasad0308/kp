/*
 * Copyright (C) 2015 Intellectual Reserve, Inc. All rights reserved.
 * This notice may not be removed.
 */
package lds.personservice.config;

import javax.sql.DataSource;

import lds.stack.db.oracle.AbstractOracleDataSourceConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Configures one or more Oracle {@link DataSource} beans with an associated {@link JdbcTemplate}.
 */
@Configuration
public class DataSourceConfiguration extends AbstractOracleDataSourceConfiguration
{

    //-- DataSource Beans --------------------------------------------------------------------------------------------//
    /**
     * Initializes the <b>primary</b> Oracle data source bean.
     *
     * @return the primary Oracle data source
     */
    @Bean
    @Primary
    public DataSource dataSource()
    {
        return createDataSource("person-service-db");
    }


    //-- JdbcTemplate beans ------------------------------------------------------------------------------------------//
    /**
     * Initializes the <b>primary</b> JDBC template bean.
     *
     * @return the primary JDBC template
     */
    @Bean
    @Primary
    public JdbcTemplate jdbcTemplate()
    {
        return new JdbcTemplate(dataSource());
    }
}
