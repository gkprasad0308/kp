package lds.personservice.person.drop;

import lds.personservice.util.validation.annotation.ValidDropStatus;
import lds.prsms.utils.validation.ValidationGroups;

import javax.validation.constraints.NotNull;

public class WritableDropNote extends DropNote
{

    private static final long serialVersionUID = -1198694432866903079L;
    @NotNull(groups = ValidationGroups.Put.class)
    @ValidDropStatus(groups = ValidationGroups.class)
    private Integer status;

    public Integer getStatus()
    {
        return status;
    }

    public void setStatus(Integer status)
    {
        this.status = status;
    }
}
