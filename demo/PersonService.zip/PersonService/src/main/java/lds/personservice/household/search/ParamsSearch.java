package lds.personservice.household.search;

import lds.personservice.household.HouseholdRowMapper;
import lds.personservice.household.ListParams;
import lds.personservice.person.PersonRowMapper;
import org.springframework.util.CollectionUtils;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by jsi7iv on 1/5/16.
 */
public class ParamsSearch extends BaseSearch {

    public ParamsSearch(ListParams listParams) {
        super(listParams);
    }

    @Override
    protected void buildMainSelect() {
        select.append("SELECT ").append(HouseholdRowMapper.getSelectStatement("h")).append(",").append(PersonRowMapper.getSelectStatement("p"));

        from.append(" FROM ").append(" ( ").append(buildNestSql()).append(" ) root ");
        from.append(" JOIN ").append(" ims.person_mstr p");
        from.append(" ON root.person_id = p.person_id ");
        from.append(" JOIN ims.hshld_mstr h ");
        from.append(" ON h.hshld_id = p.hshld_id ");
    }

    private String buildNestSql() {
        boolean includePersonReferral = false;
        List<String> personWheres = new LinkedList<>();
        List<String> personReferralWheres = new LinkedList<>();
        List<String> referralGroupWheres = new LinkedList<>();
        String personStatement = "SELECT p.person_id\n"
                + "                  FROM hshld_mstr h\n"
                + "                 INNER JOIN person_mstr p\n"
                + "                    ON p.hshld_id = h.hshld_id\n"
                + "                 WHERE 1=1 AND ";

        String personReferralStatement = "SELECT pr.person_id\n"
                + "                  FROM person_rfrl pr\n"
                + "                 WHERE 1=1 AND  ";

        String referralGroupStatement = "SELECT pr.person_id\n"
                + "                  FROM person_rfrl pr\n"
                + "                 INNER JOIN rfrl_grp rg\n"
                + "                    ON rg.rfrl_grp_id = pr.rfrl_grp_id\n"
                + "                 WHERE rg.claim_dt IS NULL AND \n";

        if (!CollectionUtils.isEmpty(listParams.getProsAreas())) {
            personWheres.add(" p.pros_area_id in (:prosAreaId) ");
            referralGroupWheres.add(" rg.rcv_pros_area_id IN (:prosAreaId) ");
            sqlParameters.addValue("prosAreaId", listParams.getProsAreas());
        }
        if (!CollectionUtils.isEmpty(listParams.getStewardCmisIds())) {
            personWheres.add(" h.stwrd_cmis_id IN (:stwrdCmisId) ");
            personReferralWheres.add(" pr.owner_stwrd_cmis_id IN (:stwrdCmisId) ");
            referralGroupWheres.add(" rg.rcv_stwrd_cmis_id IN (:stwrdCmisId) ");
            sqlParameters.addValue("stwrdCmisId", listParams.getStewardCmisIds());
            includePersonReferral = true;
        }
        if (!CollectionUtils.isEmpty(listParams.getOrgIds())) {
            personWheres.add(" h.org_id IN (:orgId) ");
            personReferralWheres.add(" pr.owner_org_id IN (:orgId) ");
            referralGroupWheres.add(" rg.rcv_org_id IN (:orgId) ");
            sqlParameters.addValue("orgId", listParams.getOrgIds());
            includePersonReferral = true;
        }
        if (!CollectionUtils.isEmpty(listParams.getMissionaryIds())) {
            personWheres.add(" h.msny_id IN (:msnyId) ");
            personReferralWheres.add(" pr.owner_msny_id IN (:msnyId) ");
            referralGroupWheres.add(" rg.rcv_msny_id IN (:msnyId) ");
            sqlParameters.addValue("msnyId", listParams.getMissionaryIds());
            includePersonReferral = true;
        }

        personStatement += " ( " + String.join(" OR ", personWheres) + " ) ";
        personReferralStatement += " ( " + String.join(" OR ", personReferralWheres) + " ) ";
        referralGroupStatement += " ( " + String.join(" OR ", referralGroupWheres) + " ) ";

        return new StringBuilder(128).append("SELECT a.person_id ")
                .append(" FROM (SELECT base.person_id, ROW_NUMBER() OVER(PARTITION BY base.person_id ORDER BY ROWNUM) rn ")
                .append(" FROM ( ").append(personStatement)
                .append(includePersonReferral ? " UNION ALL " : "").append(includePersonReferral ? personReferralStatement : "")
                .append(" UNION ALL ").append(referralGroupStatement)
                .append(" ) base ) a WHERE a.rn = 1 ").toString();
    }
}
