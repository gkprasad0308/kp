package lds.personservice.util.validation.constraint;

import lds.personservice.missionorg.Entity;
import lds.personservice.missionorg.MissionOrgService;
import lds.personservice.person.Person;
import lds.personservice.util.validation.annotation.ValidProsAreaAssignment;
import lds.personservice.util.validation.service.HouseholdValidationService;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.stream.Collectors;

@Named
public class ProsAreaAssignmentValidator implements ConstraintValidator<ValidProsAreaAssignment, Person> {

    @Inject
    private HouseholdValidationService householdService;

    @Inject
    private MissionOrgService missionOrgService;

    @Override
    public void initialize(ValidProsAreaAssignment validProsAreaAssignment) {
        // isValid does the work
    }

    @Override
    public boolean isValid(Person person, ConstraintValidatorContext constraintValidatorContext) {
        boolean result = true;
        if(person != null && !StringUtils.isEmpty(person.getHouseholdId())){
            Long orgId = householdService.getHouseholdOrgId(person.getHouseholdId());
            result = checkOrgProsAreaAssignment(orgId, person.getProsAreaId());
        }

        return result;
    }

    private boolean checkOrgProsAreaAssignment(final Long orgId, final Long prosAreaId) {
        boolean result = true;
        if(orgId != null && prosAreaId != null){
            Entity entity = missionOrgService.getOrgUnitsForArea(prosAreaId);
            result = entity != null && hasMatchingOrgId(orgId, entity);
        }
        return result;
    }

    private boolean hasMatchingOrgId(Long orgId, Entity entity) {
        boolean result = false;
        if(!CollectionUtils.isEmpty(entity.getChildren())){
            result = getOrgIds(entity.getChildren()).stream()
                    .filter(child -> orgId.equals(child))
                    .findAny().orElse(null) != null;
        }

        return result;
    }

    private List<Long> getOrgIds(List<Entity> orgs)
    {
        List<Long> orgIds = orgs.stream()
                .map(Entity::getId)
                .collect(Collectors.toList());

        orgIds.addAll(
                orgs.stream()
                        .filter(org -> !CollectionUtils.isEmpty(org.getChildren()))
                        .flatMap(org -> org.getChildren().stream())
                        .map(Entity::getId)
                        .collect(Collectors.toList())
        );
        return orgIds;
    }
}
