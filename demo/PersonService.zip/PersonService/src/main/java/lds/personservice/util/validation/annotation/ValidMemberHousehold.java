package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.MemberHouseholdValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = MemberHouseholdValidator.class)
@ConstraintDescription("A household with a cmisId member cannot be deleted, nor can it be assigned to a stewardCmisId or missionary")
public @interface ValidMemberHousehold {

    String message() default "{lds.personservice.util.validation.constraints.VAlidMemberHousehold.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
