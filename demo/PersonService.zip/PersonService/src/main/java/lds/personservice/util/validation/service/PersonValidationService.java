package lds.personservice.util.validation.service;

import lds.personservice.person.PersonRepository;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public class PersonValidationService {

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private PersonRepository repository;

    public boolean personExists(String guid){
        LOGGER.info("Checking personGuid exists {}", guid);
        return repository.personWithGuidExists(guid);
    }
}
