package lds.personservice.config;

import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;

import javax.validation.Validator;

/**
 * Configuration class to turn on bean validation support in Spring such that the {@link Validated) annotation may be used.
 * <p>
 * The configuration also provides the ability for validators to use Spring dependency injection to access repositories and
 * other facilities.
 */
@Configuration
public class ValidationConfiguration {

    @Bean
    public Validator validator() {
        return new LocalValidatorFactoryBean();
    }

    @Bean
    public MethodValidationPostProcessor methodValidationPostProcessor(final Validator validator) {
        MethodValidationPostProcessor processor = new MethodValidationPostProcessor();
        processor.setValidator(validator);

        return processor;
    }

    @Bean
    public ValidationConfigurationBeanPostProcessor validationConfigurationBeanPostProcessor(final Validator validator) {
        return new ValidationConfigurationBeanPostProcessor(validator);
    }

    /**
     * Bean post processor to workaround Hibernate and shut off bean validation.
     * <p>
     * Given that validation includes persistence, crossing the streams with querying the database while attempting to
     * persist in the database causes all sorts of errors, and prevents doing the work twice.
     *
     */
    public static class ValidationConfigurationBeanPostProcessor implements BeanPostProcessor {

        private final Validator validator;

        public ValidationConfigurationBeanPostProcessor(final Validator validator) {
            this.validator = validator;
        }

        @Override
        public Object postProcessBeforeInitialization(Object bean, String beanName) {
            if (bean instanceof LocalContainerEntityManagerFactoryBean) {
                LocalContainerEntityManagerFactoryBean.class.cast(bean)
                        .getJpaPropertyMap()
                        .put("javax.persistence.validation.factory", validator);
            }

            return bean;
        }

        @Override
        public Object postProcessAfterInitialization(Object bean, String beanName) {
            return bean;
        }
    }
}
