package lds.personservice.options;

import java.util.List;

import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${lds.api.resources.options.href}")
public class OptionsController
{

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private OptionsService optionsService;

    @RequestMapping(method = RequestMethod.GET)
    public Options getOptions(@RequestParam(value = "lang", required = false, defaultValue = "en") String langCd)
    {
        LOGGER.info(String.format("Received a request for all options with localeCode %s", langCd));
        return optionsService.getOptions(langCd);
    }

    @RequestMapping(value = "/age", method = RequestMethod.GET)
    public List<AgeCategory> getAgeCategories(@RequestParam(value = "lang", required = false, defaultValue = "en") String langCd)
    {
        LOGGER.info(String.format("Received a request for age categories with localeCode %s", langCd));
        return optionsService.getAgeCategories(langCd);
    }

    @RequestMapping(value = "/language", method = RequestMethod.GET)
    public List<Language> getLanguages(@RequestParam(value = "lang", required = false, defaultValue = "en") String langCd)
    {
        LOGGER.info(String.format("Received a request for languages with localeCode %s", langCd));
        return optionsService.getLanguages(langCd);
    }

    @RequestMapping(value = "/source", method = RequestMethod.GET)
    public List<Source> getSources(@RequestParam(value = "lang", required = false, defaultValue = "en") String langCd)
    {
        LOGGER.info(String.format("Received a request for sources/find_types with localeCode %s", langCd));
        return optionsService.getSources(langCd);
    }

    @RequestMapping(value = "/contactType", method = RequestMethod.GET)
    public List<ContactType> getContactTypes(@RequestParam(value = "lang", required = false, defaultValue = "en") String langCd)
    {
        LOGGER.info(String.format("Received a request for contactTypes for isoCode %s", langCd));
        return optionsService.getContactTypes(langCd);
    }

    @RequestMapping(value = "/status", method = RequestMethod.GET)
    public List<Status> getStatuses(@RequestParam(value = "lang", required = false, defaultValue = "en") String langCd)
    {
        LOGGER.info(String.format("Received a request for person statuses for isoCode %s", langCd));
        return optionsService.getStats(langCd);
    }
}
