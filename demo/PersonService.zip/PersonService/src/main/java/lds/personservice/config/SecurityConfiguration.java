package lds.personservice.config;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter implements AuthenticationEventPublisher
{

    private static final Logger LOG = Logger.getLogger(SecurityConfiguration.class.getName());
    @Value("${basic-auth.username}")
    private String user;

    @Value("${basic-auth.password}")
    private String password;

    @Override
    protected void configure(HttpSecurity http) throws Exception
    {
        http
              .csrf().disable()
              .authorizeRequests()
              .antMatchers(HttpMethod.OPTIONS, "/api/**").authenticated()
              .antMatchers("/api/**").hasRole("USER")
              .anyRequest().authenticated()
              .and()
              .formLogin()
              .and()
              .httpBasic();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception
    {
        auth
              .inMemoryAuthentication()
              .withUser(user)
              .password(password)
              .roles("USER");

        auth.authenticationEventPublisher(this);

    }

    @Override
    public void publishAuthenticationSuccess(Authentication authentication)
    {
        LOG.log(Level.INFO, "Authentication success: {0}", authentication.getName());
    }

    @Override
    public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication)
    {
        LOG.log(Level.INFO, "Authentication Failure: {0}", exception.getMessage());
    }
}
