package lds.personservice.options;

import java.util.List;

public class Options
{

    private List<Status> statuses;
    private List<ContactType> contactTypes;
    private List<Source> sources;
    private List<Language> languages;
    private List<AgeCategory> ageCategories;

    public void setStatuses(List<Status> statuses)
    {
        this.statuses = statuses;
    }

    public List<Status> getStatuses()
    {
        return statuses;
    }

    public void setContactTypes(List<ContactType> contactTypes)
    {
        this.contactTypes = contactTypes;
    }

    public List<ContactType> getContactTypes()
    {
        return contactTypes;
    }

    public void setSources(List<Source> sources)
    {
        this.sources = sources;
    }

    public List<Source> getSources()
    {
        return sources;
    }

    public void setLanguages(List<Language> languages)
    {
        this.languages = languages;
    }

    public List<Language> getLanguages()
    {
        return languages;
    }

    public void setAgeCategories(List<AgeCategory> ageCategories)
    {
        this.ageCategories = ageCategories;
    }

    public List<AgeCategory> getAgeCategories()
    {
        return ageCategories;
    }
}
