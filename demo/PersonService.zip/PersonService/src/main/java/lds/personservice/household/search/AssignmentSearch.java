package lds.personservice.household.search;

import lds.personservice.household.HouseholdRowMapper;
import lds.personservice.household.ListParams;
import lds.personservice.person.PersonRowMapper;

/**
 * Created by jsi7iv on 1/5/16.
 */
public class AssignmentSearch extends BaseSearch {

    public AssignmentSearch(ListParams listParams) {
        super(listParams);
    }

    @Override
    protected void buildMainSelect() {
        select.append("SELECT ").append(HouseholdRowMapper.getSelectStatement("h")).append(",").append(PersonRowMapper.getSelectStatement("p"));

        from.append(" FROM ").append(" ims.hshld_mstr h");
        from.append(" LEFT JOIN ").append(" ims.person_mstr p");
        from.append(" ON h.hshld_id = p.hshld_id ");
        if (listParams.getAssignmentArea() != null && listParams.getAssignmentArea() > 0) {
            from.append(" JOIN ").append(" ims.crnt_person_gtt crpgtt ");
            from.append(" ON p.person_id = crpgtt.person_id ");
        }
    }
}
