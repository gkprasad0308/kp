package lds.personservice.contactinfo.phone;

import com.fasterxml.jackson.annotation.JsonCreator;
import lds.personservice.contactinfo.ContactInfoType;

public enum PhoneTypes implements ContactInfoType
{

    PHN_HOME(1),
    PHN_WORK(3),
    PHN_MOBILE(2),
    PHN_OTHER(4);

    private final int id;

    PhoneTypes(int id)
    {
        this.id = id;
    }

    @JsonCreator
    public static PhoneTypes forValue(String value)
    {
        return PhoneTypes.valueOf(value.toUpperCase());
    }

    public int id()
    {
        return this.id;
    }

}
