package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.AgeCategoryValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = AgeCategoryValidator.class)
@ConstraintDescription("If provided, this must be a valid age category id from the age categor options")
public @interface ValidAgeCategory {

    String message() default "{lds.personservice.util.validation.constraints.UnsupportedValue.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
