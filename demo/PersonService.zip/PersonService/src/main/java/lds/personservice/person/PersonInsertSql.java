package lds.personservice.person;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import lds.personservice.BaseUpdateSql;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class PersonInsertSql extends BaseUpdateSql
{

    public static final String PERSON_ID = "personId";
    public static final String FIRST_NAME = "firstName";
    public static final String LAST_NAME = "lastName";
    public static final String AGE_CAT_ID = "ageCatId";
    public static final String GENDER = "gender";
    public static final String HSHLD_ID = "hshldId";
    public static final String PERSON_STAT_ID = "personStatId";
    public static final String NOTE = "note";
    public static final String FOCUS_PERSON = "focusPerson";
    public static final String CMIS_ID = "cmisId";
    public static final String PROS_AREA_ID = "prosAreaId";
    public static final String GUID = "guid";
    public static final String CONVERT = "convert";
    public static final String FIND_ID = "findId";
    public static final String PREF_LANG_ID = "prefLangId";
    public static final String PREF_CONTACT_TYPE = "prefContactType";
    public static final String FIND_DETAIL = "findDetail";

    @Autowired
    public PersonInsertSql(DataSource dataSource)
    {
        init(dataSource);
    }

    private void init(DataSource dataSource)
    {
        setDataSource(dataSource);
        setSql("INSERT INTO ims.person_mstr ("
              + "   person_id"
              + "   ,del_yn"
              + "   ,first_nm   "
              + "   ,last_nm"
              + "   ,age_c_id   "
              + "   ," + GENDER
              + "   ,hshld_id"
              + "   ,person_stat_id"
              + "   ,crt_dt"
              + "   ,mod_dt"
              + "   ," + NOTE
              + "   ,afab_focus_person_yn"
              + "   ,cmis_id"
              + "   ,pros_area_id   "
              + "   ,client_" + GUID
              + "   ," + CONVERT + "_yn"
              + "   ,find_id"
              + "   ,pref_lang_id"
              + "   ,pref_cntct_t_id"
              + "   ,find_dtl_id"
              + " ) VALUES ("
              + "   :" + PERSON_ID
              + "   ,'N'"
              + "   ,:" + FIRST_NAME
              + "   ,:" + LAST_NAME
              + "   ,:" + AGE_CAT_ID
              + "   ,:" + GENDER
              + "   ,:" + HSHLD_ID
              + "   ,:" + PERSON_STAT_ID
              + "   ,SYSDATE"
              + "   ,SYSDATE"
              + "   ,:" + NOTE
              + "   ,:" + FOCUS_PERSON
              + "   ,:" + CMIS_ID
              + "   ,:" + PROS_AREA_ID
              + "   ,:" + GUID
              + "   ,:" + CONVERT
              + "   ,:" + FIND_ID
              + "   ,:" + PREF_LANG_ID
              + "   ,:" + PREF_CONTACT_TYPE
              + "   ,:" + FIND_DETAIL
              + " ) ");

        declareParameter(new SqlParameter(PERSON_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(FIRST_NAME, Types.VARCHAR));
        declareParameter(new SqlParameter(LAST_NAME, Types.VARCHAR));
        declareParameter(new SqlParameter(AGE_CAT_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(GENDER, Types.VARCHAR));
        declareParameter(new SqlParameter(HSHLD_ID, Types.VARCHAR));
        declareParameter(new SqlParameter(PERSON_STAT_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(NOTE, Types.VARCHAR));
        declareParameter(new SqlParameter(FOCUS_PERSON, Types.VARCHAR));
        declareParameter(new SqlParameter(CMIS_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PROS_AREA_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(GUID, Types.VARCHAR));
        declareParameter(new SqlParameter(CONVERT, Types.VARCHAR));
        declareParameter(new SqlParameter(FIND_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PREF_LANG_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PREF_CONTACT_TYPE, Types.NUMERIC));
        declareParameter(new SqlParameter(FIND_DETAIL, Types.NUMERIC));
    }

    public Map<String, Object> getParamsUsing(Person person)
    {
        return new MapSqlParameterSource()
              .addValue(PERSON_ID, person.getServerId())
              .addValue(FIRST_NAME, person.getFirstName())
              .addValue(LAST_NAME, person.getLastName())
              .addValue(AGE_CAT_ID, person.getAgeCatId())
              .addValue(GENDER, person.getGender())
              .addValue(HSHLD_ID, person.getHouseholdServerId())
              .addValue(PERSON_STAT_ID, person.getStatus())
              .addValue(NOTE, person.getNote())
              .addValue(FOCUS_PERSON, parseBoolean(person.isFocusPerson()))
              .addValue(CMIS_ID, person.getCmisId())
              .addValue(PROS_AREA_ID, person.getProsAreaId())
              .addValue(GUID, person.getGuid())
              .addValue(CONVERT, parseBoolean(person.isConvert()))
              .addValue(FIND_ID, person.getContactSource())
              .addValue(PREF_LANG_ID, person.getPreferredLangId())
              .addValue(PREF_CONTACT_TYPE, person.getPreferredContactType())
              .addValue(FIND_DETAIL, person.getContactSourceDtl())
              .getValues();
    }
}
