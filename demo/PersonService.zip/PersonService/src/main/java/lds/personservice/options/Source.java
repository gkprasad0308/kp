package lds.personservice.options;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonUnwrapped;

public class Source implements Option
{

    private int id;
    @JsonProperty(value = "parentId")
    private Integer parentSourceId;
    private int sortOrder;
    @JsonIgnore
    private Date deleteDate;
    @JsonUnwrapped
    private SourceType sourceType;

    @Override
    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Integer getParentSourceId()
    {
        return parentSourceId;
    }

    public void setParentSourceId(Integer parentSourceId)
    {
        this.parentSourceId = parentSourceId;
    }

    public int getSortOrder()
    {
        return sortOrder;
    }

    public void setSortOrder(int sortOrder)
    {
        this.sortOrder = sortOrder;
    }

    public Date getDeleteDate()
    {
        return deleteDate;
    }

    public void setDeleteDate(Date deleteDate)
    {
        this.deleteDate = deleteDate;
    }

    public SourceType getSourceType()
    {
        return sourceType;
    }

    public void setSourceType(SourceType sourceType)
    {
        this.sourceType = sourceType;
    }
}
