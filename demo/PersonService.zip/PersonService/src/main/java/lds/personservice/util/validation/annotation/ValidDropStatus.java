package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.DropStatusValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = DropStatusValidator.class)
@ConstraintDescription("Must be a valid drop status which is a drop with parent id 5 and actual id is not 5")
public @interface ValidDropStatus {

    String message() default "{lds.personservice.util.validation.constraints.UnsupportedValue.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
