package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.HouseholdAssignmentValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = HouseholdAssignmentValidator.class)
@ConstraintDescription("If a household is assigned, it can only be assigned to one of missionaryId, orgId, or stewardCmisId")
public @interface ValidHouseholdAssignment {

    String message() default "{lds.personservice.uitl.validation.constraints.ValidHouseholdAssignment.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
