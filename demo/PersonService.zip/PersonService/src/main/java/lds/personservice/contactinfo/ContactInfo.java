package lds.personservice.contactinfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lds.personservice.contactinfo.email.Email;
import lds.personservice.contactinfo.email.EmailTypes;
import lds.personservice.contactinfo.phone.Phone;
import lds.personservice.contactinfo.phone.PhoneTypes;
import org.springframework.util.CollectionUtils;

import javax.validation.Valid;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactInfo
{
    public static final int INITIAL_TYPE_CAPACITY = 4;
    @Valid
    private List<Phone> phoneNumbers;
    @Valid
    private List<Email> emailAddresses;

    public List<Phone> getPhoneNumbers()
    {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<Phone> phoneNumbers)
    {
        this.phoneNumbers = phoneNumbers;
    }

    public List<Email> getEmailAddresses()
    {
        return emailAddresses;
    }

    public void setEmailAddresses(List<Email> emailAddresses)
    {
        this.emailAddresses = emailAddresses;
    }

    public void addPhone(PhoneTypes type, String phnNbr)
    {
        if (CollectionUtils.isEmpty(phoneNumbers)) {
            phoneNumbers = new ArrayList<>();
        }
        phoneNumbers.add(new Phone(type, phnNbr));
    }

    public void addEmail(EmailTypes type, String address)
    {
        if (CollectionUtils.isEmpty(emailAddresses)) {
            emailAddresses = new ArrayList<>();
        }
        emailAddresses.add(new Email(type, address));
    }

    public ContactInfo extractUniqueTypes(ContactInfo other){
        ContactInfo deltas = new ContactInfo();

        if(other != null) {
            deltas.setPhoneNumbers(extractUniquePhones(other));
            deltas.setEmailAddresses(extractUniqueEmails(other));
        }
        else {
            deltas = this;
        }

        return deltas;
    }

    private List<Email> extractUniqueEmails(ContactInfo other) {
        List<Email> emails = new ArrayList<>(INITIAL_TYPE_CAPACITY);
        if(CollectionUtils.isEmpty(other.emailAddresses)){
            emails = this.emailAddresses;
        }
        else if(!CollectionUtils.isEmpty(this.emailAddresses)) {
            final Set<EmailTypes> otherTypes = other.emailAddresses.stream().map(Email::getType).collect(Collectors.toSet());
            emails = this.emailAddresses.stream().filter(email -> !otherTypes.contains(email.getType())).collect(Collectors.toList());
        }
        return emails;
    }

    private List<Phone> extractUniquePhones(ContactInfo other) {
        List<Phone> phones = new ArrayList<>(INITIAL_TYPE_CAPACITY);
        if(CollectionUtils.isEmpty(other.phoneNumbers)){
            phones = this.phoneNumbers;
        }
        else if(!CollectionUtils.isEmpty(this.phoneNumbers)) {
            final Set<PhoneTypes> otherTypes = other.phoneNumbers.stream().map(Phone::getType).collect(Collectors.toSet());
            phones = this.phoneNumbers.stream().filter( phone -> !otherTypes.contains(phone.getType())).collect(Collectors.toList());
        }
        return phones;
    }


    public ContactInfo extractDuplicatedTypes(ContactInfo other){
        ContactInfo duplicates = new ContactInfo();

        if(other != null) {
            duplicates.setPhoneNumbers(extractDuplicatedPhones(other));
            duplicates.setEmailAddresses(extractDuplicatedEmails(other));
        }
        else {
            duplicates.setEmailAddresses(new ArrayList<>());
            duplicates.setPhoneNumbers(new ArrayList<>());
        }

        return duplicates;
    }

    private List<Phone> extractDuplicatedPhones(ContactInfo other) {
        List<Phone> duplicates = new ArrayList<>(INITIAL_TYPE_CAPACITY);
        if(!CollectionUtils.isEmpty(this.phoneNumbers) && !CollectionUtils.isEmpty(other.phoneNumbers)){
            final Set<PhoneTypes> otherTypes = other.phoneNumbers.stream().map(Phone::getType).collect(Collectors.toSet());
            duplicates = this.phoneNumbers.stream().filter(phone -> otherTypes.contains(phone.getType())).collect(Collectors.toList());
        }
        return duplicates;
    }

    private List<Email> extractDuplicatedEmails(ContactInfo other) {
        List<Email> duplicates = new ArrayList<>(INITIAL_TYPE_CAPACITY);
        if(!CollectionUtils.isEmpty(this.emailAddresses) && !CollectionUtils.isEmpty(other.emailAddresses)){
            final Set<EmailTypes> otherTypes = other.emailAddresses.stream().map(Email::getType).collect(Collectors.toSet());
            duplicates = this.emailAddresses.stream().filter(email -> otherTypes.contains(email.getType())).collect(Collectors.toList());
        }
        return duplicates;
    }
}
