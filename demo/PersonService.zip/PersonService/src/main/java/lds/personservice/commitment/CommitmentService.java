package lds.personservice.commitment;

import lds.personservice.person.PersonRepository;
import lds.prsms.utils.HashKeyGenerator;
import lds.prsms.utils.errors.ServiceException;
import lds.stack.validation.Check;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@Service
public class CommitmentService {

    private static final Logger LOG = Logger.getLogger(CommitmentService.class);
    @Autowired
    private CommitmentRepository commitmentRepo;

    @Autowired
    private PersonRepository personRepository;

    public Commitment createCommitment(Commitment commitmentEntity) {

        Commitment result;
        if (commitmentEntity == null) {
            LOG.error("No entity error in createCommitment service");
            throw new ServiceException(HttpStatus.BAD_REQUEST, "error.post.commitment.noEntity");
        }

        Long personId = personRepository.getPersonIdByGuid(commitmentEntity.getPersonGuid());
        commitmentEntity.setPersonId(personId);
        Commitment potentialDuplicate = commitmentRepo.findByPersonAndTeachingItem(commitmentEntity.getTeachingItemId(), commitmentEntity.getPersonId());

        String cGuid = commitmentEntity.getClientGuid();
        if (Check.isEmpty(cGuid)) {
            commitmentEntity.setClientGuid(HashKeyGenerator.getInstance().getHashKeyFromObject(commitmentEntity));
        }

        //if there is already a commitment in the database with this same guid
        if (commitmentRepo.findByClientGuid(commitmentEntity.getClientGuid()) != null) {
            LOG.error("Duplicate client guid in commitment create: " + commitmentEntity.getClientGuid());
            throw new ServiceException(HttpStatus.NOT_ACCEPTABLE, "error.post.commitment.duplicate.clientGuid");
        }

        if (potentialDuplicate != null) {
            potentialDuplicate.setDeleted(false);
            potentialDuplicate.setInviteDate(commitmentEntity.getInviteDate());
            potentialDuplicate.setKeptDate(commitmentEntity.getKeptDate());
            potentialDuplicate.setWasKept(commitmentEntity.getWasKept());
            result = commitmentRepo.save(potentialDuplicate);
        } else {
            commitmentEntity.setDeleted(false);
            LOG.debug("Creating Commitment");
            result = commitmentRepo.save(commitmentEntity);
        }

        return completeCommitment(result);
    }

    public Commitment updateCommitment(Commitment commitmentEntity, String guid) {
        if (commitmentEntity == null) {
            LOG.error("No entity error in createCommitment service");
            throw new ServiceException(HttpStatus.BAD_REQUEST, "error.put.commitment.noEntity");
        }

        Commitment baseEntity = commitmentRepo.findByClientGuid(guid);
        if (baseEntity == null || baseEntity.getDeleted()) {
            LOG.error("Attempt to update a deleted or non-existent commitment: " + commitmentEntity.getClientGuid());
            throw new ServiceException(HttpStatus.NOT_FOUND, "error.put.commitment.not.found");
        }

        LOG.debug("Updating Commitment " + guid);
        Long personId = personRepository.getPersonIdByGuid(commitmentEntity.getPersonGuid());
        commitmentEntity.setPersonId(personId);
        baseEntity.setKeptDate(commitmentEntity.getKeptDate());
        baseEntity.setWasKept(commitmentEntity.getWasKept());
        baseEntity.setInviteDate(commitmentEntity.getInviteDate());

        return completeCommitment(commitmentRepo.save(baseEntity));
    }

    public Commitment deleteCommitment(String commitmentGuid) {
        if (StringUtils.isEmpty(commitmentGuid)) {
            LOG.error("No commitmentId error in commitment DELETE");
            throw new ServiceException(HttpStatus.BAD_REQUEST, "error.delete.commitment.commitmentId");
        }

        LOG.debug("Finding commitment by id: " + commitmentGuid);
        Commitment commitmentEntity = commitmentRepo.findByClientGuid(commitmentGuid);
        if (commitmentEntity == null) {
            LOG.error("No commitment found for id: " + commitmentGuid);
            throw new ServiceException(NOT_FOUND, "error.delete.commitment.not.found");
        }

        LOG.debug("Deleting commitment: " + commitmentGuid);
        commitmentEntity.setDeleted(true);
        return completeCommitment(commitmentRepo.save(commitmentEntity));
    }

    private Commitment completeCommitment(Commitment commitment) {
        if (null != commitment) {
            String pg = commitment.getPersonGuid();
            Long pi = commitment.getPersonId();

            if (null == pg && null != pi) {
                commitment.setPersonGuid(personRepository.getPersonById(pi).getGuid());
            }

            if (null != pg && null == pi) {
                commitment.setPersonId(personRepository.getPersonIdByGuid(pg));
            }
        }

        return commitment;
    }
}
