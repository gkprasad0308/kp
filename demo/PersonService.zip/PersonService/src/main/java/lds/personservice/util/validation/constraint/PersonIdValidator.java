package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidPersonId;
import lds.personservice.util.validation.service.PersonValidationService;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;


@Named
public class PersonIdValidator implements ConstraintValidator<ValidPersonId, String> {

    @Inject
    private PersonValidationService service;

    @Override
    public void initialize(ValidPersonId validPersonId) {
        // isValid does the work
    }

    @Override
    public boolean isValid(String guid, ConstraintValidatorContext constraintValidatorContext) {
        boolean result = true;

        if(!StringUtils.isEmpty(guid)){
            result = service.personExists(guid);
        }

        return result;
    }
}
