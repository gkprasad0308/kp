package lds.personservice.person.builder;


import lds.personservice.person.Person;

import java.util.List;

public interface PeopleBuilder {

    PeopleBuilder withParams(BuilderParams params);

    PeopleBuilder withPeople(List<Person> people);

    PeopleBuilder construct();

    List<Person> getResults();
}
