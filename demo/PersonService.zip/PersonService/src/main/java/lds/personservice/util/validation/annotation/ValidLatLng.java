package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.LatLngValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = LatLngValidator.class)
@ConstraintDescription("If a lat is provide a lng must be also, and this is true with the inverse")
public @interface ValidLatLng {

    String message() default "{lds.personservice.util.validation.constraints.ValidLatLng.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
