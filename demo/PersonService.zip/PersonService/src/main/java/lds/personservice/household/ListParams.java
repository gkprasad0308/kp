package lds.personservice.household;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lds.prsms.utils.errors.ServiceException;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class ListParams
{
    private static final Logger LOG = Logging.getLogger();

    private List<Long> orgIds;
    private List<Long> prosAreas;
    private List<Long> missionaryIds;
    private List<Long> stewardCmisIds;
    private Long assignmentArea;
    private List<InclusionParams> inclusions;
    private Date modDate;
    private boolean includeDeleted = false;

    public List<Long> getOrgIds()
    {
        return orgIds;
    }

    public void parseOrgIds(String orgIds)
    {
        this.orgIds = parseStringIntoList(orgIds, "orgId");
    }

    public List<Long> getProsAreas()
    {
        return prosAreas;
    }

    public void parseProsAreas(String prosAreas)
    {
        this.prosAreas = parseStringIntoList(prosAreas, "prosArea");
    }

    public List<Long> getMissionaryIds()
    {
        return missionaryIds;
    }

    public void parseMissionaryIds(String msnyId)
    {
        this.missionaryIds = parseStringIntoList(msnyId, "missionaryIds");
    }

    public List<Long> getStewardCmisIds()
    {
        return stewardCmisIds;
    }

    public void parseStewardCmisIds(String stewardCmisIds)
    {
        this.stewardCmisIds = parseStringIntoList(stewardCmisIds, "stewardCmisId");
    }

    public Long getAssignmentArea()
    {
        return assignmentArea;
    }

    public void setAssignmentArea(Long assignmentArea)
    {
        this.assignmentArea = assignmentArea;
    }

    public List<InclusionParams> getInclusions()
    {
        return inclusions;
    }

    public void setInclusions(String inclusions)
    {
        this.inclusions = parseInclusions(inclusions);
    }

    public Date getModDate()
    {
        return modDate;
    }

    public void setModDate(Long modDate)
    {
        if (modDate == null) {
            return;
        }
        this.modDate = new Date();
        this.modDate.setTime(modDate);
    }

    public boolean isIncludeDeleted()
    {
        return includeDeleted;
    }

    public void setIncludeDeleted(boolean includeDeleted)
    {
        this.includeDeleted = includeDeleted;
    }

    public boolean hasActionableContent()
    {
        return assignmentArea != null || hasParamsSearchContent();
    }

    public boolean hasParamsSearchContent(){
        return !CollectionUtils.isEmpty(orgIds)
                || !CollectionUtils.isEmpty(prosAreas)
                || !CollectionUtils.isEmpty(missionaryIds)
                || !CollectionUtils.isEmpty(stewardCmisIds);
    }

    private List<Long> parseStringIntoList(String param, String fieldName)
    {
        List<Long> list = new LinkedList<>();
        if (!StringUtils.isEmpty(param)) {
            String[] parts = param.split(",");
            for (String part : parts) {
                try {
                    list.add(Long.parseLong(part));
                } catch (NumberFormatException ex) {
                    throw new ServiceException(HttpStatus.BAD_REQUEST, "query.param.error." + fieldName + ".invalid");
                }
            }
        }
        return list;
    }

    private List<InclusionParams> parseInclusions(String inclusions)
    {
        List<InclusionParams> results = new ArrayList<>();
        if (StringUtils.isEmpty(inclusions)) {
            return results;
        }

        String[] incParams = inclusions.split(",");
        for (String param : incParams) {
            InclusionParams inclusionParam = InclusionParams.getFromParam(param);
            if (inclusionParam != null) {
                results.add(inclusionParam);
            }
        }
        return results;
    }

    @Override
    public String toString()
    {
        ObjectMapper mapper = new ObjectMapper();
        String value = super.toString();
        try {
            value = mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            LOG.error("Failure parsing list params", e);
        }
        return value;
    }
}
