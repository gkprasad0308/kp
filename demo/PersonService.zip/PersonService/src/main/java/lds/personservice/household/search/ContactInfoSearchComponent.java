package lds.personservice.household.search;


import lds.personservice.contactinfo.ContactInfoRowMapper;
import lds.personservice.household.InclusionParams;
import lds.personservice.household.ListParams;
import org.springframework.util.CollectionUtils;

import static java.util.Objects.requireNonNull;

public class ContactInfoSearchComponent implements SearchComponent{

    private String personPrefix;

    public ContactInfoSearchComponent(String personPrefix){
        this.personPrefix = requireNonNull(personPrefix);
    }

    @Override
    public SearchFragment buildFragment(ListParams listParams) {
        SearchFragment fragment = null;
        if(listParams != null && !CollectionUtils.isEmpty(listParams.getInclusions())
                && listParams.getInclusions().contains(InclusionParams.CONTACT_INFO)){
            fragment = new SearchFragment()
                    .withSelectFragment(ContactInfoRowMapper.getSelectStatement())
                    .withFromFragment(ContactInfoRowMapper.getJoinStatement(personPrefix));
        }

        return fragment;
    }
}
