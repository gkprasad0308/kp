package lds.personservice.options;

import java.util.List;
import java.util.logging.Logger;

import lds.stack.logging.jdk.Logging;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class SourceRepository implements OptionsRepository<Source>
{

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private NamedParameterJdbcTemplate namedTemplate;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Source> getOptions(int langId)
    {
        LOGGER.info(String.format("Getting non deleted sources for langId %d", langId));

        String sql = "select f.find_id, f.parent_find_id, f.sort_ord, f.del_dt, z.FIND_T_ID, z.FIND_T_CD, s.str as FIND_T_DSCR\n"
              + "from ims.z_find_t z\n"
              + "  join ims.z_find f on f.FIND_T_ID = z.FIND_T_ID\n"
              + "  join ims.afab_str_key k on k.afab_STR_KEY = ('findType.' || z.FIND_T_CD)\n"
              + "  join ims.afab_str s on s.afab_STR_KEY_ID = k.afab_STR_KEY_ID\n"
              + "  where s.LANG_ID = :langId\n"
              + "and f.del_dt is null\n"
              + "order by f.sort_ord";
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("langId", langId);

        return namedTemplate.query(sql, params, (rs, rowNum) -> {
            SourceType sourceType = new SourceType();
            sourceType.setSourceTypeCode(rs.getString("FIND_T_CD"));
            sourceType.setSourceTypeDescription(rs.getString("FIND_T_DSCR"));
            sourceType.setSourceTypeId(rs.getInt("FIND_T_ID"));

            Source source = new Source();
            source.setDeleteDate(rs.getDate("del_dt"));
            source.setParentSourceId(rs.getInt("parent_find_id"));
            source.setSortOrder(rs.getInt("sort_ord"));
            source.setId(rs.getInt("find_id"));
            source.setSourceType(sourceType);

            return source;
        });
    }

    public boolean exists(int contactSource)
    {
        return jdbcTemplate.queryForObject(
              "SELECT count(*) FROM ims.z_find WHERE find_id = ?",
              new Object[]{contactSource},
              Integer.class
        ) > 0;
    }
}
