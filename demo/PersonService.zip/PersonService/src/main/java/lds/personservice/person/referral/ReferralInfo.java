package lds.personservice.person.referral;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ReferralInfo
{

    private int referralStatId;
    private boolean escalated;
    private Long ownerMissionaryId;
    private Long ownerOrgId;
    private String note;
    private Long receivingProsArea;
    private Long receivingOrgId;
    private Long receivingMissionaryId;
    private Date claimDate;
    private Date createDate;
    private Referrer referrer;
    private Long receivingStewardCmisId;
    private Long ownerStewardCmisId;

    @JsonIgnore
    public boolean isEmpty()
    {
        return referrer == null && createDate == null;
    }

    public int getReferralStatId()
    {
        return referralStatId;
    }

    public void setReferralStatId(int referralStatId)
    {
        this.referralStatId = referralStatId;
    }

    public boolean isEscalated()
    {
        return escalated;
    }

    public void setEscalated(boolean escalated)
    {
        this.escalated = escalated;
    }

    public Long getOwnerMissionaryId()
    {
        return ownerMissionaryId;
    }

    public void setOwnerMissionaryId(Long ownerMissionaryId)
    {
        this.ownerMissionaryId = ownerMissionaryId;
    }

    public Long getOwnerOrgId()
    {
        return ownerOrgId;
    }

    public void setOwnerOrgId(Long ownerOrgId)
    {
        this.ownerOrgId = ownerOrgId;
    }

    public String getNote()
    {
        return note;
    }

    public void setNote(String note)
    {
        this.note = note;
    }

    public Long getReceivingProsArea()
    {
        return receivingProsArea;
    }

    public void setReceivingProsArea(Long receivingProsArea)
    {
        this.receivingProsArea = receivingProsArea;
    }

    public Long getReceivingOrgId()
    {
        return receivingOrgId;
    }

    public void setReceivingOrgId(Long receivingOrgId)
    {
        this.receivingOrgId = receivingOrgId;
    }

    public Long getReceivingMissionaryId()
    {
        return receivingMissionaryId;
    }

    public void setReceivingMissionaryId(Long receivingMissionaryId)
    {
        this.receivingMissionaryId = receivingMissionaryId;
    }

    public Date getClaimDate()
    {
        return claimDate;
    }

    public void setClaimDate(Date claimDate)
    {
        this.claimDate = claimDate;
    }

    public Date getCreateDate()
    {
        return createDate;
    }

    public void setCreateDate(Date createDate)
    {
        this.createDate = createDate;
    }

    public void setReferrer(Referrer referrer)
    {
        this.referrer = referrer;
    }

    public Referrer getReferrer()
    {
        return referrer;
    }

    public void setReceivingStewardCmisId(Long receivingStewardCmisId)
    {
        this.receivingStewardCmisId = receivingStewardCmisId;
    }

    public Long getReceivingStewardCmisId()
    {
        return receivingStewardCmisId;
    }

    public void setOwnerStewardCmisId(Long ownerStewardCmisId)
    {
        this.ownerStewardCmisId = ownerStewardCmisId;
    }

    public Long getOwnerStewardCmisId()
    {
        return ownerStewardCmisId;
    }
}
