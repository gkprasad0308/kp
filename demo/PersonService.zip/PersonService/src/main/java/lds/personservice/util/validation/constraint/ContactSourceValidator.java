package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidContactSource;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class ContactSourceValidator implements ConstraintValidator<ValidContactSource, Integer> {

    @Autowired
    private OptionsValidationService optionsService;

    @Override
    public void initialize(ValidContactSource validContactSource) {
        // TODO consider making a call to get the contact sources during initialize
    }

    @Override
    public boolean isValid(Integer contactSource, ConstraintValidatorContext constraintValidatorContext) {
        return contactSource == null || optionsService.contactSourceExists(contactSource);
    }
}
