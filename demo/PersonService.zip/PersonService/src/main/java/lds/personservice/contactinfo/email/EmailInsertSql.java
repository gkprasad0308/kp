package lds.personservice.contactinfo.email;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.stereotype.Component;

@Component
public class EmailInsertSql extends SqlUpdate
{

    public static final String PERSON_ID = "personId";
    public static final String COMM_TYPE_ID = "commTypeId";
    public static final String EMAIL_ADDR = "emailAddr";

    @Autowired
    public EmailInsertSql(DataSource dataSource)
    {
        init(dataSource);
    }

    private void init(DataSource dataSource)
    {
        setDataSource(dataSource);
        setSql("INSERT INTO ims.person_email ( "
              + "   person_email_id"
              + "   ,person_id"
              + "   ,comm_t_id"
              + "   ,email_addr"
              + " ) VALUES ("
              + "   ims.person_email_sq.nextval "
              + "   ,:" + PERSON_ID
              + "   ,:" + COMM_TYPE_ID
              + "   ,:" + EMAIL_ADDR
              + " ) ");

        declareParameter(new SqlParameter(PERSON_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(COMM_TYPE_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(EMAIL_ADDR, Types.VARCHAR));
    }

    public Map<String, Object> getParamsUsing(Email email, Long personId)
    {
        return new MapSqlParameterSource()
              .addValue(PERSON_ID, personId)
              .addValue(COMM_TYPE_ID, email.getType().id())
              .addValue(EMAIL_ADDR, email.getAddress())
              .getValues();
    }
}
