package lds.personservice.util.validation.interfaces;

public interface PersonPut {
}
