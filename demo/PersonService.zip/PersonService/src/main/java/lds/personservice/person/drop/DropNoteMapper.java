package lds.personservice.person.drop;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DropNoteMapper implements RowMapper<DropNote>
{

    public static final String NOTE = "note";
    public static final String DEL_YN = "del_yn";
    public static final String ALERT_DT = "alert_dt";
    public static final String MOD_DT = "mod_dt";
    public static final String CLIENT_GUID = "client_guid";

    @Override
    public DropNote mapRow(ResultSet rs, int i) throws SQLException
    {
        DropNote dropNote = new DropNote();

        dropNote.setNote(rs.getString(NOTE));
        dropNote.setDeleted("Y".equals(rs.getString(DEL_YN)));
        dropNote.setAlertDate(rs.getDate(ALERT_DT));
        dropNote.setModifiedDate(rs.getDate(MOD_DT));
        dropNote.setGuid(rs.getString(CLIENT_GUID));

        return dropNote;
    }
}
