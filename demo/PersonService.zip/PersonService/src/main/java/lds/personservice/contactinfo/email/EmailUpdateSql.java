package lds.personservice.contactinfo.email;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.stereotype.Component;

@Component
public class EmailUpdateSql extends SqlUpdate
{

    public static final String EMAIL_ADDR = "emailAddr";
    public static final String COMM_TYPE_ID = "commTypeId";
    public static final String PERSON_ID = "personId";

    @Autowired
    public EmailUpdateSql(DataSource dataSource)
    {
        init(dataSource);
    }

    private void init(DataSource dataSource)
    {
        setDataSource(dataSource);
        setSql(" UPDATE ims.person_email SET " +
                "       email_addr = :" + EMAIL_ADDR +
                " WHERE comm_t_id = :" + COMM_TYPE_ID +
                "   AND person_id = :" + PERSON_ID);

        declareParameter(new SqlParameter(EMAIL_ADDR, Types.VARCHAR));
        declareParameter(new SqlParameter(COMM_TYPE_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PERSON_ID, Types.NUMERIC));
    }

    public Map<String, Object> getParamsUsing(Email email, Long personId)
    {
        return new MapSqlParameterSource()
              .addValue(EMAIL_ADDR, email.getAddress())
              .addValue(COMM_TYPE_ID, email.getType().id())
              .addValue(PERSON_ID, personId)
              .getValues();
    }
}
