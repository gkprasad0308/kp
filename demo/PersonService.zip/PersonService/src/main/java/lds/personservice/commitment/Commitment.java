package lds.personservice.commitment;

import java.io.Serializable;
import java.util.Calendar;
import java.util.TimeZone;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import lds.personservice.converters.BooleanToStringConverter;
import lds.personservice.converters.LongToTimestampConverter;
import lds.personservice.util.validation.annotation.ValidPersonId;
import lds.prsms.utils.api.annotations.WriteOnly;
import lds.prsms.utils.validation.ValidationGroups;
import lds.prsms.utils.validation.annotation.ValidGuid;

@Entity
@Table(name = "PERSON_CMT_KEPT_MSTR_UV", schema = "IMS")
@SuppressWarnings({"ConsistentAccessType", "IdDefinedInHierarchy", "PersistenceUnitPresent"})
@JsonPropertyOrder({"id", "personId", "teachingItemId", "deleted", "wasKept", "modifiedDate", "inviteDate", "keptDate"})
public class Commitment implements Serializable {

    private static final long serialVersionUID = 364879149909041024L;

    @Id
    @JsonIgnore
    @SequenceGenerator(name = "commitmentIdSequence", sequenceName = "IMS.person_cmt_kept_sq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "commitmentIdSequence")
    @Column(name = "PERSON_CMT_KEPT_ID", nullable = false, precision = 38)
    private Long id;

    @JsonIgnore
    @Column(name = "PERSON_ID")
    private Long personId;

    //unique
    @NotNull(groups = {ValidationGroups.Post.class})
    @Column(name = "TCHN_ITEM_ID")
    private Long teachingItemId;
    @Column(name = "MOD_DT")
    @Convert(converter = LongToTimestampConverter.class)
    private Long modifiedDate;

    @NotNull(groups = {ValidationGroups.Post.class, ValidationGroups.Put.class})
    @Column(name = "INVT_DT")
    @Convert(converter = LongToTimestampConverter.class)
    private Long inviteDate;
    @Column(name = "KEPT_YN")
    @Convert(converter = BooleanToStringConverter.class)
    private Boolean wasKept;
    @Column(name = "KEPT_DT")
    @Convert(converter = LongToTimestampConverter.class)
    private Long keptDate;
    @JsonProperty("id")
    @Column(name = "CLIENT_GUID", length = 32)
    @ValidGuid(groups = {ValidationGroups.Post.class, ValidationGroups.Put.class})
    @NotNull(groups = {ValidationGroups.Put.class})
    private String clientGuid;

    @Transient
    @JsonProperty("personId")
    @WriteOnly
    @NotNull(groups = {ValidationGroups.Post.class})
    @ValidPersonId(groups = {ValidationGroups.Post.class, ValidationGroups.Put.class})
    private String personGuid;

    @Column(name = "DEL_YN", nullable = false)
    @Convert(converter = BooleanToStringConverter.class)
    private Boolean deleted;

    public Long getId() {
        return id;
    }

    public void setId(Long commitmentId) {
        this.id = commitmentId;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long newPersonId) {
        this.personId = newPersonId;
    }

    public Long getTeachingItemId() {
        return teachingItemId;
    }

    public void setTeachingItemId(Long newTeach) {
        teachingItemId = newTeach;
    }

    public Long getInviteDate() {
        return inviteDate;
    }

    public void setInviteDate(Long invt) {
        inviteDate = invt;
    }

    public Long getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Long modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Boolean getWasKept() {
        return wasKept;
    }

    public void setWasKept(Boolean kept) {
        wasKept = kept;
    }

    public Long getKeptDate() {
        return keptDate;
    }

    public void setKeptDate(Long kept) {
        keptDate = kept;
    }

    public Boolean getDeleted() {
        return this.deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public String getClientGuid() {
        return clientGuid;
    }

    public void setClientGuid(String clientGuid) {
        this.clientGuid = clientGuid;
    }

    @Transient
    public String getPersonGuid() {
        return personGuid;
    }

    @Transient
    public void setPersonGuid(String personGuid) {
        this.personGuid = personGuid;
    }

    @PreUpdate
    @PrePersist
    void configureModDate() {
        TimeZone tz = TimeZone.getTimeZone("America/Boise");
        Calendar c = Calendar.getInstance(tz);
        this.setModifiedDate(c.getTimeInMillis());
    }
}
