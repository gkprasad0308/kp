package lds.personservice.contactinfo;

import lds.personservice.contactinfo.email.Email;
import lds.personservice.contactinfo.phone.Phone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
public class ContactInfoService {

    @Autowired
    private ContactInfoRepository repository;

    public void createNewContactInfo(final long personId, final ContactInfo contactInfo){
        if(contactInfo == null){
            return;
        }

        if(!CollectionUtils.isEmpty(contactInfo.getEmailAddresses()))
            insertEmails(personId, contactInfo.getEmailAddresses());
        if(!CollectionUtils.isEmpty(contactInfo.getPhoneNumbers()))
            insertPhoneNumbers(personId, contactInfo.getPhoneNumbers());
    }

    public void mixUpdateContactInfo(final long personId, final ContactInfo newInfo, final ContactInfo originalInfo){
        if(newInfo != null) {
            updateContactInfo(personId, newInfo.extractDuplicatedTypes(originalInfo));
            createNewContactInfo(personId, newInfo.extractUniqueTypes(originalInfo));
        }
        if(originalInfo != null) {
            removeContactInfo(personId, originalInfo.extractUniqueTypes(newInfo));
        }
    }

    public void updateContactInfo(final long personId, final ContactInfo contactInfo){
        if(contactInfo == null){
            return;
        }

        if(!CollectionUtils.isEmpty(contactInfo.getPhoneNumbers()))
            updatePhoneNumbers(personId, contactInfo.getPhoneNumbers());
        if(!CollectionUtils.isEmpty(contactInfo.getEmailAddresses()))
            updateEmails(personId, contactInfo.getEmailAddresses());
    }

    public void removeContactInfo(final long personId, final ContactInfo contactInfo){
        if(contactInfo == null){
            return;
        }

        if(!CollectionUtils.isEmpty(contactInfo.getPhoneNumbers()))
            removePhoneNumbers(personId, contactInfo.getPhoneNumbers());
        if(!CollectionUtils.isEmpty(contactInfo.getEmailAddresses()))
            removeEmails(personId, contactInfo.getEmailAddresses());
    }

    private void insertPhoneNumbers(long personId, List<Phone> phoneNumbers) {
        for(Phone phone: phoneNumbers){
            repository.insertPhone(phone, personId);
        }
    }

    private void insertEmails(long personId, List<Email> emailAddresses) {
        for(Email email: emailAddresses){
            repository.insertEmail(email, personId);
        }
    }

    private void updatePhoneNumbers(long personId, List<Phone> phoneNumbers) {
        for(Phone phone: phoneNumbers){
            repository.updatePhone(phone, personId);
        }
    }

    private void updateEmails(long personId, List<Email> emails){
        for(Email email: emails){
            repository.updateEmail(email, personId);
        }
    }

    private void removePhoneNumbers(long personId, List<Phone> phoneNumbers){
        for(Phone phone : phoneNumbers){
            repository.removePhone(phone.getType(), personId);
        }
    }

    private void removeEmails(long personId, List<Email> emails){
        for(Email email: emails){
            repository.removeEmail(email.getType(), personId);
        }
    }

}
