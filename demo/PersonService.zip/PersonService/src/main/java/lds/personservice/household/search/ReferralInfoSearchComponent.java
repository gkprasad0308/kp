package lds.personservice.household.search;

import lds.personservice.household.InclusionParams;
import lds.personservice.household.ListParams;
import lds.personservice.person.referral.ReferralMapper;
import org.springframework.util.CollectionUtils;

import static java.util.Objects.requireNonNull;

public class ReferralInfoSearchComponent implements SearchComponent {

    private String personPrefix;

    public ReferralInfoSearchComponent(String personPrefix){
        this.personPrefix = requireNonNull(personPrefix);
    }

    @Override
    public SearchFragment buildFragment(ListParams listParams) {
        SearchFragment fragment = null;
        if(listParams != null && !CollectionUtils.isEmpty(listParams.getInclusions())
                && listParams.getInclusions().contains(InclusionParams.REFERRAL_INFO)){
            fragment = new SearchFragment()
                    .withSelectFragment(ReferralMapper.getSelectStatement("pr", "rg"))
                    .withFromFragment(ReferralMapper.getJoinStatement(personPrefix, "pr", "rg"));
        }

        return fragment;
    }
}
