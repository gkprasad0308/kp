package lds.personservice.household;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum InclusionParams
{
    FELLOWSHIPPERS,
    CONTACT_INFO,
    REFERRAL_INFO,
    DROP_NOTES,
    COMMITMENTS;

    public static InclusionParams getFromParam(String param)
    {
        InclusionParams result = null;

        if (!StringUtils.isEmpty(param)) {
            String finalParam = param.toUpperCase();

            for (InclusionParams incParam : InclusionParams.values()) {
                if (incParam.name().equals(finalParam)) {
                    result = incParam;
                    break;
                }
            }
        }

        return result;
    }

    public static List<InclusionParams> getDeltas(List<InclusionParams> params){

        List<InclusionParams> deltas = valuesAsList();
        if(!CollectionUtils.isEmpty(params)) {
            deltas = deltas.stream()
                    .filter(param -> !params.contains(param))
                    .collect(Collectors.toList());
        }
        return deltas;
    }
    public static List<InclusionParams> valuesAsList() {
        return Arrays.asList(InclusionParams.values()).stream().collect(Collectors.toList());
    }
}
