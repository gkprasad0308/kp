package lds.personservice.options;

import java.util.List;

public interface OptionsRepository<T extends Option> {
    List<T> getOptions(int langId);
}
