package lds.personservice.person;

import lds.personservice.util.SimpleSproc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Types;

@Component
public class DeletePersonSproc implements SimpleSproc
{

    public static final String I_PERSON_ID = "i_person_id";
    public static final String SCHEMA_NAME = "ims";
    public static final String CATALOG_NAME = "ims_person_mgmt";
    public static final String PROCEDURE_NAME = "delete_person";
    private final DataSource dataSource;

    @Autowired
    public DeletePersonSproc(DataSource dataSource)
    {
        this.dataSource = dataSource;
    }

    @Override
    public SimpleJdbcCall getStoredProc()
    {
        return new SimpleJdbcCall(dataSource)
              .withSchemaName(SCHEMA_NAME)
              .withCatalogName(CATALOG_NAME)
              .withProcedureName(PROCEDURE_NAME)
              .declareParameters(new SqlParameter(I_PERSON_ID, Types.NUMERIC));
    }

    public MapSqlParameterSource getParametersUsing(long personId)
    {
        return new MapSqlParameterSource()
              .addValue(I_PERSON_ID, personId);
    }

}
