package lds.personservice.missionorg;

import java.util.List;

public class ParentageWrapper
{

    private List<Parentage> parentage;

    public List<Parentage> getParentage() {
        return parentage;
    }

    public void setParentage(List<Parentage> parentage) {
        this.parentage = parentage;
    }
}
