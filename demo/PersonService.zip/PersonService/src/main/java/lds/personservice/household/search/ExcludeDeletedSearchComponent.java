package lds.personservice.household.search;

import lds.personservice.household.ListParams;
import org.apache.commons.lang3.ArrayUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ExcludeDeletedSearchComponent implements SearchComponent {

    private String[] prefixis;

    public ExcludeDeletedSearchComponent(String... prefixis){
        this.prefixis = prefixis;
    }

    @Override
    public SearchFragment buildFragment(ListParams listParams) {
        SearchFragment fragment = null;
        if(listParams != null && !listParams.isIncludeDeleted() && !ArrayUtils.isEmpty(prefixis)){

            List<String> fragments = Arrays.asList(prefixis).stream()
                    .map(prefix -> prefix + ".del_yn = :deleted")
                    .collect(Collectors.toList());

            fragment = new SearchFragment()
                .withWhereFragment(String.join(" AND ", fragments))
                .addParameter("deleted", "N");
        }
        return fragment;
    }
}
