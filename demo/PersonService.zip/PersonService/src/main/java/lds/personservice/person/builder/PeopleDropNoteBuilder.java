package lds.personservice.person.builder;


import lds.personservice.household.InclusionParams;
import lds.personservice.person.Person;
import lds.personservice.person.drop.DropNote;
import lds.personservice.person.drop.DropNoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class PeopleDropNoteBuilder extends AbstractConcretePeopleBuilder<DropNote> {

    @Autowired
    private DropNoteRepository repository;

    @Override
    protected Map<Long, List<DropNote>> getPeopleIdToTypeMap(List<Long> personIds) {
        return repository.getNotesForPeople(personIds);
    }

    @Override
    protected void mapToPeople(List<Person> people, Map<Long, List<DropNote>> typeMap) {
        for(Person person: people){
            person.setDropNotes(typeMap.get(person.getServerId()));
        }
    }

    @Override
    public boolean appliesToBuilder(BuilderParams params) {
        return containsInclusion(params, InclusionParams.DROP_NOTES);
    }
}
