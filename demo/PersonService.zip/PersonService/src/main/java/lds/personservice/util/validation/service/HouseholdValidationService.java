package lds.personservice.util.validation.service;

import lds.personservice.household.Household;
import lds.personservice.household.HouseholdRepository;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public class HouseholdValidationService {

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private HouseholdRepository householdRepository;

    public boolean householdExists(String householdGuid) {
        return householdRepository.householdWithGuidExists(householdGuid);
    }

    public Long getHouseholdOrgId(String householdGuid) {
        Long orgId = null;
        if(!StringUtils.isEmpty(householdGuid)){
            try {
                Household household = householdRepository.getHouseholdByGuid(householdGuid);
                orgId = household.getOrgId();
            }
            catch (NullPointerException e){
                LOGGER.warn(String.format("houshold guid %s did not match a valid household", householdGuid), e);
            }
        }
        return orgId;
    }

    public Household getOriginal(String guid) {
        Household household = null;
        if(!StringUtils.isEmpty(guid) && householdExists(guid)){
            household = householdRepository.getHouseholdByGuid(guid);
        }
        return household;
    }
}
