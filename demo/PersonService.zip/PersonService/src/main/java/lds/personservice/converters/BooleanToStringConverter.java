package lds.personservice.converters;

import javax.persistence.AttributeConverter;

/**
 * Created by Tim Jacobsen on 9/15/2015.
 */
public class BooleanToStringConverter implements AttributeConverter<Boolean, String>
{

    @Override
    public String convertToDatabaseColumn(Boolean value)
    {
        return Boolean.TRUE.equals(value) ? "Y" : "N";
    }

    @Override
    public Boolean convertToEntityAttribute(String value)
    {
        return "Y".equals(value);
    }

}
