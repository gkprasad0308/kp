package lds.personservice.person.fellowshipper;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FellowshipInfo
{

    private List<FellowshipData> fellowshippers;
    private List<FellowshipData> fellowshippees;

    public List<FellowshipData> getFellowshippers()
    {
        return fellowshippers;
    }

    public void setFellowshippers(List<FellowshipData> fellowshippers)
    {
        this.fellowshippers = fellowshippers;
    }

    public List<FellowshipData> getFellowshippees()
    {
        return fellowshippees;
    }

    public void setFellowshippees(List<FellowshipData> fellowshippees)
    {
        this.fellowshippees = fellowshippees;
    }

}
