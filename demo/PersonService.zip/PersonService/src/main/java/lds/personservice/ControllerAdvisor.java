package lds.personservice;

import lds.personservice.util.validation.ValidationException;
import lds.personservice.util.validation.ValidationResult;
import lds.prsms.utils.errors.ServiceError;
import lds.prsms.utils.errors.ServiceException;
import lds.prsms.utils.validation.ValidationError;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
public class ControllerAdvisor
{

    private static final Logger LOGGER = Logging.getLogger();
    private static final String ERROR_PREFIX = "error.";

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ValidationResult> handleMethodArgumentNotValidException(final HttpServletRequest request, final MethodArgumentNotValidException ex) {
        final String httpMethod = request.getMethod().toLowerCase();
        final String parameterName = ex.getParameter().getParameterName();

        ValidationResult validationError = new ValidationResult();
        final List<lds.prsms.utils.validation.FieldError> errorCodes = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(fieldError -> new lds.prsms.utils.validation.FieldError(fieldError.getField(), buildFieldErrorMessage(parameterName, httpMethod, fieldError)))
                .collect(Collectors.toList());
        final List<String> globalErrorCodes = ex.getBindingResult()
                .getGlobalErrors()
                .stream()
                .map(globalError -> buildObjectErrorMessage(globalError.getObjectName(), httpMethod, globalError))
                .collect(Collectors.toList());

        validationError.setFieldErrors(errorCodes);
        validationError.setGlobalErrors(globalErrorCodes);

        LOGGER.error("Validation errors encountered: {}", validationError.toString());

        return new ResponseEntity<>(validationError, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ValidationError handleValidationError(ValidationException ex)
    {
        logException(ex);
        ValidationError validationError = new ValidationError();

        for (lds.prsms.utils.validation.FieldError fieldError : ex.getFieldErrors()) {
            validationError.addFieldError(fieldError);
        }
        return validationError;
    }

    @ExceptionHandler(ServiceException.class)
    @ResponseBody
    public ResponseEntity<ServiceError> handleServiceException(ServiceException ex)
    {
        logException(ex);
        ServiceError error = new ServiceError(ex.getStatus(), ex.getCode());
        return new ResponseEntity<>(error, error.getStatus());
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ServiceError handleDefaultException(Exception ex)
    {
        logException(ex);
        return new ServiceError(HttpStatus.INTERNAL_SERVER_ERROR, ServiceException.SERVER_ERROR_UNKNOWN);
    }

    private void logException(Throwable ex) {
        LOGGER.error(String.format("EXCEPTION: %s", ex.getMessage()), ex);
    }

    /**
     * Builds an error message from a {@link FieldError}.
     * @param parameterName Parameter name that was found to be in violation
     * @param httpMethod HTTP method of the request
     * @param fieldError Field error containing the details of the error
     * @return Concatenated error message
     */
    private String buildFieldErrorMessage(final String parameterName, final String httpMethod, final FieldError fieldError) {
        final StringBuilder builder = new StringBuilder();
        builder.append(ERROR_PREFIX);
        builder.append(httpMethod);
        builder.append(".");
        builder.append(parameterName);
        builder.append(".");
        builder.append(fieldError.getDefaultMessage());
        builder.append(".");
        builder.append(fieldError.getField());

        return builder.toString();
    }

    /**
     * Builds an error message from a {@link FieldError}.
     * @param parameterName Parameter name that was found to be in violation
     * @param httpMethod HTTP method of the request
     * @param objectError Field error containing the details of the error
     * @return Concatenated error message
     */
    private String buildObjectErrorMessage(final String parameterName, final String httpMethod, final ObjectError objectError) {
        final StringBuilder builder = new StringBuilder();
        builder.append(ERROR_PREFIX);
        builder.append(httpMethod);
        builder.append(".");
        builder.append(parameterName);
        builder.append(".");
        builder.append(objectError.getDefaultMessage());

        return builder.toString();
    }
}
