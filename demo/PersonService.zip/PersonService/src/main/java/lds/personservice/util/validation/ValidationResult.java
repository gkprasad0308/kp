package lds.personservice.util.validation;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lds.prsms.utils.errors.ServiceError;
import lds.prsms.utils.validation.FieldError;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ValidationResult extends ServiceError {
    public static final String DEFAULT_CODE = "validation.errors";
    public static final HttpStatus DEFAULT_STATUS = HttpStatus.BAD_REQUEST;
    private static final Logger LOG = Logging.getLogger();

    private List<FieldError> fieldErrors;
    private List<String> globalErrors;

    public ValidationResult(){
        super(DEFAULT_STATUS, DEFAULT_CODE);
    }

    public ValidationResult(HttpStatus status, String code) {
        super(status, code);
    }

    public void addFieldError(String field, String code){
        FieldError fieldError = new FieldError(field, code);
        if(fieldErrors == null){
            fieldErrors = new ArrayList<>();
        }
        fieldErrors.add(fieldError);
    }

    public List<FieldError> getFieldErrors() {
        return fieldErrors;
    }

    public void setFieldErrors(List<FieldError> fieldErrors) {
        this.fieldErrors = fieldErrors;
    }

    public List<String> getGlobalErrors() {
        return globalErrors;
    }

    public void setGlobalErrors(List<String> globalErrors) {
        this.globalErrors = globalErrors;
    }

    public void addFieldError(FieldError fieldError) {
        if(CollectionUtils.isEmpty(fieldErrors)){
            fieldErrors = new LinkedList<>();
        }
        fieldErrors.add(fieldError);
    }

    @Override
    public String toString(){
        try {
            return new ObjectMapper().writeValueAsString(this);
        } catch (JsonProcessingException e) {
            LOG.warn("Unexpected error during validation result: ", e);
            return "un-mappable conversion of this to json";
        }
    }
}
