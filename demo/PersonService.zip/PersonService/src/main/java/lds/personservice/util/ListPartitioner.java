package lds.personservice.util;

import org.springframework.util.CollectionUtils;

import java.util.LinkedList;
import java.util.List;

public class ListPartitioner<T> {

    public static final int MAX_ORACLE_SIZE = 1000;

    public List<List<T>> oraclePartition(List<T> items){
        return partition(items, MAX_ORACLE_SIZE);
    }

    public List<List<T>> partition(List<T> items, int maxSize){
        List<List<T>> partitions = new LinkedList<>();

        if(!CollectionUtils.isEmpty(items)) {
            for (int i = 0; i < items.size(); i += maxSize) {
                partitions.add(items.subList(i, Math.min(items.size(), i + maxSize)));
            }
        }

        return partitions;
    }
}
