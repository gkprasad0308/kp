package lds.personservice.household;

import static java.util.Objects.requireNonNull;

import java.util.List;
import java.util.stream.Stream;

import javax.inject.Inject;

import lds.personservice.household.search.BaseSearch;
import lds.personservice.household.search.HouseholdSearchFactory;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import lds.personservice.contactinfo.ContactInfoRowMapper;
import lds.personservice.person.PersonRowMapper;
import lds.personservice.person.PopulateCurrentPersonProcedure;
import lds.personservice.person.referral.ReferralMapper;
import lds.prsms.utils.UUIDGenerator;
import lds.prsms.utils.errors.ServiceException;
import lds.stack.logging.slf4j.Logging;

@Repository
public class HouseholdRepository {

    private static final Logger LOGGER = Logging.getLogger();

    private final NamedParameterJdbcTemplate namedTemplate;

    private final JdbcTemplate jdbcTemplate;

    private final HouseholdInsertSql householdInsertSql;

    private final HouseholdUpdateSql householdUpdateSql;

    private final PopulateCurrentPersonProcedure populateCurrentPersonProcedure;

    private final HouseholdSearchFactory searchFactory;

    private final UUIDGenerator uuidGenerator;
    
    @Inject
    public HouseholdRepository(final NamedParameterJdbcTemplate namedTemplate, final JdbcTemplate jdbcTemplate,
        final HouseholdInsertSql householdInsertSql, final HouseholdUpdateSql householdUpdateSql, final PopulateCurrentPersonProcedure populateCurrentPersonProcedure,
        final HouseholdSearchFactory searchFactory, final UUIDGenerator uuidGenerator) {
        this.namedTemplate = requireNonNull(namedTemplate, "namedTemplate shall not be null");
        this.jdbcTemplate = requireNonNull(jdbcTemplate, "jdbcTemplate shall not be null");
        this.householdInsertSql = requireNonNull(householdInsertSql, "householdInsertSql shall not be null");
        this.householdUpdateSql = requireNonNull(householdUpdateSql, "householdUpdateSql shall not be null");
        this.populateCurrentPersonProcedure = requireNonNull(populateCurrentPersonProcedure, "populateCurrentPersonProcedure shall not be null");
        this.searchFactory = requireNonNull(searchFactory, "searchFactory cannot be null");
        this.uuidGenerator = requireNonNull(uuidGenerator, "uuidGenerator shall not be null");
    }

    public List<Household> searchHouseholds(ListParams listParams) {
        BaseSearch search = searchFactory.getSearch(listParams);
        populateAssignmentAreaSproc(listParams);
        return namedTemplate.query(search.getSql(), search.getSqlParameters(), search.getExtractor());
    }

    private void populateAssignmentAreaSproc(ListParams listParams) {
        if(listParams.getAssignmentArea() != null && listParams.getAssignmentArea() > 0) {
            SqlParameterSource params = populateCurrentPersonProcedure.getParametersUsing(listParams.getAssignmentArea());
            populateCurrentPersonProcedure.getStoredProc().execute(params);
        }
    }

    public void createNewHousehold(Household household) {
        household.setServerId(getNextHouseholdId());
        LOGGER.info(String.format("Assigned id %d to new household", household.getServerId()));

        if (StringUtils.isEmpty(household.getGuid())) {
            household.setGuid(generateAcceptableId());
        }
        household.cleanAddress();
        householdInsertSql.updateByNamedParam(householdInsertSql.getParamsUsing(household));
    }

    private long getNextHouseholdId() {
        return jdbcTemplate.queryForObject("SELECT ims.hshld_sq.nextval FROM dual", Long.class);
    }

    public void updateHousehold(Household household) {
        household.cleanAddress();
        householdUpdateSql.updateByNamedParam(householdUpdateSql.getParamsUsing(household));
    }

    public Household getHouseholdById(Long householdId) {
        HouseholdExtractor householdExtractor = new HouseholdExtractor();
        householdExtractor.useContactInfoRowMapper(true);
        householdExtractor.useReferralRowMapper(true);
        String sql = "SELECT " + HouseholdRowMapper.getSelectStatement("h") + ","
                     + PersonRowMapper.getSelectStatement("p") + ", "
                     + ContactInfoRowMapper.getSelectStatement() + ","
                     + ReferralMapper.getSelectStatement("pr", "rg")
                     + " FROM ims.hshld_mstr h "
                     + " LEFT JOIN ims.person_mstr p "
                     + "   ON h.hshld_id = p.hshld_id "
                     + ContactInfoRowMapper.getJoinStatement("p")
                     + ReferralMapper.getJoinStatement("p", "pr", "rg")
                     + " WHERE h.hshld_id = :householdId";
        List<Household> households = namedTemplate.query(sql, new MapSqlParameterSource().addValue("householdId", householdId), householdExtractor);
        if (CollectionUtils.isEmpty(households)) {
            throw new ServiceException(HttpStatus.BAD_REQUEST, "household.notFound");
        }
        return households.get(0);
    }

    public void deleteHousehold(Long householdId) {
        String sql = "UPDATE ims.hshld_mstr SET del_yn = 'Y', mod_dt = SYSDATE WHERE hshld_id = :hshldId";
        namedTemplate.update(sql, new MapSqlParameterSource().addValue("hshldId", householdId));
    }

    public Household getHouseholdByGuid(String householdGuid) {
        HouseholdExtractor householdExtractor = new HouseholdExtractor();
        householdExtractor.useContactInfoRowMapper(true);
        householdExtractor.useReferralRowMapper(true);
        String sql = "SELECT " + HouseholdRowMapper.getSelectStatement("h") + ","
                     + PersonRowMapper.getSelectStatement("p") + ", "
                     + ContactInfoRowMapper.getSelectStatement() + ","
                     + ReferralMapper.getSelectStatement("pr", "rg")
                     + " FROM ims.hshld_mstr h "
                     + " LEFT JOIN ims.person_mstr p "
                     + "   ON h.hshld_id = p.hshld_id "
                     + ContactInfoRowMapper.getJoinStatement("p")
                     + ReferralMapper.getJoinStatement("p", "pr", "rg")
                     + " WHERE h.client_guid = :householdGuid";
        List<Household> households = namedTemplate.query(sql, new MapSqlParameterSource().addValue("householdGuid", householdGuid), householdExtractor);

        if (CollectionUtils.isEmpty(households)) {
            LOGGER.warn("Household not found with guid {}", householdGuid);
            throw new NullPointerException("household with guid not found");
        }

        return households.get(0);
    }

    public boolean householdWithGuidExists(String householdGuid) {
        HouseholdExtractor householdExtractor = new HouseholdExtractor();
        householdExtractor.useContactInfoRowMapper(true);
        householdExtractor.useReferralRowMapper(true);
        String sql = "SELECT count(*) FROM ims.hshld_mstr h WHERE h.client_guid = :householdGuid";
        int count = namedTemplate.queryForObject(sql, new MapSqlParameterSource().addValue("householdGuid", householdGuid),Integer.class);

        return count > 0;
    }

    private String generateAcceptableId() {
        final String result = Stream.generate(uuidGenerator::getAsString)
              .filter(g -> !householdWithGuidExists(g))
              .limit(5)
              .findFirst()
              .orElseThrow(() -> new ServiceException(HttpStatus.INTERNAL_SERVER_ERROR, "error.post.household.ungeneratable.guid"));

        return result;
    }
}
