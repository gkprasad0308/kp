package lds.personservice.util.validation.constraint;

import lds.personservice.household.Household;
import lds.personservice.util.validation.annotation.ValidLatLng;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class LatLngValidator implements ConstraintValidator<ValidLatLng, Household> {
    @Override
    public void initialize(ValidLatLng validLatLng) {
        // isValid does the work
    }

    @Override
    public boolean isValid(Household household, ConstraintValidatorContext constraintValidatorContext) {
        return (household.getLng() == null && household.getLat() == null) ||
                (household.getLat() != null && household.getLng() != null);
    }
}
