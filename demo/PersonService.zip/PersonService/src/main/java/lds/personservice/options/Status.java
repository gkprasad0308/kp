package lds.personservice.options;

public class Status implements Option
{

    private int id;
    private Integer parentId;
    private String code;
    private String name;
    private int typeId;

    @Override
    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public Integer getParentId()
    {
        return parentId;
    }

    public void setParentId(Integer parentId)
    {
        this.parentId = parentId;
    }

    public String getCode()
    {
        return code;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public void setTypeId(int typeId)
    {
        this.typeId = typeId;
    }

    public int getTypeId()
    {
        return typeId;
    }
}
