package lds.personservice.person.drop;

import lds.personservice.util.SimpleSproc;
import lds.prsms.utils.UUIDGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Calendar;
import java.util.TimeZone;

@Component
public class DropNoteSproc implements SimpleSproc
{

    public static final String PERSON_ID = "i_person_id";
    public static final String STATUS_ID = "i_status_id";
    public static final String MOD_DT = "i_mod_dt";
    public static final String DTL_NOTE = "i_dtl_note";
    public static final String DTL_CLIENT_GUID = "i_dtl_client_guid";
    public static final String DTL_ALERT_DT = "i_dtl_alert_dt";
    public static final String SCHEMA_NAME = "ims";
    public static final String CATALOG_NAME = "ims_person_stat_pkg";
    public static final String FUNCTION_NAME = "store_manual_status";
    private final DataSource dataSource;

    @Autowired
    public DropNoteSproc(DataSource dataSource)
    {
        this.dataSource = dataSource;
    }

    @Override
    public SimpleJdbcCall getStoredProc()
    {
        return new SimpleJdbcCall(dataSource)
              .withSchemaName(SCHEMA_NAME)
              .withCatalogName(CATALOG_NAME)
              .withFunctionName(FUNCTION_NAME)
              .declareParameters(
                    new SqlParameter(PERSON_ID, Types.NUMERIC),
                    new SqlParameter(STATUS_ID, Types.NUMERIC),
                    new SqlParameter(MOD_DT, Types.DATE),
                    new SqlParameter(DTL_NOTE, Types.VARCHAR),
                    new SqlParameter(DTL_CLIENT_GUID, Types.VARCHAR),
                    new SqlParameter(DTL_ALERT_DT, Types.DATE)
              );
    }

    public SqlParameterSource getParametersUsing(long personId, WritableDropNote dropNote)
    {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("America/Boise"));
        return new MapSqlParameterSource()
              .addValue(PERSON_ID, personId)
              .addValue(STATUS_ID, dropNote.getStatus())
              .addValue(MOD_DT, cal.getTime())
              .addValue(DTL_NOTE, dropNote.getNote())
              .addValue(DTL_CLIENT_GUID, UUIDGenerator.getInstance().getAsString())
              .addValue(DTL_ALERT_DT, dropNote.getAlertDate());
    }
}
