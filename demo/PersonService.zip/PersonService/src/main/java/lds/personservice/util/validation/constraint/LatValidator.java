package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidLat;
import org.apache.commons.lang3.math.NumberUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;


public class LatValidator implements ConstraintValidator<ValidLat, String> {
    @Override
    public void initialize(ValidLat validLat) {
        // isValid does the work
    }

    @Override
    public boolean isValid(String lat, ConstraintValidatorContext constraintValidatorContext) {
        boolean result = true;

        if(lat != null){
            Double number = NumberUtils.toDouble(lat, 99999.99999);
            result = number < 90 && number > -90;
        }

        return result;
    }
}
