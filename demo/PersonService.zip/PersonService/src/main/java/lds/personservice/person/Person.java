package lds.personservice.person;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lds.personservice.commitment.Commitment;
import lds.personservice.contactinfo.ContactInfo;
import lds.personservice.person.drop.DropNote;
import lds.personservice.person.fellowshipper.FellowshipInfo;
import lds.personservice.person.referral.ReferralInfo;
import lds.personservice.util.BaseAbpModel;
import lds.personservice.util.validation.annotation.*;
import lds.personservice.util.validation.interfaces.PersonPost;
import lds.personservice.util.validation.interfaces.PersonPut;
import lds.prsms.utils.api.annotations.ReadOnly;
import lds.prsms.utils.validation.ValidationGroups.Post;
import lds.prsms.utils.validation.ValidationGroups.Put;
import lds.prsms.utils.validation.annotation.ValidGuid;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@ValidCmisIdMember(groups = {Put.class, Post.class})
@ValidProsAreaAssignment(groups = {PersonPost.class, PersonPut.class})
@JsonPropertyOrder({"id", "householdId", "ageCatId", "serverId", "status", "contactSource", "contactSourceDtl", "preferredLangId", "preferredContactType",
    "cmisId", "prosAreaId", "firstName", "lastName", "gender", "focusPerson = false", "convert = false", "deleted = false", "member = false",
    "modDate", "createDate", "note", "contactInfo", "fellowshipInfo", "referralInfo", "dropNotes", "commitments"})
public class Person extends BaseAbpModel<Person> {

    @ValidGuid(groups = {Post.class, Put.class})
    @JsonProperty("id")
    private String guid;

    private Long serverId;

    @NotNull(groups = {PersonPost.class})
    @ValidHouseholdId(groups = {PersonPost.class, PersonPut.class})
    private String householdId;

    @JsonIgnore
    private Long householdServerId;

    @Size(max = 60, groups = {Post.class, Put.class})
    private String firstName;

    @Size(max = 60, min = 0, groups = {Post.class, Put.class})
    private String lastName;

    @ValidGender(groups = {Post.class, Put.class})
    private String gender;
    private boolean focusPerson = false;

    @ValidAgeCategory(groups = {Post.class, Put.class})
    private Integer ageCatId;

    @NotNull(groups = {Post.class})
    @ValidStatus(groups = {Post.class, Put.class})
    private Integer status;
    private boolean convert = false;

    @NotNull(groups = {Post.class})
    @ValidContactSource(groups = {Post.class, Put.class})
    private Integer contactSource;
    private Integer contactSourceDtl;
    private Long cmisId;
    @ValidPreferredLangId(groups = {Post.class, Put.class})
    private Integer preferredLangId;
    @ValidPreferredContactType(groups = {Post.class, Put.class})
    private Integer preferredContactType;
    @ReadOnly
    private boolean member = false;
    @Valid
    private ContactInfo contactInfo;
    @ReadOnly
    @Valid
    private List<DropNote> dropNotes;
    @Size(max = 1025, groups = {Post.class, Put.class})
    private String note;
    private Long prosAreaId;
    @ReadOnly
    private FellowshipInfo fellowshipInfo;
    @ReadOnly
    private ReferralInfo referralInfo;
    @ReadOnly
    private List<Commitment> commitments;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        addKey("guid", guid);
        this.guid = guid;
    }

    public Long getServerId() {
        return serverId;
    }

    public void setServerId(Long serverId) {
        this.serverId = serverId;
    }

    public Long getHouseholdServerId() {
        return householdServerId;
    }

    public void setHouseholdServerId(Long householdServerId) {
        addKey("householdServerId", householdServerId);
        this.householdServerId = householdServerId;
    }

    public String getHouseholdId() {
        return householdId;
    }

    public void setHouseholdId(String householdId) {
        addKey("householdId", householdId);
        this.householdId = householdId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        addKey("firstName", firstName);
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        addKey("lastName", lastName);
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        addKey("gender", gender);
        this.gender = gender;
    }

    public boolean isFocusPerson() {
        return focusPerson;
    }

    public void setFocusPerson(boolean focusPerson) {
        addKey("focusPerson", focusPerson);
        this.focusPerson = focusPerson;
    }

    public Integer getAgeCatId() {
        return ageCatId;
    }

    public void setAgeCatId(Integer ageCatId) {
        addKey("ageCatId", ageCatId);
        this.ageCatId = ageCatId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        addKey("status", status);
        this.status = status;
    }

    public boolean isConvert() {
        return convert;
    }

    public void setIsConvert(boolean isConvert) {
        addKey("convert", isConvert);
        this.convert = isConvert;
    }

    public Integer getContactSource() {
        return contactSource;
    }

    public void setContactSource(Integer contactSource) {
        addKey("contactSource", contactSource);
        this.contactSource = contactSource;
    }

    public Integer getContactSourceDtl() {
        return contactSourceDtl;
    }

    public void setContactSourceDtl(Integer contactSourceDtl) {
        addKey("contactSourceDtl", contactSourceDtl);
        this.contactSourceDtl = contactSourceDtl;
    }

    public Long getCmisId() {
        return cmisId;
    }

    public void setCmisId(Long cmisId) {
        addKey("cmisId", cmisId);
        this.cmisId = cmisId;
    }

    public Integer getPreferredLangId() {
        return preferredLangId;
    }

    public void setPreferredLangId(Integer preferredLangId) {
        addKey("preferredLangId", preferredLangId);
        this.preferredLangId = preferredLangId;
    }

    public Integer getPreferredContactType() {
        return preferredContactType;
    }

    public void setPreferredContactType(Integer preferredContactType) {
        addKey("preferredContactType", preferredContactType);
        this.preferredContactType = preferredContactType;
    }

    public boolean isMember() {
        return member;
    }

    public void setMember(boolean member) {
        addKey("member", member);
        this.member = member;
    }

    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        addKey("note", note);
        this.note = note;
    }

    public Long getProsAreaId() {
        return prosAreaId;
    }

    public void setProsAreaId(Long prosAreaId) {
        addKey("prosAreaId", prosAreaId);
        this.prosAreaId = prosAreaId;
    }

    public void setFellowshipInfo(FellowshipInfo fellowshipInfo) {
        this.fellowshipInfo = fellowshipInfo;
    }

    public FellowshipInfo getFellowshipInfo() {
        return fellowshipInfo;
    }

    public void setReferralInfo(ReferralInfo referralInfo) {
        this.referralInfo = referralInfo;
    }

    public ReferralInfo getReferralInfo() {
        return referralInfo;
    }

    public List<DropNote> getDropNotes() {
        return dropNotes;
    }

    public void setDropNotes(List<DropNote> dropNotes) {
        this.dropNotes = dropNotes;
    }

    public List<Commitment> getCommitments() {
        return commitments;
    }

    public void setCommitments(List<Commitment> commitments) {
        this.commitments = commitments;
    }

    public boolean hasProsAreaChanged(Person original) {
        boolean result = false;
        if(original != null) {
            result = isFieldPresent("prosAreaId") && getProsAreaId() != null &&
                    !getProsAreaId().equals(original.getProsAreaId());
        }
        return result;
    }
}
