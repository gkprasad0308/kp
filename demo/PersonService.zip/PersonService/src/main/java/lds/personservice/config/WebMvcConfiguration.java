/*
 * Copyright (C) 2015 Intellectual Reserve, Inc. All rights reserved.
 * This notice may not be removed.
 */
package lds.personservice.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @author Robert Thornton
 */
@Configuration
public class WebMvcConfiguration extends WebMvcConfigurerAdapter
{

    @Value("${lds.defaultPath:${lds.api.contextPath:/api}}")
    private String defaultPath;

    @Override
    public void addViewControllers(ViewControllerRegistry registry)
    {
        registry.addViewController("/").setViewName("redirect:" + defaultPath);
    }
}
