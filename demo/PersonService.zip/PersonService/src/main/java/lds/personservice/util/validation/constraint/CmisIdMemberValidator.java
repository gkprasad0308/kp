package lds.personservice.util.validation.constraint;

import lds.personservice.person.Person;
import lds.personservice.util.validation.annotation.ValidCmisIdMember;
import lds.personservice.util.validation.service.OptionsValidationService;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class CmisIdMemberValidator implements ConstraintValidator<ValidCmisIdMember, Person> {

    @Inject
    private OptionsValidationService validationService;

    @Override
    public void initialize(ValidCmisIdMember validCmisIdMember) {
        // isValid does the work
    }

    @Override
    public boolean isValid(Person person, ConstraintValidatorContext constraintValidatorContext) {
        boolean result = false;

        if(person != null){
            result = person.getCmisId() == null || (person.getProsAreaId() == null && validationService.isMemberStatus(person.getStatus()));
        }

        return result;
    }
}
