package lds.personservice.missionorg;

import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.util.CollectionUtils;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Parentage extends MisOrgEntity
{

    private List<Parentage> parents;

    public List<Parentage> getParents()
    {
        return parents;
    }

    public void setParents(List<Parentage> parents)
    {
        this.parents = parents;
    }

    public void addParent(Parentage parent) {
        if(CollectionUtils.isEmpty(parents)){
            parents = new LinkedList<>();
        }
        parents.add(parent);
    }
}
