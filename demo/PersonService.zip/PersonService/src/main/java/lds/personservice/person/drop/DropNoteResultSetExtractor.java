package lds.personservice.person.drop;

import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DropNoteResultSetExtractor implements ResultSetExtractor<Map<Long, List<DropNote>>>
{

    public static final String PERSON_ID = "person_id";
    private DropNoteMapper dropNoteMapper = new DropNoteMapper();

    @Override
    public Map<Long, List<DropNote>> extractData(ResultSet rs) throws SQLException
    {
        Map<Long, List<DropNote>> resultMap = new HashMap<>();

        int index = 0;
        while (rs.next()) {
            DropNote note = dropNoteMapper.mapRow(rs, ++index);
            long personId = rs.getLong(PERSON_ID);
            if (!resultMap.containsKey(personId)) {
                resultMap.put(personId, new ArrayList<>());
            }
            resultMap.get(personId).add(note);
        }
        return resultMap;
    }

}
