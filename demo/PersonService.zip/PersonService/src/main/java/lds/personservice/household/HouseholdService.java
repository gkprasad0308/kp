package lds.personservice.household;

import lds.personservice.person.Person;
import lds.personservice.person.PersonService;
import lds.personservice.person.builder.BuilderParams;
import lds.personservice.person.builder.PeopleBuilder;
import lds.personservice.person.builder.PeopleBuilderService;
import lds.prsms.utils.errors.ServiceException;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class HouseholdService {

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private HouseholdRepository householdRepository;

    @Autowired
    private PersonService personService;

    @Autowired
    private PeopleBuilderService peopleBuilderService;

    public HouseholdListWrapper searchHouseholds(ListParams params) {
        List<Household> households = householdRepository.searchHouseholds(params);

        BuilderParams builderParams = new BuilderParams(params);
        PeopleBuilder builder = peopleBuilderService.getBuilder();
        builder.withParams(builderParams)
                .withPeople(households.stream().flatMap(h -> h.getPeople().stream()).collect(Collectors.toList()))
                .construct();
        return new HouseholdListWrapper(households);
    }

    public Household getHousehold(String householdGuid) {
        try {
            Household household = householdRepository.getHouseholdByGuid(householdGuid);
            if (CollectionUtils.isEmpty(household.getPeople())) {
                LOGGER.warn(String.format("Household for id %s has no people", householdGuid));
                return household;
            }

            BuilderParams params = new BuilderParams();
            params.setInclusions(InclusionParams.values());
            PeopleBuilder builder = peopleBuilderService.getBuilder();
            builder.withParams(params)
                    .withPeople(household.getPeople())
                    .construct();

            return household;
        }
        catch (NullPointerException e){
            LOGGER.warn("error getting household: ", e);
            throw new ServiceException(HttpStatus.BAD_REQUEST, "household.notFound");
        }
    }

    public void deleteHousehold(String householdGuid) {
        LOGGER.info(String.format("Deleting household %s", householdGuid));
        Household original = getHousehold(householdGuid);

        householdRepository.deleteHousehold(original.getServerId());
        if (!CollectionUtils.isEmpty(original.getPeople())) {
            for (Person person : original.getPeople()) {
                personService.deletePerson(person.getGuid());
            }
        }
    }

    public void updateHousehold(Household household, String householdGuid) {
        LOGGER.info(String.format("Updating household %s", householdGuid));
        Household extantHousehold = getHousehold(householdGuid);
        extantHousehold.applyChangesToThis(household);
        householdRepository.updateHousehold(extantHousehold);
        handleHouseholdPeople(household);
    }

    public Household createNewHousehold(Household household) {
        LOGGER.info("Creating a new household");
        // TODO validationify
        if (!StringUtils.isEmpty(household.getGuid()) && householdRepository.householdWithGuidExists(household.getGuid())) {
            LOGGER.error("Encountered a duplicate household guid {} during the creation of a household", household.getGuid());
            throw new ServiceException(HttpStatus.BAD_REQUEST, "error.household.create.duplicate.guid");
        }
        household.cleanAddress();
        householdRepository.createNewHousehold(household);
        handleHouseholdPeople(household);

        return getHousehold(household.getGuid());
    }

    private void handleHouseholdPeople(Household household) {
        LOGGER.info(String.format("Updating %d people for household %s",
                CollectionUtils.isEmpty(household.getPeople()) ? 0 : household.getPeople().size(), household.getGuid()));

        household.applyHouseholdIdsAcrossPeople();
        personService.savePeople(household.getPeople());
    }
}
