/*
 * Copyright (C) 2015 Intellectual Reserve, Inc. All rights reserved.
 * This notice may not be removed.
 */
package lds.personservice;

import lds.personservice.missionorg.MissionOrgService;
import lds.prsms.utils.api.ApiContext;
import lds.prsms.utils.api.ServiceAppDetails;
import lds.stack.spring.web.ResourceDecorator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import static lds.stack.spring.web.Link.toSelf;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.HEAD;

/**
 * The main web service API entry point.
 */
@RestController
@RequestMapping("${lds.api.resources.serviceDetails.href}")
public class MainController
{
    @Autowired
    private ApiContext apiContext;

    @Autowired
    private MissionOrgService missionOrgService;

    //-- HTTP Method Mappings ----------------------------------------------------------------------------------------//
    /**
     * Handles requests for headers from this endpoint. This operation is useful for clients that need to obtain resource headers
     * (such as the CSRF token) without incurring the overhead of requesting the resource itself.
     */
    @ResponseStatus(NO_CONTENT)
    @RequestMapping(method = HEAD)
    public void head()
    {
        // default method from stack starter
    }

    /**
     * Returns meta-information about the web service application such as platform, version, build date, and so forth.
     *
     * @return An object describing the web service application, optionally decorated with hypermedia links
     */
    @RequestMapping(method = GET, produces = {"application/hal+json", "application/json"})
    public ServiceAppDetails get()
    {
        ServiceAppDetails appDetails = apiContext.getAppDetails();
        appDetails.setModels(apiContext.getModels());
        appDetails.addHealthCheck("missionOrgService", missionOrgService.healthCheck());
        return ResourceDecorator.forResource(appDetails)
              .link(toSelf())
              .link(apiContext.getLinks())
              .decorate();
    }
}
