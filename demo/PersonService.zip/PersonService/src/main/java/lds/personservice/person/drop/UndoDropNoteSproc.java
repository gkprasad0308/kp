package lds.personservice.person.drop;

import java.sql.Types;
import java.util.Date;

import javax.sql.DataSource;

import lds.personservice.util.SimpleSproc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

@Component
public class UndoDropNoteSproc implements SimpleSproc
{

    public static final String SCHEMA_NAME = "ims";
    public static final String CATALOG_NAME = "ims_person_stat_pkg";
    public static final String PROCEDURE_NAME = "undo_drop";
    public static final String PERSON_STWRD_DTL_ID = "i_person_stwrd_dtl_id";
    public static final String NEW_MOD_DT = "i_new_mod_dt";
    private final DataSource dataSource;

    @Autowired
    public UndoDropNoteSproc(DataSource dataSource)
    {
        this.dataSource = dataSource;
    }

    @Override
    public SimpleJdbcCall getStoredProc()
    {
        return new SimpleJdbcCall(dataSource)
              .withSchemaName(SCHEMA_NAME)
              .withCatalogName(CATALOG_NAME)
              .withProcedureName(PROCEDURE_NAME)
              .withoutProcedureColumnMetaDataAccess()
              .declareParameters(
                    new SqlParameter(PERSON_STWRD_DTL_ID, Types.NUMERIC),
                    new SqlParameter(NEW_MOD_DT, Types.DATE)
              );
    }

    public MapSqlParameterSource getParametersUsing(Long personStewardDetailId, Date newModDate)
    {
        return new MapSqlParameterSource()
              .addValue(PERSON_STWRD_DTL_ID, personStewardDetailId)
              .addValue(NEW_MOD_DT, newModDate);
    }
}
