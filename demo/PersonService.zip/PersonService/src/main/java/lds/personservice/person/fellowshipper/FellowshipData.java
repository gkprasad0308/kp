package lds.personservice.person.fellowshipper;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class FellowshipData
{

    @JsonIgnore
    private long personServerId;
    private String personId;
    private String firstName;
    private String lastName;
    private boolean deleted;

    @JsonIgnore
    public long getPersonServerId()
    {
        return personServerId;
    }

    public void setPersonServerId(long personServerId)
    {
        this.personServerId = personServerId;
    }

    public String getPersonId()
    {
        return personId;
    }

    public void setPersonId(String personId)
    {
        this.personId = personId;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public boolean isDeleted()
    {
        return deleted;
    }

    public void setDeleted(boolean deleted)
    {
        this.deleted = deleted;
    }
}
