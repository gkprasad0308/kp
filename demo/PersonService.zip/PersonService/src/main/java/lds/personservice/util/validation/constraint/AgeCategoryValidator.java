package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidAgeCategory;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class AgeCategoryValidator implements ConstraintValidator<ValidAgeCategory, Integer> {

    @Autowired
    private OptionsValidationService optionsValidationService;

    @Override
    public void initialize(ValidAgeCategory validAgeCategory) {
        // TODO maybe hit the validation service during the initailize phase?
    }

    @Override
    public boolean isValid(Integer ageCategory, ConstraintValidatorContext constraintValidatorContext) {
        return ageCategory == null || optionsValidationService.ageCategoryExists(ageCategory);
    }
}
