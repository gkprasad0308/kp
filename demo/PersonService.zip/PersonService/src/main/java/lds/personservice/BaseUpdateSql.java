package lds.personservice;

import org.springframework.jdbc.object.SqlUpdate;

public class BaseUpdateSql extends SqlUpdate
{

    protected String parseBoolean(Boolean value)
    {
        return Boolean.TRUE.equals(value) ? "Y" : "N";
    }
}
