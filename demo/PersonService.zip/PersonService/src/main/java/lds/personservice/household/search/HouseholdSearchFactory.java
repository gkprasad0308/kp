package lds.personservice.household.search;

import lds.personservice.household.ListParams;

import javax.inject.Named;

@Named
public class HouseholdSearchFactory {

    public BaseSearch getSearch(ListParams listParams){
        BaseSearch search;
        if (listParams.getAssignmentArea() != null && listParams.getAssignmentArea() > 0) {
            search = new AssignmentSearch(listParams);
        } else {
            search = new ParamsSearch(listParams);
        }
        return search;
    }
}
