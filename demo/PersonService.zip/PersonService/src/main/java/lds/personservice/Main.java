/*
 * Copyright (C) 2015 Intellectual Reserve, Inc. All rights reserved.
 * This notice may not be removed.
 */
package lds.personservice;

import lds.stack.logging.slf4j.Logging;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * The main application entry point.
 */
@SpringBootApplication
@EnableTransactionManagement
public class Main
{

    private static final Logger LOGGER = Logging.getLogger();

    /**
     * Start up the Spring Boot Application container.
     *
     * @param args Command-line arguments.
     */
    public static void main(String[] args)
    {
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--encrypt":
                    encrypt(args, i + 1);
                    return;
                case "--decrypt":
                    decrypt(args, i + 1);
                    return;
                default:
                    continue;
            }
        }
        SpringApplication.run(Main.class, args);
    }

    private static void encrypt(String[] args, int index)
    {
        if (index >= args.length) {
            LOGGER.error("The \"--encrypt\" command requires an argument");
            System.exit(1);
        }
        LOGGER.info("{cipher}" + getEncryptor().encrypt(args[index]));
    }

    private static void decrypt(String[] args, int index)
    {
        if (index >= args.length) {
            LOGGER.error("The \"--decrypt\" command requires an argument");
            System.exit(1);
        }
        String value = args[index];
        String[] supportedPrefixes = {"{cipher}"};
        for (String prefix : supportedPrefixes) {
            if (value.toLowerCase().startsWith(prefix)) {
                value = value.substring(prefix.length());
                break;
            }
        }
        LOGGER.info(getEncryptor().decrypt(value));
    }

    private static StandardPBEStringEncryptor getEncryptor()
    {
        String secret = System.getProperty("lds.encryptor.secret");
        if (secret == null) {
            LOGGER.error("ERROR! The \"lds.encryptor.secret\" JVM argument is not defined.");
            System.exit(1);
        }
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(secret);
        return encryptor;
    }
}
