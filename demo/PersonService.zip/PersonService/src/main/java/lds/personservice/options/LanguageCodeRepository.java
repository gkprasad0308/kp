package lds.personservice.options;

import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;

import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

@Repository
public class LanguageCodeRepository implements OptionsRepository<Language>
{

    private static final Logger LOGGER = Logging.getLogger();
    public static final int DEFAULT_LANG_ID = 0;

    @Autowired
    private JdbcTemplate template;

    @Autowired
    NamedParameterJdbcTemplate namedTemplate;

    public boolean exists(int langId)
    {
        return template.queryForObject(
              "SELECT count(*) FROM mdmr.mdm_language WHERE language_code = ? AND count_as_approved_y_n_flag = 'Y'",
              new Object[]{langId},
              Integer.class
        ) > 0;
    }

    @Override
    public List<Language> getOptions(int langId)
    {
        LOGGER.info(String.format("Getting languages for langId %d", langId));
        String sql = "SELECT lang.language_code, trans.lang_name, lang.written_y_n_flag, lang.spoken_y_n_flag, lang.iso_lang_cd_alpha3, lang.iso_lang_cd_part1\n"
              + "    FROM MDMR.mdm_language lang\n"
              + "    JOIN MDMR.mdm_language_trans trans\n"
              + "      ON lang.language_code = trans.language_code\n"
              + "   WHERE translation_language_code = :langId"
              + "	  AND lang.count_as_approved_y_n_flag = 'Y'"
              + "   ORDER BY trans.lang_name ";

        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("langId", langId);

        return namedTemplate.query(sql, params, (rs, rowNum) -> {
            Language language = new Language();

            language.setId(rs.getInt("language_code"));
            language.setName(rs.getString("lang_name"));
            language.setWritten("Y".equals(rs.getString("written_y_n_flag")));
            language.setSpoken("Y".equals(rs.getString("spoken_y_n_flag")));
            language.setIso2Code(rs.getString("iso_lang_cd_part1"));
            language.setIso3Code(rs.getString("iso_lang_cd_alpha3"));

            return language;
        });
    }

    private Locale determineLocale(String langCd)
    {
        String finalLangCd = langCd.contains("-") ? langCd.split("-")[0] : langCd;
        Locale result;

        Locale locale = new Locale(finalLangCd);
        if (isValidLocale(locale)) {
            result = locale;
        } else {
            LOGGER.warn(String.format("Invalid locale provided: %s. defaulting to English", langCd));
            result = new Locale("en");
        }

        return result;
    }

    private boolean isValidLocale(Locale locale)
    {
        try {
            return locale.getISO3Language() != null && locale.getISO3Country() != null;
        } catch (MissingResourceException e) {
            LOGGER.warn("Invalid locale detected returning false", e);
            return false;
        }
    }

    public Integer getLangIdFromLocale(String localeCode)
    {
        LOGGER.info(String.format("Looking up langId from localeCode %s", localeCode));
        Locale locale = determineLocale(localeCode);
        String sql = "select l.language_code from mdmr.mdm_language l where l.iso_lang_cd_alpha3 = ?";
        List<Integer> values = template.query(sql, new Object[]{locale.getISO3Language()}, (rs, rowNum) -> rs.getInt("language_code"));

        if (CollectionUtils.isEmpty(values)) {
            LOGGER.warn(String.format("No language code found for Locale: %s. Defaulting to English", locale.toString()));
            return DEFAULT_LANG_ID;
        }
        Integer value = values.get(0);
        LOGGER.info(String.format("Found langId %d for localeCode %s", value, localeCode));
        return value;
    }
}
