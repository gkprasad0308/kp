package lds.personservice.util.validation.service;

import lds.personservice.options.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public class OptionsValidationService {

    private final SourceRepository sourceRepository;
    private final AgeCategoryRepository ageCategoryRepository;
    private final ContactTypeRepository contactTypeRepository;
    private final LanguageCodeRepository languageCodeRepository;
    private final StatusRepository statusRepository;

    @Autowired
    public OptionsValidationService(
            SourceRepository sourceRepository,
            AgeCategoryRepository ageCategoryRepository,
            ContactTypeRepository contactTypeRepository,
            LanguageCodeRepository languageCodeRepository,
            StatusRepository statusRepository
    ){
        this.statusRepository = statusRepository;
        this.languageCodeRepository = languageCodeRepository;
        this.contactTypeRepository = contactTypeRepository;
        this.ageCategoryRepository = ageCategoryRepository;
        this.sourceRepository = sourceRepository;
    }

    public boolean statusExists(int statusValue) {
        return statusRepository.exists(statusValue);
    }

    public boolean ageCategoryExists(int ageCategory) {
        return ageCategoryRepository.exists(ageCategory);
    }

    public boolean contactSourceExists(int contactSource) {
        return sourceRepository.exists(contactSource);
    }

    public boolean languageExists(int langId) {
        return languageCodeRepository.exists(langId);
    }

    public boolean contactTypeExists(Integer preferredContactType) {
        return contactTypeRepository.exists(preferredContactType);
    }

    public boolean isMemberStatus(final Integer statusId) {
        if(statusId == null){
            return false;
        }

        return statusRepository.getStatusesForCategory(StatusRepository.MEMBER_CATEGORY)
                .stream().anyMatch(s -> s.getId() == statusId);
    }

    public boolean isValidDropStatus(final Integer status) {
        if(status == null || status == StatusRepository.DROP_CATEGORY){
            return false;
        }

        return statusRepository.getStatusesForCategory(StatusRepository.DROP_CATEGORY)
                .stream().anyMatch(s -> s.getId() == status);
    }
}
