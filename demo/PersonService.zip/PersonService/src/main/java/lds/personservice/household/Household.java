package lds.personservice.household;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lds.personservice.person.Person;
import lds.personservice.util.BaseAbpModel;
import lds.personservice.util.validation.annotation.*;
import lds.prsms.utils.validation.ValidationGroups.Post;
import lds.prsms.utils.validation.ValidationGroups.Put;
import lds.prsms.utils.validation.annotation.ValidGuid;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@JsonIgnoreProperties(ignoreUnknown = true)
@ValidPinDrop(groups = {Post.class, Put.class})
@ValidLatLng(groups = {Post.class, Put.class})
@ValidOrgAssignment(groups = {Post.class, Put.class})
@ValidHouseholdAssignment(groups = {Post.class, Put.class})
@ValidMemberHousehold(groups = {Post.class, Put.class})
@JsonPropertyOrder({"id", "orgId", "missionaryId", "stewardCmisId", "serverId", "deleted", "modDate", "createDate", "address", "lat", "lng", "pinDropped", "people"})
public class Household extends BaseAbpModel {
    private Long serverId;

    @ValidGuid(groups = {Post.class, Put.class})
    @JsonProperty(value = "id")
    private String guid;
    private Long orgId;
    private Long missionaryId;
    private Long stewardCmisId;

    @Size(max = 512, groups = {Post.class, Put.class})
    private String address;
    @Size(max = 32, groups = {Post.class, Put.class})
    @ValidLat(groups = {Post.class, Put.class})
    private String lat;
    @Size(max = 32, groups = {Post.class, Put.class})
    @ValidLng(groups = {Post.class, Put.class})
    private String lng;

    private Boolean pinDropped;
    @Valid
    private List<Person> people;

    public Long getServerId() {
        return serverId;
    }

    public void setServerId(Long serverId) {
        addKey("serverId", serverId);
        this.serverId = serverId;
    }

    @JsonProperty("id")
    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        addKey("guid", guid);
        this.guid = guid;
    }

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        addKey("orgId", orgId);
        this.orgId = orgId;
    }

    public Long getMissionaryId() {
        return missionaryId;
    }

    public void setMissionaryId(Long missionaryId) {
        addKey("missionaryId", missionaryId);
        this.missionaryId = missionaryId;
    }

    public Long getStewardCmisId() {
        return stewardCmisId;
    }

    public void setStewardCmisId(Long stewardCmisId) {
        addKey("stewardCmisId", stewardCmisId);
        this.stewardCmisId = stewardCmisId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        addKey("address", address);
        this.address = address;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        addKey("lat", lat);
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        addKey("lng", lng);
        this.lng = lng;
    }

    public Boolean getPinDropped() {
        return pinDropped;
    }

    public void setPinDropped(Boolean pinDropped) {
        addKey("pinDropped", pinDropped);
        this.pinDropped = pinDropped;
    }

    public List<Person> getPeople() {
        return people;
    }

    public void setPeople(List<Person> people) {
        addKey("people", people);
        this.people = people;
    }

    public void addPerson(Person person) {
        if(person != null) {
            if (people == null) {
                people = new ArrayList<>();
            }

            people.add(person);
        }
    }

    public List<Long> listProsAreaIds() {
        if(CollectionUtils.isEmpty(getPeople())){
            return new ArrayList<>();
        }
        return getPeople().stream()
                .filter(person -> person.getProsAreaId() != null)
                .map(Person::getProsAreaId)
                .collect(Collectors.toList());
    }

    public boolean hasOrgChanged(Household that){
        return that != null && isFieldPresent("orgId") && getOrgId() != null
                && !getOrgId().equals(that.getOrgId());
    }

    public boolean hasCmisIdMember(){
        boolean result = false;

        if(!CollectionUtils.isEmpty(people)){
            result = people.stream()
                    .filter(person -> person.getCmisId() != null)
                    .findFirst().orElse(null) != null;
        }

        return result;
    }

    public boolean changedToMissionary(Household original){
        return getMissionaryId() != null && original.getOrgId() != null;
    }

    public void applyHouseholdIdsAcrossPeople(){
        if(!CollectionUtils.isEmpty(people)){
            people.stream().forEach(person -> {
                person.setHouseholdId(this.getGuid());
                person.setHouseholdServerId(this.getServerId());
            });
        }
    }

    public void cleanAddress(){
        boolean hasAddress = getAddress() != null;

        if (hasAddress && (StringUtils.isEmpty(getLat()) || StringUtils.isEmpty(getLng()))) {
            setLat(null);
            setLng(null);
        }
    }
}
