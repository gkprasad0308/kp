package lds.personservice.household.search;


import lds.personservice.household.ListParams;

public interface SearchComponent {

    SearchFragment buildFragment(ListParams listParams);
}
