package lds.personservice.person;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import lds.personservice.AssignmentService;
import lds.personservice.household.Household;
import lds.personservice.household.HouseholdService;
import lds.personservice.util.ResponseWrapper;
import lds.personservice.util.validation.interfaces.PersonPost;
import lds.personservice.util.validation.interfaces.PersonPut;
import lds.prsms.utils.validation.ValidationGroups.Put;
import lds.prsms.utils.validation.ValidationGroups.Post;
import lds.stack.logging.slf4j.Logging;
import lds.stack.spring.web.Link;
import lds.stack.spring.web.ResourceDecorator;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Description;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${lds.api.resources.people.href}")
public class PersonController
{

    public static final String PERSON_ID_PATH = "/{personId}";
    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private PersonService personService;

    @Autowired
    private HouseholdService householdService;

    @Autowired
    private AssignmentService assignmentService;

    @Value("${lds.api.contextPath}/households")
    private String householdEndpoint;

    @Value("${lds.api.contextPath}/people")
    private String peopleEndpoint;


    /**
     * Attempts to get the person along with all of their details for the provided id. Also a HATEOAS link will be returned for the
     * household
     *
     * @param personGuid - id for the person to search for
     *
     * @return returns a person or null
     */
    @Description("Attempts to get the person along with all of their details for the provided id. Also a HATEOAS Link will be returned for the household")
    @RequestMapping(method = RequestMethod.GET, value = PERSON_ID_PATH, produces = "application/json")
    public Person getPersonById(@PathVariable("personId") String personGuid)
    {
        LOGGER.info(String.format("Retreiving person %s", personGuid));
        Person result = null;

        Person person = personService.getPersonDetail(personGuid);
        if (person == null) {
            LOGGER.warn(String.format("Returning null for personGuid %s", personGuid));
        } else {

            Link householdLink = new Link();
            householdLink.withHref(householdEndpoint + "/" + person.getHouseholdId());
            householdLink.setRel("household");
            result = ResourceDecorator.forResource(person).link(householdLink).decorate();
        }

        return result;
    }

    /**
     * Creates a new person with the passed in person object. The person must pass validation requirements set on the person model
     * in addition to having a householdId. If the person object passed in does not have a householdId it will return an error
     *
     * @param person - JSON for the person to be created
     *
     * @return returns the person that was created
     */
    @Description("Creates a new person with the passed in person model payload. The person payload must have a householdId")
    @RequestMapping(method = RequestMethod.POST)
    public Person createNewPerson(@Validated({Post.class, PersonPost.class}) @Valid @RequestBody Person person)
    {
        LOGGER.info("Received request to Create a new person");
        personService.createPerson(person);
        LOGGER.info(String.format("Finished request to Create new person %s", person.getGuid()));
        return person;
    }

    /**
     * Updates the passed in person object with the id passed in. This supports partial updates so long as constraints are met. In
     * addition, this may update the entire household if the persons pros area changes
     *
     * @param person     - The json object passed in to update the person
     * @param personGuid - The person id to be used to compare against and update against
     *
     * @return returns the updated person
     */
    @Description("Updates the passed in person model. The id in the path will be used as the key for the person model. The model must have a householdId.")
    @RequestMapping(method = RequestMethod.PUT, value = PERSON_ID_PATH, produces = "application/json")
    public Person updatePerson(@Validated({Put.class, PersonPut.class}) @Valid @RequestBody Person person, @PathVariable("personId") String personGuid)
    {
        LOGGER.info(String.format("Received a request to Update person %s", personGuid));

        Person original = personService.getPersonDetail(personGuid);

        if (person.hasProsAreaChanged(original)) {
            LOGGER.info(String.format("person %s assignment changed proceeding with a household update", personGuid));
            Household hshld = assignmentService.handlePersonAssignment(person, personGuid);
            householdService.updateHousehold(hshld, hshld.getGuid());
        } else {
            LOGGER.info(String.format("person %s assignment didn't change proceeding with a person update", personGuid));
            personService.updatePerson(person, personGuid);
        }

        Person result = getPersonById(personGuid);
        LOGGER.info(String.format("Finished request to Update person %s", personGuid));
        return result;
    }

    /**
     * Marks the person with this id as deleted. In addition, this will mark the household deleted if this is the only person along
     * with deleting events, tasks, commitments, etc in a likewise manner.
     * <p>
     * Does nothing if the id doesn't match a person
     *
     * @param personGuid
     */
    @Description("Deletes the person linked to the id passed in.")
    @RequestMapping(method = RequestMethod.DELETE, value = PERSON_ID_PATH, produces = "application/json")
    public void deletePerson(@PathVariable("personId") String personGuid)
    {
        LOGGER.info(String.format("Received request to Delete person %s", personGuid));
        personService.deletePerson(personGuid);
        LOGGER.info(String.format("Finshed request: Delete person %s", personGuid));
    }

    /**
     * Link Fellowshipper will create or update a fellowshipper record from the fellowshipperId passed in to the personId passed in
     *
     * @param personGuid
     * @param fellowshipperGuid
     *
     * @return
     */
    @Description("Links two people together. One as the fellowshipper, the other as the investigator ")
    @RequestMapping(method = RequestMethod.PUT, value = "/{personId}/fellowshipper/{fellowshipperId}", produces = "application/json")
    public ResponseWrapper linkFellowshipper(@PathVariable("personId") String personGuid, @PathVariable("fellowshipperId") String fellowshipperGuid)
    {
        LOGGER.info(String.format("Linking person %s to fellowshipper %s", personGuid, fellowshipperGuid));
        personService.linkFellowshipper(personGuid, fellowshipperGuid);
        LOGGER.info(String.format("Linked person %s to fellowshipper %s", personGuid, fellowshipperGuid));

        return decorateFellowshipperRequest(personGuid, fellowshipperGuid);
    }

    /**
     * unLinkFellowshipper will mark the fellowshipper row for the fellowshipperId and personId passed in. If there is no
     * relationship nothing will change.
     *
     * @param personGuid
     * @param fellowshipperGuid
     *
     * @return
     */
    @Description("UnlinkFellowshipper will mark the fellowshipper row for the providedIds. If there is no existing relationship nothing will change.")
    @RequestMapping(method = RequestMethod.DELETE, value = "/{personId}/fellowshipper/{fellowshipperId}", produces = "application/json")
    public ResponseWrapper unLinkFellowshipper(@PathVariable("personId") String personGuid, @PathVariable("fellowshipperId") String fellowshipperGuid)
    {
        LOGGER.info(String.format("Removing link between person %s and Fellowshipper %s", personGuid, fellowshipperGuid));
        personService.removeFellowshipper(personGuid, fellowshipperGuid);
        LOGGER.info(String.format("Removed link between person %s and Fellowshipper %s", personGuid, fellowshipperGuid));

        return decorateFellowshipperRequest(personGuid, fellowshipperGuid);
    }

    private ResponseWrapper decorateFellowshipperRequest(@PathVariable("personId") String personGuid, @PathVariable("fellowshipperId") String fellowshipperGuid) {
        return ResourceDecorator
              .forResource(new ResponseWrapper())
              .link(Link.toRel("person").withHref(peopleEndpoint + PERSON_ID_PATH.replace("{personId}", personGuid)))
              .link(Link.toRel("fellowshipper").withHref(peopleEndpoint + PERSON_ID_PATH.replace("{personId}", fellowshipperGuid)))
              .decorate();
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/merge/from/{fromId}/to/{toId}", produces = "application/json")
    public Person mergePerson(@PathVariable("fromId") String fromGuid, @PathVariable("toId") String toGuid)
    {
        LOGGER.info(String.format("Received request to merge person %s to person %s", fromGuid, toGuid));
        personService.merge(fromGuid, toGuid);
        Person person = getPersonById(toGuid);
        LOGGER.info("merge success");

        return person;
    }

    @Description("Calculate status endpoint currently only calculates the status by oracle server id instead of UUID. This endpoint is mostly used internally")
    @RequestMapping(method = RequestMethod.PUT, value = "/calculate/status/{id}", produces = "application/json")
    public List<Person> calculatePersonStatus(@PathVariable("id") Long id)
    {
        LOGGER.info(String.format("Received request to update status for person %d", id));
        List<Person> result = personService.calculateStatuses(Arrays.asList(id));
        LOGGER.info("re-calculate success");

        return result;
    }

    @Description("Calculate status endpoint currently only calculates the status by oracle server id instead of UUID. This endpoint is mostly used internally")
    @RequestMapping(method = RequestMethod.PUT, value = "/calculate/statuses/", produces = "application/json")
    public ResponseEntity calculatePersonStatus(@RequestBody List<Long> ids)
    {
        ResponseEntity result;
        LOGGER.info(String.format("Received request to update statuses for people %s", StringUtils.join(ids, ",")));
        try {
            result = new ResponseEntity<>(personService.calculateStatuses(ids), HttpStatus.OK);
            LOGGER.info("re-calculate success");
        } catch (Exception e) {
            LOGGER.error(String.format("Exception while attempting to calculate status for people %s", StringUtils.join(ids, ",")), e);
            result = new ResponseEntity<>("error.put.calc.statuses.failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return result;
    }
}
