package lds.personservice.config;

import lds.prsms.utils.api.ApiContext;
import lds.prsms.utils.api.utils.ResourceExtractor;
import lds.prsms.utils.config.UuidGeneratorConfig;
import lds.stack.spring.application.ServiceApplicationDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.Environment;

@Configuration
@ComponentScan("lds.prsmsutils")
@Import(UuidGeneratorConfig.class)
public class PRSMSConfiguration
{

    @Autowired
    private Environment env;

    @Autowired
    private ServiceApplicationDetails serviceApplicationDetails;

    @Bean
    public ResourceExtractor resourceExtractor(){
        return new ResourceExtractor(env);
    }

    @Bean
    public ApiContext apiContext(ResourceExtractor resourceExtractor)
    {
        return new ApiContext(resourceExtractor, serviceApplicationDetails, "lds.personservice");
    }
}
