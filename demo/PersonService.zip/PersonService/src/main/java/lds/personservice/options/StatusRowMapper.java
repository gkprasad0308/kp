package lds.personservice.options;


import lds.personservice.util.BaseRowMapper;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class StatusRowMapper extends BaseRowMapper implements RowMapper<Status> {

    public static final String STAT_ID = "person_stat_id";
    public static final String PARENT_STAT_ID = "parent_stat_id";
    public static final String TYPE_ID = "person_t_id";
    public static final String STAT_CODE = "person_stat_cd";
    public static final String DESCRIPTION = "person_stat_dscr";

    @Override
    public Status mapRow(ResultSet rs, int i) throws SQLException {
        Status status = new Status();

        status.setId(rs.getInt(STAT_ID));
        status.setParentId(extractIntegerObject(rs, PARENT_STAT_ID));
        status.setTypeId(rs.getInt(TYPE_ID));
        status.setCode(rs.getString(STAT_CODE));
        status.setName(rs.getString(DESCRIPTION));

        return status;
    }
}
