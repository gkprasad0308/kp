package lds.personservice.options;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class StatusRepository implements OptionsRepository<Status>
{
    public static final int MEMBER_CATEGORY = 8;
    public static final int DROP_CATEGORY = 5;

    @Autowired
    private JdbcTemplate template;

    @Override
    public List<Status> getOptions(int langId)
    {
        String sql = "SELECT stat.person_stat_id, stat.parent_stat_id, stat.person_t_id, stat.person_stat_cd, str.str as person_stat_dscr "
              + " FROM ims.z_person_stat stat"
              + " JOIN ims.afab_str_key strKey ON ('personStatus.' || stat.person_stat_cd) = strKey.afab_str_key"
              + " JOIN ims.afab_str str ON strKey.afab_str_key_id = str.afab_str_key_id "
              + " WHERE display_yn = 'Y' AND str.lang_id = ? AND (stat.parent_stat_id IS NULL OR stat.person_stat_id <> stat.parent_stat_id)"
              + " ORDER BY person_stat_id";
        return template.query(sql, new Object[]{langId}, new StatusRowMapper());
    }

    public boolean exists(int statusId)
    {
        String sql = "SELECT count(*) FROM ims.z_person_stat WHERE person_stat_id = ? AND (parent_stat_id IS NULL OR person_stat_id <> parent_stat_id)";
        return template.queryForObject(sql, new Object[]{statusId}, Integer.class) > 0;
    }

    public List<Status> getStatusesForCategory(int categoryId){
        String sql = "SELECT * FROM ims.z_person_stat WHERE parent_stat_id = ?";
        return template.query(sql, new Object[]{categoryId}, new StatusRowMapper());
    }
}
