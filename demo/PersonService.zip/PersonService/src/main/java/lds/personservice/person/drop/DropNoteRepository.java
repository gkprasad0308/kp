package lds.personservice.person.drop;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import lds.personservice.util.ListPartitioner;
import lds.stack.logging.jdk.Logging;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DropNoteRepository
{

    private static final Logger LOGGER = Logging.getLogger();

    @Autowired
    private NamedParameterJdbcTemplate namedTemplate;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private DropNoteSproc dropNoteSproc;

    @Autowired
    private UndoDropNoteSproc undoDropNoteSproc;

    @Autowired
    private ResetPersonSproc resetPersonSproc;

    public Long findLatestDropIdForPerson(long personId)
    {
        String sql = "select p.PERSON_STWRD_DTL_ID from PERSON_STWRD_DTL p where p.PERSON_ID = :personId and p.DEL_YN = 'N' and ROWNUM <= 1 ORDER BY p.MOD_DT DESC";
        return jdbcTemplate.queryForObject(sql, new Object[]{personId}, Long.class);
    }

    public boolean hasDropId(long personId){
        String sql = "SELECT count(*) FROM person_stwrd_dtl WHERE person_id = :personId and del_yn = 'N'";
        return jdbcTemplate.queryForObject(sql, new Object[]{personId}, Long.class) > 0;
    }

    public List<DropNote> getNotesForPerson(long personId)
    {
        String sql = "SELECT note, alert_dt, del_yn, mod_dt, client_guid FROM ims.person_stwrd_dtl WHERE person_id = :personId";
        MapSqlParameterSource params = new MapSqlParameterSource()
              .addValue("personId", personId);

        return namedTemplate.query(sql, params.getValues(), new DropNoteMapper());
    }

    public Map<Long, List<DropNote>> getNotesForPeople(List<Long> personIds)
    {
        Map<Long, List<DropNote>> dropNotes = new HashMap<>();
        List<List<Long>> partitions = new ListPartitioner<Long>().oraclePartition(personIds);
        LOGGER.info(String.format("Number of partitions for dropNotes %d", partitions.size()));

        String sql = "SELECT person_id, note, alert_dt, del_yn, mod_dt, client_guid FROM ims.person_stwrd_dtl WHERE person_id in (:personIds) ";
        Map<Long, List<DropNote>> extractedMap;
        for (List<Long> part : partitions) {
            MapSqlParameterSource params = new MapSqlParameterSource()
                  .addValue("personIds", part);

            extractedMap = namedTemplate.query(sql, params.getValues(), new DropNoteResultSetExtractor());

            dropNotes.putAll(extractedMap);
        }

        return dropNotes;
    }

    public void undoDrop(Long dropId, Date date)
    {
        undoDropNoteSproc.getStoredProc().execute(undoDropNoteSproc.getParametersUsing(dropId, date));
    }

    public void dropPerson(long personId, WritableDropNote dropNote)
    {
        dropNoteSproc.getStoredProc().execute(dropNoteSproc.getParametersUsing(personId, dropNote));
    }

    public void resetPerson(long personId, Date resetDate)
    {
        resetPersonSproc.getStoredProc().execute(resetPersonSproc.getParemetersUsing(personId, resetDate));
    }
}
