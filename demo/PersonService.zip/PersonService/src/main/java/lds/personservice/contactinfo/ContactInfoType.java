package lds.personservice.contactinfo;

public interface ContactInfoType
{

    String name();
}
