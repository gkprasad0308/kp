package lds.personservice.util;

public class ResponseWrapper
{
}
