package lds.personservice.commitment;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CommitmentRepository extends JpaRepository<Commitment, Long>
{

    @Query("select c from Commitment c where c.deleted = 'N' AND c.id = :id")
    Commitment findById(@Param("id") Long commitmentId);

    @Query("select c from Commitment c where clientGuid=:guid")
    Commitment findByClientGuid(@Param("guid") String clientGuid);

    @Query("select c from Commitment c where personId=:personId AND teachingItemId = :teachingItemId")
    Commitment findByPersonAndTeachingItem(@Param("teachingItemId") Long teachingItemId, @Param("personId") Long personId);

    @Query("select c from Commitment c where personId=:personId")
    List<Commitment> findByPerson(@Param("personId") Long personId);

    @Query("select c from Commitment c where personId IN :personIds")
    List<Commitment> findByPeople(@Param("personIds") List<Long> personIds);

}
