package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidGender;
import org.springframework.util.StringUtils;

import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class GenderValidator implements ConstraintValidator<ValidGender, String> {

    @Override
    public void initialize(ValidGender validGender) {
        // isValid does the work
    }

    @Override
    public boolean isValid(String gender, ConstraintValidatorContext constraintValidatorContext) {
        return StringUtils.isEmpty(gender) || "M".equals(gender) || "F".equals(gender);
    }
}
