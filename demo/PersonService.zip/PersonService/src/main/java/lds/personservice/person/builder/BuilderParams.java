package lds.personservice.person.builder;


import lds.personservice.household.InclusionParams;
import lds.personservice.household.ListParams;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

public class BuilderParams {

    private List<InclusionParams> inclusions;

    public BuilderParams(){
        // Default Constructor
    }

    public BuilderParams(ListParams params){
        if(params != null) {
            this.inclusions = params.getInclusions();
        }
    }

    public List<InclusionParams> getInclusions() {
        return inclusions;
    }

    public void setInclusions(List<InclusionParams> inclusions) {
        this.inclusions = inclusions;
    }

    public void setInclusions(InclusionParams[] inclusions){
        this.inclusions = Arrays.asList(inclusions);
    }

    public boolean hasInclusion(InclusionParams param){
        return !CollectionUtils.isEmpty(inclusions) && inclusions.contains(param);
    }
}
