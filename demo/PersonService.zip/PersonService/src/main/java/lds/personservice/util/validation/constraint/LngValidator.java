package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidLng;
import org.apache.commons.lang3.math.NumberUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class LngValidator implements ConstraintValidator<ValidLng, String> {

    @Override
    public void initialize(ValidLng validLng) {
        // isValid does the work
    }

    @Override
    public boolean isValid(String lng, ConstraintValidatorContext constraintValidatorContext) {
        boolean result = true;

        if(lng != null){
            Double number = NumberUtils.toDouble(lng, 99999.99999);
            result = number < 180 && number > -180;
        }

        return result;
    }
}
