package lds.personservice.person.builder;

import lds.personservice.commitment.Commitment;
import lds.personservice.commitment.CommitmentRepository;
import lds.personservice.household.InclusionParams;
import lds.personservice.person.Person;
import lds.personservice.util.ListPartitioner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class PeopleCommitmentBuilder extends AbstractConcretePeopleBuilder<Commitment> {

    @Autowired
    private CommitmentRepository repository;

    @Override
    public boolean appliesToBuilder(BuilderParams params) {
        return containsInclusion(params, InclusionParams.COMMITMENTS);
    }

    @Override
    protected void mapToPeople(List<Person> people, Map<Long, List<Commitment>> commitmentMap) {
        for (Person p : people) {
            p.setCommitments(commitmentMap.get(p.getServerId()));
        }
    }

    @Override
    protected Map<Long, List<Commitment>> getPeopleIdToTypeMap(List<Long> personIds) {
        List<List<Long>> partitions = new ListPartitioner<Long>().oraclePartition(personIds);
        List<Commitment> commitments = new LinkedList<>();
        for (List<Long> partition : partitions) {
            commitments.addAll(repository.findByPeople(partition));
        }
        return commitments.stream().collect(Collectors.groupingBy(Commitment::getPersonId));
    }
}
