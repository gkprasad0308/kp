package lds.personservice.util;


import java.util.Date;

public abstract class BaseAbpModel<T extends PartiallyUpdatableModel> extends PartiallyUpdatableModel<T> {
    protected boolean deleted = false;
    protected Date modDate;
    protected Date createDate;

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        addKey("deleted", deleted);
        this.deleted = deleted;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        addKey("modDate", modDate);
        this.modDate = modDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        addKey("createDate", createDate);
        this.createDate = createDate;
    }
}
