package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidDropStatus;
import lds.personservice.util.validation.service.OptionsValidationService;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class DropStatusValidator implements ConstraintValidator<ValidDropStatus, Integer> {

    @Inject
    private OptionsValidationService optionsValidationService;

    @Override
    public void initialize(ValidDropStatus validDropStatus) {
        // TODO consider making a call to get the Drop Statuses during initialize
    }

    @Override
    public boolean isValid(Integer dropStatus, ConstraintValidatorContext constraintValidatorContext) {
        return dropStatus != null && optionsValidationService.isValidDropStatus(dropStatus);
    }
}
