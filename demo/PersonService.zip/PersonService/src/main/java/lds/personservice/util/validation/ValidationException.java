package lds.personservice.util.validation;

import lds.prsms.utils.validation.FieldError;

public class ValidationException extends RuntimeException
{

    private static final long serialVersionUID = -8639386654641298690L;

    private final transient FieldError[] fieldErrors;

    public ValidationException(FieldError... errors)
    {
        this.fieldErrors = errors;
    }

    public FieldError[] getFieldErrors()
    {
        return fieldErrors;
    }
}
