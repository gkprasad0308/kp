package lds.personservice.household.search;


import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.util.StringUtils;

public class SearchFragment {

    private String selectFragment;
    private String fromFragment;
    private String whereFragment;
    private MapSqlParameterSource params;

    public String getSelectFragment() {
        return selectFragment;
    }

    public String getFromFragment() {
        return fromFragment;
    }

    public String getWhereFragment() {
        return whereFragment;
    }

    public MapSqlParameterSource getParams() {
        return params;
    }

    public void setParams(MapSqlParameterSource params) {
        this.params = params;
    }

    public SearchFragment withSelectFragment(String selectStatement) {
        if(!StringUtils.isEmpty(selectStatement)){
            selectFragment =selectStatement;
        }
        return this;
    }

    public SearchFragment withFromFragment(String fromFragment) {
        if(!StringUtils.isEmpty(fromFragment)){
            this.fromFragment = fromFragment;
        }
        return this;
    }

    public SearchFragment withWhereFragment(String whereFragment) {
        if(!StringUtils.isEmpty(whereFragment)){
            this.whereFragment = whereFragment;
        }
        return this;
    }

    public boolean isEmpty() {
        return StringUtils.isEmpty(selectFragment) && StringUtils.isEmpty(whereFragment) && StringUtils.isEmpty(fromFragment);
    }

    public SearchFragment addParameter(String key, Object value) {
        if(params == null){
            params = new MapSqlParameterSource();
        }
        params.addValue(key, value);
        return this;
    }
}
