package lds.personservice.person.builder;

import lds.personservice.person.Person;

import java.util.List;

public interface ConcretePeopleBuilder {

    boolean appliesToBuilder(BuilderParams params);

    List<Person> build(List<Person> people);
}
