package lds.personservice.person.builder;


import lds.personservice.household.InclusionParams;
import lds.personservice.person.Person;
import lds.personservice.person.fellowshipper.FellowshipInfo;
import lds.personservice.person.fellowshipper.FellowshipMap;
import lds.personservice.person.fellowshipper.FellowshipperRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class PeopleFellowshipBuilder implements ConcretePeopleBuilder {

    @Autowired
    private FellowshipperRepository repository;

    @Override
    public boolean appliesToBuilder(BuilderParams params) {
        return params != null && params.hasInclusion(InclusionParams.FELLOWSHIPPERS);
    }

    @Override
    public List<Person> build(List<Person> people) {
        if(!CollectionUtils.isEmpty(people)){
            List<Long> personIds = people.stream().map(Person::getServerId).collect(Collectors.toList());
            FellowshipMap fellowshipMap = repository.getFellowshipMapForPeople(personIds);
            for(Person person: people){
                FellowshipInfo info = fellowshipMap.getFellowshipInfoForPerson(person.getServerId());
                person.setFellowshipInfo(info);
            }
        }

        return people;
    }
}
