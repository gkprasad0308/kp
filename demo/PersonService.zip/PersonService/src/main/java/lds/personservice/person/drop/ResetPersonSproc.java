package lds.personservice.person.drop;

import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.sql.DataSource;

import lds.personservice.util.SimpleSproc;
import lds.prsms.utils.UUIDGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

@Component
public class ResetPersonSproc implements SimpleSproc
{

    public static final String SCHEMA_NAME = "ims";
    public static final String CATALOG_NAME = "ims_person_stat_pkg";
    public static final String FUNCTION_NAME = "reset_to_potential";
    public static final String PERSON_ID = "i_person_id";
    public static final String RESET_DT = "i_reset_dt";
    public static final String MOD_DT = "i_mod_dt";
    public static final String CLIENT_GUID = "i_client_guid";
    private final DataSource dataSource;

    @Autowired
    public ResetPersonSproc(DataSource dataSource)
    {
        this.dataSource = dataSource;
    }

    @Override
    public SimpleJdbcCall getStoredProc()
    {
        return new SimpleJdbcCall(dataSource)
              .withSchemaName(SCHEMA_NAME)
              .withCatalogName(CATALOG_NAME)
              .withFunctionName(FUNCTION_NAME)
              .declareParameters(
                    new SqlParameter(PERSON_ID, Types.NUMERIC),
                    new SqlParameter(RESET_DT, Types.DATE),
                    new SqlParameter(MOD_DT, Types.DATE),
                    new SqlParameter(CLIENT_GUID, Types.VARCHAR)
              );
    }

    public SqlParameterSource getParemetersUsing(long personId, Date resetDate)
    {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("America/Boise"));

        return new MapSqlParameterSource()
              .addValue(PERSON_ID, personId)
              .addValue(RESET_DT, resetDate)
              .addValue(MOD_DT, cal.getTime())
              .addValue(CLIENT_GUID, UUIDGenerator.getInstance().getAsString());
    }
}
