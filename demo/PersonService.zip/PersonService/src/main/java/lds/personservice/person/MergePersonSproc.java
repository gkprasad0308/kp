package lds.personservice.person;

import lds.personservice.util.SimpleSproc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Types;

@Component
public class MergePersonSproc implements SimpleSproc
{
    public static final String SCHEMA_NAME = "ims";
    public static final String CATALOG_NAME = "ims_pros_area_mgmt";
    public static final String PROCEDURE_NAME = "merge_person_rcrds";
    public static final String FROM_PERSON_ID = "i_from_person_id";
    public static final String TO_PERSON_ID = "i_to_person_id";
    private final DataSource dataSource;

    @Autowired
    public MergePersonSproc(DataSource dataSource)
    {
        this.dataSource = dataSource;
    }

    @Override
    public SimpleJdbcCall getStoredProc()
    {
        return new SimpleJdbcCall(dataSource)
              .withSchemaName(SCHEMA_NAME)
              .withCatalogName(CATALOG_NAME)
              .withProcedureName(PROCEDURE_NAME)
              .declareParameters(
                    new SqlParameter(FROM_PERSON_ID, Types.NUMERIC),
                    new SqlParameter(TO_PERSON_ID, Types.NUMERIC)
              );
    }

    public MapSqlParameterSource getParametersUsing(Long fromPersonId, Long toPersonId)
    {
        MapSqlParameterSource result = new MapSqlParameterSource();
        result.addValue(FROM_PERSON_ID, fromPersonId);
        result.addValue(TO_PERSON_ID, toPersonId);
        return result;
    }
}
