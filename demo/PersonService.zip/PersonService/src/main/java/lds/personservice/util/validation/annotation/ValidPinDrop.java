package lds.personservice.util.validation.annotation;

import lds.personservice.util.validation.constraint.PinDropValidator;
import lds.prsms.utils.api.annotations.ConstraintDescription;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PinDropValidator.class)
@ConstraintDescription("If PinDropped is set, a lat and lng must be provided")
public @interface ValidPinDrop {

    String message() default "{lds.personservice.util.validation.constraints.ValidPinDrop.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
