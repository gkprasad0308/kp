package lds.personservice.person;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import lds.personservice.BaseUpdateSql;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class PersonUpdateSql extends BaseUpdateSql
{

    public static final String FIRST_NAME = "firstName";
    public static final String LAST_NAME = "lastName";
    public static final String AGE_CAT_ID = "ageCatId";
    public static final String GENDER = "gender";
    public static final String HSHLD_ID = "hshldId";
    public static final String STATUS_ID = "statusId";
    public static final String NOTE = "note";
    public static final String FOCUS_PERSON = "focusPerson";
    public static final String CMIS_ID = "cmisId";
    public static final String CONVERT = "convert";
    public static final String SOURCE_ID = "sourceId";
    public static final String PREF_LANG_ID = "prefLangId";
    public static final String PREF_CONTACT_TYPE = "prefContactType";
    public static final String SOURCE_DTL = "sourceDtl";
    public static final String PERSON_ID = "personId";

    @Autowired
    public PersonUpdateSql(DataSource dataSource)
    {
        init(dataSource);
    }

    private void init(DataSource dataSource)
    {
        setDataSource(dataSource);
        setSql("UPDATE ims.person_mstr SET"
              + " first_nm = :" + FIRST_NAME
              + " ,last_nm = :" + LAST_NAME
              + " ,age_c_id = :" + AGE_CAT_ID
              + " ,gender = :" + GENDER
              + " ,hshld_id = :" + HSHLD_ID
              + " ,person_stat_id = :" + STATUS_ID
              + " ,mod_dt = SYSDATE"
              + " ,note = :" + NOTE
              + " ,afab_focus_person_yn = :" + FOCUS_PERSON
              + " ,cmis_id = :" + CMIS_ID
              + " ,convert_yn = :" + CONVERT
              + " ,find_id = :" + SOURCE_ID
              + " ,pref_lang_id = :" + PREF_LANG_ID
              + " ,pref_cntct_t_id = :" + PREF_CONTACT_TYPE
              + " ,find_dtl_id = :" + SOURCE_DTL
              + " WHERE person_id = :" + PERSON_ID);

        declareParameter(new SqlParameter(FIRST_NAME, Types.VARCHAR));
        declareParameter(new SqlParameter(LAST_NAME, Types.VARCHAR));
        declareParameter(new SqlParameter(AGE_CAT_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(GENDER, Types.VARCHAR));
        declareParameter(new SqlParameter(HSHLD_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(STATUS_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(NOTE, Types.VARCHAR));
        declareParameter(new SqlParameter(FOCUS_PERSON, Types.VARCHAR));
        declareParameter(new SqlParameter(CMIS_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(CONVERT, Types.VARCHAR));
        declareParameter(new SqlParameter(SOURCE_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PREF_LANG_ID, Types.NUMERIC));
        declareParameter(new SqlParameter(PREF_CONTACT_TYPE, Types.NUMERIC));
        declareParameter(new SqlParameter(SOURCE_DTL, Types.NUMERIC));
        declareParameter(new SqlParameter(PERSON_ID, Types.NUMERIC));
    }

    public Map<String, Object> getParamsUsing(Person person)
    {
        return new MapSqlParameterSource()
              .addValue(FIRST_NAME, person.getFirstName())
              .addValue(LAST_NAME, person.getLastName())
              .addValue(AGE_CAT_ID, person.getAgeCatId())
              .addValue(GENDER, person.getGender())
              .addValue(HSHLD_ID, person.getHouseholdServerId())
              .addValue(STATUS_ID, person.getStatus())
              .addValue(NOTE, person.getNote())
              .addValue(FOCUS_PERSON, parseBoolean(person.isFocusPerson()))
              .addValue(CMIS_ID, person.getCmisId())
              .addValue(CONVERT, parseBoolean(person.isConvert()))
              .addValue(SOURCE_ID, person.getContactSource())
              .addValue(PREF_LANG_ID, person.getPreferredLangId())
              .addValue(PREF_CONTACT_TYPE, person.getPreferredContactType())
              .addValue(SOURCE_DTL, person.getContactSourceDtl())
              .addValue(PERSON_ID, person.getServerId())
              .getValues();
    }
}
