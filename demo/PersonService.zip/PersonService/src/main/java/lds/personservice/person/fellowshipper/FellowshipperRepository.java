package lds.personservice.person.fellowshipper;

import java.util.Arrays;
import java.util.List;

import lds.personservice.person.Person;
import lds.personservice.util.ListPartitioner;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

@Repository
public class FellowshipperRepository
{

    private static final Logger LOGGER = Logging.getLogger();
    public static final String DELETE_FELLOWSHIPPER_LINK = "UPDATE ims.fellowshipper_mstr_uv SET del_yn = 'Y', mod_dt = SYSDATE WHERE person_id = :fellowshipperId AND ivgtr_person_id = :personId ";

    @Autowired
    private NamedParameterJdbcTemplate namedTemplate;

    @Autowired
    private FellowshipInsertSql fellowshipInsertSql;

    @Autowired
    private FellowshipUpdateSql fellowshipUpdateSql;

    public FellowshipInfo getFellowshipInfoForPerson(Long personId)
    {
        FellowshipInfo info = new FellowshipInfo();
        if (personId != null) {
            info = getFellowshipMapForPeople(Arrays.asList(personId)).getFellowshipInfoForPerson(personId);
        }
        return info;
    }

    /**
     * linkPersonToFellowshipper will either update the existing row in the DB to be non deleted, or create a new row in the DB for
     * the fellowshipper, investigator pair.
     *
     * @param person
     * @param fellowshipper
     */
    public void linkPersonToFellowshipper(Person person, Person fellowshipper)
    {
        Long personId = person.getServerId();
        Long fellowshipperId = fellowshipper.getServerId();
        if (fellowshipperHasInvestigator(personId, fellowshipperId)) {
            updateFellowshipper(personId, fellowshipperId);
        } else {
            insertFellowshipper(personId, fellowshipperId);
        }
    }

    public void insertFellowshipper(Long personId, Long fellowshipperId) {
        fellowshipInsertSql.updateByNamedParam(fellowshipInsertSql.getParamsUsing(personId, fellowshipperId));
    }

    public void updateFellowshipper(Long personId, Long fellowshipperId) {
        fellowshipUpdateSql.updateByNamedParam(fellowshipUpdateSql.getParamsUsing(personId, fellowshipperId));
    }

    private boolean fellowshipperHasInvestigator(Long personId, Long fellowshipperId)
    {
        String sql = "SELECT count(*) FROM ims.fellowshipper_mstr_uv WHERE person_id = :fellowshipperId AND ivgtr_person_id = :personId";
        return namedTemplate.queryForObject(sql, new MapSqlParameterSource().addValue("fellowshipperId", fellowshipperId).addValue("personId", personId), Integer.class) > 0;
    }

    public void removePersonToFellowshipperLink(long personId, long fellowshipperId)
    {
        namedTemplate.update(DELETE_FELLOWSHIPPER_LINK, new MapSqlParameterSource().addValue("personId", personId).addValue("fellowshipperId", fellowshipperId));
    }

    /**
     * Returns all the fellowshippers associated to the passed in person ids. This returns the fellowship record either as the
     * fellowshipper, or the fellowshippee depending on the role this person filled per row.
     *
     *
     * @param personIds
     *
     * @return
     */
    public FellowshipMap getFellowshipMapForPeople(List<Long> personIds)
    {
        FellowshipMap fellowshipMap = new FellowshipMap();
        if(!CollectionUtils.isEmpty(personIds)) {
            fellowshipMap = getFellowshipMap(personIds);
        }

        return fellowshipMap;
    }

    private FellowshipMap getFellowshipMap(List<Long> personIds) {
        FellowshipMap fellowshipMap = null;
        List<List<Long>> partitions = new ListPartitioner<Long>().oraclePartition(personIds);
        LOGGER.info(String.format("Number of partitions for fellowshipIds %d", partitions.size()));

        String sql;
        for (List<Long> parts : partitions) {
            sql = "SELECT f.person_id, f.ivgtr_person_id, p.person_id as pId, p.client_guid as pGuid, f.del_yn, p.first_nm, p.last_nm "
                    + " FROM ims.fellowshipper_mstr_uv f"
                    + " JOIN ims.person_mstr p ON f.person_id = p.person_id "
                    + " WHERE p.person_id in (:personIds) "
                    + " UNION "
                    + " SELECT f.person_id, f.ivgtr_person_id, p.person_id as pId, p.client_guid as pGuid, f.del_yn, p.first_nm, p.last_nm "
                    + " FROM ims.fellowshipper_mstr_uv f "
                    + " JOIN ims.person_mstr p ON f.ivgtr_person_id = p.person_id "
                    + " WHERE p.person_id in (:personIds) ";
            FellowshipMap subset = namedTemplate.query(sql, new MapSqlParameterSource().addValue("personIds", parts), new FellowshipperResultSetExtractor());
            if(fellowshipMap == null){
                fellowshipMap = subset;
            }
            else {
                fellowshipMap.mergeMaps(subset);
            }
        }
        return fellowshipMap;
    }
}
