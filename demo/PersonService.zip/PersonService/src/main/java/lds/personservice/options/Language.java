package lds.personservice.options;

public class Language implements Option
{

    private int id;
    private String name;
    private String iso3Code;
    private String iso2Code;
    private boolean written;
    private boolean spoken;

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getIso3Code()
    {
        return iso3Code;
    }

    public void setIso3Code(String iso3Code)
    {
        this.iso3Code = iso3Code;
    }

    public String getIso2Code()
    {
        return iso2Code;
    }

    public void setIso2Code(String iso2Code)
    {
        this.iso2Code = iso2Code;
    }

    public boolean isWritten()
    {
        return written;
    }

    public void setWritten(boolean written)
    {
        this.written = written;
    }

    public boolean isSpoken()
    {
        return spoken;
    }

    public void setSpoken(boolean spoken)
    {
        this.spoken = spoken;
    }
}
