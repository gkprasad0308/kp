package lds.personservice.contactinfo.phone;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lds.prsms.utils.validation.ValidationGroups;
import org.apache.commons.lang3.builder.CompareToBuilder;

import java.util.Objects;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Phone
{

    @NotNull(groups = {ValidationGroups.Post.class, ValidationGroups.Put.class})
    private PhoneTypes type;
    @Size(max = 32, groups = {ValidationGroups.Post.class, ValidationGroups.Put.class})
    private String number;

    public Phone()
    {
        // Default Constructor for Jackson
    }

    public Phone(PhoneTypes type, String number)
    {
        this.type = type;
        this.number = number;
    }

    public PhoneTypes getType()
    {
        return type;
    }

    @JsonDeserialize(using = PhoneDeserializer.class)
    public void setType(PhoneTypes type)
    {
        this.type = type;
    }

    public String getNumber()
    {
        return number;
    }

    public void setNumber(String number)
    {
        this.number = number;
    }

    @Override
    public int hashCode(){
        return Objects.hash(37, this.getType(), this.getNumber());
    }

    @Override
    public boolean equals(Object obj){
        if(obj == null || !(obj instanceof Phone)){
            return false;
        }
        Phone that = (Phone)obj;

        return CompareToBuilder.reflectionCompare(this, that) == 0;
    }
}
