package lds.personservice.converters;

import java.sql.Timestamp;

import javax.persistence.AttributeConverter;

/**
 * Created by Tim Jacobsen on 9/17/2015.
 * <p>
 */
public class LongToTimestampConverter implements AttributeConverter<Long, Timestamp>
{

    @Override
    public Timestamp convertToDatabaseColumn(Long value)
    {
        return value != null ? new Timestamp(value) : null;
    }

    @Override
    public Long convertToEntityAttribute(Timestamp value)
    {
        return value != null ? value.getTime() : null;
    }
}
