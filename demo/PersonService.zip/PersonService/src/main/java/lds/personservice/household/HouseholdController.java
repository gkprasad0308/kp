package lds.personservice.household;

import lds.personservice.AssignmentService;
import lds.prsms.utils.api.annotations.Description;
import lds.prsms.utils.validation.ValidationGroups;
import lds.stack.spring.web.Link;
import lds.stack.spring.web.ResourceDecorator;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.util.Objects.requireNonNull;

@RestController
@RequestMapping("${lds.api.resources.households.href}")
public class HouseholdController {

	public static final String INCLUDE_QUERY_STR = "include";

	private static final Logger LOGGER = Logger.getLogger(HouseholdController.class.getName());

	private final HouseholdService householdService;

	private final AssignmentService assignmentService;

    @Inject
	public HouseholdController(final HouseholdService householdService, final AssignmentService assignmentService) {
		this.householdService = requireNonNull(householdService, "householdService shall not be null");
		this.assignmentService = requireNonNull(assignmentService, "assignmentService shall not be null");
	}

	/**
	 * getHouseholds returns a list of households that match the provided search
	 * critera so long as there is a filter included.
	 * <p>
	 * Filters are orgId, prosAreaId, msnyId, stewardCmisId, and assignmentArea
	 * If none of these are provided then an empty list is returned
	 *
	 * @param orgId - filter by wards/missions
	 * @param prosArea - filter by prosArea assignment on person
	 * @param msnyId
	 * @param stewardCmisId - filter by the cmisId of a member
	 * missionary/steward for household
	 * @param assignmentArea - filter by a missionary assignment. This includes
	 * prosArea for missionary, missionary assigned data, companions data, and
	 * referrals (is slow)
	 * @param inclusions - list of additional data that can be returned like
	 * contactInfo, Fellowshipper Ids, and Referral Data
	 * @param modDate - Long timestamp that filter the results by those
	 * households/people modified since this time
	 * @param includeDeleted - flag that will return deleted households/people
	 *
	 * @return - Wrapper that contains a list of households
	 */
	@Description("List endpoint to get a list of households. One of the following query params must be provided: orgId, prosArea, msnyId, stewardCmisId, assignmentArea, or no data will be returned. Optional inclusions can be added through the inclusions param")
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, name = "getHouseholds")
	public HouseholdListWrapper getHouseholds(
			@RequestParam(value = "orgId", required = false) @Description("comma separated list of orgIds. Does OR based logic with prosArea, msnyId, stewardCmisId params") String orgId,
			@RequestParam(value = "prosArea", required = false) @Description("comma separated list of pros area ids. Does OR based logic with orgId, msnyId, stewardCmisId params") String prosArea,
			@RequestParam(value = "msnyId", required = false) @Description("comma separated list of missionaryIds. Does OR based logic with prosArea, orgId, stewardCmisId params") String msnyId,
			@RequestParam(value = "stewardCmisId", required = false) @Description("comma separated list of steward cmis ids. Does OR based logic with prosArea, msnyId, orgId params") String stewardCmisId,
			@RequestParam(value = "assignmentArea", required = false) @Description("exclusive query param. Returns people same way AreaBook Planner 1.X does") Long assignmentArea,
			@RequestParam(value = INCLUDE_QUERY_STR, required = false) @Description("comma separated list of inclusions. What inclusions are available are listed in the links section of the response") String inclusions,
			@RequestParam(value = "modDate", required = false) @Description("epoch timestamp to use when filtering results by modified date. "
					+ "Returns a household if the household has been modified since this param, or if any person in the household has been modified since this param") Long modDate,
			@RequestParam(value = "includeDel", required = false, defaultValue = "false") boolean includeDeleted,
            HttpServletRequest request) {
		ListParams params = new ListParams();
		params.setAssignmentArea(assignmentArea);
		params.setIncludeDeleted(includeDeleted);
		params.setInclusions(inclusions);
		params.setModDate(modDate);
		params.parseMissionaryIds(msnyId);
		params.parseOrgIds(orgId);
		params.parseProsAreas(prosArea);
		params.parseStewardCmisIds(stewardCmisId);

		LOGGER.log(Level.INFO, "getting list of households for params: {0}", params.toString());

		HouseholdListWrapper listWrapper = new HouseholdListWrapper();

		if (params.hasActionableContent()) {
			listWrapper = householdService.searchHouseholds(params);
		}

		LOGGER.info(String.format("households found %d",
				!CollectionUtils.isEmpty(listWrapper.getHouseholds()) ? listWrapper.getHouseholds().size() : 0));

		ResourceDecorator<HouseholdListWrapper> resourceDecorator = ResourceDecorator.forResource(listWrapper);
		resourceDecorator.link(buildInclusionLinks(params, request));

		return resourceDecorator.decorate();
	}

	/**
	 * Builds HATEOAS Links from the list params for the /households list
	 * endpoint. This includes appending any query params included on this
	 * request
	 *
	 * @param listParams - list of params associated with this request
	 *
	 * @return - returns a list of links with inclusion params that were not
	 * part of the request
	 */
    // TODO extract onto householdListWrapper... or somewhere else
	private List<Link> buildInclusionLinks(ListParams listParams, HttpServletRequest req) {
        String url = req.getRequestURI() + (StringUtils.isEmpty(req.getQueryString()) ? "" : "?" + req.getQueryString());
        InclusionLinksBuilder builder = new InclusionLinksBuilder()
                .withRequestUrl(url)
                .withInclusionParams(InclusionParams.getDeltas(listParams.getInclusions()));
		return builder.generate();
	}

	/**
	 * Creates a new household, and if there are any people on the household
	 * (either new or existing) it will create/update those people to link them
	 * to the new household.
	 * <p>
	 * Household and person validations will occur and errors may result
	 *
	 * @param household - the household to create any any people to be created
	 *
	 * @return returns the newly created household
	 */
	@Description("Creates a new household. If there are any people on the household payload, they will be created/updated based on the presence of that person record having an id")
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, name = "createHousehold")
	public Household createNewHousehold(@Validated(ValidationGroups.Post.class) @Valid @RequestBody Household household) {
		Household result = householdService.createNewHousehold(household);
		LOGGER.info(String.format("Created a new household %s", household.getGuid()));

		return result;
	}

	/**
	 * Attempts to get the household from the passed in id. This will contain
	 * all of the people and all of the data for a person that is optionally
	 * included.
	 *
	 * @param householdGuid - the long householdId
	 *
	 * @return returns the household
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/{householdId}", produces = MediaType.APPLICATION_JSON_VALUE, name = "manageHousehold")
	public Household getHouseholdById(@PathVariable("householdId") String householdGuid) {
		LOGGER.info(String.format("Getting household for id %s", householdGuid));
		return householdService.getHousehold(householdGuid);
	}

	/**
	 * Updates the passed in household with the provided householdId. This
	 * update will add/update people as well that are included in the payload.
	 * Additionally, this update supports partial updates based off of the
	 * provided json. If fields are not provided in the json they will not be
	 * updated
	 *
	 * @param household - The household to be updated and the people to be
	 * created/updated
	 * @param householdGuid - The id for the household to be udpated (id must
	 * exist, and overrides the payloads id)
	 *
	 * @return returns the updated household
	 */
	@Description("Updates the household using the provided id. If there are any people on the household payload, they will be created/updated based on the presence of that person record having an id")
	@RequestMapping(method = RequestMethod.PUT, value = "/{householdId}", produces = MediaType.APPLICATION_JSON_VALUE, name = "manageHousehold")
	public Household updateHousehold(@Validated(ValidationGroups.Put.class) @Valid @RequestBody Household household,
			@PathVariable("householdId") String householdGuid) {
		LOGGER.info(String.format("Received an update request for householdId %s", householdGuid));
		Household result = assignmentService.handleHouseholdAssignment(household, householdGuid);
		householdService.updateHousehold(result, householdGuid);

		LOGGER.info(String.format("Completed update for householdId %s", householdGuid));
		return householdService.getHousehold(householdGuid);
	}

	/**
	 * Marks the household for deletion based off of the provided id.
	 *
	 * @param householdGuid - id to be marked as deleted
	 *
	 * @return returns success if successful
	 */
	@RequestMapping(method = RequestMethod.DELETE, value = "/{householdId}", name = "manageHousehold")
    @ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteHousehold(@PathVariable("householdId") String householdGuid) {
		householdService.deleteHousehold(householdGuid);
	}

}
