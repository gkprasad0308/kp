package lds.personservice.options;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "z_age_c", schema = "ims")
public class AgeCategory implements Serializable, Option
{

    private static final long serialVersionUID = -8579435449243181829L;
    @Id
    @Column(name = "age_c_id")
    private int id;

    @Column(name = "age_c_cd")
    private String code;

    @Column(name = "age_c_dscr")
    private String name;

    @Override
    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getCode()
    {
        return code;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}
