package lds.personservice.missionorg;

import java.util.logging.Level;
import java.util.logging.Logger;

import lds.prsms.utils.api.healthcheck.HealthCheckBuilder;
import lds.prsms.utils.api.healthcheck.model.HealthCheck;
import lds.prsms.utils.errors.ServiceException;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

@Service
public class MissionOrgService
{

    private static final Logger LOGGER = Logger.getLogger(MissionOrgService.class.getName());

    @Value("${servicesources.mission-org-service.username}")
    private String misOrgAuthUser;

    @Value("${servicesources.mission-org-service.password}")
    private String misOrgAuthPass;

    @Value("${servicesources.mission-org-service.schema}")
    private String schema;

    @Value("${servicesources.mission-org-service.host}")
    private String host;

    @Value("${servicesources.mission-org-service.rootPath}")
    private String rootPath;

    private static final String PROS_AREA_CHILDREN = "/pros_area/{areaId}";
    private static final String ORGANIZATION_PARENTAGE = "/organization/{orgId}/parentage";

    public Entity getOrgUnitsForArea(long areaId)
    {
        HttpEntity<String> request = constructRequest();
        RestTemplate template = new RestTemplate();
        UriComponents components = UriComponentsBuilder.newInstance()
              .scheme(schema)
              .host(host)
              .path(rootPath)
              .pathSegment(PROS_AREA_CHILDREN)
              .build();
        LOGGER.info(String.format("Requesting orgUnits for area %d uri: %s", areaId, components.toUri()));

        try {
            ResponseEntity<Entity> response = template.exchange(components.toUriString(), HttpMethod.GET, request, Entity.class, areaId);

            return response.getBody();
        } catch (RestClientException e) {
            LOGGER.log(Level.SEVERE, "Failed to get children for pros area: " + areaId + " error:" + e.getMessage(), e);
            throw new ServiceException(HttpStatus.INTERNAL_SERVER_ERROR, "internal.service.failed");
        }
    }

    public ParentageWrapper getAreasForOrg(long orgId)
    {
        HttpEntity<String> request = constructRequest();
        RestTemplate template = new RestTemplate();
        UriComponents components = UriComponentsBuilder.newInstance()
              .scheme(schema)
              .host(host)
              .path(rootPath)
              .pathSegment(ORGANIZATION_PARENTAGE)
              .build();
        LOGGER.info(String.format("Requesting areas for org %d uri: %s", orgId, components.toUri()));
        try {
            ResponseEntity<ParentageWrapper> response = template.exchange(components.toUriString(), HttpMethod.GET, request, ParentageWrapper.class, orgId);
            return response.getBody();
        } catch (RestClientException e) {
            LOGGER.log(Level.SEVERE, "Failed to get parentage for orgId: " + orgId + " error:" + e.getMessage(), e);
            throw new ServiceException(HttpStatus.INTERNAL_SERVER_ERROR, "internal.service.failed");
        }
    }

    private HttpEntity<String> constructRequest()
    {
        HttpHeaders header = new HttpHeaders();
        header.add("Authorization", "Basic " + Base64.encodeBase64String((misOrgAuthUser + ":" + misOrgAuthPass).getBytes()));
        return new HttpEntity<>(header);
    }

    public HealthCheck healthCheck()
    {
        UriComponents components = UriComponentsBuilder.newInstance()
              .scheme(schema)
              .host(host)
              .path(rootPath)
              .build();
        return HealthCheckBuilder.getInstance().healthCheckEndpoint(components.toUriString(), constructRequest());
    }
}
