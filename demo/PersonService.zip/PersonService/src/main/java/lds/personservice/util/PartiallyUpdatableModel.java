package lds.personservice.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.util.CollectionUtils;

public abstract class PartiallyUpdatableModel<T extends PartiallyUpdatableModel>
{
    private static final Logger LOGGER = Logging.getLogger();

    @JsonIgnore
    protected Map<String, Object> jsonKeys;

    public void addKey(String key, Object value)
    {
        if (CollectionUtils.isEmpty(jsonKeys)) {
            jsonKeys = new HashMap<>();
        }
        jsonKeys.put(key, value);
    }

    public boolean isFieldPresent(String name)
    {
        if (CollectionUtils.isEmpty(jsonKeys)) {
            return false;
        }
        return jsonKeys.containsKey(name);
    }

    private void clearKeys(){
        LOGGER.info("Clearing json keys");
        this.jsonKeys = new HashMap<>();
    }

    public void applyChangesToThis(T otherInstance){
        try {
            this.clearKeys();
            BeanInfo beanInfo = Introspector.getBeanInfo(otherInstance.getClass());
            for(PropertyDescriptor descriptor: beanInfo.getPropertyDescriptors()){
                if(otherInstance.isFieldPresent(descriptor.getDisplayName())){
                    LOGGER.info("Applying change to field {} onto this", descriptor.getDisplayName());
                    descriptor.getWriteMethod().invoke(this, descriptor.getReadMethod().invoke(otherInstance));
                }
            }
        } catch (IntrospectionException | InvocationTargetException | IllegalAccessException ex) {
            LOGGER.error("Unexpected reflection exception applying changes", ex);
            throw new RuntimeException(ex);
        }
    }
}
