package lds.personservice.contactinfo.email;

import com.fasterxml.jackson.annotation.JsonCreator;
import lds.personservice.contactinfo.ContactInfoType;

public enum EmailTypes implements ContactInfoType
{
    EMAIL_HOME(1),
    EMAIL_FAMILY(5),
    EMAIL_WORK(3),
    EMAIL_OTHER(4);

    private final int id;

    EmailTypes(int id)
    {
        this.id = id;
    }

    @JsonCreator
    public static EmailTypes forValue(String value)
    {
        return EmailTypes.valueOf(value.toUpperCase());
    }

    public int id()
    {
        return id;
    }
}
