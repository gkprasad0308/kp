package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidPreferredLangId;
import lds.personservice.util.validation.service.OptionsValidationService;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class PreferredLanguageValidator implements ConstraintValidator<ValidPreferredLangId, Integer> {

    @Autowired
    private OptionsValidationService optionsService;

    @Override
    public void initialize(ValidPreferredLangId validPreferredLangId) {
        // TODO consider initializing the list of languages and consider checking against that list
    }

    @Override
    public boolean isValid(Integer langId, ConstraintValidatorContext constraintValidatorContext) {
        return langId == null || optionsService.languageExists(langId);
    }
}
