package lds.personservice.util.validation.constraint;

import lds.personservice.util.validation.annotation.ValidHouseholdId;
import lds.personservice.util.validation.service.HouseholdValidationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Named
public class HouseholdIdValidator implements ConstraintValidator<ValidHouseholdId, String>{

    @Autowired
    private HouseholdValidationService householdService;

    @Override
    public void initialize(ValidHouseholdId validHouseholdId) {

    }

    @Override
    public boolean isValid(String householdGuid, ConstraintValidatorContext constraintValidatorContext) {
        boolean result = true;
        if(!StringUtils.isEmpty(householdGuid)){
            result = householdService.householdExists(householdGuid);
        }

        return result;
    }
}
