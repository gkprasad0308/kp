package lds.personservice.person;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;

import lds.personservice.commitment.Commitment;
import lds.personservice.commitment.CommitmentRepository;
import lds.personservice.contactinfo.ContactInfoService;
import lds.personservice.household.Household;
import lds.personservice.household.HouseholdRepository;
import lds.personservice.person.drop.DropNoteRepository;
import lds.personservice.person.drop.WritableDropNote;
import lds.personservice.person.fellowshipper.FellowshipperRepository;
import lds.personservice.util.validation.service.OptionsValidationService;
import lds.prsms.utils.errors.ServiceException;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

@Service
@Transactional
public class PersonService
{

    private static final Logger LOGGER = Logging.getLogger();
    public static final String INVALID_PERSON_ID = "invalid.personId";

    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private FellowshipperRepository fellowshipperRepository;

    @Autowired
    private DropNoteRepository dropNoteRepository;

    @Autowired
    private HouseholdRepository householdRepository;

    @Autowired
    private CommitmentRepository commitmentRepository;

    @Autowired
    private CalcStatusSproc calcStatusSproc;

    @Autowired
    private MergePersonSproc mergeSproc;

    @Autowired
    private ContactInfoService contactInfoService;

    @Autowired
    private OptionsValidationService optionsValidationService;

    public Person getPersonDetail(String personGuid)
    {
        LOGGER.info(String.format("Getting person detail for %s", personGuid));
        Person result = null;
        if (!StringUtils.isEmpty(personGuid)) {
            result = personRepository.getPersonByGuid(personGuid);
            if (result != null) {
                Household household = householdRepository.getHouseholdById(result.getHouseholdServerId());
                if (household != null) {
                    result.setHouseholdId(household.getGuid());
                }

                LOGGER.info(String.format("Getting fellowshipInfo for person %s", personGuid));
                result.setFellowshipInfo(fellowshipperRepository.getFellowshipInfoForPerson(result.getServerId()));
                LOGGER.info(String.format("Getting dropNotes for person %s", personGuid));
                result.setDropNotes(dropNoteRepository.getNotesForPerson(result.getServerId()));

                List<Commitment> commitments = commitmentRepository.findByPerson(result.getServerId());
                if (!CollectionUtils.isEmpty(commitments)) {
                    result.setCommitments(commitments);
                }
            }
        }

        return result;
    }

    public void savePeople(List<Person> people){
        if(!CollectionUtils.isEmpty(people)) {
            for (Person person : people) {
                if (person.getGuid() != null && personRepository.personWithGuidExists(person.getGuid())) {
                    updatePerson(person, person.getGuid());
                } else {
                    createPerson(person);
                }
            }
        }
    }

    public void deletePerson(String personGuid)
    {
        LOGGER.info(String.format("deleting person %s", personGuid));
        Person original = personRepository.getPersonByGuid(personGuid);
        if (original.getCmisId() != null) {
            LOGGER.error(String.format("Person %s being deleted has a cmisId. Returning an error", personGuid));
            throw new ServiceException(HttpStatus.BAD_REQUEST, "delete.hasCmisId");
        }
        personRepository.deletePerson(original.getServerId());
    }

    public void createPerson(Person person)
    {
        Household household = householdRepository.getHouseholdByGuid(person.getHouseholdId());
        // TODO validationify
        if(!StringUtils.isEmpty(person.getGuid()) && personRepository.personWithGuidExists(person.getGuid())){
            LOGGER.error("Attempted to create a person with a duplciated guid {}", person.getGuid());
            throw new ServiceException(HttpStatus.BAD_REQUEST, "error.create.person.duplicate.guid");
        }

        person.setHouseholdServerId(household.getServerId());
        LOGGER.info("Creating person");
        personRepository.createPerson(person);
        contactInfoService.createNewContactInfo(person.getServerId(), person.getContactInfo());
    }

    public void updatePerson(Person person, String personGuid)
    {
        person.setGuid(personGuid);
        Person original = personRepository.getPersonByGuid(personGuid);
        // TODO validationIfy
        if (original.getCmisId() != null && !original.getHouseholdId().equals(person.getHouseholdId())) {
            LOGGER.warn(String.format("Tried to change the householdId from %s to %s on a person %s that has a cmisId ", original.getHouseholdId(), person.getHouseholdId(), personGuid));
            throw new ServiceException(HttpStatus.BAD_REQUEST, "invalid.hasCmisId");
        }
        if (person.getHouseholdServerId() == null) {
            person.setHouseholdServerId(householdRepository.getHouseholdByGuid(person.getHouseholdId()).getServerId());
        }

        LOGGER.info(String.format("Updating person %s", personGuid));
        original.applyChangesToThis(person);
        personRepository.updatePerson(original);
        contactInfoService.mixUpdateContactInfo(original.getServerId(), person.getContactInfo(), original.getContactInfo());
    }

    public Long getPersonIdByGuid(String guid)
    {
        Long serverId = null;

        if(personRepository.personWithGuidExists(guid)){
            serverId = personRepository.getPersonIdByGuid(guid);
        }

        return serverId;
    }

    public void linkFellowshipper(String personGuid, String fellowshipperGuid)
    {
        Person person = getPersonDetail(personGuid);
        if (person == null) {
            LOGGER.error(String.format("Couldn't link fellowshipper %s to person %s because person doesn't exist", fellowshipperGuid, fellowshipperGuid));
            throw new ServiceException(HttpStatus.BAD_REQUEST, INVALID_PERSON_ID);
        }
        Person fellowshipper = getPersonDetail(fellowshipperGuid);
        if (fellowshipper == null) {
            LOGGER.error(String.format("Couldn't link fellowshipper %s to person %s because fellowshipper doesn't exist", fellowshipperGuid, fellowshipperGuid));
            throw new ServiceException(HttpStatus.BAD_REQUEST, "invalid.fellowshipperId");
        }
        if (!optionsValidationService.isMemberStatus(fellowshipper.getStatus())) {
            LOGGER.error(String.format("Attempted to add a fellowshipper %s that has a status %d that is not a member status", fellowshipperGuid, fellowshipper.getStatus()));
            throw new ServiceException(HttpStatus.BAD_REQUEST, "invalid.fellowshipper.notMember");
        }

        fellowshipperRepository.linkPersonToFellowshipper(person, fellowshipper);
    }

    public void removeFellowshipper(String personGuid, String fellowshipperGuid)
    {
        Person person = getPersonDetail(personGuid);
        if (person == null) {
            LOGGER.error(String.format("Couldn't remove fellowshipper link for fellowshipper %s and person %s because person doesn't map to a real person", fellowshipperGuid, personGuid));
            throw new ServiceException(HttpStatus.BAD_REQUEST, INVALID_PERSON_ID);
        }
        Person fellowshipper = getPersonDetail(fellowshipperGuid);
        if (fellowshipper == null) {
            LOGGER.error(String.format("Couldn't remove fellowshipper link for fellowshipper %s and person %s because fellowshipper doesn't map to a real person", fellowshipperGuid, personGuid));
            throw new ServiceException(HttpStatus.BAD_REQUEST, "invalid.fellowshipperId");
        }

        fellowshipperRepository.removePersonToFellowshipperLink(person.getServerId(), fellowshipper.getServerId());
    }

    public void dropPerson(String personGuid, WritableDropNote dropNote)
    {
        Person person = getPersonDetail(personGuid);
        if (person == null) {
            LOGGER.info(String.format("Couldn't drop person %s because the person was not found", personGuid));
            throw new ServiceException(HttpStatus.NOT_FOUND, INVALID_PERSON_ID);
        }

        LOGGER.info(String.format("Dropping person %s", personGuid));
        dropNoteRepository.dropPerson(person.getServerId(), dropNote);
    }

    public void resetDrop(String personGuid, Date resetDate)
    {
        Person person = getPersonDetail(personGuid);
        if (person == null) {
            LOGGER.info(String.format("Couldn't reset drop of person %s because the person was not found", personGuid));
            throw new ServiceException(HttpStatus.NOT_FOUND, "invalid.person");
        }

        LOGGER.info(String.format("Resetting person %s to potential", personGuid));
        dropNoteRepository.resetPerson(person.getServerId(), resetDate);
    }

    public void undoDrop(String personGuid)
    {
        Person person = getPersonDetail(personGuid);
        if (person == null) {
            LOGGER.warn(String.format("Attemted to undo a drop for a non existant person %s", personGuid));
            return;
        }

        TimeZone tz = TimeZone.getTimeZone("America/Boise");
        Calendar c = Calendar.getInstance(tz);
        LOGGER.debug("finding the most recent drop for person: " + personGuid);
        if(dropNoteRepository.hasDropId(person.getServerId())) {
            Long l = dropNoteRepository.findLatestDropIdForPerson(person.getServerId());
            LOGGER.info("Un-Dropping note: " + l);
            dropNoteRepository.undoDrop(l, c.getTime());
            LOGGER.info("recalculating status: " + l);
            List<Long> temp = new ArrayList<>();
            temp.add(person.getServerId());
            calculateStatuses(temp).get(0);
            LOGGER.info("Note " + l + " was un-dropped");
        }
    }

    public void merge(String fromPersonGuid, String toPersonGuid)
    {
        LOGGER.debug("Merging data from person: " + fromPersonGuid + " to person: " + toPersonGuid);
        Person fromPerson = personRepository.getPersonByGuid(fromPersonGuid);
        Person toPerson = personRepository.getPersonByGuid(toPersonGuid);
        if (fromPerson == null) {
            LOGGER.warn(String.format("FromPersonId %s does not reference a person.", fromPersonGuid));
            throw new ServiceException(HttpStatus.BAD_REQUEST, "merge.fromId.notValid");
        }
        if (toPerson == null) {
            LOGGER.warn(String.format("toPersonId %s does not reference a person.", toPerson));
            throw new ServiceException(HttpStatus.BAD_REQUEST, "merge.toId.notValid");
        }
        if (fromPerson.getCmisId() != null) {
            LOGGER.error("Attempt to merge a person with a CMSID");
            throw new ServiceException(HttpStatus.BAD_REQUEST, "merge.from.has.cmsId");
        }
        SqlParameterSource params = mergeSproc.getParametersUsing(fromPerson.getServerId(), toPerson.getServerId());
        SimpleJdbcCall call = mergeSproc.getStoredProc();
        call.execute(params);

        LOGGER.info("Merge to person: " + toPersonGuid + " was a success");
    }

    public List<Person> calculateStatuses(List<Long> ids)
    {
        String idString = String.join(",", ids.stream().map(id -> id.toString()).collect(Collectors.toList()));
        LOGGER.debug("Calculating status for id(s): " + idString);
        calcStatusSproc.getStoredProc().execute(calcStatusSproc.getParametersUsing(idString));
        LOGGER.info("Calculating status for id(s): " + idString + " was a success");
        return personRepository.getPersonsByIds(ids);
    }
}
