package lds.personservice.util.validation.constraint;

import lds.personservice.household.Household;
import lds.personservice.missionorg.MissionOrgService;
import lds.personservice.missionorg.Parentage;
import lds.personservice.missionorg.ParentageWrapper;
import lds.personservice.util.validation.annotation.ValidOrgAssignment;
import lds.personservice.util.validation.service.HouseholdValidationService;
import lds.prsms.utils.errors.ServiceException;
import lds.stack.logging.slf4j.Logging;
import org.slf4j.Logger;
import org.springframework.util.CollectionUtils;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.LinkedList;
import java.util.List;

@Named
public class OrgAssignmentValidator implements ConstraintValidator<ValidOrgAssignment, Household> {

    private static final Logger LOG = Logging.getLogger();

    @Inject
    private HouseholdValidationService householdService;

    @Inject
    private MissionOrgService missionOrgService;

    @Override
    public void initialize(ValidOrgAssignment validOrgAssignment) {
        // isValid does the work
    }

    @Override
    public boolean isValid(Household household, ConstraintValidatorContext constraintValidatorContext) {
        boolean result = true;
        if(household.getOrgId() != null){
            List<Long> prosAreas = getProsAreaIds(household);
            result = CollectionUtils.isEmpty(prosAreas) || hasMatchingArea(household.getOrgId(), prosAreas);
        }

        return result;
    }

    private boolean hasMatchingArea(final Long orgId, final List<Long> personAreaIds) {
        boolean result = false;
        try {
            ParentageWrapper wrapper = missionOrgService.getAreasForOrg(orgId);
            if (wrapper != null && !CollectionUtils.isEmpty(wrapper.getParentage())) {
                List<Long> areaIds = getAreaIds(wrapper.getParentage());
                result = personAreaIds.stream()
                        .filter(id -> !areaIds.contains(id))
                        .findFirst().orElse(null) == null;
            }
        }
        catch (ServiceException ex){
            LOG.warn("encountered exception checking error in validation", ex);
        }
        return result;
    }

    private List<Long> getAreaIds(List<Parentage> parents)
    {
        List<Long> areaIds = new LinkedList<>();
        for (Parentage parent : parents) {
            if ("pros_area".equalsIgnoreCase(parent.getType())) {
                areaIds.add(parent.getId());
            } else if ("organization".equalsIgnoreCase(parent.getType()) && !CollectionUtils.isEmpty(parent.getParents())) {
                areaIds.addAll(getAreaIds(parent.getParents()));
            }
        }

        return areaIds;
    }

    private List<Long> getProsAreaIds(Household household) {
        List<Long> prosAreas = new LinkedList<>();
        Household original = householdService.getOriginal(household.getGuid());
        if(original != null) {
            prosAreas.addAll(original.listProsAreaIds());
        }
        prosAreas.addAll(household.listProsAreaIds());
        return prosAreas;
    }
}
