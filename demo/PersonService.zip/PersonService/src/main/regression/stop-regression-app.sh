ps ax | grep -i 'personservice' | grep -v grep | awk '{print $1}' | xargs kill -SIGTERM
