#!/bin/sh

restage=0;
function usage { 
	echo "Usage: $0 -e <environment> where <environment> is one of dev, test, stage, prod etc. -r (optional) restage app." 
}

NUMARGS=$#
if [ $NUMARGS -eq 0 ]; then
  usage;
  exit 1;
fi

while getopts ":e:r" opt; do
	case $opt in
		e  ) env=$OPTARG;;
		h  ) usage; exit;;
        r  ) restage=1;;
		\? ) echo "Unknown option: -$OPTARG" >&2; usage; exit 1;;
        :  ) echo "Missing option argument for -$OPTARG" >&2; usage; exit 1;;
    esac
done

case $env in
	dev  )  cf target -s missionary-services-non-prod;
            LOGLEVEL="trace"; 
            DB="a612";
            DBUSER="IMS_PTI";
            DBPASS="XpIWuGzM4R6qjktxPnXyrHRnC";
            MISORGSCHEMA="https";
            MISORGHOST="mission-org-service-v2.app-dev.lds.org";
            MISORGAUTHUSR="basic";
            MISORGAUTHPAS="HHH000397";
            MISORGROOTPATH="/mission-org-service/v2.0";
            USERNAME="basic";
            PASSWORD="HHH000397";
            ;;
            
	test )  cf target -s missionary-services-non-prod;
            LOGLEVEL="info"; 
            DB="a622";
            DBUSER="IMS_PTI";
            DBPASS="XpIWuGzM4R6qjktxPnXyrHRnC";
            MISORGSCHEMA="https";
			MISORGHOST="mission-org-service-v2.app-test.lds.org";
			MISORGAUTHUSR="basic";
			MISORGAUTHPAS="HHH000397";
			MISORGROOTPATH="/mission-org-service/v2.0";
			USERNAME="basic";
			PASSWORD="HHH000397";
            ;;
            
	stage)  cf target -s missionary-services-non-prod;
            LOGLEVEL="info"; 
            DB="a632";
            DBUSER="IMS_PTI";
            DBPASS="XpIWuGzM4R6qjktxPnXyrHRnC";
            MISORGSCHEMA="https";
			MISORGHOST="missionary-stage.ldschurch.org";
			MISORGAUTHUSR="basic";
			MISORGAUTHPAS="HHH000397";
			MISORGROOTPATH="/mission-org-service/v2.0";
			USERNAME="basic";
			PASSWORD="HHH000397";
            ;;
            
	prod ) echo "Please see your ASE"; exit 1;;
	*    ) echo "Unsupported environment"; exit 1;;
esac

cf unbind-service person-service-$env person-service-db#$env

yes | cf delete-service person-service-db#$env

cf create-oracle-service person-service-db#$env Existing -s $DB -u $DBUSER -p $DBPASS

cf bind-service person-service-$env person-service-db#$env

cf unbind-service person-service-$env person-service-config#$env

yes | cf delete-service person-service-config#$env

cf create-user-provided-service person-service-config#$env -p '{"username":"'$USERNAME'", "password":"'$PASSWORD'","schema":"'$MISORGSCHEMA'","host":"'$MISORGHOST'","basic-auth-username":"'$MISORGAUTHUSR'", "basic-auth-password":"'$MISORGAUTHPAS'", "rootPath":"'$MISORGROOTPATH'"}'

cf bind-service person-service-$env person-service-config#$env

if [ $restage -eq 1 ]; then
    cf restage person-service-$env
fi